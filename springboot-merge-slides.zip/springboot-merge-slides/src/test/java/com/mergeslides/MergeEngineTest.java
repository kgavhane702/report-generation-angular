package com.mergeslides;

import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

class MergeEngineTest {
    @TempDir Path temp;
    final PackageReader reader = TestPackages.reader();
    final PackageMergeService engine = new PackageMergeService(reader, new AtomicPackageWriter(reader));
    @Test void orderedMergeAndIndependentIdenticalThemes() throws Exception {
        Path a = TestPackages.create(temp, "a.pptx", "A", 3), b = TestPackages.create(temp, "b.pptx", "B", 2);
        var result = engine.merge(List.of(new InputSpec(a, List.of(3, 1, 3), false), new InputSpec(b, -1, false)), temp.resolve("merged.pptx"));
        var out = reader.read(result.outputPath()); assertEquals(4, result.slideCount());
        assertEquals(List.of("A3", "A1", "A3", "B2"), out.slides().stream().map(n -> Xml.findAll(Xml.parse(out.parts().get(n), n), A, "t").get(0).getTextContent()).toList());
        assertEquals(2, out.contentTypes().values().stream().filter(ContentType.THEME.mime()::equals).count());
    }
    @Test void hiddenFilteringAndAtomicFailure() throws Exception {
        Path source = TestPackages.create(temp, "a.pptx", "A", 3), output = temp.resolve("merged.pptx");
        assertEquals(2, engine.merge(List.of(new InputSpec(source, null, true)), output).slideCount()); byte[] before = Files.readAllBytes(output);
        assertThrows(MergeException.class, () -> engine.merge(List.of(new InputSpec(source, 0, false)), output)); assertArrayEquals(before, Files.readAllBytes(output));
        var broken = TestPackages.parts("Broken", 1); broken.remove("ppt/theme/theme1.xml");
        assertThrows(MergeException.class, () -> new AtomicPackageWriter(reader).write(broken, output)); assertArrayEquals(before, Files.readAllBytes(output));
        try (var paths = Files.list(temp)) { assertFalse(paths.anyMatch(p -> p.getFileName().toString().endsWith(".tmp"))); }
    }
    @Test void sourceOutputIdentityAndHardLinksAreRejected() throws Exception {
        Path source = TestPackages.create(temp, "a.pptx", "A", 1); byte[] before = Files.readAllBytes(source);
        assertThrows(MergeException.class, () -> engine.merge(List.of(new InputSpec(source)), source));
        Path link = temp.resolve("link.pptx"); Files.createLink(link, source);
        assertThrows(MergeException.class, () -> engine.merge(List.of(new InputSpec(source)), link)); assertArrayEquals(before, Files.readAllBytes(source));
    }
    @Test void repeatedMutableChartsAreSeparateAndBinaryBytesSurvive() throws Exception {
        var parts = TestPackages.parts("A", 1);
        String slideRels = new String(parts.get("ppt/slides/_rels/slide1.xml.rels"), StandardCharsets.UTF_8).replace("</Relationships>", "<Relationship Id=\"chart\" Type=\"" + R + "/chart\" Target=\"../charts/chart1.xml\"/></Relationships>");
        parts.put("ppt/slides/_rels/slide1.xml.rels", slideRels.getBytes(StandardCharsets.UTF_8));
        parts.put("ppt/charts/chart1.xml", ("<c:chartSpace xmlns:c=\"http://schemas.openxmlformats.org/drawingml/2006/chart\"/>").getBytes(StandardCharsets.UTF_8));
        String ct = new String(parts.get(TYPES), StandardCharsets.UTF_8).replace("</Types>", "<Override PartName=\"/ppt/charts/chart1.xml\" ContentType=\"" + MIME_BASE + "drawingml.chart+xml\"/></Types>"); parts.put(TYPES, ct.getBytes(StandardCharsets.UTF_8));
        Path source = TestPackages.write(temp.resolve("a.pptx"), parts);
        var out = reader.read(engine.merge(List.of(new InputSpec(source, List.of(1, 1), false)), temp.resolve("out.pptx")).outputPath());
        assertEquals(2, out.parts().keySet().stream().filter(n -> n.startsWith("ppt/charts/")).count());
    }
    @Test void xmlQNameDeclarationsAreRetainedAndEntitiesRejected() {
        String xml = "<p:sld xmlns:p=\"" + P + "\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\" xmlns:p99=\"urn:future\" mc:Ignorable=\"p99\"/>";
        var out = Xml.parse(Xml.bytes(Xml.parse(xml.getBytes(StandardCharsets.UTF_8), "test")), "serialized"); assertEquals("urn:future", out.lookupNamespaceURI("p99"));
        assertThrows(MergeException.class, () -> Xml.parse("<!DOCTYPE x [<!ENTITY x 'unsafe'>]><x>&x;</x>".getBytes(StandardCharsets.UTF_8), "dtd"));
    }
    @Test void deterministicAndConcurrentRequestsHaveNoSharedState() throws Exception {
        Path source = TestPackages.create(temp, "a.pptx", "A", 3); var pool = Executors.newFixedThreadPool(2);
        try {
            var futures = pool.invokeAll(List.of(() -> engine.merge(List.of(new InputSpec(source)), temp.resolve("one.pptx")), () -> engine.merge(List.of(new InputSpec(source)), temp.resolve("two.pptx"))));
            for (var future : futures) future.get(); assertArrayEquals(Files.readAllBytes(temp.resolve("one.pptx")), Files.readAllBytes(temp.resolve("two.pptx")));
        } finally { pool.shutdownNow(); }
    }
    @Test void sameFilenameWarningsRetainEverySourceIdentity() throws Exception {
        Path base = TestPackages.create(Files.createDirectories(temp.resolve("base")), "slide_001.pptx", "A", 1);
        var parts = TestPackages.parts("B", 1);
        String presentation = new String(parts.get(PRESENTATION), StandardCharsets.UTF_8).replace("9144000", "12800000");
        parts.put(PRESENTATION, presentation.getBytes(StandardCharsets.UTF_8));
        Path second = TestPackages.write(Files.createDirectories(temp.resolve("second")).resolve("slide_001.pptx"), parts);
        Path third = TestPackages.write(Files.createDirectories(temp.resolve("third")).resolve("slide_001.pptx"), parts);
        var result = engine.merge(List.of(new InputSpec(base), new InputSpec(second), new InputSpec(third)), temp.resolve("out.pptx"));
        assertEquals(2, result.warnings().size());
        assertTrue(result.warnings().stream().anyMatch(w -> w.contains(second.toString()) && w.contains(base.toString())));
        assertTrue(result.warnings().stream().anyMatch(w -> w.contains(third.toString()) && w.contains(base.toString())));
    }
}
