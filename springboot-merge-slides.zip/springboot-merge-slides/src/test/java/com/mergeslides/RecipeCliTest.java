package com.mergeslides;

import com.mergeslides.cli.MergeCli;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.*;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class RecipeCliTest {
    @TempDir Path temp;
    @Test void cliAcceptsV2AndLegacyAndExplicitOverwrite() throws Exception {
        TestPackages.create(temp, "input.pptx", "CLI", 4);
        Path v2 = Files.writeString(temp.resolve("v2.json"), "{\"version\":2,\"sources\":[\"input.pptx\"],\"select\":[{\"file\":\"input.pptx\",\"slides\":[2,1]}],\"options\":{\"remaining\":\"none\"}}");
        var reader = TestPackages.reader(); var cli = new MergeCli(new PackageMergeService(reader, new AtomicPackageWriter(reader)), new InputResolver(new ObjectMapper()));
        var bytes = new ByteArrayOutputStream(); var stream = new PrintStream(bytes);
        String[] args = {"-r", v2.toString(), "-o", "out.pptx"};
        assertEquals(0, cli.run(args, temp, temp, stream, stream));
        assertEquals(2, cli.run(args, temp, temp, stream, stream));
        assertEquals(0, cli.run(new String[]{"-r", v2.toString(), "-o", "out.pptx", "--overwrite"}, temp, temp, stream, stream));
        assertEquals(2, reader.read(temp.resolve("out.pptx")).slides().size());
        Files.writeString(temp.resolve("legacy.json"), "[{\"file\":\"input.pptx\",\"slides\":[3,1,3]}]");
        assertEquals(0, cli.run(new String[]{"legacy.json", "-o", "legacy.pptx"}, temp, temp, stream, stream));
        assertEquals(3, reader.read(temp.resolve("legacy.pptx")).slides().size());
    }
}
