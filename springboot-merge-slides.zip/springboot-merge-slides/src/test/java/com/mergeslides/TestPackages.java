package com.mergeslides;

import com.mergeslides.infrastructure.ooxml.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

public final class TestPackages {
    private TestPackages() {}
    public static PackageReader reader() { return new PackageReader(new PackageValidator()); }
    public static Map<String, byte[]> parts(String label, int count) {
        Map<String, byte[]> parts = new LinkedHashMap<>(); Map<String, String> types = new LinkedHashMap<>();
        StringBuilder slides = new StringBuilder(), rels = new StringBuilder();
        for (int i = 1; i <= count; i++) {
            slides.append("<p:sldId id=\"").append(255 + i).append("\" r:id=\"s").append(i).append("\"/>");
            rels.append(rel("s" + i, RelationshipType.SLIDE, "slides/slide" + i + ".xml"));
            put(parts, types, "ppt/slides/slide" + i + ".xml", "<p:sld xmlns:p=\"" + P + "\" xmlns:a=\"" + A + "\"" + (i == count ? " show=\"0\"" : "") + "><p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>" + label + i + "</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>", ContentType.SLIDE.mime());
            put(parts, types, "ppt/slides/_rels/slide" + i + ".xml.rels", relationships(rel("l", RelationshipType.SLIDE_LAYOUT, "../slideLayouts/slideLayout1.xml")), RELS_MIME);
        }
        put(parts, types, PRESENTATION, "<p:presentation xmlns:p=\"" + P + "\" xmlns:r=\"" + R + "\"><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"m\"/></p:sldMasterIdLst><p:sldIdLst>" + slides + "</p:sldIdLst><p:sldSz cx=\"9144000\" cy=\"6858000\"/></p:presentation>", ContentType.PRESENTATION.mime());
        put(parts, types, PackagePaths.rels(PRESENTATION), relationships(rel("m", RelationshipType.SLIDE_MASTER, "slideMasters/slideMaster1.xml") + rels), RELS_MIME);
        put(parts, types, ROOT_RELS, relationships(rel("r", RelationshipType.OFFICE_DOCUMENT, PRESENTATION)), RELS_MIME);
        put(parts, types, "ppt/slideMasters/slideMaster1.xml", "<p:sldMaster xmlns:p=\"" + P + "\" xmlns:r=\"" + R + "\"><p:cSld name=\"" + label + "\"/><p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"l\"/></p:sldLayoutIdLst></p:sldMaster>", ContentType.MASTER.mime());
        put(parts, types, "ppt/slideMasters/_rels/slideMaster1.xml.rels", relationships(rel("l", RelationshipType.SLIDE_LAYOUT, "../slideLayouts/slideLayout1.xml") + rel("t", RelationshipType.THEME, "../theme/theme1.xml")), RELS_MIME);
        put(parts, types, "ppt/slideLayouts/slideLayout1.xml", "<p:sldLayout xmlns:p=\"" + P + "\"><p:cSld/></p:sldLayout>", MIME_BASE + "presentationml.slideLayout+xml");
        put(parts, types, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", relationships(rel("m", RelationshipType.SLIDE_MASTER, "../slideMasters/slideMaster1.xml")), RELS_MIME);
        put(parts, types, "ppt/theme/theme1.xml", "<a:theme xmlns:a=\"" + A + "\" name=\"same\"><a:themeElements/></a:theme>", ContentType.THEME.mime());
        StringBuilder ct = new StringBuilder("<Types xmlns=\"" + CT + "\">");
        types.forEach((name, type) -> ct.append("<Override PartName=\"/").append(name).append("\" ContentType=\"").append(type).append("\"/>"));
        parts.put(TYPES, (ct + "</Types>").getBytes(StandardCharsets.UTF_8)); return parts;
    }
    public static Path write(Path file, Map<String, byte[]> parts) throws Exception {
        try (var zip = new ZipOutputStream(Files.newOutputStream(file))) { for (var p : parts.entrySet()) { zip.putNextEntry(new ZipEntry(p.getKey())); zip.write(p.getValue()); zip.closeEntry(); } }
        return file;
    }
    public static Path create(Path folder, String filename, String label, int count) throws Exception { return write(folder.resolve(filename), parts(label, count)); }
    public static String relationships(String body) { return "<Relationships xmlns=\"" + RELS + "\">" + body + "</Relationships>"; }
    public static String rel(String id, RelationshipType type, String target) { return "<Relationship Id=\"" + id + "\" Type=\"" + type.uri() + "\" Target=\"" + target + "\"/>"; }
    private static void put(Map<String, byte[]> parts, Map<String, String> types, String name, String content, String type) { parts.put(name, content.getBytes(StandardCharsets.UTF_8)); types.put(name, type); }
}
