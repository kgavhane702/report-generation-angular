package com.mergeslides;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.RecipeCodec;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

class FluentLibraryTest {
    @TempDir Path temp;
    Path a, b;
    @BeforeEach void decks() throws Exception {
        a = deck("a.pptx", Set.of(4), "Introduction", "Revenue", "Roadmap", "Revenue", null);
        b = deck("b.pptx", Set.of(), "Revenue", "Costs", "Conclusion");
    }
    MergeSlides.Builder job() { return MergeSlides.builder().baseDirectory(temp).reporter(MergeReporter.silent()); }
    List<String> rows(MergePlan plan) { return plan.slides().stream().map(s -> s.file().getFileName() + ":" + s.slideNumber()).toList(); }
    List<Integer> numbers(MergePlan plan) { return plan.slides().stream().map(PlannedSlide::slideNumber).toList(); }

    @Test void globalTitlesPreserveRequestedOrderAndAppendEverythingElse() {
        var plan = job().searchFiles(a, b).addTitles("roadmap", "REVENUE").plan();
        assertEquals(List.of("a.pptx:3", "a.pptx:2", "a.pptx:4", "b.pptx:1", "a.pptx:1", "a.pptx:5", "b.pptx:2", "b.pptx:3"), rows(plan));
        assertEquals(4, plan.summary().selectedCount()); assertEquals(4, plan.summary().remainingCount());
    }
    @Test void scopedTitlesImplicitlyRegisterOneSource() {
        assertEquals(List.of(3, 2, 1), numbers(job().addTitles(b, "Conclusion", "Costs").plan()));
    }
    @Test void whitespacePunctuationAndPartialTitlesAreNotNormalized() {
        var plan = job().searchFiles(a).addTitles("Revenue ", "Reve", "Revenue!").plan();
        assertEquals(List.of(1, 2, 3, 4, 5), numbers(plan));
        assertEquals(3, plan.diagnostics().size());
        assertTrue(plan.diagnostics().stream().allMatch(d -> d.code() == DiagnosticCode.TITLE_NOT_FOUND));
    }
    @Test void localHiddenSuppressionExclusionsAndExplicitRestoration() throws Exception {
        Path eight = deck("eight.pptx", Set.of(3, 7), "One", "Two", "Three", "Four", "Five", "Six", "Seven", null);
        var builder = job().searchFiles(eight).selectFile(eight, InputSelection.range("2-5").skipHidden()).excludeSlide(eight, 4);
        assertEquals(List.of(2, 5, 1, 6, 7, 8), numbers(builder.plan()));
        assertEquals(List.of(2, 5, 3, 1, 6, 7, 8), numbers(builder.selectFile(eight, InputSelection.slides(3, 4).skipHidden(false)).plan()));
    }
    @Test void localFalseOverridesGlobalTrueButNotHardExclusions() {
        var plan = job().searchFiles(a).skipHidden().selectFile(a, InputSelection.slides(4).skipHidden(false)).plan();
        assertEquals(List.of(4, 1, 2, 3, 5), numbers(plan));
        assertEquals(List.of(1, 2, 3, 5), numbers(job().searchFiles(a).skipHidden().selectFile(a, InputSelection.slides(4).skipHidden(false)).excludeSlide(a, 4).plan()));
    }
    @Test void firstAndLastOnlyChangeRequestedPlacement() {
        assertEquals(List.of(2, 1, 3, 4, 5), numbers(job().searchFiles(a).addTitle("Revenue").duplicateTitles(DuplicateTitlePolicy.FIRST).plan()));
        assertEquals(List.of(4, 1, 2, 3, 5), numbers(job().searchFiles(a).addTitle("Revenue").duplicateTitles(DuplicateTitlePolicy.LAST).plan()));
        var error = assertThrows(MergeException.class, () -> job().searchFiles(a).addTitle("Revenue").duplicateTitles(DuplicateTitlePolicy.ERROR).plan());
        assertEquals(DiagnosticCode.DUPLICATE_TITLE, error.failureCode());
    }
    @Test void candidateRestrictionIsFilterNotOrderingAndDoesNotRestrictRemaining() {
        assertEquals(List.of(2, 4), numbers(job().addFile(a, InputSelection.title("Revenue").within(4, 2, 2)).remainingSlides(RemainingSlides.NONE).plan()));
        assertEquals(List.of(4, 1, 2, 3, 5), numbers(job().addFile(a, InputSelection.title("Revenue").withinRange("3-5")).plan()));
        assertEquals(1, job().addFile(a, InputSelection.title("Revenue").within(List.of())).plan().diagnostics().size());
    }
    @Test void duplicateInputsBindTheirOwnSelectionsWithoutCrossProducts() {
        var plan = job().addFile(a, InputSelection.slides(1)).addFile(a, InputSelection.slides(3)).remainingSlides(RemainingSlides.NONE).plan();
        assertEquals(List.of(1, 3), numbers(plan)); assertEquals(2, plan.summary().sourceCount());
        assertEquals(10, job().addFiles(a, a).plan().slides().size());
        assertEquals(5, job().addFiles(a, a).duplicateSources(DuplicateSourcePolicy.SKIP).plan().slides().size());
    }
    @Test void repeatedSlidesAreSeparateFromDuplicateTitlePolicy() {
        assertEquals(List.of(2, 4, 2, 4), numbers(job().searchFiles(a).addTitles("Revenue", "revenue").remainingSlides(RemainingSlides.NONE).plan()));
        assertEquals(List.of(2, 4), numbers(job().searchFiles(a).addTitles("Revenue", "revenue").remainingSlides(RemainingSlides.NONE).repeatedSlides(RepeatedSlidePolicy.SKIP).plan()));
        assertEquals(DiagnosticCode.REPEATED_SLIDE, assertThrows(MergeException.class, () -> job().addFile(a, InputSelection.slides(1, 1)).repeatedSlides(RepeatedSlidePolicy.ERROR).plan()).failureCode());
    }
    @Test void intentionallySkippedSourceDoesNotGenerateMissingTitleWarning() {
        var plan = job().addFile(a, InputSelection.title("Revenue"))
                .addFile(a, InputSelection.title("missing"))
                .duplicateSources(DuplicateSourcePolicy.SKIP).onMissing(MissingTitlePolicy.ERROR)
                .remainingSlides(RemainingSlides.NONE).plan();
        assertEquals(List.of(2, 4), numbers(plan)); assertTrue(plan.diagnostics().isEmpty());
    }
    @Test void errorPoliciesAndInvalidCandidateReferencesHaveSpecificCodes() {
        assertEquals(DiagnosticCode.DUPLICATE_SOURCE, assertThrows(MergeException.class, () -> job().searchFiles(a, a).duplicateSources(DuplicateSourcePolicy.ERROR).plan()).failureCode());
        assertEquals(DiagnosticCode.INVALID_SELECTION, assertThrows(MergeException.class, () -> job().addFile(a, InputSelection.title("Revenue").within(999)).plan()).failureCode());
        assertEquals(DiagnosticCode.OUTPUT_IS_SOURCE, assertThrows(MergeException.class, () -> job().addFile(a).output(a).overwrite(true).merge()).failureCode());
    }
    @Test void structuredFailureLocationsDoNotRequireMessageParsing() {
        var missing = assertThrows(MergeException.class, () -> job().addTitle(a, "Absent title").onMissing(MissingTitlePolicy.ERROR).plan());
        var diagnostic = missing.diagnostics().get(missing.diagnostics().size() - 1);
        assertEquals(1, diagnostic.selectionIndex()); assertEquals("Absent title", diagnostic.details().get("title"));
        assertEquals(a.toString(), diagnostic.source()); assertEquals(missing.operationId(), diagnostic.operationId());
        var source = assertThrows(MergeException.class, () -> job().searchFiles(temp.resolve("absent.pptx")).plan());
        assertEquals(temp.resolve("absent.pptx").toString(), source.diagnostics().get(0).source());
    }
    @Test void completionReporterFailureIsIncludedInBothDetailedAndLegacyWarnings() {
        var report = job().addFile(b).output(temp.resolve("completion.pptx"))
                .reporter(event -> { if (event.type() == MergeEvent.Type.COMPLETED) throw new IllegalStateException("completion observer failed"); })
                .mergeDetailed();
        assertEquals(1, report.result().warnings().size());
        assertEquals(DiagnosticCode.REPORTER_FAILED, report.diagnostics().get(0).code());
    }
    @Test void remainingStartAndNoneAndNoSelectors() {
        assertEquals(List.of(1, 3, 5, 2, 4), numbers(job().searchFiles(a).addTitle("Revenue").remainingSlides(RemainingSlides.START).plan()));
        assertEquals(List.of(2, 4), numbers(job().searchFiles(a).addTitle("Revenue").remainingSlides(RemainingSlides.NONE).plan()));
        assertEquals(List.of(1, 2, 3, 4, 5), numbers(job().searchFiles(a).remainingSlides(RemainingSlides.NONE).plan()));
    }
    @Test void missingTitlesWarnForFileAndGlobalScopesAndStrictModeIsOptional() {
        var plan = job().searchFiles(a).addTitle("missing").addTitle(a, "also missing").plan();
        assertEquals(2, plan.diagnostics().size()); assertEquals(5, plan.slides().size());
        assertEquals(DiagnosticCode.TITLE_NOT_FOUND, assertThrows(MergeException.class, () -> job().addTitle(a, "missing").onMissing(MissingTitlePolicy.ERROR).plan()).failureCode());
        assertEquals(DiagnosticCode.NO_ELIGIBLE_SLIDES, assertThrows(MergeException.class, () -> job().addTitle(a, "missing").remainingSlides(RemainingSlides.NONE).plan()).failureCode());
    }
    @Test void filteredTitleExplainsWhyItHasNoEligibleMatch() {
        var plan = job().searchFiles(a).selectFile(a, InputSelection.title("Revenue").within(4).skipHidden()).plan();
        assertEquals(DiagnosticCode.TITLE_NO_ELIGIBLE_MATCH, plan.diagnostics().get(0).code());
        assertFalse(numbers(plan).contains(4));
    }
    @Test void sourceDiscoveryIsStrictEvenWithOtherValidInputs() throws Exception {
        Path empty = Files.createDirectory(temp.resolve("empty"));
        assertEquals(DiagnosticCode.DIRECTORY_EMPTY, assertThrows(MergeException.class, () -> job().searchFiles(a, empty).plan()).failureCode());
        assertEquals(DiagnosticCode.SOURCE_NOT_FOUND, assertThrows(MergeException.class, () -> job().searchFiles(a, temp.resolve("absent.pptx")).plan()).failureCode());
        Path corrupt = Files.writeString(temp.resolve("corrupt.pptx"), "not zip");
        assertEquals(DiagnosticCode.INVALID_PRESENTATION, assertThrows(MergeException.class, () -> job().searchFiles(a, corrupt).plan()).failureCode());
    }
    @Test void directoryOrderExcludesLockFilesAndDestination() throws Exception {
        Path folder = Files.createDirectory(temp.resolve("folder"));
        Files.copy(b, folder.resolve("slide10.pptx")); Files.copy(a, folder.resolve("slide2.pptx"));
        Files.writeString(folder.resolve("~$slide.pptx"), "ignored"); Files.writeString(folder.resolve("out.pptx"), "existing destination");
        var plan = job().searchDirectory(folder).output(folder.resolve("out.pptx")).plan();
        assertEquals("slide2.pptx", plan.slides().get(0).file().getFileName().toString()); assertEquals(8, plan.slides().size());
    }
    @Test void mergeCreatesValidatedOutputAndProtectsExistingDestination() throws Exception {
        Path target = temp.resolve("out.pptx");
        var report = job().searchFiles(a, b).addTitle("Revenue").output(target).mergeDetailed();
        assertEquals(8, report.result().slideCount()); assertEquals(8, TestPackages.reader().read(target).slides().size());
        byte[] before = Files.readAllBytes(target);
        assertEquals(DiagnosticCode.OUTPUT_EXISTS, assertThrows(MergeException.class, () -> job().addFile(b).output(target).merge()).failureCode());
        assertArrayEquals(before, Files.readAllBytes(target));
        assertEquals(3, job().addFile(b).output(target).overwrite(true).merge().slideCount());
    }
    @Test void corruptInputsAndEmptyResultsPreserveOutput() throws Exception {
        Path output = Files.writeString(temp.resolve("sentinel.pptx"), "preserve");
        Path bad = Files.writeString(temp.resolve("bad.pptx"), "bad");
        assertThrows(MergeException.class, () -> job().searchFiles(a, bad).output(output).overwrite(true).merge());
        assertEquals("preserve", Files.readString(output));
        assertThrows(MergeException.class, () -> job().addTitle(a, "missing").remainingSlides(RemainingSlides.NONE).output(output).overwrite(true).merge());
        assertEquals("preserve", Files.readString(output));
    }
    @Test void reporterReceivesOneWarningAndOneTerminalEventAndFailureDoesNotBreakMerge() {
        List<MergeEvent> events = new ArrayList<>();
        var report = job().reporter(events::add).operationId("application-job-1").addTitle(a, "missing").output(temp.resolve("logged.pptx")).mergeDetailed();
        assertEquals(1, events.stream().filter(e -> e.type() == MergeEvent.Type.DIAGNOSTIC).count());
        assertEquals(1, events.stream().filter(e -> e.type() == MergeEvent.Type.COMPLETED).count());
        assertEquals("application-job-1", report.operationId());
        assertEquals(1, report.result().warnings().size());
        var broken = job().reporter(e -> { throw new IllegalStateException("logger down"); }).addFile(b).output(temp.resolve("broken-log.pptx")).mergeDetailed();
        assertTrue(broken.diagnostics().stream().anyMatch(d -> d.code() == DiagnosticCode.REPORTER_FAILED));
    }
    @Test void failuresCarryOperationAndAccumulatedWarningsAndPreviewDoesNotReport() {
        List<MergeEvent> events = new ArrayList<>();
        job().reporter(events::add).addTitle(a, "missing").plan(); assertTrue(events.isEmpty());
        var error = assertThrows(MergeException.class, () -> job().reporter(events::add).operationId("failed-job")
                .addTitle(a, "missing").remainingSlides(RemainingSlides.NONE).output(temp.resolve("none.pptx")).merge());
        assertEquals("failed-job", error.operationId()); assertEquals(2, error.diagnostics().size());
        assertEquals(1, events.stream().filter(e -> e.type() == MergeEvent.Type.FAILED).count());
    }
    @Test void jsonV2AndLegacyRecipesUseTheirOwnDefaultsAndRelativePaths() throws Exception {
        Path recipe = Files.writeString(temp.resolve("recipe.json"), """
                {"version":2,"sources":["a.pptx","b.pptx"],"select":["Roadmap",{"file":"b.pptx","title":"Conclusion"}],
                 "exclude":[{"file":"a.pptx","slides":[4]}]}
                """);
        assertEquals(List.of("a.pptx:3", "b.pptx:3", "a.pptx:1", "a.pptx:2", "a.pptx:5", "b.pptx:1", "b.pptx:2"), rows(job().addRecipe(recipe).plan()));
        Path legacy = Files.writeString(temp.resolve("legacy.json"), "\uFEFF[{\"file\":\"a.pptx\",\"slides\":[3,1,3]}]");
        assertEquals(List.of(3, 1, 3), numbers(job().addRecipe(legacy).plan()));
    }
    @Test void strictCodecRejectsAmbiguousAndUnknownOptions() {
        var codec = new RecipeCodec();
        for (String json : List.of("{\"version\":2,\"options\":{\"title_match\":\"contains\"}}", "{\"version\":2,\"select\":[{\"title\":\"a\",\"titles\":[\"b\"]}]}", "{\"version\":2,\"options\":{\"skip_hidden\":\"true\"}}"))
            assertThrows(MergeException.class, () -> codec.decode(codec.parse(json), temp));
        assertThrows(MergeException.class, () -> codec.parse("{\"version\":2,\"version\":2}"));
    }
    @Test void recipesRemainOrderedAndOuterHardExclusionsApplyToRecipeOnlySources() throws Exception {
        Path recipe = Files.writeString(temp.resolve("chunk.json"), "[{\"file\":\"a.pptx\",\"slides\":[3,1,3]}]");
        var plan = job().addRecipe(recipe).addFile(b, InputSelection.slides(2))
                .excludeSlide(a, 3).remainingSlides(RemainingSlides.NONE).plan();
        assertEquals(List.of("a.pptx:1", "b.pptx:2"), rows(plan));
    }
    @Test void callerCollectionsAreCopiedAndNoArbitraryBodyTextIsTreatedAsTitle() throws Exception {
        List<Integer> indices = new ArrayList<>(List.of(2)); InputSelection selection = InputSelection.slides(indices); indices.set(0, 3);
        assertEquals(List.of(2), numbers(job().addFile(a, selection).remainingSlides(RemainingSlides.NONE).plan()));
        Path body = TestPackages.create(temp, "body.pptx", "Revenue", 2);
        var plan = job().searchFiles(body).addTitle("Revenue1").plan();
        assertEquals(DiagnosticCode.TITLE_NOT_FOUND, plan.diagnostics().get(0).code()); assertNull(plan.slides().get(0).title());
    }
    @Test void splitRunsPreserveExactTextAndLayoutCanIdentifyTitle() throws Exception {
        var parts = TestPackages.parts("X", 1);
        String slide = slide("Annual Revenue", false).replace("<p:ph type=\"title\"/>", "<p:ph idx=\"7\"/>")
                .replace("Annual Revenue", "Annual </a:t></a:r><a:r><a:t>Revenue");
        parts.put("ppt/slides/slide1.xml", slide.getBytes(StandardCharsets.UTF_8));
        parts.put("ppt/slideLayouts/slideLayout1.xml", ("<p:sldLayout xmlns:p=\"" + com.mergeslides.infrastructure.ooxml.Ooxml.P + "\"><p:cSld><p:spTree><p:sp><p:nvSpPr><p:nvPr><p:ph type=\"title\" idx=\"7\"/></p:nvPr></p:nvSpPr></p:sp></p:spTree></p:cSld></p:sldLayout>").getBytes(StandardCharsets.UTF_8));
        Path file = TestPackages.write(temp.resolve("inherited.pptx"), parts);
        var plan = job().addTitle(file, "ANNUAL REVENUE").remainingSlides(RemainingSlides.NONE).plan();
        assertEquals("Annual Revenue", plan.slides().get(0).title());
    }
    @Test void createOnlyCommitHasExactlyOneWinnerAcrossConcurrentExecutions() throws Exception {
        Path output = temp.resolve("race.pptx"); ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            List<Callable<Object>> actions = List.of(() -> attempt(output), () -> attempt(output));
            List<Object> results = new ArrayList<>(); for (Future<Object> future : pool.invokeAll(actions)) results.add(future.get());
            assertEquals(1, results.stream().filter(MergeResult.class::isInstance).count());
            assertEquals(1, results.stream().filter(x -> x == DiagnosticCode.OUTPUT_EXISTS).count());
            assertEquals(3, TestPackages.reader().read(output).slides().size());
        } finally { pool.shutdownNow(); }
    }
    Object attempt(Path output) { try { return job().addFile(b).output(output).merge(); } catch (MergeException e) { return e.failureCode(); } }
    Path deck(String name, Set<Integer> hidden, String... values) throws Exception {
        var parts = TestPackages.parts(name, values.length);
        for (int i = 0; i < values.length; i++) parts.put("ppt/slides/slide" + (i + 1) + ".xml", slide(values[i], hidden.contains(i + 1)).getBytes(StandardCharsets.UTF_8));
        return TestPackages.write(temp.resolve(name), parts);
    }
    String slide(String title, boolean hidden) {
        String p = com.mergeslides.infrastructure.ooxml.Ooxml.P, a = com.mergeslides.infrastructure.ooxml.Ooxml.A;
        String shape = title == null ? "" : "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title\"/><p:cNvSpPr/><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:t>" + title.replace("&", "&amp;").replace("<", "&lt;") + "</a:t></a:r></a:p></p:txBody></p:sp>";
        return "<p:sld xmlns:p=\"" + p + "\" xmlns:a=\"" + a + "\"" + (hidden ? " show=\"0\"" : "") + "><p:cSld><p:spTree>" + shape + "</p:spTree></p:cSld></p:sld>";
    }
}
