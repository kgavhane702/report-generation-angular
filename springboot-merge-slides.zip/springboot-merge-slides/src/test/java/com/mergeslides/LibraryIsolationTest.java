package com.mergeslides;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.JarFile;
import static org.junit.jupiter.api.Assertions.*;

class LibraryIsolationTest {
    @TempDir Path temp;
    @Test void publishedJarRunsWithOnlyJdkAndDeclaredJacksonDependencies() throws Exception {
        Path jar = Path.of(System.getProperty("merge.library.jar"));
        try (var archive = new JarFile(jar.toFile())) {
            assertFalse(archive.stream().anyMatch(e -> e.getName().contains("/MergeController") || e.getName().contains("/config/") || e.getName().startsWith("BOOT-INF/")));
        }
        List<URL> urls = new ArrayList<>(); urls.add(jar.toUri().toURL());
        for (String dependency : System.getProperty("merge.library.dependencies").split(java.util.regex.Pattern.quote(java.io.File.pathSeparator)))
            urls.add(Path.of(dependency).toUri().toURL());
        Path input = TestPackages.create(temp, "input.pptx", "Standalone", 3);
        Path recipe = Files.writeString(temp.resolve("recipe.json"), "{\"version\":2,\"sources\":[\"input.pptx\"],\"select\":[{\"file\":\"input.pptx\",\"slides\":[2,1]}],\"options\":{\"remaining\":\"none\"}}");
        try (var loader = new URLClassLoader(urls.toArray(URL[]::new), ClassLoader.getPlatformClassLoader())) {
            assertThrows(ClassNotFoundException.class, () -> loader.loadClass("org.springframework.context.ApplicationContext"));
            Class<?> facade = loader.loadClass("com.mergeslides.api.lib.MergeSlides");
            Object builder = facade.getMethod("builder").invoke(null);
            Class<?> type = builder.getClass();
            type.getMethod("addRecipe", Path.class).invoke(builder, recipe);
            type.getMethod("output", Path.class).invoke(builder, temp.resolve("out.pptx"));
            Class<?> reporter = loader.loadClass("com.mergeslides.api.lib.MergeReporter");
            type.getMethod("reporter", reporter).invoke(builder, reporter.getMethod("silent").invoke(null));
            Object result = type.getMethod("merge").invoke(builder);
            assertEquals(2, result.getClass().getMethod("slideCount").invoke(result));
            assertEquals(2, TestPackages.reader().read(temp.resolve("out.pptx")).slides().size());
            assertTrue(Files.exists(input));
        }
    }
}
