package com.mergeslides;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.*;
import com.mergeslides.infrastructure.ooxml.PackagePaths;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class SelectionAndInputTest {
    @TempDir Path temp;
    final InputResolver resolver = new InputResolver(new ObjectMapper());
    @Test void selectionsRetainOrderAndDuplicates() { assertEquals(List.of(2, 0, 2, 3, 4), SlideSelector.select(List.of(3, 1, "3-5"), 5)); }
    @Test void negativesDifferFromOpenRangeStrings() { assertEquals(List.of(4), SlideSelector.select(-1, 5)); assertEquals(List.of(0, 1, 2), SlideSelector.select("-3", 5)); }
    @Test void rangesClampAndDescendingIsEmpty() { assertEquals(List.of(3, 4), SlideSelector.select("4-999", 5)); assertEquals(List.of(), SlideSelector.select("5-2", 5)); }
    @Test void sliceBoundsMatchPython() {
        assertEquals(List.of(4, 3, 2, 1, 0), SlideSelector.select(new SlideSlice(null, null, -1), 5));
        assertEquals(List.of(4, 3, 2, 1), SlideSelector.select(new SlideSlice(-1, -5, -1), 5));
        assertEquals(List.of(), SlideSelector.select(new SlideSlice(null, -1, -1), 5));
        assertEquals(List.of(0, 2, 4), SlideSelector.select(Map.of("slice", Map.of("stop", 5, "step", 2)), 10));
    }
    @Test void invalidSelectionsFail() { for (Object value : List.of(0, 7, true, 1.5, "--2", new SlideSlice(null, null, 0))) assertThrows(MergeException.class, () -> SlideSelector.select(value, 5)); }
    @Test void dictionaryFallbackDoesNotAffectTupleSelections() {
        assertNull(resolver.normalize(Map.of("file", "a.pptx", "slides", List.of()), temp).slides());
        assertEquals(List.of(), resolver.normalize(List.of("a.pptx", List.of()), temp).slides());
        assertEquals(0, resolver.normalize(List.of("a.pptx", 0), temp).slides());
        assertEquals("2", resolver.normalize(Map.of("path", "a.pptx", "slides", false, "range", "2"), temp).slides());
    }
    @Test void recipeBomAndOwnDirectoryWork() throws Exception {
        Path recipe = temp.resolve("recipe.json"); Files.writeString(recipe, "\uFEFF[{\"path\":\"deck.pptx\",\"range\":\"3,1\",\"skip_hidden\":true}]");
        assertEquals(temp.resolve("deck.pptx"), resolver.recipe(recipe).get(0).file()); assertTrue(resolver.recipe(recipe).get(0).skipHidden());
    }
    @Test void folderSortSkipsLockAndDestination() throws Exception {
        for (String name : List.of("slide10.PPTX", "slide2.pptx", "slide1.pptx", "~$lock.pptx", "output.pptx")) Files.write(temp.resolve(name), new byte[0]);
        assertEquals(List.of("slide1.pptx", "slide2.pptx", "slide10.PPTX"), resolver.folder(temp, temp.resolve("output.pptx")).stream().map(p -> p.getFileName().toString()).toList());
    }
    @Test void relativeWindowsRecipeSeparatorsArePortable() {
        assertEquals(temp.resolve("nested/deck.pptx"), resolver.normalize(Map.of("file", "nested\\deck.pptx"), temp).file());
    }
    @Test void uriResolutionRetainsEscapesAndFragments() {
        assertEquals("ppt/media/a b+z.png", PackagePaths.resolve("ppt/slides/slide1.xml", "../media/a%20b+z.png#view"));
        assertEquals("../media/a%20b%2Bz.png#view", PackagePaths.relative("ppt/slides/slide1.xml", "ppt/media/a b+z.png", "old#view"));
        assertThrows(MergeException.class, () -> PackagePaths.resolve("ppt/presentation.xml", "../../secret"));
    }
}
