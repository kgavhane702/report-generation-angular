package com.mergeslides.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.application.MergeService;
import com.mergeslides.application.UploadMergeService;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import java.nio.file.Path;

@Configuration(proxyBeanMethods = false)
public class MergeConfiguration {
    @Bean public PackageValidator packageValidator() { return new PackageValidator(); }
    @Bean public PackageReader packageReader(PackageValidator validator) { return new PackageReader(validator); }
    @Bean public AtomicPackageWriter packageWriter(PackageReader reader) { return new AtomicPackageWriter(reader); }
    @Bean public MergeService mergeService(PackageReader reader, AtomicPackageWriter writer) { return new PackageMergeService(reader, writer); }
    @Bean public InputResolver inputResolver(ObjectMapper mapper) { return new InputResolver(mapper); }
    @Bean public UploadMergeService uploadMergeService(MergeService service, InputResolver resolver, ObjectMapper mapper, @Value("${merge.temp-directory}") String temp) {
        return new UploadMergeService(service, resolver, mapper, Path.of(temp));
    }
}
