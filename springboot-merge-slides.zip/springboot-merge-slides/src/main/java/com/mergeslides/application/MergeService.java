package com.mergeslides.application;

import com.mergeslides.domain.*;
import java.nio.file.Path;
import java.util.List;

public interface MergeService {
    MergeResult merge(List<InputSpec> inputs, Path output);
}
