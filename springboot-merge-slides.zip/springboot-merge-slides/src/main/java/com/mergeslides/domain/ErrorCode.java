package com.mergeslides.domain;

public enum ErrorCode {
    INVALID_REQUEST, INVALID_PRESENTATION, INPUT_NOT_FOUND, IO_FAILURE
}
