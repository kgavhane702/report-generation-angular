package com.mergeslides.domain;

import java.util.*;
import java.util.regex.Pattern;

public final class SlideSelector {
    private static final Pattern RANGE = Pattern.compile("(\\d*)\\s*-\\s*(\\d*)");
    private SlideSelector() {}

    public static List<Integer> select(Object value, int total) {
        List<Integer> result = new ArrayList<>();
        if (value == null || "all".equals(value) || "*".equals(value)) {
            for (int i = 0; i < total; i++) result.add(i);
        } else if (value instanceof SlideSlice slice) {
            long step = slice.step() == null ? 1 : slice.step();
            if (step == 0) throw MergeException.invalid("Slice step cannot be zero.");
            long start = bound(slice.start(), total, step, true);
            long stop = bound(slice.stop(), total, step, false);
            for (long i = start; step > 0 ? i < stop : i > stop; i += step) result.add((int) i);
        } else if (value instanceof Byte || value instanceof Short || value instanceof Integer || value instanceof Long || value instanceof java.math.BigInteger) {
            long n;
            try { n = Long.parseLong(value.toString()); } catch (NumberFormatException e) { throw MergeException.invalid("Slide index is out of range: " + value); }
            long index = n > 0 ? n - 1 : total + n;
            if (n == 0 || index < 0 || index >= total) throw MergeException.invalid("Slide index " + n + " out of range for presentation with " + total + " slides.");
            result.add((int) index);
        } else if (value instanceof List<?> items) {
            for (Object item : items) result.addAll(select(item, total));
        } else if (value instanceof Map<?, ?> map && map.get("slice") instanceof Map<?, ?> slice) {
            result.addAll(select(new SlideSlice(integer(slice.get("start")), integer(slice.get("stop")), integer(slice.get("step"))), total));
        } else if (value instanceof String text) {
            for (String token : text.split(",", -1)) {
                token = token.strip();
                if (token.isEmpty()) continue;
                try {
                    if (token.contains("-")) {
                        var m = RANGE.matcher(token);
                        if (!m.matches() || (m.group(1).isEmpty() && m.group(2).isEmpty())) throw MergeException.invalid("Invalid slide range: " + token);
                        long first = m.group(1).isEmpty() ? 0 : Long.parseLong(m.group(1)) - 1;
                        long last = m.group(2).isEmpty() ? total : Long.parseLong(m.group(2));
                        for (int i = (int) Math.max(0, Math.min(first, total)); i < Math.max(0, Math.min(last, total)); i++) result.add(i);
                    } else result.addAll(select(Long.parseLong(token), total));
                } catch (NumberFormatException e) { throw MergeException.invalid("Invalid slide selection: " + token); }
            }
        } else throw MergeException.invalid("Unsupported slide selection: " + value);
        return result;
    }

    private static Integer integer(Object n) {
        if (n == null) return null;
        if (!(n instanceof Integer || n instanceof Long)) throw MergeException.invalid("Slice bounds must be integers.");
        try { return Math.toIntExact(((Number) n).longValue()); } catch (ArithmeticException e) { throw MergeException.invalid("Slice bound is out of range."); }
    }
    private static long bound(Integer n, int total, long step, boolean start) {
        if (n == null) return step > 0 ? (start ? 0 : total) : (start ? total - 1L : -1);
        long i = n;
        if (i < 0) i += total;
        return step > 0 ? Math.max(0, Math.min(i, total)) : Math.max(-1, Math.min(i, total - 1L));
    }
}
