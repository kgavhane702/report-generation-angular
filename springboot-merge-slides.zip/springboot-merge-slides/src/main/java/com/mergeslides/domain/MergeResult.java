package com.mergeslides.domain;

import java.nio.file.Path;
import java.util.List;

public record MergeResult(Path outputPath, int slideCount, List<String> warnings, long elapsedMillis) {
    public MergeResult { warnings = List.copyOf(warnings); }
}
