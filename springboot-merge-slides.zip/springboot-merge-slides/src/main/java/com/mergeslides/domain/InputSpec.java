package com.mergeslides.domain;

import java.nio.file.Path;

/** Selection may be null, a number, a range string, a list, or a SlideSlice. */
public record InputSpec(Path file, Object slides, boolean skipHidden) {
    public InputSpec { if (file == null) throw MergeException.invalid("Input path cannot be null."); }
    public InputSpec(Path file) { this(file, null, false); }
}
