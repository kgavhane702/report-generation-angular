package com.mergeslides.cli;

import com.mergeslides.application.MergeService;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.Ooxml;
import java.nio.file.*;
import java.io.PrintStream;
import java.util.*;
import com.mergeslides.api.lib.*;

public final class MergeCli {
    private final MergeService service;
    private final InputResolver resolver;
    public MergeCli(MergeService service, InputResolver resolver) { this.service = service; this.resolver = resolver; }
    public int run(String[] args, Path cwd, Path workspace, PrintStream out, PrintStream err) {
        try {
            List<String> positional = new ArrayList<>(), explicit = null; String dir = null, recipe = null, output = Ooxml.DEFAULT_OUTPUT;
            Boolean overwrite = null;
            int modes = 0;
            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                if (arg.equals("--overwrite")) { overwrite = true; continue; }
                if (arg.equals("--no-overwrite")) { overwrite = false; continue; }
                if (arg.equals("--help") || arg.equals("-h")) { out.println("Usage: java -jar merge-slides.jar merge [INPUTS | -i INPUTS... | -d DIR | -r RECIPE] [-o OUTPUT.pptx]\nAliases: --inputs, --dir, --recipe/--config/-c, --output. Folder order is natural; explicit order is retained."); return 0; }
                if (arg.equals("-i") || arg.equals("--inputs")) {
                    modes++; explicit = new ArrayList<>();
                    while (i + 1 < args.length && !args[i + 1].startsWith("-")) explicit.add(args[++i]);
                    if (explicit.isEmpty()) throw MergeException.invalid("--inputs requires at least one input.");
                } else if (Set.of("-d", "--dir", "-r", "-c", "--recipe", "--config", "-o", "--output").contains(arg)) {
                    if (++i >= args.length) throw MergeException.invalid("Missing value for " + arg);
                    if (arg.equals("-o") || arg.equals("--output")) output = args[i];
                    else { modes++; if (arg.equals("-d") || arg.equals("--dir")) dir = args[i]; else recipe = args[i]; }
                } else if (arg.startsWith("-")) throw MergeException.invalid("Unknown option: " + arg);
                else positional.add(arg);
            }
            if (modes > 1 || modes > 0 && !positional.isEmpty()) throw MergeException.invalid("Use positional inputs or one of --inputs/--dir/--recipe, not both.");
            Path target = cwd.resolve(output).toAbsolutePath().normalize(); Object input;
            if (recipe != null) input = recipe;
            else if (explicit != null) input = explicit;
            else if (!positional.isEmpty()) input = positional;
            else if (dir != null) input = resolver.folder(cwd.resolve(dir), target);
            else { Path defaults = workspace.resolve(Ooxml.DEFAULT_INPUT); input = resolver.folder(Files.exists(defaults) ? defaults : workspace, target); }
            MergeResult result;
            if (input instanceof String text && text.toLowerCase(Locale.ROOT).endsWith(".json")) {
                var builder = MergeSlides.builder().baseDirectory(cwd).addRecipe(Path.of(text)).output(target)
                        .reporter(event -> { if (event.severity() == Severity.WARN) err.println("[WARNING] " + event.message()); });
                if (overwrite != null) builder.overwrite(overwrite);
                result = builder.merge();
            } else {
                List<?> items = input instanceof List<?> list ? list : List.of(input);
                if (overwrite != null || items.stream().anyMatch(item -> item instanceof String s && s.toLowerCase(Locale.ROOT).endsWith(".json"))) {
                    var builder = MergeSlides.builder().baseDirectory(cwd).remainingSlides(RemainingSlides.NONE).overwrite(overwrite == null || overwrite)
                            .output(target).reporter(event -> { if (event.severity() == Severity.WARN) err.println("[WARNING] " + event.message()); });
                    for (Object item : items) {
                        if (item instanceof String s && s.toLowerCase(Locale.ROOT).endsWith(".json")) builder.addRecipe(Path.of(s));
                        else { var spec = resolver.normalize(item, cwd); builder.addFile(spec.file(), InputSelection.numeric(spec.slides()).skipHidden(spec.skipHidden())); }
                    }
                    result = builder.merge();
                } else {
                    result = service.merge(resolver.resolve(input, cwd, target), target);
                    for (String warning : result.warnings()) err.println("[WARNING] " + warning);
                }
            }
            out.println("[SUCCESS] Merged presentation created: " + result.outputPath()); out.println("[SUCCESS] Total slides merged: " + result.slideCount());
            return 0;
        } catch (MergeException | InvalidPathException e) { err.println("[ERROR] " + e.getMessage()); return 2; }
    }
}
