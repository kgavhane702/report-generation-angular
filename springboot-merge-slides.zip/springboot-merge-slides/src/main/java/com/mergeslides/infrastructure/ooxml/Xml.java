package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.*;

/** Namespace-aware DOM retains declarations used only by mc:Ignorable and QName values. */
public final class Xml {
    private Xml() {}
    private static final ThreadLocal<DocumentBuilder> READERS = ThreadLocal.withInitial(() -> {
        try {
            var f = DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(true);
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setFeature("http://xml.org/sax/features/external-general-entities", false);
            f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            var b = f.newDocumentBuilder();
            b.setErrorHandler(new ErrorHandler() {
                public void warning(SAXParseException e) throws SAXException { throw e; }
                public void error(SAXParseException e) throws SAXException { throw e; }
                public void fatalError(SAXParseException e) throws SAXException { throw e; }
            });
            return b;
        } catch (Exception e) { throw new IllegalStateException("Cannot configure XML reader", e); }
    });
    private static final ThreadLocal<Transformer> WRITERS = ThreadLocal.withInitial(() -> {
        try {
            var f = TransformerFactory.newInstance();
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            var t = f.newTransformer();
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            t.setOutputProperty(OutputKeys.INDENT, "no");
            return t;
        } catch (Exception e) { throw new IllegalStateException("Cannot configure XML writer", e); }
    });
    public static Element parse(byte[] data, String label) {
        try { return READERS.get().parse(new ByteArrayInputStream(data)).getDocumentElement(); }
        catch (Exception e) { throw new MergeException(ErrorCode.INVALID_PRESENTATION, "Invalid XML in " + label + ": " + e.getMessage(), e); }
    }
    public static byte[] bytes(Element root) {
        try {
            var out = new ByteArrayOutputStream();
            WRITERS.get().transform(new DOMSource(root), new StreamResult(out));
            return out.toByteArray();
        } catch (TransformerException e) { throw new MergeException(ErrorCode.INVALID_PRESENTATION, "Cannot serialize XML", e); }
    }
    public static Element root(String ns, String local) {
        var doc = READERS.get().newDocument();
        var root = doc.createElementNS(ns, qualified(ns, local));
        doc.appendChild(root);
        return root;
    }
    public static Element add(Element parent, String ns, String local) {
        var child = parent.getOwnerDocument().createElementNS(ns, qualified(ns, local));
        parent.appendChild(child);
        return child;
    }
    private static String qualified(String ns, String local) {
        return (Ooxml.P.equals(ns) ? "p:" : Ooxml.A.equals(ns) ? "a:" : Ooxml.P14.equals(ns) ? "p14:" : "") + local;
    }
    public static void rid(Element e, String id) { e.setAttributeNS(Ooxml.R, "r:id", id); }
    public static String rid(Element e) { return e.getAttributeNS(Ooxml.R, "id"); }
    public static boolean is(Element e, String ns, String local) { return ns.equals(e.getNamespaceURI()) && local.equals(e.getLocalName()); }
    public static List<Element> children(Element e) {
        var result = new ArrayList<Element>();
        if (e != null) for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling()) if (n instanceof Element child) result.add(child);
        return result;
    }
    public static Element child(Element e, String ns, String local) {
        for (var c : children(e)) if (is(c, ns, local)) return c;
        return null;
    }
    public static List<Element> descendants(Element e) {
        var all = new ArrayList<Element>(); all.add(e);
        var nodes = e.getElementsByTagNameNS("*", "*");
        for (int i = 0; i < nodes.getLength(); i++) all.add((Element) nodes.item(i));
        return all;
    }
    public static List<Element> findAll(Element e, String ns, String local) {
        return descendants(e).stream().filter(n -> is(n, ns, local)).toList();
    }
    public static Element copy(Element e) { return (Element) e.cloneNode(true); }
    public static Element appendCopy(Element parent, Element original) {
        var e = (Element) parent.getOwnerDocument().importNode(original, true); parent.appendChild(e); return e;
    }
    public static List<Attr> attributes(Element e) {
        var list = new ArrayList<Attr>(); var attrs = e.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) list.add((Attr) attrs.item(i));
        return list;
    }
    public static boolean hidden(Element e) { return Set.of("0", "false").contains(e.getAttribute("show").toLowerCase(Locale.ROOT)); }
}
