package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.application.MergeService;
import com.mergeslides.domain.*;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;

public final class PackageMergeService implements MergeService {
    private final PackageReader reader;
    private final AtomicPackageWriter writer;
    public PackageMergeService(PackageReader reader, AtomicPackageWriter writer) { this.reader = reader; this.writer = writer; }
    @Override public MergeResult merge(List<InputSpec> inputs, Path output) {
        long started = System.nanoTime(); output = output.toAbsolutePath().normalize();
        if (!output.toString().toLowerCase(Locale.ROOT).endsWith(".pptx")) throw MergeException.invalid("Output must use the .pptx extension.");
        Map<Path, PackageDocument> sources = new LinkedHashMap<>(); var sequence = new ArrayList<MergeContext.Occurrence>();
        for (var input : inputs) {
            Path path = input.file().toAbsolutePath().normalize();
            if (!Files.isRegularFile(path)) throw new MergeException(ErrorCode.INPUT_NOT_FOUND, "Input presentation not found: " + path);
            try {
                if (path.equals(output) || Files.exists(output) && Files.isSameFile(path, output)) throw MergeException.invalid("Output cannot overwrite an input presentation: " + path);
                path = path.toRealPath();
            } catch (IOException e) { throw new MergeException(ErrorCode.IO_FAILURE, "Cannot inspect input path " + path, e); }
            if (!path.toString().toLowerCase(Locale.ROOT).endsWith(".pptx")) throw MergeException.invalid("Only OOXML .pptx inputs are supported: " + path);
            var source = sources.computeIfAbsent(path, reader::read);
            List<Integer> indices;
            try { indices = SlideSelector.select(input.slides(), source.slides.size()); }
            catch (MergeException e) { throw new MergeException(e.code(), path.getFileName() + ": " + e.getMessage(), e); }
            for (int index : indices) if (!input.skipHidden() || !Xml.hidden(source.slideXml(index))) sequence.add(new MergeContext.Occurrence(source, source.slides.get(index)));
        }
        if (sequence.isEmpty()) throw MergeException.invalid("No slides selected after applying ranges and hidden-slide filtering.");
        var context = new MergeContext(new ArrayList<>(sources.values()), sequence);
        writer.write(new PresentationAssembler(context).build(), output);
        return new MergeResult(output, sequence.size(), new ArrayList<>(new LinkedHashSet<>(context.warnings)), (System.nanoTime() - started) / 1_000_000);
    }
}
