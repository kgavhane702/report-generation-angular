package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import com.mergeslides.infrastructure.input.NaturalOrder;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static com.mergeslides.infrastructure.ooxml.PackagePaths.*;
import static com.mergeslides.infrastructure.ooxml.GraphImporter.addRel;
import static com.mergeslides.infrastructure.ooxml.MergeContext.SourcePart;

final class PresentationAssembler {
    private final MergeContext c;
    private final GraphImporter importer;
    private final MetadataMerger metadata;
    PresentationAssembler(MergeContext context) { c = context; importer = new GraphImporter(c); metadata = new MetadataMerger(c); }
    Map<String, byte[]> build() {
        metadata.authorsAndStyles();
        var ordered = new ArrayList<PackageDocument>(); ordered.add(c.base);
        for (var source : c.sources) if (source != c.base) ordered.add(source);
        for (var source : ordered) {
            var rel = source.rels(PRESENTATION).values().stream().filter(r -> r.getAttribute("Type").equals(RelationshipType.NOTES_MASTER.uri())).findFirst().orElse(null);
            if (rel != null) { c.notesMaster = importer.importPart(source, resolve(PRESENTATION, rel.getAttribute("Target"))); break; }
        }
        var presentation = Xml.copy(c.base.xml.get(PRESENTATION));
        for (String name : List.of("sldMasterIdLst", "notesMasterIdLst", "handoutMasterIdLst", "sldIdLst", "custShowLst")) {
            var element = Xml.child(presentation, P, name); if (element != null) presentation.removeChild(element);
        }
        var rels = Xml.root(RELS, "Relationships"); Map<String, String> ridMap = new HashMap<>();
        var handled = Set.of(RelationshipType.SLIDE.uri(), RelationshipType.SLIDE_MASTER.uri(), RelationshipType.NOTES_MASTER.uri(), RelationshipType.HANDOUT_MASTER.uri(), RelationshipType.COMMENT_AUTHORS.uri(), RelationshipType.TABLE_STYLES.uri());
        for (var rel : c.base.rels(PRESENTATION).values()) {
            if (handled.contains(rel.getAttribute("Type"))) continue;
            String rid;
            if (rel.getAttribute("TargetMode").equals("External")) {
                var clone = Xml.appendCopy(rels, rel); rid = "rId" + Xml.children(rels).size(); clone.setAttribute("Id", rid);
            } else rid = addRel(rels, PRESENTATION, importer.importPart(c.base, resolve(PRESENTATION, rel.getAttribute("Target"))), rel.getAttribute("Type"));
            ridMap.put(rel.getAttribute("Id"), rid);
        }
        for (var e : Xml.descendants(presentation)) for (var attr : Xml.attributes(e)) if (R.equals(attr.getNamespaceURI())) {
            String id = ridMap.get(attr.getValue()); if (id == null) e.removeAttributeNode(attr); else attr.setValue(id);
        }
        for (int i = 0; i < c.sequence.size(); i++) {
            var item = c.sequence.get(i); String target = "ppt/slides/slide" + (i + 1) + ".xml";
            importer.importPart(item.source(), item.part(), item.part() + "\0" + target, target);
        }
        long nextId = FIRST_MASTER_ID; var masterList = Xml.root(P, "sldMasterIdLst");
        var names = new ArrayList<>(c.parts.keySet()); names.sort(NaturalOrder.INSTANCE);
        for (String name : names) if (ContentType.MASTER.mime().equals(c.types.get(name))) {
            String rid = addRel(rels, PRESENTATION, name, RelationshipType.SLIDE_MASTER.uri());
            var entry = Xml.add(masterList, P, "sldMasterId"); entry.setAttribute("id", Long.toString(nextId++)); Xml.rid(entry, rid);
            var root = Xml.parse(c.parts.get(name), name);
            for (var layout : Xml.children(Xml.child(root, P, "sldLayoutIdLst"))) layout.setAttribute("id", Long.toString(nextId++));
            c.parts.put(name, Xml.bytes(root));
        }
        var lists = new ArrayList<Element>(); if (!Xml.children(masterList).isEmpty()) lists.add(masterList);
        masterList(c, rels, lists, ContentType.NOTES_MASTER, RelationshipType.NOTES_MASTER, "notesMasterIdLst", "notesMasterId");
        masterList(c, rels, lists, ContentType.HANDOUT_MASTER, RelationshipType.HANDOUT_MASTER, "handoutMasterIdLst", "handoutMasterId");
        var slides = Xml.root(P, "sldIdLst");
        for (int i = 0; i < c.sequence.size(); i++) {
            String rid = addRel(rels, PRESENTATION, "ppt/slides/slide" + (i + 1) + ".xml", RelationshipType.SLIDE.uri());
            var entry = Xml.add(slides, P, "sldId"); entry.setAttribute("id", Long.toString(FIRST_SLIDE_ID + i)); Xml.rid(entry, rid);
        }
        lists.add(slides);
        var first = presentation.getFirstChild();
        for (var list : lists) presentation.insertBefore(presentation.getOwnerDocument().importNode(list, true), first);
        customShows(presentation, rels);
        metadata.sections(presentation); metadata.pruneAuthors();
        if (c.parts.containsKey(AUTHORS)) addRel(rels, PRESENTATION, AUTHORS, RelationshipType.COMMENT_AUTHORS.uri());
        if (c.parts.containsKey(TABLE_STYLES)) addRel(rels, PRESENTATION, TABLE_STYLES, RelationshipType.TABLE_STYLES.uri());
        c.store(PRESENTATION, Xml.bytes(presentation), ContentType.PRESENTATION.mime());
        c.store(PackagePaths.rels(PRESENTATION), Xml.bytes(rels), RELS_MIME);
        var rootRels = Xml.root(RELS, "Relationships");
        for (var original : c.base.rels("").values()) {
            var clone = Xml.appendCopy(rootRels, original);
            if (!original.getAttribute("TargetMode").equals("External")) clone.setAttribute("Target", relative("", importer.importPart(c.base, resolve("", original.getAttribute("Target"))), original.getAttribute("Target")));
        }
        c.store(ROOT_RELS, Xml.bytes(rootRels), RELS_MIME); metadata.appProperties();
        var ct = Xml.root(CT, "Types"); var defaults = Xml.add(ct, CT, "Default"); defaults.setAttribute("Extension", "rels"); defaults.setAttribute("ContentType", RELS_MIME);
        for (String name : new TreeSet<>(c.parts.keySet())) if (!name.endsWith(".rels")) {
            var entry = Xml.add(ct, CT, "Override"); entry.setAttribute("PartName", "/" + quote(name)); entry.setAttribute("ContentType", c.types.get(name));
        }
        c.parts.put(TYPES, Xml.bytes(ct));
        var baseSize = Xml.child(c.base.xml.get(PRESENTATION), P, "sldSz");
        for (var source : c.sources) {
            var size = Xml.child(source.xml.get(PRESENTATION), P, "sldSz");
            if (size != null && baseSize != null && (!size.getAttribute("cx").equals(baseSize.getAttribute("cx")) || !size.getAttribute("cy").equals(baseSize.getAttribute("cy")))) c.warnings.add(c.label(source) + ": source slide size differs; retaining " + c.label(c.base) + " size without scaling");
        }
        return c.parts;
    }
    private static void masterList(MergeContext c, Element rels, List<Element> lists, ContentType type, RelationshipType rel, String listName, String entryName) {
        String target = c.parts.keySet().stream().filter(n -> type.mime().equals(c.types.get(n))).findFirst().orElse(null);
        if (target == null) return;
        var list = Xml.root(P, listName); Xml.rid(Xml.add(list, P, entryName), addRel(rels, PRESENTATION, target, rel.uri())); lists.add(list);
    }
    private void customShows(Element presentation, Element rels) {
        var original = Xml.child(c.base.xml.get(PRESENTATION), P, "custShowLst"); if (original == null) return;
        var shows = Xml.copy(original); Map<String, String> outputRids = new HashMap<>();
        for (var rel : Xml.children(rels)) if (rel.getAttribute("Type").equals(RelationshipType.SLIDE.uri())) outputRids.put(rel.getAttribute("Target"), rel.getAttribute("Id"));
        for (var show : Xml.children(shows)) {
            var entries = Xml.child(show, P, "sldLst");
            if (entries == null) { shows.removeChild(show); continue; }
            for (var entry : Xml.children(entries)) {
                var rel = c.base.rels(PRESENTATION).get(Xml.rid(entry));
                String part = resolve(PRESENTATION, rel.getAttribute("Target"));
                var targets = c.destinations.get(new SourcePart(c.base.path, part));
                if (targets == null || targets.isEmpty()) entries.removeChild(entry); else Xml.rid(entry, outputRids.get(relative(PRESENTATION, targets.get(0))));
            }
            if (Xml.children(entries).isEmpty()) shows.removeChild(show);
        }
        if (!Xml.children(shows).isEmpty()) {
            var following = Xml.children(presentation).stream().filter(e -> P.equals(e.getNamespaceURI()) && AFTER_CUSTOM_SHOWS.contains(e.getLocalName())).findFirst().orElse(null);
            presentation.insertBefore(presentation.getOwnerDocument().importNode(shows, true), following);
        }
    }
}
