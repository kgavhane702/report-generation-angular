package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static com.mergeslides.infrastructure.ooxml.PackagePaths.*;
import static com.mergeslides.infrastructure.ooxml.MergeContext.*;

final class GraphImporter {
    private final MergeContext c;
    GraphImporter(MergeContext context) { c = context; }
    String importPart(PackageDocument source, String part) { return importPart(source, part, null, null); }
    String importPart(PackageDocument source, String part, String context, String forced) {
        if (part.equals(PRESENTATION)) return PRESENTATION;
        String type = source.types.get(part);
        if (ContentType.NOTES_MASTER.mime().equals(type) && c.notesMaster != null) return c.notesMaster;
        boolean shared = SHARED_DIRECTORIES.stream().anyMatch(part::startsWith) && !ContentType.THEME.mime().equals(type);
        var key = new ImportKey(source.path, part, shared ? null : context);
        if (c.mapping.containsKey(key)) return c.mapping.get(key);
        if (source.slides.contains(part) && forced == null) {
            if (context != null && context.startsWith(part + "\0")) return context.substring(part.length() + 1);
            var destinations = c.destinations.get(new SourcePart(source.path, part));
            return destinations == null ? null : destinations.get(0);
        }
        String fingerprint = shared ? type + ":" + source.fingerprint(part) : null;
        if (fingerprint != null && c.shared.containsKey(fingerprint)) {
            c.mapping.put(key, c.shared.get(fingerprint)); return c.shared.get(fingerprint);
        }
        String destination = forced == null ? c.allocate(part) : forced;
        c.mapping.put(key, destination); // Register before following cyclic master/layout dependencies.
        if (fingerprint != null) c.shared.put(fingerprint, destination);
        byte[] data = source.parts.get(part);
        var rels = Xml.root(RELS, "Relationships"); Set<String> omitted = new HashSet<>();
        for (var original : source.rels(part).values()) {
            var rel = Xml.copy(original);
            if (!original.getAttribute("TargetMode").equals("External")) {
                String target = resolve(part, original.getAttribute("Target"));
                String dependencyContext = context;
                if (ContentType.THEME.mime().equals(source.types.get(target)) && Set.of(ContentType.MASTER.mime(), ContentType.NOTES_MASTER.mime(), ContentType.HANDOUT_MASTER.mime()).contains(type)) dependencyContext = "theme-owner\0" + destination;
                String mapped = importPart(source, target, dependencyContext, null);
                if (mapped == null) {
                    omitted.add(original.getAttribute("Id"));
                    c.warnings.add(c.label(source) + ":" + part + ": removed link to omitted slide " + target); continue;
                }
                rel.setAttribute("Target", relative(destination, mapped, original.getAttribute("Target")));
            }
            Xml.appendCopy(rels, rel);
        }
        var tableIds = c.tableIds.getOrDefault(source.path, Map.of());
        if ((!omitted.isEmpty() || ContentType.COMMENTS.mime().equals(type) || !tableIds.isEmpty()) && source.xml.containsKey(part)) {
            var root = Xml.copy(source.xml.get(part));
            for (var parent : Xml.descendants(root)) for (var element : Xml.children(parent)) {
                if (Xml.attributes(element).stream().anyMatch(a -> R.equals(a.getNamespaceURI()) && omitted.contains(a.getValue()))) parent.removeChild(element);
            }
            if (ContentType.COMMENTS.mime().equals(type)) for (var comment : Xml.children(root)) if (Xml.is(comment, P, "cm")) {
                String author = c.authorIds.get(new SourcePart(source.path, comment.getAttribute("authorId")));
                int index = c.commentIndices.getOrDefault(author, 0);
                comment.setAttribute("authorId", author); comment.setAttribute("idx", Integer.toString(index)); c.commentIndices.put(author, index + 1);
            }
            for (var element : Xml.findAll(root, A, "tableStyleId")) element.setTextContent(tableIds.getOrDefault(element.getTextContent(), element.getTextContent()));
            data = Xml.bytes(root);
        }
        c.store(destination, data, type);
        if (!Xml.children(rels).isEmpty()) c.store(PackagePaths.rels(destination), Xml.bytes(rels), RELS_MIME);
        return destination;
    }
    static String addRel(Element root, String owner, String target, String type) {
        String id = "rId" + (Xml.children(root).size() + 1);
        var rel = Xml.add(root, RELS, "Relationship"); rel.setAttribute("Id", id); rel.setAttribute("Type", type); rel.setAttribute("Target", relative(owner, target)); return id;
    }
}
