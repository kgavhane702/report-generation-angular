package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class PackagePaths {
    private PackagePaths() {}
    public static String directory(String name) { int i = name.lastIndexOf('/'); return i < 0 ? "" : name.substring(0, i); }
    public static String filename(String name) { return name.substring(name.lastIndexOf('/') + 1); }
    public static String normalize(String path) {
        Deque<String> pieces = new ArrayDeque<>();
        for (String p : path.split("/")) {
            if (p.isEmpty() || p.equals(".")) continue;
            if (p.equals("..") && !pieces.isEmpty() && !pieces.peekLast().equals("..")) pieces.removeLast(); else pieces.add(p);
        }
        return String.join("/", pieces);
    }
    public static String rels(String owner) { return owner.isEmpty() ? Ooxml.ROOT_RELS : (directory(owner).isEmpty() ? "" : directory(owner) + "/") + "_rels/" + filename(owner) + ".rels"; }
    public static String owner(String rels) {
        if (rels.equals(Ooxml.ROOT_RELS)) return "";
        String dir = directory(rels);
        if (!filename(dir).equals("_rels") || !rels.endsWith(".rels")) throw invalid("Invalid relationships part: " + rels);
        return (directory(dir).isEmpty() ? "" : directory(dir) + "/") + filename(rels).substring(0, filename(rels).length() - 5);
    }
    public static String decode(String path) {
        try { return URLDecoder.decode(path.replace("+", "%2B"), StandardCharsets.UTF_8); }
        catch (IllegalArgumentException e) { throw invalid("Invalid escaped package URI: " + path); }
    }
    public static String resolve(String owner, String target) {
        String text = target.replace('\\', '/');
        int fragment = text.indexOf('#'); if (fragment >= 0) text = text.substring(0, fragment);
        if (text.contains("?") || text.startsWith("//") || text.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) throw invalid("Internal relationship is not a package URI: " + target);
        String path = decode(text);
        String resolved = path.isEmpty() ? owner : normalize(path.startsWith("/") ? path : directory(owner) + "/" + path);
        if (resolved.equals("..") || resolved.startsWith("../")) throw invalid("Relationship escapes package: " + target);
        return resolved;
    }
    public static String quote(String path) {
        var out = new StringBuilder();
        for (byte b : path.getBytes(StandardCharsets.UTF_8)) {
            int n = b & 255;
            if (n >= 'a' && n <= 'z' || n >= 'A' && n <= 'Z' || n >= '0' && n <= '9' || "/._-~".indexOf(n) >= 0) out.append((char)n);
            else out.append(String.format("%%%02X", n));
        }
        return out.toString();
    }
    public static String relative(String owner, String destination, String original) {
        List<String> from = directory(owner).isEmpty() ? List.of() : List.of(directory(owner).split("/"));
        List<String> to = List.of(destination.split("/"));
        int same = 0; while (same < from.size() && same < to.size() && from.get(same).equals(to.get(same))) same++;
        var parts = new ArrayList<String>(); for (int i = same; i < from.size(); i++) parts.add(".."); parts.addAll(to.subList(same, to.size()));
        int hash = original.indexOf('#');
        return quote(String.join("/", parts)) + (hash < 0 ? "" : original.substring(hash));
    }
    public static String relative(String owner, String destination) { return relative(owner, destination, ""); }
    private static MergeException invalid(String message) { return new MergeException(ErrorCode.INVALID_PRESENTATION, message); }
}
