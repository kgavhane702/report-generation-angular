package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import org.w3c.dom.Element;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static com.mergeslides.infrastructure.ooxml.PackagePaths.*;

public final class PackageValidator {
    public void validate(PackageDocument p) {
        for (String required : List.of(TYPES, ROOT_RELS, PRESENTATION, PackagePaths.rels(PRESENTATION))) if (!p.parts.containsKey(required)) fail(p, "Missing required package part " + required);
        var ct = p.xml.get(TYPES);
        if (!Xml.is(ct, CT, "Types")) fail(p, "Invalid content-types root namespace");
        Map<String, String> defaults = new HashMap<>(), overrides = new HashMap<>();
        for (var e : Xml.children(ct)) {
            Map<String, String> target; String key;
            if (Xml.is(e, CT, "Default")) { target = defaults; key = e.getAttribute("Extension").toLowerCase(Locale.ROOT); }
            else if (Xml.is(e, CT, "Override")) { target = overrides; key = decode(e.getAttribute("PartName").replaceFirst("^/+", "")); }
            else { fail(p, "Unrecognized content-type entry"); return; }
            if (target.putIfAbsent(key, e.getAttribute("ContentType")) != null) fail(p, "Duplicate content-type declaration: " + key);
        }
        for (String name : p.parts.keySet()) {
            if (name.equals(TYPES)) continue;
            String type = overrides.getOrDefault(name, defaults.get(name.substring(name.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT)));
            if (type == null || type.isEmpty()) fail(p, "Missing content type for " + name);
            p.types.put(name, type);
            if (name.endsWith(".rels")) {
                String owner = owner(name);
                if (!owner.isEmpty() && !p.parts.containsKey(owner)) fail(p, "Orphan relationships part " + name);
                var root = p.xml.get(name);
                if (!Xml.is(root, RELS, "Relationships")) fail(p, "Invalid relationship namespace in " + name);
                var rels = new LinkedHashMap<String, Element>();
                for (var rel : Xml.children(root)) {
                    String id = rel.getAttribute("Id");
                    if (!Xml.is(rel, RELS, "Relationship") || id.isEmpty() || rels.putIfAbsent(id, rel) != null || rel.getAttribute("Type").isEmpty() || !rel.hasAttribute("Target")) fail(p, "Invalid or duplicate relationship in " + name + ": " + id);
                    if (!rel.getAttribute("TargetMode").equals("External") && !p.parts.containsKey(resolve(owner, rel.getAttribute("Target")))) fail(p, name + " points to missing part " + resolve(owner, rel.getAttribute("Target")));
                }
                p.relationships.put(owner, rels);
            }
        }
        if (!ContentType.PRESENTATION.mime().equals(p.types.get(PRESENTATION))) fail(p, "Only non-macro OOXML .pptx presentations are supported");
        var office = p.rels("").values().stream().filter(r -> r.getAttribute("Type").equals(RelationshipType.OFFICE_DOCUMENT.uri())).toList();
        if (office.size() != 1 || !resolve("", office.get(0).getAttribute("Target")).equals(PRESENTATION)) fail(p, "Root relationship must identify ppt/presentation.xml");
        if (p.parts.keySet().stream().anyMatch(n -> n.startsWith("_xmlsignatures/"))) fail(p, "Digitally signed packages must be unsigned before merging");
        Set<Long> ids = new HashSet<>();
        for (var e : Xml.children(Xml.child(p.xml.get(PRESENTATION), P, "sldIdLst"))) {
            long id = identifier(p, e);
            var rel = p.rels(PRESENTATION).get(Xml.rid(e));
            if (!ids.add(id) || id < FIRST_SLIDE_ID || id >= FIRST_MASTER_ID) fail(p, "Invalid or duplicate slide ID: " + id);
            if (rel == null || !rel.getAttribute("Type").equals(RelationshipType.SLIDE.uri())) fail(p, "Slide ID " + id + " has no slide relationship");
            String target = resolve(PRESENTATION, rel.getAttribute("Target"));
            if (p.slides.contains(target) || !ContentType.SLIDE.mime().equals(p.types.get(target))) fail(p, "Invalid or duplicate presentation slide: " + target);
            p.slides.add(target); p.slideIds.add(id);
        }
        var entries = new ArrayList<>(Xml.children(Xml.child(p.xml.get(PRESENTATION), P, "sldMasterIdLst")));
        Map<String, String> themeOwners = new HashMap<>();
        p.xml.forEach((name, root) -> {
            if (!Xml.is(root, P, "sldMaster")) return;
            Set<String> targets = new HashSet<>();
            for (var layout : Xml.children(Xml.child(root, P, "sldLayoutIdLst"))) {
                entries.add(layout);
                var rel = p.rels(name).get(Xml.rid(layout));
                if (rel == null || !rel.getAttribute("Type").equals(RelationshipType.SLIDE_LAYOUT.uri())) fail(p, name + " contains invalid layout reference");
                if (!targets.add(resolve(name, rel.getAttribute("Target")))) fail(p, name + " registers the same layout more than once");
            }
            for (var rel : p.rels(name).values()) if (rel.getAttribute("Type").equals(RelationshipType.THEME.uri())) {
                String theme = resolve(name, rel.getAttribute("Target"));
                String previous = themeOwners.putIfAbsent(theme, name);
                if (previous != null && !previous.equals(name)) fail(p, "Theme " + theme + " is shared by multiple slide masters");
            }
        });
        ids.clear();
        for (var e : entries) { long id = identifier(p, e); if (!ids.add(id) || id < FIRST_MASTER_ID || id >= (1L << 32)) fail(p, "Invalid or duplicate master/layout ID: " + id); }
        Set<String> authors = new HashSet<>();
        for (var root : p.xml.values()) if (Xml.is(root, P, "cmAuthorLst")) for (var author : Xml.children(root)) authors.add(author.getAttribute("id"));
        p.xml.forEach((owner, root) -> {
            if (owner.endsWith(".rels") || owner.equals(TYPES)) return;
            for (var e : Xml.descendants(root)) for (var attr : Xml.attributes(e)) if (R.equals(attr.getNamespaceURI()) && !attr.getValue().isEmpty() && !p.rels(owner).containsKey(attr.getValue())) fail(p, owner + " references missing relationship " + attr.getValue());
            if (ContentType.COMMENTS.mime().equals(p.types.get(owner))) for (var comment : Xml.children(root)) if (Xml.is(comment, P, "cm") && !authors.contains(comment.getAttribute("authorId"))) fail(p, owner + " references unknown comment author");
        });
    }
    private long identifier(PackageDocument p, Element e) {
        try { return Long.parseLong(e.getAttribute("id")); } catch (NumberFormatException ex) { fail(p, "Invalid numeric ID"); return 0; }
    }
    private void fail(PackageDocument p, String message) { throw new MergeException(ErrorCode.INVALID_PRESENTATION, p.path.getFileName() + ": " + message); }
}
