package com.mergeslides.infrastructure.ooxml;

import java.nio.file.Path;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

/** Mutable data exists only for one invocation; Spring services themselves are stateless. */
final class MergeContext {
    record SourcePart(Path source, String part) {}
    record ImportKey(Path source, String part, String context) {}
    record Occurrence(PackageDocument source, String part) {}
    final List<PackageDocument> sources;
    final List<Occurrence> sequence;
    final PackageDocument base;
    final Map<String, byte[]> parts = new LinkedHashMap<>();
    final Map<String, String> types = new LinkedHashMap<>();
    final Map<ImportKey, String> mapping = new HashMap<>();
    final Map<String, String> shared = new HashMap<>();
    final Set<String> reserved = new HashSet<>(Set.of(PRESENTATION, AUTHORS, TABLE_STYLES));
    final Map<SourcePart, List<String>> destinations = new HashMap<>();
    final Map<SourcePart, String> authorIds = new HashMap<>();
    final Map<Path, Map<String, String>> tableIds = new HashMap<>();
    final Map<String, Integer> commentIndices = new HashMap<>();
    final List<String> warnings = new ArrayList<>();
    private final Map<Path, String> sourceLabels = new HashMap<>();
    String notesMaster;

    MergeContext(List<PackageDocument> sources, List<Occurrence> sequence) {
        this.sources = sources; this.sequence = sequence;
        this.base = sources.stream().reduce((a, b) -> b.richness() > a.richness() ? b : a).orElseThrow();
        Map<String, Integer> filenameCounts = new HashMap<>();
        for (var source : sources) filenameCounts.merge(source.path.getFileName().toString().toLowerCase(Locale.ROOT), 1, Integer::sum);
        for (var source : sources) {
            String name = source.path.getFileName().toString();
            sourceLabels.put(source.path, filenameCounts.get(name.toLowerCase(Locale.ROOT)) > 1 ? source.path.toString() : name);
        }
        for (int i = 0; i < sequence.size(); i++) {
            var occurrence = sequence.get(i); String name = "ppt/slides/slide" + (i + 1) + ".xml";
            reserved.add(name);
            destinations.computeIfAbsent(new SourcePart(occurrence.source.path, occurrence.part), key -> new ArrayList<>()).add(name);
        }
    }
    String label(PackageDocument source) { return sourceLabels.get(source.path); }
    void store(String name, byte[] data, String type) { parts.put(name, data); types.put(name, type); }
    String allocate(String preferred) {
        String result = preferred; int count = 2;
        int dot = preferred.lastIndexOf('.'); if (dot < preferred.lastIndexOf('/')) dot = preferred.length();
        while (reserved.contains(result)) result = preferred.substring(0, dot) + "_merge" + count++ + preferred.substring(dot);
        reserved.add(result); return result;
    }
}
