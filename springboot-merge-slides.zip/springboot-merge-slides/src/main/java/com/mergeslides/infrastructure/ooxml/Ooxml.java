package com.mergeslides.infrastructure.ooxml;

import java.util.*;

public final class Ooxml {
    private Ooxml() {}
    public static final String P = "http://schemas.openxmlformats.org/presentationml/2006/main";
    public static final String A = "http://schemas.openxmlformats.org/drawingml/2006/main";
    public static final String R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    public static final String RELS = "http://schemas.openxmlformats.org/package/2006/relationships";
    public static final String CT = "http://schemas.openxmlformats.org/package/2006/content-types";
    public static final String EP = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties";
    public static final String P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main";
    public static final String MIME_BASE = "application/vnd.openxmlformats-officedocument.";
    public static final String PPTX_MIME = MIME_BASE + "presentationml.presentation";
    public static final String RELS_MIME = "application/vnd.openxmlformats-package.relationships+xml";
    public static final String TYPES = "[Content_Types].xml";
    public static final String PRESENTATION = "ppt/presentation.xml";
    public static final String ROOT_RELS = "_rels/.rels";
    public static final String AUTHORS = "ppt/commentAuthors.xml";
    public static final String TABLE_STYLES = "ppt/tableStyles.xml";
    public static final String DEFAULT_INPUT = "ppts";
    public static final String DEFAULT_OUTPUT = "merged_output_autonomous.pptx";
    public static final String TEMP_PREFIX = ".pptx-merge-";
    public static final long FIRST_SLIDE_ID = 256;
    public static final long FIRST_MASTER_ID = 1L << 31;
    public static final String SECTION_EXTENSION = "{521415D9-36F7-43E2-AB2F-B90AF26B5E84}";
    public static final Set<String> AFTER_CUSTOM_SHOWS = Set.of("photoAlbum", "custDataLst", "kinsoku", "defaultTextStyle", "modifyVerifier", "extLst");
    public static final List<String> SHARED_DIRECTORIES = List.of("ppt/slideLayouts/", "ppt/slideMasters/", "ppt/notesMasters/", "ppt/handoutMasters/", "ppt/media/");

    public enum RelationshipType {
        OFFICE_DOCUMENT("officeDocument"), SLIDE("slide"), SLIDE_LAYOUT("slideLayout"),
        SLIDE_MASTER("slideMaster"), NOTES_SLIDE("notesSlide"), NOTES_MASTER("notesMaster"),
        HANDOUT_MASTER("handoutMaster"), COMMENT_AUTHORS("commentAuthors"), TABLE_STYLES("tableStyles"), THEME("theme");
        private final String uri;
        RelationshipType(String name) { uri = R + "/" + name; }
        public String uri() { return uri; }
    }
    public enum ContentType {
        PRESENTATION("presentationml.presentation.main+xml"), SLIDE("presentationml.slide+xml"),
        MASTER("presentationml.slideMaster+xml"), THEME("theme+xml"),
        NOTES_MASTER("presentationml.notesMaster+xml"), NOTES_SLIDE("presentationml.notesSlide+xml"),
        HANDOUT_MASTER("presentationml.handoutMaster+xml"), COMMENTS("presentationml.comments+xml"),
        AUTHORS("presentationml.commentAuthors+xml"), TABLE_STYLES("presentationml.tableStyles+xml"),
        EXTENDED_PROPERTIES("extended-properties+xml");
        private final String mime;
        ContentType(String suffix) { mime = MIME_BASE + suffix; }
        public String mime() { return mime; }
    }
}
