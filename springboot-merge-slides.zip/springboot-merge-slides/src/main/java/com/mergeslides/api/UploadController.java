package com.mergeslides.api;

import com.mergeslides.application.*;
import com.mergeslides.infrastructure.ooxml.Ooxml;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.async.*;
import java.util.concurrent.Callable;

@RestController
@RequestMapping("/api/v1/merges")
public class UploadController {
    private static final Logger LOG = LoggerFactory.getLogger(UploadController.class);
    private final UploadMergeService uploads;
    public UploadController(UploadMergeService uploads) { this.uploads = uploads; }
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<StreamingResponseBody> upload(@RequestParam("files") List<MultipartFile> files, @RequestParam(value = "recipe", required = false) String recipe, HttpServletRequest request) throws IOException {
        List<UploadMergeService.Upload> sources = new ArrayList<>();
        UploadMergeService.PreparedDownload prepared;
        try {
            for (var file : files) sources.add(new UploadMergeService.Upload(file.getOriginalFilename(), file.getInputStream()));
            prepared = uploads.prepare(sources, recipe);
        } finally { for (var source : sources) source.stream().close(); }
        for (String warning : prepared.result().warnings()) LOG.warn("Upload merge: {}", warning);
        String operationId = (String) request.getAttribute(MergeOperationFilter.ATTRIBUTE);
        WebAsyncUtils.getAsyncManager(request).registerCallableInterceptor(prepared,
                new CallableProcessingInterceptor() {
                    @Override public <T> void afterCompletion(NativeWebRequest ignored, Callable<T> task) {
                        try { prepared.close(); }
                        catch (IOException error) { LOG.warn("[{}] TEMP_CLEANUP_FAILED after download completion", operationId, error); }
                    }
                });
        StreamingResponseBody body = stream -> {
            String previous = MDC.get("merge.operationId");
            if (operationId != null) MDC.put("merge.operationId", operationId);
            try (prepared; var input = Files.newInputStream(prepared.result().outputPath())) { input.transferTo(stream); }
            catch (IOException error) { LOG.error("[{}] TRANSFER_FAILED: download or cleanup failed after merge preparation", operationId, error); throw error; }
            finally { if (previous == null) MDC.remove("merge.operationId"); else MDC.put("merge.operationId", previous); }
        };
        return ResponseEntity.ok().contentType(MediaType.parseMediaType(Ooxml.PPTX_MIME))
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("merged.pptx").build().toString())
                .header("X-Merge-Slide-Count", Integer.toString(prepared.result().slideCount()))
                .header("X-Merge-Warning-Count", Integer.toString(prepared.result().warnings().size()))
                .contentLength(Files.size(prepared.result().outputPath())).body(body);
    }
}
