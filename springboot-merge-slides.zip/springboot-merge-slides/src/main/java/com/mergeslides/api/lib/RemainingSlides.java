package com.mergeslides.api.lib;

/** Placement of eligible slides not emitted by an explicit selection. */
public enum RemainingSlides { START, END, NONE }
