package com.mergeslides.api.lib;

public enum MissingTitlePolicy { SKIP, ERROR }
