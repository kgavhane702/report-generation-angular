package com.mergeslides.api.lib.internal;

import com.mergeslides.api.lib.*;
import java.nio.file.Path;
import java.util.List;

/** Internal transport model shared by the fluent and JSON adapters. */
public record MergeDefinition(Path baseDirectory, Path output, List<Source> sources,
        List<Query> queries, List<Exclusion> exclusions, Options options) {
    public MergeDefinition { sources = List.copyOf(sources); queries = List.copyOf(queries); exclusions = List.copyOf(exclusions); }
    public MergeDefinition withOutput(Path value) { return new MergeDefinition(baseDirectory, value, sources, queries, exclusions, options); }
    public record Source(int registration, Path path) {}
    public record Query(Integer registration, Path file, InputSelection selection, Path recipe) {}
    public record Exclusion(Path file, InputSelection selection) {}
    public record Options(Boolean skipHidden, DuplicateTitlePolicy duplicateTitles,
            DuplicateSourcePolicy duplicateSources, RepeatedSlidePolicy repeatedSlides,
            MissingTitlePolicy onMissing, RemainingSlides remaining, Boolean overwrite) {
        public static Options defaults() { return new Options(false, DuplicateTitlePolicy.ALL, DuplicateSourcePolicy.ALLOW,
                RepeatedSlidePolicy.ALLOW, MissingTitlePolicy.SKIP, RemainingSlides.END, false); }
        public Options orElse(Options other) {
            return new Options(skipHidden == null ? other.skipHidden : skipHidden,
                    duplicateTitles == null ? other.duplicateTitles : duplicateTitles,
                    duplicateSources == null ? other.duplicateSources : duplicateSources,
                    repeatedSlides == null ? other.repeatedSlides : repeatedSlides,
                    onMissing == null ? other.onMissing : onMissing,
                    remaining == null ? other.remaining : remaining,
                    overwrite == null ? other.overwrite : overwrite);
        }
    }
}
