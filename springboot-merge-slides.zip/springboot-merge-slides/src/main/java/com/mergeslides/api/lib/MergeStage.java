package com.mergeslides.api.lib;

public enum MergeStage { VALIDATION, DISCOVERY, READ, SELECTION, ASSEMBLY, WRITE, TRANSFER }
