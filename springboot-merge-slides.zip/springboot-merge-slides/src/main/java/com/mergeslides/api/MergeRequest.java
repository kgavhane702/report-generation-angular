package com.mergeslides.api;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public record MergeRequest(List<Object> inputs, String recipePath, @NotBlank String output, Object recipe) {
    public MergeRequest(List<Object> inputs, String recipePath, String output) { this(inputs, recipePath, output, null); }
}
