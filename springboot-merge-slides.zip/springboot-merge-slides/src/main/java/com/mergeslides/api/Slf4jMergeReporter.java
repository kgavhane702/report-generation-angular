package com.mergeslides.api;

import com.mergeslides.api.lib.*;
import org.slf4j.Logger;
import java.util.Objects;

/** Optional host adapter; excluded from the standalone library artifact. */
public final class Slf4jMergeReporter implements MergeReporter {
    private final Logger logger;
    private Slf4jMergeReporter(Logger logger) { this.logger = Objects.requireNonNull(logger); }
    public static Slf4jMergeReporter of(Logger logger) { return new Slf4jMergeReporter(logger); }
    @Override public void report(MergeEvent event) {
        String message = "[" + event.operationId() + "] " + event.code() + ": " + event.message();
        switch (event.severity()) {
            case DEBUG -> logger.debug(message);
            case INFO -> logger.info(message);
            case WARN -> logger.warn(message);
            case ERROR -> { if (event.cause() == null) logger.error(message); else logger.error(message, event.cause()); }
        }
    }
}
