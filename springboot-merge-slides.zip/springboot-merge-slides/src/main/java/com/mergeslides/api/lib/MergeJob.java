package com.mergeslides.api.lib;

import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.domain.MergeResult;
import com.mergeslides.infrastructure.ooxml.PlannedMergeEngine;
import java.util.UUID;

/** Immutable reusable configuration. Each terminal call performs a fresh, independent execution. */
public final class MergeJob {
    private final MergeDefinition definition;
    private final MergeReporter reporter;
    private final String operationId;
    MergeJob(MergeDefinition definition, MergeReporter reporter, String operationId) {
        this.definition = definition; this.reporter = reporter; this.operationId = operationId;
    }
    public static MergeJob fromDefinition(MergeDefinition definition, MergeReporter reporter) {
        return new MergeJob(definition, reporter, null);
    }
    public static MergeJob fromDefinition(MergeDefinition definition, MergeReporter reporter, String operationId) {
        return new MergeJob(definition, reporter, operationId);
    }
    public MergePlan plan() { return new PlannedMergeEngine().plan(definition, id()); }
    public MergePlan preview() { return plan(); }
    public MergeResult merge() { return mergeDetailed().result(); }
    public MergeReport mergeDetailed() { return new PlannedMergeEngine().merge(definition, reporter, id()); }
    private String id() { return operationId == null ? UUID.randomUUID().toString() : operationId; }
}
