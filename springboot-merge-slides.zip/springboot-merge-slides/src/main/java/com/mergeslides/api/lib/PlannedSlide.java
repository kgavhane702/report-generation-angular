package com.mergeslides.api.lib;

import java.nio.file.Path;

public record PlannedSlide(int outputPosition, Path file, int sourceOccurrence,
        int slideNumber, String title, boolean hidden, Origin origin, Integer selectionIndex) {
    public enum Origin { SELECTED, REMAINING }
}
