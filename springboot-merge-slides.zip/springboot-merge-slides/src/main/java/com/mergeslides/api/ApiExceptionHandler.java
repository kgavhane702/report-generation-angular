package com.mergeslides.api;

import com.mergeslides.domain.*;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import java.io.IOException;
import java.nio.file.InvalidPathException;
import java.util.*;

/** Only handles this adapter's controllers, never unrelated host application endpoints. */
@RestControllerAdvice(assignableTypes = {MergeController.class, UploadController.class})
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(ApiExceptionHandler.class);
    private final MergeHttpErrorMapper mapper = new MergeHttpErrorMapper();
    @ExceptionHandler(MergeException.class)
    public ResponseEntity<Object> merge(MergeException error, WebRequest request) {
        String id = id(request);
        if (error.code() == ErrorCode.IO_FAILURE) LOG.error("[{}] {} at {}", id, error.failureCode(), error.stage(), error);
        else LOG.error("[{}] {} at {}", id, error.failureCode(), error.stage());
        return new ResponseEntity<>(mapper.body(error, id), headers(id), mapper.status(error));
    }
    @ExceptionHandler(InvalidPathException.class)
    public ResponseEntity<Object> path(Exception error, WebRequest request) {
        return response("INVALID_REQUEST", "A supplied path is invalid.", HttpStatus.BAD_REQUEST, request);
    }
    @ExceptionHandler(IOException.class)
    public ResponseEntity<Object> io(IOException error, WebRequest request) {
        if (committed(request)) return null; // Stream callback already logged delivery failure; headers cannot be replaced.
        LOG.error("[{}] IO_FAILURE", id(request), error);
        return response("IO_FAILURE", "The merge could not complete because of an I/O failure.", HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> unexpected(Exception error, WebRequest request) {
        LOG.error("[{}] INTERNAL_ERROR", id(request), error);
        if (committed(request)) return null;
        return response("INTERNAL_ERROR", "An unexpected error occurred. Refer to the operation ID.", HttpStatus.INTERNAL_SERVER_ERROR, request);
    }
    @Override protected ResponseEntity<Object> handleExceptionInternal(Exception error, Object body, HttpHeaders headers,
            HttpStatusCode status, WebRequest request) {
        if (committed(request)) return null;
        String message = error instanceof MaxUploadSizeExceededException ? "Upload exceeds the hosting application's configured limits." : "Invalid HTTP request. Check its body, fields, parameters and content type.";
        if (error instanceof MethodArgumentNotValidException validation) {
            String id = id(request);
            var fields = validation.getBindingResult().getFieldErrors().stream()
                    .map(field -> Map.of("field", field.getField(), "message", Objects.toString(field.getDefaultMessage(), "Invalid value"))).toList();
            return new ResponseEntity<>(Map.of("code", "INVALID_REQUEST", "message", message, "operationId", id, "errors", fields), headers(id), status);
        }
        return response("INVALID_REQUEST", message, status, request);
    }
    private ResponseEntity<Object> response(String code, String message, HttpStatusCode status, WebRequest request) {
        String id = id(request);
        return new ResponseEntity<>(Map.of("code", code, "message", message, "operationId", id), headers(id), status);
    }
    private HttpHeaders headers(String id) { HttpHeaders headers = new HttpHeaders(); headers.set(MergeOperationFilter.HEADER, id); return headers; }
    private String id(WebRequest request) {
        Object value = request.getAttribute(MergeOperationFilter.ATTRIBUTE, WebRequest.SCOPE_REQUEST);
        if (value != null) return value.toString();
        String id = UUID.randomUUID().toString(); request.setAttribute(MergeOperationFilter.ATTRIBUTE, id, WebRequest.SCOPE_REQUEST); return id;
    }
    private boolean committed(WebRequest request) {
        return request instanceof ServletWebRequest servlet && servlet.getResponse() != null && servlet.getResponse().isCommitted();
    }
}
