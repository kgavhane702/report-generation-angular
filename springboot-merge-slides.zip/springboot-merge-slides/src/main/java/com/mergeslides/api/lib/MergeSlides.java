package com.mergeslides.api.lib;

import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.domain.*;
import java.nio.file.Path;
import java.util.*;

/** Entry point for plain Java; no Spring context or PowerPoint installation is required. */
public final class MergeSlides {
    private MergeSlides() {}
    public static Builder builder() { return new Builder(); }
    public static MergeClient.Builder client() { return new MergeClient.Builder(); }
    public static MergeResult merge(List<Path> files, Path output) { return builder().addFiles(files).output(output).merge(); }

    public static final class Builder {
        private Path base = Path.of("").toAbsolutePath(), output;
        private final List<MergeDefinition.Source> sources = new ArrayList<>();
        private final List<MergeDefinition.Query> queries = new ArrayList<>();
        private final List<MergeDefinition.Exclusion> exclusions = new ArrayList<>();
        private Boolean skipHidden, overwrite;
        private DuplicateTitlePolicy duplicates;
        private DuplicateSourcePolicy duplicateSources;
        private RepeatedSlidePolicy repeatedSlides;
        private MissingTitlePolicy missing;
        private RemainingSlides remaining;
        private MergeReporter reporter = MergeReporter.systemLogger();
        private String operationId;

        public Builder baseDirectory(Path value) { base = Objects.requireNonNull(value).toAbsolutePath().normalize(); return this; }
        public Builder output(Path value) { output = Objects.requireNonNull(value); return this; }
        public Builder reporter(MergeReporter value) { reporter = Objects.requireNonNull(value); return this; }
        public Builder operationId(String value) {
            if (value == null || value.isBlank() || value.length() > 128 || value.codePoints().anyMatch(Character::isISOControl))
                throw MergeException.invalid("operationId must be nonblank, at most 128 characters, and contain no control characters.");
            operationId = value; return this;
        }
        public Builder skipHidden() { return skipHidden(true); }
        public Builder skipHidden(boolean value) { skipHidden = value; return this; }
        public Builder overwrite(boolean value) { overwrite = value; return this; }
        public Builder duplicateTitles(DuplicateTitlePolicy value) { duplicates = Objects.requireNonNull(value); return this; }
        public Builder duplicateSources(DuplicateSourcePolicy value) { duplicateSources = Objects.requireNonNull(value); return this; }
        public Builder repeatedSlides(RepeatedSlidePolicy value) { repeatedSlides = Objects.requireNonNull(value); return this; }
        public Builder onMissing(MissingTitlePolicy value) { missing = Objects.requireNonNull(value); return this; }
        public Builder remainingSlides(RemainingSlides value) { remaining = Objects.requireNonNull(value); return this; }
        public Builder remaining(RemainingSlides value) { return remainingSlides(value); }
        public Builder searchFiles(Path... files) { return searchFiles(Arrays.asList(files)); }
        public Builder searchFiles(List<Path> files) {
            for (Path file : files) sources.add(new MergeDefinition.Source(sources.size(), Objects.requireNonNull(file)));
            return this;
        }
        public Builder sources(List<Path> files) { return searchFiles(files); }
        public Builder searchDirectory(Path path) { return searchFiles(path); }
        public Builder directory(Path path) { return searchDirectory(path); }
        public Builder addFile(Path file) { return addFile(file, InputSelection.all()); }
        public Builder addFile(Path file, InputSelection selection) {
            int id = sources.size(); sources.add(new MergeDefinition.Source(id, Objects.requireNonNull(file)));
            queries.add(new MergeDefinition.Query(id, null, Objects.requireNonNull(selection), null)); return this;
        }
        public Builder addFiles(Path... files) { return addFiles(Arrays.asList(files)); }
        public Builder addFiles(List<Path> files) { return addFiles(files, InputSelection.all()); }
        public Builder addFiles(List<Path> files, InputSelection selection) { for (Path file : files) addFile(file, selection); return this; }
        public Builder addDirectory(Path path) { return addFile(path); }
        public Builder addDirectory(Path path, InputSelection selection) { return addFile(path, selection); }
        public Builder addAll(List<MergeInput> inputs) { for (MergeInput input : inputs) addFile(input.file(), input.selection()); return this; }
        public Builder selectFile(Path file, InputSelection selection) {
            queries.add(new MergeDefinition.Query(null, Objects.requireNonNull(file), Objects.requireNonNull(selection), null)); return this;
        }
        public Builder select(InputSelection selection) {
            if (selection.kind() != InputSelection.Kind.TITLES) throw MergeException.invalid("Global selections must be title-based; numbers need a file.");
            queries.add(new MergeDefinition.Query(null, null, selection, null)); return this;
        }
        public Builder addTitle(String title) { return select(InputSelection.title(title)); }
        public Builder addTitles(String... titles) { return addTitles(Arrays.asList(titles)); }
        public Builder addTitles(List<String> titles) { if (!titles.isEmpty()) select(InputSelection.titles(titles)); return this; }
        public Builder orderByTitles(List<String> titles) { return addTitles(titles); }
        public Builder orderByTitles(String... titles) { return addTitles(titles); }
        public Builder addTitle(Path file, String title) { return selectFile(file, InputSelection.title(title)); }
        public Builder addTitles(Path file, List<String> titles) { return selectFile(file, InputSelection.titles(titles)); }
        public Builder addTitles(Path file, String... titles) { return addTitles(file, Arrays.asList(titles)); }
        public Builder addSlide(Path file, int slide) { return addSlides(file, slide); }
        public Builder addSlides(Path file, int... slides) { return selectFile(file, InputSelection.slides(slides)); }
        public Builder addSlides(Path file, List<Integer> slides) { return selectFile(file, InputSelection.slides(slides)); }
        public Builder addRange(Path file, int first, int last) { return selectFile(file, InputSelection.range(first + "-" + last)); }
        public Builder addSlice(Path file, SlideSlice slice) { return selectFile(file, InputSelection.slice(slice)); }
        public Builder addAll(Path file) { return selectFile(file, InputSelection.all()); }
        public Builder excludeSlide(Path file, int slide) { return excludeSlides(file, slide); }
        public Builder excludeSlides(Path file, int... slides) { return exclude(file, InputSelection.slides(slides)); }
        public Builder excludeSlides(Path file, List<Integer> slides) { return exclude(file, InputSelection.slides(slides)); }
        public Builder excludeRange(Path file, int first, int last) { return exclude(file, InputSelection.range(first + "-" + last)); }
        public Builder exclude(Path file, InputSelection selection) {
            if (selection.kind() == InputSelection.Kind.TITLES) throw MergeException.invalid("Exclusions require slide numbers or ranges.");
            exclusions.add(new MergeDefinition.Exclusion(Objects.requireNonNull(file), selection)); return this;
        }
        public Builder addRecipe(Path file) { queries.add(new MergeDefinition.Query(null, null, null, Objects.requireNonNull(file))); return this; }
        public MergeJob build() {
            if (sources.isEmpty() && queries.stream().noneMatch(q -> q.file() != null || q.recipe() != null))
                throw MergeException.invalid("Provide source files, a directory, or file-specific selections.");
            return new MergeJob(new MergeDefinition(base, output, sources, queries, exclusions,
                    new MergeDefinition.Options(skipHidden, duplicates, duplicateSources, repeatedSlides, missing, remaining, overwrite)), reporter, operationId);
        }
        public MergePlan plan() { return build().plan(); }
        public MergePlan preview() { return plan(); }
        public MergeResult merge() { return build().merge(); }
        public MergeReport mergeDetailed() { return build().mergeDetailed(); }
    }
}
