package com.mergeslides.api.lib;

import java.nio.file.Path;
import java.util.Objects;

/** Reusable, immutable application defaults; each job and execution has independent state. */
public final class MergeClient {
    private final Path base;
    private final MergeReporter reporter;
    private MergeClient(Path base, MergeReporter reporter) { this.base = base; this.reporter = reporter; }
    public MergeSlides.Builder newJob() { return MergeSlides.builder().baseDirectory(base).reporter(reporter); }
    public static final class Builder {
        private Path base = Path.of("").toAbsolutePath();
        private MergeReporter reporter = MergeReporter.systemLogger();
        public Builder baseDirectory(Path path) { base = Objects.requireNonNull(path).toAbsolutePath().normalize(); return this; }
        public Builder reporter(MergeReporter value) { reporter = Objects.requireNonNull(value); return this; }
        public MergeClient build() { return new MergeClient(base, reporter); }
    }
}
