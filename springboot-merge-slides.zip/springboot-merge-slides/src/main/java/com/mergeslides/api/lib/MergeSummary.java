package com.mergeslides.api.lib;

/** Slide counters refer to source occurrences, except emitted counts which include repetitions. */
public record MergeSummary(int sourceCount, int selectedCount, int remainingCount,
        int hiddenFilteredCount, int excludedCount, int duplicateFilteredCount, int missingTitleCount) {}
