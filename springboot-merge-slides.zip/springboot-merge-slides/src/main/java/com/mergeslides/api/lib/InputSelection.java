package com.mergeslides.api.lib;

import com.mergeslides.domain.MergeException;
import com.mergeslides.domain.SlideSlice;
import java.util.*;

/** Immutable selection. Numeric syntax delegates to the existing SlideSelector. */
public final class InputSelection {
    public enum Kind { ALL, NUMBERS, TITLES }
    private final Kind kind;
    private final Object numbers, within;
    private final List<String> titles;
    private final Boolean skipHidden;
    private final DuplicateTitlePolicy duplicates;

    private InputSelection(Kind kind, Object numbers, List<String> titles, Object within,
            Boolean skipHidden, DuplicateTitlePolicy duplicates) {
        this.kind = kind; this.numbers = freeze(numbers); this.titles = List.copyOf(titles);
        this.within = freeze(within); this.skipHidden = skipHidden; this.duplicates = duplicates;
    }
    public static InputSelection all() { return new InputSelection(Kind.ALL, null, List.of(), null, null, null); }
    public static InputSelection slides(int... values) { return slides(Arrays.stream(values).boxed().toList()); }
    public static InputSelection slides(List<Integer> values) { return numeric(values); }
    public static InputSelection range(String range) { return numeric(Objects.requireNonNull(range)); }
    public static InputSelection slice(SlideSlice slice) { return numeric(Objects.requireNonNull(slice)); }
    public static InputSelection selection(SlideSlice slice) { return slice(slice); }
    public static InputSelection numeric(Object value) { return new InputSelection(Kind.NUMBERS, value, List.of(), null, null, null); }
    public static InputSelection title(String title) { return titles(Collections.singletonList(title)); }
    public static InputSelection titles(String... titles) { return titles(Arrays.asList(titles)); }
    public static InputSelection titles(List<String> titles) {
        if (titles == null || titles.isEmpty() || titles.stream().anyMatch(t -> t == null || t.isBlank()))
            throw MergeException.invalid("Requested titles must be nonblank; whitespace is otherwise significant.");
        return new InputSelection(Kind.TITLES, null, titles, null, null, null);
    }
    public InputSelection skipHidden() { return skipHidden(true); }
    public InputSelection skipHidden(boolean value) { return new InputSelection(kind, numbers, titles, within, value, duplicates); }
    public InputSelection duplicates(DuplicateTitlePolicy value) {
        if (kind != Kind.TITLES) throw MergeException.invalid("duplicateTitles applies only to title selections.");
        return new InputSelection(kind, numbers, titles, within, skipHidden, Objects.requireNonNull(value));
    }
    public InputSelection duplicateTitles(DuplicateTitlePolicy value) { return duplicates(value); }
    public InputSelection within(int... values) { return withinSelection(Arrays.stream(values).boxed().toList()); }
    public InputSelection within(List<Integer> values) { return withinSelection(values); }
    public InputSelection withinRange(String range) { return withinSelection(Objects.requireNonNull(range)); }
    public InputSelection withinSlice(SlideSlice slice) { return withinSelection(Objects.requireNonNull(slice)); }
    public InputSelection withinSelection(Object value) {
        if (kind != Kind.TITLES) throw MergeException.invalid("within applies only to title selections.");
        return new InputSelection(kind, numbers, titles, value, skipHidden, duplicates);
    }
    public Kind kind() { return kind; }
    public Object numbers() { return numbers; }
    public List<String> titles() { return titles; }
    public Object within() { return within; }
    public Boolean skipHiddenOverride() { return skipHidden; }
    public DuplicateTitlePolicy duplicateOverride() { return duplicates; }

    private static Object freeze(Object value) {
        if (value == null || value instanceof Number || value instanceof String || value instanceof SlideSlice || value instanceof Boolean) return value;
        if (value instanceof List<?> list) return Collections.unmodifiableList(list.stream().map(InputSelection::freeze).toList());
        if (value instanceof Map<?, ?> map) {
            var copy = new LinkedHashMap<Object, Object>(); map.forEach((k, v) -> copy.put(k, freeze(v)));
            return Collections.unmodifiableMap(copy);
        }
        throw MergeException.invalid("Unsupported selection value: " + value.getClass().getName());
    }
}
