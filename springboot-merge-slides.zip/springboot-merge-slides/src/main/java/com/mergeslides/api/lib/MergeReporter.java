package com.mergeslides.api.lib;

/** Replaceable event sink. Implementations shared across jobs must be thread safe. */
@FunctionalInterface
public interface MergeReporter {
    void report(MergeEvent event);

    static MergeReporter silent() { return event -> {}; }

    static MergeReporter systemLogger() {
        System.Logger logger = System.getLogger("com.mergeslides");
        return event -> {
            System.Logger.Level level = switch (event.severity()) {
                case DEBUG -> System.Logger.Level.DEBUG;
                case INFO -> System.Logger.Level.INFO;
                case WARN -> System.Logger.Level.WARNING;
                case ERROR -> System.Logger.Level.ERROR;
            };
            String message = "[" + event.operationId() + "] " + event.code() + ": " + event.message();
            if (event.cause() == null) logger.log(level, message);
            else logger.log(level, message, event.cause());
        };
    }
}
