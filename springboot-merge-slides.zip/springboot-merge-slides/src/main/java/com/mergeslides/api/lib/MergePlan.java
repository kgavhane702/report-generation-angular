package com.mergeslides.api.lib;

import java.util.List;

/** Detached preview. A subsequent merge re-reads sources rather than executing stale state. */
public record MergePlan(String operationId, List<PlannedSlide> slides,
        List<MergeDiagnostic> diagnostics, MergeSummary summary) {
    public MergePlan { slides = List.copyOf(slides); diagnostics = List.copyOf(diagnostics); }
}
