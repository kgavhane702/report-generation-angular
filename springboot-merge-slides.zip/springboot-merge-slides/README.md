# Standalone Spring Boot PPTX merger

For the new standalone Java library, title recipes, fluent functions, defaults and diagnostics, see [README-LIBRARY.md](README-LIBRARY.md). The library distribution has no Spring dependency or upload-size limit; this executable remains an optional hosting adapter.

Java implementation of the existing merge workflows, using Spring Boot **3.5.16**, Gradle **8.7**, and Java **17+**. The executable JAR supports a REST server and a CLI. It never calls Python, PowerPoint, LibreOffice, shell commands, or native Office libraries.

The same JAR runs on Windows, Linux, and macOS with a compatible Java runtime. Gradle is needed only to build the source. Production merging does not render slides and does not require installed fonts or Office applications. PowerPoint in the workspace verification reports is an optional test oracle, outside this project and outside the production execution path. Runtime verification in this workspace was performed on Windows; Linux/macOS runtime testing is not claimed.

This project contains source, build/configuration files, and tests. It contains no sample PPTX, images, media, or Python files. Existing inputs remain outside it. Database integration is deliberately excluded.

## Build and run

From this project directory on Windows:

```powershell
.\gradlew.bat clean test bootJar
$env:MERGE_WORKSPACE = (Resolve-Path ..).Path
java -jar build/libs/merge-slides.jar
```

On Linux/macOS, from this project directory:

```sh
sh ./gradlew clean test bootJar
export MERGE_WORKSPACE="$(cd .. && pwd)"
java -jar build/libs/merge-slides.jar
```

Server: `http://localhost:8080`. Health: `GET /actuator/health`. Set `PORT` or `--server.port=18087` to change the port. The JAR includes Spring and its embedded HTTP server; no separately installed application server is needed.

Copy the built JAR to production, provide Java 17+, and set `MERGE_WORKSPACE` to the external data directory. Gradle, this source project, and the original Python script are unnecessary at runtime. Use paths appropriate to the destination machine; relative recipe paths can use forward slashes on every OS. Legacy backslashes in recipe paths are also accepted. Windows drive letters do not designate Linux/macOS paths.

## CLI

Use the `merge` subcommand to run a single operation and exit without starting Spring's HTTP server. These examples run from the project directory and write beside the existing `output/` folder:

```powershell
# All 58 single-slide presentations in natural filename order.
java -jar build/libs/merge-slides.jar merge -d ../splitted_ppt -o ../springboot-oupt/examples/all-split.pptx

# Two whole presentations, in the supplied order.
java -jar build/libs/merge-slides.jar merge -i ../multi_slide_ppt/part_02.pptx ../multi_slide_ppt/part_01.pptx -o ../springboot-oupt/examples/two-decks.pptx

# Reorder, repeat, and select inclusive ranges.
java -jar build/libs/merge-slides.jar merge -i "../multi_slide_ppt/part_01.pptx:11,3,8,1,3" "../multi_slide_ppt/part_02.pptx:2-4" -o ../springboot-oupt/examples/reordered.pptx

# Existing JSON recipe; paths inside it are relative to its own directory.
java -jar build/libs/merge-slides.jar merge -r "../Merge Slide/recipes_archive/recipes/01_your_custom_order_7_slides.json" -o ../springboot-oupt/examples/recipe.pptx
```

Supports positional paths and the aliases `-i/--inputs`, `-d/--dir`, `-r/-c/--recipe/--config`, `-o/--output`, and `-h/--help`. Select exactly one input mode. Files, folders, and JSON recipes can be mixed through ordered inputs. Folder expansion is nonrecursive, naturally sorted (`slide1`, `slide2`, `slide10`), case-insensitive for `.pptx`, and skips Office `~$` lock files and the destination.

Explicit CLI input/output paths resolve against the current working directory. With no inputs, use `MERGE_WORKSPACE/ppts`, falling back to the workspace itself. If the environment variable is absent, CLI discovers a `ppts` folder in the current directory or uses its parent. The default output is `merged_output_autonomous.pptx` in the working directory. Prefer explicit paths for production. Errors print to stderr and return exit code **2**; successful merges return **0**.

## REST

`POST /api/v1/merges` accepts JSON with exactly one of `inputs` or `recipePath`, and a required `output`:

```json
{
  "inputs": [
    {"file": "multi_slide_ppt/part_01.pptx", "slides": [11, 3, 8, 1, 3]},
    {"path": "multi_slide_ppt/part_02.pptx", "range": "2-4", "skip_hidden": true}
  ],
  "output": "springboot-oupt/rest/reordered.pptx"
}
```

Folders are valid input paths. A saved recipe request uses `{"recipePath":"path/to/recipe.json","output":"path/to/output.pptx"}`. Server input/output paths resolve against `MERGE_WORKSPACE` (default `..`); absolute native paths are accepted. Recipe entries resolve against the recipe's own directory. A response contains `outputPath`, `slideCount`, `warnings`, and `elapsedMillis`.

Windows request example, from the workspace containing the external presentations:

```powershell
$body = @{ inputs = @('splitted_ppt'); output = 'springboot-oupt/rest/all-split.pptx' } | ConvertTo-Json
Invoke-RestMethod -Uri http://localhost:8080/api/v1/merges -Method Post -ContentType application/json -Body $body
```

`POST /api/v1/merges/upload` accepts repeated multipart fields named `files` and an optional text field named `recipe`. It returns the merged PPTX as an attachment with `X-Merge-Slide-Count` and `X-Merge-Warning-Count` headers. Warning details are logged. Upload order is retained without a recipe. A recipe is a top-level JSON list using the uploaded filenames, which must be unique; it cannot refer to server paths.

```powershell
curl.exe --fail -o springboot-oupt/uploaded.pptx -F "files=@splitted_ppt/slide_02.pptx" -F "files=@splitted_ppt/slide_01.pptx" http://localhost:8080/api/v1/merges/upload
```

On Linux/macOS use `curl` in place of `curl.exe`. The optional `recipe` text field supports, for example, `[{"file":"slide_02.pptx","slides":[1,1]},{"file":"slide_01.pptx"}]`. Uploads and output are staged outside the source project and removed after streaming or failure. Set `MERGE_TEMP_DIR` to change staging storage. Upload limits default to 100 MB per file and 512 MB per request; configure `MERGE_UPLOAD_FILE_LIMIT` and `MERGE_UPLOAD_REQUEST_LIMIT` as needed.

Errors use `{ "code": "...", "message": "..." }`: invalid requests **400**, missing inputs **404**, invalid PPTX packages **422**, write failures **500**, oversized uploads **413**.

## Recipes and selections

Existing UTF-8 JSON recipes, including BOM-prefixed files, are unchanged: a top-level list containing path strings, `"deck.pptx:3,1"`, arrays such as `["deck.pptx", [3,1], true]`, or objects with `file`/`path`, `slides`/`range`, and `skip_hidden`. Directory entries apply their selection to every expanded presentation.

| Selection | Meaning |
| --- | --- |
| omitted, `null`, `"all"`, `"*"` | All slides |
| `3`, `[3,1,3]` | One-based picks, ordered, including repeats |
| integer `-1` | Last slide |
| `"2-5,8"` | Inclusive ascending range and slide 8 |
| `"5-"`, `"-3"` | Slide 5 through end; first three slides |
| `[5,4,3]` | Reverse picks |
| `{"slice":{"start":null,"stop":null,"step":-1}}` | Reverse all slides using zero-based slicing |

Java callers can use `SlideSlice(start, stop, step)` with nullable bounds. Zero steps, boolean slide numbers, zero individual picks, and out-of-range individual picks fail. Ranges clamp to bounds; descending ranges select nothing. Empty final selections fail without replacing any existing output. Hidden slides are retained unless `skip_hidden` is true.

Legacy compatibility: falsy object `slides` values (`[]`, `""`, `0`, `false`) fall back to `range`, then all slides if it is absent. Array input specifications preserve their exact selection: `["deck.pptx", []]` selects none and `["deck.pptx", 0]` fails.

## Architecture and package behavior

- `api`: thin Spring MVC controllers, request/response records, centralized error mapping.
- `application`: reusable `MergeService` interface and upload lifecycle service.
- `domain`: framework-independent input/result records, errors, and slide selection.
- `infrastructure.input`: legacy recipe normalization, portable paths, folder expansion, natural sorting.
- `infrastructure.ooxml`: reader/validator, dependency graph importer, metadata merger, presentation assembler, atomic writer.
- `cli`: CLI argument parsing that uses the same merge engine.
- `config`: Spring dependency wiring. The CLI wires these Java components directly to avoid starting a web context for a batch operation.

Relationship/content-type enums, OOXML namespaces, package paths, policy defaults, and ID bounds are centralized in `Ooxml`; application errors use `ErrorCode`. All mutable source/merge state belongs to one invocation. Singleton services do not retain packages or mappings between requests. XML parsers/serializers are isolated per thread.

The engine follows the complete source relationship graph. It preserves supplied native charts/workbooks, SmartArt, pictures, audio/video, OLE, layouts/themes, notes, classic comments, external links, sections, and custom table styles. Shared dependency graphs deduplicate only when their complete graph matches, including root identity. Distinct slide masters keep separate theme parts. Repeated slide instances receive independent mutable charts, embeddings, comments, and notes. Internal links remap to selected outputs; omitted targets are removed with warnings. Self-links follow their own instance; links to repeated targets use the first occurrence. Base custom shows retain selected entries.

Inputs and staged output are validated for CRC, XML, content types, references, IDs, layout registrations, and comment authors. Known unreferenced recovery trash is discarded. Sources cannot be overwritten, including hard links. The writer validates a temporary ZIP beside the destination and atomically replaces the output only after success. Failed merges preserve any existing output and clean staging files.

Existing policies remain: the richest source supplies the one presentation-wide slide canvas; mixed-size slides are not scaled and produce warnings. Source notes retain text/shapes but inherit the selected shared notes master. Only non-macro transitional OOXML `.pptx` is supported; binary `.ppt`, encrypted, macro-enabled, and digitally signed packages are unsupported. The existing fixtures do not establish every third-party extension, every SmartArt/chart variant, modern threaded comments, Zoom/Morph, or 3D behavior. Filesystem writes require normal permissions and support for atomic replacement.

## Verification

`test` runs self-contained Java unit/MVC tests using packages generated in temporary directories. No fixtures are bundled.

```powershell
.\gradlew.bat test integrationTest bootJar
```

`integrationTest` reproduces the 43 existing scenarios using external fixtures and the existing external baseline report. It uses Java only and checks ordered slide markup, native binary hashes, package integrity, sections, expected rejections, and all 87 original source hashes. These optional tests skip when the original workspace baseline is absent after copying the source project.

Configure another fixture workspace/output location with `-PmergeWorkspace=/path/to/workspace -PmergeResults=/path/to/results`. The default integration output is **`../springboot-oupt/`**, a sibling of the existing `output/` directory. Independent command logs and validation receipts are saved per scenario.

Optional native visual verification tools and previews are stored under that external results folder. They are not shipped in the application JAR or source-only archive. They are unnecessary for production. Performance depends on package sizes, ZIP compression, filesystem, JVM startup/warmup, and concurrency; see the measured external benchmark report instead of assuming Java is always faster.

Completed workspace verification: **22 unit/MVC tests**, **43/43 external scenarios**, **38/38 native PowerPoint opens**, **16/16 pixel-identical advanced slides**, and **3/3 business-slide comparisons matching outside correctly updated slide numbers**. All 87 original source files remained unchanged. Gradle ran on Java 21; the test launcher ran on Java 17.0.12, and the distributable class version is 61 (Java 17).

The three-trial fresh-CLI benchmark on this Windows machine measured the 58-file split-folder merge at a median **17.10 s in Java versus 21.66 s in Python** (about 21% less wall time). Small cold CLI jobs were slower in Java: the five-slide reorder measured **6.85 s versus 3.06 s**. These are workload-specific measurements, not a general speed guarantee.

### Downloaded complex-sample regression suite

Eight public samples from the Apache POI and Aspose Java example repositories are stored externally under `../springboot-oupt/internet-complex-review/`. They contain 20 slides covering native SmartArt (including rotated text), a multi-slide effects/media demo, layered pictures, OLE embeddings, charts with embedded workbooks, video, and animation/audio. Some are focused one-slide feature fixtures. Their exact upstream URLs, pinned commit IDs, feature inventories, and SHA-256 hashes are in the external `sources-manifest.json`; none are bundled in this project or its JAR.

```powershell
.\gradlew.bat internetTest
```

Use `-PinternetSamples=/path/to/external/review-folder` to configure another download location. The task skips when those external files are unavailable; it does not access the network or launch Office. Its 26 JUnit cases perform **46 merge operations**: identity merges, **20 individual slide splits**, natural-order reassembly, recipe reversal/repetition, and merging all eight originals and all splits. It independently checks slide markup/order, ZIP CRCs, content types, relationship targets, binary dependency hashes, and unchanged source checksums.

Optional external PowerPoint QA opened all **46 generated outputs**, rendered **128 output slides**, and obtained exact pixel matches on all **90 comparisons with matching canvases**. The remaining 38 slides belong to combined decks with different source canvas sizes; they are rendered/opened but are not asserted pixel-identical to their individual originals, following the documented no-scaling policy. Separately, all **20 PNG exports of the direct eight-deck merge were byte-identical to the exports of the all-split reassembly**, using their shared canvas. Native SmartArt/chart/table/OLE/media object counts matched on all 20 original/reassembled slides. Actual HTTP JSON and multipart-upload requests were also run for all eight samples: all 16 outputs matched the SHA-256 of the audited identity merges. These checks do not activate OLE or establish interactive playback/animation timing.

This suite identified ambiguous diagnostics when split folders reuse filenames such as `slide_001.pptx`. Warnings now use full source paths when filenames collide, retaining distinct warnings for distinct sources. A self-contained regression test covers that case. The package-copying behavior remains unchanged.
