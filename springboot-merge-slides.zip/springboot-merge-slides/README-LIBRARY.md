# Merge Slides Java library

Java 17+ library for valid, non-macro transitional OOXML `.pptx` files. Spring and Microsoft PowerPoint are not required. Python files are unchanged. The existing server/CLI remains optional.

## Build and installation

```powershell
.\gradlew.bat test integrationTest internetTest bootJar libraryDist standaloneSmokeTest
```

- `build/libs/merge-slides-library-1.0.0.jar`: normal library JAR.
- `build/distributions/merge-slides-library-1.0.0-distribution.zip`: library, Jackson dependencies, sources/Javadoc, Maven POM, examples and schema.
- `build/libs/merge-slides.jar`: optional runnable server/CLI.

Use every JAR in the distribution's `lib/` directory. Only Jackson Databind and its transitive dependencies are required externally. There is no Spring or logging backend requirement, and the build publishes nothing externally.

After extracting the distribution, compile `examples/LibraryExample.java` with `javac --release 17 -cp "lib/*" -d classes examples/LibraryExample.java`. Run it on Windows with `java -cp "classes;lib/*" LibraryExample INPUT.pptx OUTPUT.pptx`; on Linux/macOS use `"classes:lib/*"` as the classpath.

For the full commented, function-only workspace demo, run `.\gradlew.bat runFunctionScenarios` (or the earlier `runTemporaryScenarios` task name). The single main is `examples/FunctionScenarioMain.java`, class `com.mergeslides.demo.FunctionScenarioMain`. Its successful PPTX files, copied source, scenario report, event log, title inventory and slide-order report are written directly to the workspace's `function_pptx` folder. Use `-PscenarioWorkspace="C:/path/to/workspace"` to select another copy of the required workspace inputs. The examples document expected warnings/errors and assert their exact diagnostic codes. Reruns replace the named demo outputs; source presentations are read only.

The distribution also includes this runner. Compile it with `javac --release 17 -cp "lib/*" -d classes examples/FunctionScenarioMain.java`, then run `java -cp "classes;lib/*" com.mergeslides.demo.FunctionScenarioMain "C:/path/to/workspace"` on Windows (use `classes:lib/*` on Linux/macOS). Its workspace inputs are not bundled in the distribution.

## Simple function call

```java
import com.mergeslides.api.lib.*;
import java.nio.file.Path;

var result = MergeSlides.builder()
    .addFiles(Path.of("a.pptx"), Path.of("b.pptx"))
    .output(Path.of("merged.pptx"))
    .merge();
```

Existing destinations fail by default; use `.overwrite(true)` to replace them. An input presentation can never be the output, even with overwrite enabled.

## Sources and selections

`searchFiles`/`searchDirectory` register an ordered search pool. `addFile`, `addFiles`, `addDirectory`, and `addAll(List<MergeInput>)` append explicit input occurrences with bound selections. Repeated inputs do not create a cross-product of their selections.

`selectFile` and file-specific `addTitle/addTitles/addSlides` helpers query matching pool occurrences; an absent file is registered once. File paths must resolve correctly: there is no basename search elsewhere.

```java
var job = MergeSlides.builder()
    .searchFiles(Path.of("a.pptx"), Path.of("b.pptx"))
    .addTitles("Introduction", "Roadmap")
    .selectFile(Path.of("a.pptx"),
        InputSelection.title("Revenue").withinRange("2-8").skipHidden())
    .selectFile(Path.of("b.pptx"), InputSelection.slides(3, 1, 3))
    .excludeRange(Path.of("a.pptx"), 10, 12)
    .output(Path.of("merged.pptx"))
    .build();

var preview = job.plan();        // No output required or written.
var report = job.mergeDetailed();
var result = report.result();    // Existing MergeResult shape.
```

Choose `merge()` or `mergeDetailed()`; each executes a merge. Preview is detached metadata; merging re-reads current sources. Clients and built jobs are immutable/reusable. Builders are mutable; caller collections are copied. Reporter implementations shared between threads must be thread safe.

Directories expand nonrecursively in natural filename order, ignoring non-PPTX files, Office lock files and the destination. Every explicit source must be valid. A missing file/directory or directory with no usable PPTX files fails even when other sources are valid.

## Selection functions

```java
InputSelection.all();
InputSelection.slides(7, 3, 7);
InputSelection.range("2-5,8");
InputSelection.slice(new com.mergeslides.domain.SlideSlice(null, null, -1));
InputSelection.title("Revenue");
InputSelection.titles("Revenue", "Conclusion");
InputSelection.title("Revenue").within(1, 2, 5);
InputSelection.title("Revenue").withinRange("2-8");
InputSelection.title("Revenue").duplicates(DuplicateTitlePolicy.LAST);
InputSelection.range("2-8").skipHidden();
InputSelection.slides(4).skipHidden(false);
```

Picks are one-based; negative integers count from the end. Ranges are inclusive and clamp to bounds; slices retain zero-based Python-style behavior. Invalid individual picks and a zero slice step fail. Valid empty ranges/slices select nothing.

`within` filters title candidates independently per file. It does not reorder matches or exclude other slides from remaining output. Repeated candidate numbers do not duplicate matches. Omitted means unrestricted; an empty list means no candidates.

Titles match exactly, ignoring case only. Spaces, punctuation, accents and line breaks remain significant. No trimming, whitespace collapsing, fuzzy matching or Unicode normalization occurs. Only actual title/centered-title placeholders are read, including layout-inherited identification. The first nonblank title placeholder is used; text runs add no artificial spaces. Body text, notes, filenames, shape names and images are not fallback titles. Untitled slides remain eligible for numeric/remaining selection.

## Defaults and precedence

| Setting | Default | Alternatives |
|---|---|---|
| `skipHidden` | false | No-argument method sets true; local overrides global |
| `duplicateTitles` | ALL | FIRST, LAST, ERROR |
| `duplicateSources` | ALLOW | SKIP, ERROR |
| `repeatedSlides` | ALLOW | SKIP, ERROR |
| `onMissing` | SKIP with warning | ERROR |
| `remainingSlides` | END | START, NONE |
| `overwrite` | false | true |

Global setters affect the entire job, regardless of call position; the last value wins. Hard numeric/range exclusions always win across inclusion methods and repeated source occurrences. Exclusions cannot introduce sources. Filtering never renumbers source slides.

Hidden candidates filtered locally cannot return through remaining slides. Other hidden slides follow the global policy. Another explicit selection allowing hidden slides can restore a locally filtered slide; hard exclusions still win.

Selections preserve requested order. Remaining slides preserve source/slide order and include untitled slides and alternatives left by FIRST/LAST. Selected occurrences are not automatically appended again. Intentional repetitions remain allowed. `repeatedSlides(SKIP)` retains the first physical slide in final output order.

No selectors means all eligible source slides, even with remaining NONE. With selectors, NONE means only requested output. Missing titles skip and warn in both global and file scopes. Empty final output is an error.

## Diagnostics and your application's logger

```java
var client = MergeSlides.client()
    .baseDirectory(Path.of("presentations"))
    .reporter(event -> {
        // Route to YOUR logger: severity(), code(), operationId(), stage(), message(), cause().
        System.out.println(event.operationId() + " " + event.code() + " " + event.message());
    }).build();

try {
    var report = client.newJob().addTitle(Path.of("a.pptx"), "Revenue")
        .output(Path.of("merged.pptx")).mergeDetailed();
    report.diagnostics().forEach(d -> System.out.println(d.code()));
} catch (com.mergeslides.domain.MergeException error) {
    // Inspect failureCode(), stage(), operationId(), diagnostics(), getCause(); never parse messages.
    throw error;
}
```

The default reporter uses the JDK logger; a custom reporter replaces it. `MergeReporter.silent()` suppresses reporting without losing diagnostics. Reporter failure records REPORTER_FAILED and disables that reporter for this invocation, with no unexpected fallback logger. Preview does not log warnings. Each execution gets a fresh operation ID unless supplied explicitly.

`MergeResult.warnings()` remains a string list. Detailed reports add typed diagnostics, summary counts and executed slide metadata. Exceptions include prior warnings and the terminal failure. The library does not configure logging backends, global levels, MDC, HTTP or application quotas.

| Situation | Outcome |
|---|---|
| Missing title or title matching only filtered slides | Skip request and warn |
| Configured hidden filtering, exclusions, duplicate SKIP | Silent skip; reflected in counts |
| Allowed duplicates | Normal processing |
| Missing/empty source, corrupt PPTX, invalid selection, strict-policy violation | Typed failure |
| Empty final output | NO_ELIGIBLE_SLIDES |
| Existing destination without overwrite | OUTPUT_EXISTS |
| Mixed canvas sizes or removed links to omitted slides | Preservation warning |

## Recipes and CLI

See `examples/title-recipe.json` and `docs/recipe-v2.schema.json`. V2 has sources, select, exclude and options. Title strings search the known pool. Numeric selectors require a file.

```java
MergeSlides.builder().addRecipe(Path.of("recipe.json"))
    .output(Path.of("merged.pptx")).merge();
```

Recipe paths resolve from the recipe's folder. Explicit builder options override a sole loaded recipe. Recipes mixed with other inputs contribute independent ordered selection chunks; ordinary sources stay in their own pool.

Legacy arrays preserve selection-only behavior, aliases, UTF-8 BOM support and replacement policy. They do not gain remaining slides; title fields inside them require migration to v2.

```powershell
java -jar build/libs/merge-slides.jar merge -r recipe.json -o merged.pptx
java -jar build/libs/merge-slides.jar merge -r recipe.json -o merged.pptx --overwrite
```

`--overwrite`/`--no-overwrite` override destination policy. Existing legacy CLI forms remain valid.

## Optional HTTP adapter

`/api/v1/merges` accepts exactly one of inputs, recipePath, or inline recipe, plus output. Existing success fields remain unchanged. Multipart supports legacy/v2 recipes, unique filenames and uploaded-file references only. V2 defaults its pool to upload order when sources are omitted.

Scoped controller advice provides safe errors with operation IDs, failure codes and stages. HTTP logging/MDC and the SLF4J bridge are excluded from the library JAR. Transfer failures after headers are committed are logged and cleaned up; they cannot be converted to a JSON response.

Upload limits, media types, request timeouts and logging configuration belong to the application. Direct library calls impose no file-size/upload cap; practical capacity depends on heap and disk. The supplied server retains configurable MERGE_UPLOAD_FILE_LIMIT and MERGE_UPLOAD_REQUEST_LIMIT.

## Output and portability

The Java implementation targets Windows/Linux/macOS; paths must be valid for the current OS. Sources are read only. Corrupt packages fail ZIP/CRC/XML/content-type/relationship/ID validation before output publication.

Create-only output links validated same-directory staging to the destination, preventing replacement by competing writers. Overwrite uses the existing atomic move. Filesystem support is required; unsupported safe commits fail without an unsafe fallback. Existing output survives merge failure. Cleanup failure after commit is a warning.

Existing format/canvas limitations remain: no binary `.ppt`, macro-enabled/encrypted/signed packages, OCR or automatic canvas scaling. Native-object coverage is defined by regression fixtures, not every third-party extension.
