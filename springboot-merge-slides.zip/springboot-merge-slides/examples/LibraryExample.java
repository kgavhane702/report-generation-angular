import com.mergeslides.api.lib.*;
import com.mergeslides.domain.MergeException;
import java.nio.file.Path;

/** Compile/run using only the library and lib/*.jar dependencies from the distribution. */
public final class LibraryExample {
    public static void main(String[] args) {
        if (args.length != 2) throw new IllegalArgumentException("Usage: LibraryExample INPUT.pptx OUTPUT.pptx");
        Path input = Path.of(args[0]);
        MergeClient client = MergeSlides.client().reporter(event -> {
            if (event.severity() != Severity.DEBUG)
                System.out.println(event.operationId() + " " + event.code() + " " + event.message());
        }).build();
        try {
            MergeJob job = client.newJob().searchFiles(input)
                    .selectFile(input, InputSelection.slides(1))
                    .remainingSlides(RemainingSlides.NONE)
                    .output(Path.of(args[1])).overwrite(true).build();
            System.out.println("Preview slides: " + job.plan().slides().size());
            MergeReport report = job.mergeDetailed();
            System.out.println("Created " + report.result().outputPath() + " with " + report.result().slideCount() + " slide(s)");
        } catch (MergeException error) {
            System.err.println("Failure " + error.failureCode() + " at " + error.stage() + "; operation " + error.operationId());
            throw error;
        }
    }
}
