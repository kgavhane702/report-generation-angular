package com.mergeslides.infrastructure.ooxml;

import java.util.*;

/** Ordered Java configuration for untagged heading shape names. Real title placeholders always win. */
public final class SlideTitleRulesConfig {
    private SlideTitleRulesConfig() {
    }

    /** Highest-priority fallback first. Add template-specific names above the generic names. */
    public static List<Rule> rules() {
        return List.of(header("db-Heading"), section("db-Section Title"), header("Title"), header("Titel"),
                header("Heading"), section("Section Title"), section("Section Titel"), section("Section Heading"),
                header("*-Title"), header("*-Titel"), header("*-Heading"), header("*_Title"), header("*_Titel"),
                header("*_Heading"), section("*-Section Title"), section("*-Section Titel"),
                section("*-Section Heading"), section("*_Section Title"), section("*_Section Titel"),
                section("*_Section Heading"));
    }

    /** A named header must start within the upper quarter of the slide. */
    public static Rule header(String shapeName) {
        return new Rule(shapeName, Region.HEADER);
    }

    /** A named section-divider title may start within the upper two thirds of the slide. */
    public static Rule section(String shapeName) {
        return new Rule(shapeName, Region.SECTION);
    }

    public enum Region {
        HEADER(0.25), SECTION(2.0 / 3);

        private final double maxTopFraction;

        Region(double maxTopFraction) {
            this.maxTopFraction = maxTopFraction;
        }

        double maxTopFraction() {
            return maxTopFraction;
        }
    }

    /** Case-insensitive shape name, optional numeric suffix; '*' is the only wildcard. */
    public record Rule(String shapeName, Region region) {
        public Rule {
            shapeName = Objects.requireNonNull(shapeName, "shapeName").strip();
            Objects.requireNonNull(region, "region");
            if (shapeName.replace("*", "").isBlank())
                throw new IllegalArgumentException(
                        "A specific heading shape name is required; '*' alone is not allowed.");
        }
    }
}
