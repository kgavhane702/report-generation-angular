package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

/** Reads one existing heading line, preferring title placeholders over named header text boxes. */
final class SlideTitleReader {
    private final SlideTitleRules rules;

    SlideTitleReader() {
        this(SlideTitleRules.defaults());
    }

    SlideTitleReader(SlideTitleRules rules) {
        this.rules = Objects.requireNonNull(rules);
    }

    String title(PackageDocument source, int index) {
        Element slide = source.slideXml(index), layout = null;
        for (var rel : source.rels(source.slides.get(index)).values())
            if (rel.getAttribute("Type").equals(RelationshipType.SLIDE_LAYOUT.uri()))
                layout = source.xml.get(PackagePaths.resolve(source.slides.get(index), rel.getAttribute("Target")));
        List<Element> shapes = Xml.findAll(slide, P, "sp");
        for (Element shape : shapes) {
            if (hidden(shape))
                continue;
            Element ph = placeholder(shape);
            if (ph == null)
                continue;
            String type = ph.getAttribute("type");
            if (type.isEmpty() && layout != null) {
                String id = ph.hasAttribute("idx") ? ph.getAttribute("idx") : "0";
                for (Element candidate : Xml.descendants(layout)) {
                    if (!Xml.is(candidate, P, "sp"))
                        continue;
                    Element inherited = placeholder(candidate);
                    if (inherited != null
                            && id.equals(inherited.hasAttribute("idx") ? inherited.getAttribute("idx") : "0")) {
                        type = inherited.getAttribute("type");
                        break;
                    }
                }
            }
            if (!Set.of("title", "ctrTitle").contains(type))
                continue;
            String title = heading(shape);
            if (title != null)
                return title;
        }
        return namedHeader(source, shapes);
    }

    private String namedHeader(PackageDocument source, List<Element> shapes) {
        Element size = Xml.child(source.xml.get(PRESENTATION), P, "sldSz");
        double width = number(size, "cx"), height = number(size, "cy");
        if (width <= 0 || height <= 0)
            return null;
        String best = null;
        int bestPriority = Integer.MAX_VALUE;
        double bestY = Double.POSITIVE_INFINITY;
        boolean ambiguous = false;
        for (Element shape : shapes) {
            // Untagged group children need group-coordinate resolution; never guess their placement.
            if (!(shape.getParentNode() instanceof Element parent) || !Xml.is(parent, P, "spTree")
                    || placeholder(shape) != null || hidden(shape))
                continue;
            Element identity = Xml.child(Xml.child(shape, P, "nvSpPr"), P, "cNvPr");
            String name = identity == null ? "" : identity.getAttribute("name").strip();
            Element transform = Xml.child(Xml.child(shape, P, "spPr"), A, "xfrm");
            Element offset = Xml.child(transform, A, "off"), extent = Xml.child(transform, A, "ext");
            if (offset == null || extent == null || !offset.hasAttribute("x") || !offset.hasAttribute("y"))
                continue;
            double x = number(offset, "x"), y = number(offset, "y");
            double shapeWidth = number(extent, "cx"), shapeHeight = number(extent, "cy");
            if (shapeWidth <= 0 || shapeHeight <= 0 || x >= width || x + shapeWidth <= 0 || y + shapeHeight <= 0
                    || y < -height / 50)
                continue;
            int priority = rules.priority(name, y / height);
            if (priority < 0)
                continue;
            String title = heading(shape);
            if (title == null)
                continue;
            if (priority < bestPriority || (priority == bestPriority && y < bestY)) {
                best = title;
                bestPriority = priority;
                bestY = y;
                ambiguous = false;
            } else if (priority == bestPriority && y == bestY && !title.equals(best))
                ambiguous = true;
        }
        return ambiguous ? null : best;
    }

    private String heading(Element shape) {
        Element body = Xml.child(shape, P, "txBody");
        for (Element paragraph : Xml.children(body)) {
            if (!Xml.is(paragraph, A, "p"))
                continue;
            var runs = new ArrayList<HeadingRun>();
            for (Element element : Xml.descendants(paragraph)) {
                if (Xml.is(element, A, "br")) {
                    String line = line(runs);
                    if (line != null)
                        return line;
                    runs.clear();
                } else if (Xml.is(element, A, "t")) {
                    Element properties = Xml.child((Element) element.getParentNode(), A, "rPr");
                    boolean footnote = number(properties, "baseline") > 0
                            && element.getTextContent().matches("[\\d\\s*†‡,]+");
                    String[] lines = element.getTextContent().split("\\R", -1);
                    for (int i = 0; i < lines.length; i++) {
                        if (i > 0) {
                            String line = line(runs);
                            if (line != null)
                                return line;
                            runs.clear();
                        }
                        runs.add(new HeadingRun(lines[i], footnote));
                    }
                }
            }
            String line = line(runs);
            if (line != null)
                return line;
        }
        return null;
    }

    private String line(List<HeadingRun> runs) {
        int end = runs.size();
        while (end > 0 && (runs.get(end - 1).footnote || runs.get(end - 1).text.isBlank()))
            end--;
        // Keep a title made entirely of superscript text; only remove a trailing reference after real text.
        if (end == 0)
            end = runs.size();
        var text = new StringBuilder();
        for (int i = 0; i < end; i++)
            text.append(runs.get(i).text);
        String title = text.toString().strip();
        return title.isBlank() ? null : title;
    }

    private boolean hidden(Element shape) {
        Element identity = Xml.child(Xml.child(shape, P, "nvSpPr"), P, "cNvPr");
        return identity != null
                && Set.of("1", "true").contains(identity.getAttribute("hidden").toLowerCase(Locale.ROOT));
    }

    private double number(Element element, String attribute) {
        try {
            return element == null ? 0 : Double.parseDouble(element.getAttribute(attribute));
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private Element placeholder(Element shape) {
        Element properties = Xml.child(shape, P, "nvSpPr");
        if (properties == null)
            return null;
        Element nv = Xml.child(properties, P, "nvPr");
        return nv == null ? null : Xml.child(nv, P, "ph");
    }

    private record HeadingRun(String text, boolean footnote) {
    }
}
