package com.mergeslides.infrastructure.ooxml;

import java.util.*;
import java.util.regex.Pattern;

/** Compiles an immutable snapshot of the ordered Java heading configuration. */
final class SlideTitleRules {
    private final List<Rule> rules;

    SlideTitleRules(List<SlideTitleRulesConfig.Rule> definitions) {
        var rules = new ArrayList<Rule>();
        var names = new HashSet<String>();
        for (var definition : List.copyOf(definitions)) {
            String name = definition.shapeName();
            if (!names.add(name.toLowerCase(Locale.ROOT)))
                throw new IllegalArgumentException("Duplicate slide title shape-name rule: " + name);
            String pattern = String.join(".*", Arrays.stream(name.split("\\*", -1)).map(Pattern::quote).toList())
                    + "(?:\\s+\\d+)?";
            rules.add(new Rule(Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE),
                    definition.region().maxTopFraction()));
        }
        this.rules = List.copyOf(rules);
    }

    static SlideTitleRules defaults() {
        return new SlideTitleRules(SlideTitleRulesConfig.rules());
    }

    int priority(String name, double topFraction) {
        for (int index = 0; index < rules.size(); index++) {
            Rule rule = rules.get(index);
            if (topFraction <= rule.maxTop && rule.name.matcher(name).matches())
                return index;
        }
        return -1;
    }

    private record Rule(Pattern name, double maxTop) {
    }
}
