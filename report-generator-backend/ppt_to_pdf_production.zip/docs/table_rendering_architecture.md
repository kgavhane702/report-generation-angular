# OpenXML Table Architecture & Styling Reference

This guide provides a comprehensive technical reference for the OpenXML Table parsing, styling, and rendering pipeline in the `ppt-to-pdf` conversion engine. It explains how tables, table styles (`tableStyles.xml`), background fills, margins, and text alignments are resolved and rendered.

---

## 1. Overview of the Table Pipeline

```mermaid
flowchart TD
    A["DrawingML Graphic Frame (<a:tbl>)"] --> B["TableParser (ppt_to_pdf/openxml/table_parser.py)"]
    TS["ppt/tableStyles.xml"] --> B
    CE["ColorEngine (ppt_to_pdf/openxml/color_resolver.py)"] --> B
    TP["TextParser (ppt_to_pdf/openxml/text_parser.py)"] --> B
    
    B --> C["TableModel & TableCellModel (ppt_to_pdf/core/models.py)"]
    
    C --> D["TableRenderer (ppt_to_pdf/renderers/table_renderer.py)"]
    TL["TextLayouter (ppt_to_pdf/typography/text_layouter.py)"] --> D
    
    D --> E["Vector PDF Canvas (mupdf_canvas.py)"]
```

---

## 2. Table Style Resolution (`tableStyles.xml`)

In OpenXML PowerPoint presentations, tables inherit formatting from built-in or custom table styles defined in `ppt/tableStyles.xml`.

### 2.1 Table Style Identification
Every table defines its style identifier and conditional formatting flags inside `<a:tblPr>`:
```xml
<a:tblPr firstRow="1" bandRow="1" firstCol="0" lastCol="0">
    <a:tableStyleId>{073A0DAA-6AF3-43AB-8588-CEC1D06C72B9}</a:tableStyleId>
</a:tblPr>
```

### 2.2 Cascading Style Section Priority
When resolving a cell at `(row, col)` with dimensions `(num_rows, num_cols)`, `TableParser` checks conditional sections in the following precedence:

| Priority | Condition | Style Section Name | Description |
|---|---|---|---|
| **1 (Direct)** | `<a:tcPr><a:solidFill>` present on cell | *Direct Cell Override* | Direct cell fill takes absolute priority. |
| **2** | `row == 0` and `firstRow == 1` | `firstRow` | Header row styling. |
| **3** | `row == num_rows - 1` and `lastRow == 1` | `lastRow` | Summary/footer row styling. |
| **4** | `col == 0` and `firstCol == 1` | `firstCol` | Left index column styling. |
| **5** | `col == num_cols - 1` and `lastCol == 1` | `lastCol` | Right summary column styling. |
| **6** | `bandRow == 1` and `row % 2 == 1` | `band1H` | Alternating odd horizontal band. |
| **7** | `bandRow == 1` and `row % 2 == 0` | `band2H` | Alternating even horizontal band. |
| **8** | `bandCol == 1` and `col % 2 == 1` | `band1V` | Alternating odd vertical band. |
| **9** | `bandCol == 1` and `col % 2 == 0` | `band2V` | Alternating even vertical band. |
| **10 (Fallback)** | Any other cell | `wholeTbl` | Default table body styling. |

---

## 3. DrawingML Color Transforms & Gamma Decoding

In ISO/IEC 29500-1 OpenXML DrawingML specifications, tint, shade, and luminance transforms operate in **linear color space**. When converting to display/PDF sRGB, gamma compensation must be applied.

### 3.1 Tint Formula with sRGB Gamma Decoding
```python
# Linear blending with white (1.0)
r_lin = r * tint + (1.0 - tint)
g_lin = g * tint + (1.0 - tint)
b_lin = b * tint + (1.0 - tint)

# Standard sRGB gamma compensation (gamma = 2.2)
r_srgb = (r_lin ** (1.0 / 2.2)) if r_lin > 0 else 0.0
g_srgb = (g_lin ** (1.0 / 2.2)) if g_lin > 0 else 0.0
b_srgb = (b_lin ** (1.0 / 2.2)) if b_lin > 0 else 0.0
```

- **Example**: A 20% tint (`tint="20000"`) on dark scheme color `dk1` (`#000000`):
  $$C_{\text{linear}} = 0.0 \times 0.20 + 0.80 = 0.80$$
  $$C_{\text{sRGB}} = 0.80^{1/2.2} = 0.9036 \approx [0.90, 0.90, 0.90]\ (\text{#E7E7E7})$$
  *(Prevents washed-out or overly dark grey fills in table body cells).*

---

## 4. Cell Layout, Margins & Padding

### 4.1 Default Insets (ISO/IEC 29500-1 §21.1.3.16)
If cell properties `<a:tcPr>` omit explicit margins, default insets are:
- `marL` (Left): $7.2\,\text{pt}$ ($91440\,\text{EMU}$)
- `marT` (Top): $3.6\,\text{pt}$ ($45720\,\text{EMU}$)
- `marR` (Right): $7.2\,\text{pt}$ ($91440\,\text{EMU}$)
- `marB` (Bottom): $3.6\,\text{pt}$ ($45720\,\text{EMU}$)

When explicit margins are defined in `tcPr` (e.g. `marL="9525"`), they are converted via `emu_to_pt(val)` ($9525 / 12700 = 0.75\,\text{pt}$).

---

## 5. Grid Geometry & Dynamic Row Heights

`TableRenderer` computes the final grid layout in three stages:

### 5.1 Column Width Normalization
If the sum of column widths in `<a:tblGrid>` differs from the shape width `<a:ext cx="...">`, column widths scale proportionally:
$$\text{scale} = \frac{\text{bounds.w}}{\sum \text{col\_widths}}$$

### 5.2 Dynamic Row Height Expansion
OpenXML specifies `<a:tr h="...">` as the **minimum row height**. If a cell contains wrapped text or larger insets, the row height automatically expands:
$$\text{cell\_req\_h} = \text{layout\_block.total\_height} + t_{\text{ins}} + b_{\text{ins}}$$
$$\text{row\_height}[r] = \max(\text{min\_row\_height}[r], \text{cell\_req\_h})$$

Multi-row spanned cells distribute any height shortfall evenly across their spanned rows.

---

## 6. Text Alignment & Trailing Whitespace

### 6.1 Visible Glyph Centering & Right Alignment
In table number and metric cells with centered (`algn="ctr"`) or right-aligned (`algn="r"`) text, trailing whitespace (spaces/NBSP) is excluded from the line width calculation:

```python
# Trim trailing whitespace before computing alignment offset
visible_line_w = line_w
if fragments and fragments[-1].text:
    last_text = fragments[-1].text
    trimmed = last_text.rstrip(" \t\xa0")
    if len(trimmed) < len(last_text):
        trailing_ws = last_text[len(trimmed):]
        trailing_w = font_metrics.measure_run_width(trailing_ws, ...)
        visible_line_w = max(0.0, line_w - trailing_w)

if para.align == HorizontalAlign.CENTER:
    align_offset = (cur_avail - visible_line_w) / 2.0
elif para.align == HorizontalAlign.RIGHT:
    align_offset = max(0.0, cur_avail - visible_line_w)
```

---

## 7. Key Code Files & Modifying Tables

| Component | File Path | Key Responsibilities |
|---|---|---|
| **Table Parser** | [`ppt_to_pdf/openxml/table_parser.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/openxml/table_parser.py) | Parses `<a:tbl>`, extracts grid columns, rows, cell spans, and resolves `tableStyles.xml` inheritance. |
| **Table Renderer** | [`ppt_to_pdf/renderers/table_renderer.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/renderers/table_renderer.py) | Calculates cell geometry, renders background fills via `draw_rect`, draws cell borders, and delegates text rendering. |
| **Color Resolver** | [`ppt_to_pdf/openxml/color_resolver.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/openxml/color_resolver.py) | Resolves scheme colors, tints, shades, and applies sRGB gamma decoding. |
| **Text Layouter** | [`ppt_to_pdf/typography/text_layouter.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/typography/text_layouter.py) | Handles cell paragraph wrapping, insets, character spacing (`spc`), and visible text centering. |

---

## 8. Developer Quick Reference: How to Extend

1. **Adding Support for New Table Style Elements (e.g. Cell Borders from Style)**:
   - In [`table_parser.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/openxml/table_parser.py), locate `_parse_cell`.
   - Read `<a:tcBdr>` from `tc_style` within the resolved style section and parse `<a:left>`, `<a:top>`, `<a:right>`, `<a:bottom>` if cell borders are not explicitly set on `tcPr`.
2. **Adjusting Alternate Row Banding**:
   - Check `band_row` condition in `_parse_cell` in [`table_parser.py`](file:///d:/app/ppt-pdf-conversion/ppt_to_pdf/openxml/table_parser.py).
3. **Debugging Table Positioning**:
   - Run the diff engine on the specific slide:
     ```bash
     python scripts/diff_engine.py --slides "45"
     ```
   - Inspect the 3-panel diff image in `ground_truth/diffs/diff_slide_<N>.png`.
