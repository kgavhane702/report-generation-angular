"""
Slide Compositor and Page Renderer.
Orchestrates page lifecycle, backgrounds, bookmarks, and visual element rendering order.
"""

from typing import Optional
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import (
    SlideModel,
    ShapeModel,
    PictureModel,
    TableModel,
    ChartModel,
    ConnectorModel,
    GroupModel,
    Rect2D,
    FillType,
)
from .base import BaseElementRenderer
from .shape_renderer import ShapeRenderer
from .text_renderer import TextRenderer
from .image_renderer import ImageRenderer
from .table_renderer import TableRenderer
from .chart_renderer import ChartRenderer
from .connector_renderer import ConnectorRenderer
from .group_renderer import GroupRenderer


class SlideRenderer:
    """
    Renders full SlideModel instances onto the vector PDF canvas.
    """
    def __init__(
        self,
        shape_renderer: Optional[ShapeRenderer] = None,
        image_renderer: Optional[ImageRenderer] = None,
        table_renderer: Optional[TableRenderer] = None,
        chart_renderer: Optional[ChartRenderer] = None,
        connector_renderer: Optional[ConnectorRenderer] = None,
        group_renderer: Optional[GroupRenderer] = None,
        font_metrics=None,
    ):
        from ..typography.font_metrics import FontMetrics
        fm = font_metrics or FontMetrics()
        text_renderer = TextRenderer(font_metrics=fm)
        self.shape_renderer = shape_renderer or ShapeRenderer(text_renderer=text_renderer)
        self.image_renderer = image_renderer or ImageRenderer()
        self.table_renderer = table_renderer or TableRenderer(text_renderer=text_renderer)
        self.chart_renderer = chart_renderer or ChartRenderer(font_metrics=fm)
        self.connector_renderer = connector_renderer or ConnectorRenderer()
        self.group_renderer = group_renderer or GroupRenderer(
            shape_renderer=self.shape_renderer,
            image_renderer=self.image_renderer,
            table_renderer=self.table_renderer,
            chart_renderer=self.chart_renderer,
            connector_renderer=self.connector_renderer,
        )

    def render_slide(self, slide: SlideModel, canvas: BaseCanvas, context: RenderContext) -> None:
        # Start new page
        canvas.begin_page(width=slide.width, height=slide.height)

        # 1. Add Bookmark / Outline entry
        if context.config.generate_bookmarks and slide.title:
            canvas.add_bookmark(title=slide.title, page_number=context.slide_number)

        # 2. Draw Background
        if context.config.render_backgrounds and slide.background_fill:
            bg_rect = Rect2D(0, 0, slide.width, slide.height)
            if slide.background_fill.fill_type == FillType.BLIP and slide.background_fill.image_bytes:
                canvas.draw_image(slide.background_fill.image_bytes, bg_rect)
            else:
                canvas.draw_rect(bg_rect, fill=slide.background_fill, stroke=None)

        # 3. Render Shapes in visual Z-order
        for shape in slide.shapes:
            if isinstance(shape, ShapeModel) and context.config.render_shapes:
                self.shape_renderer.render(shape, canvas, context)
            elif isinstance(shape, PictureModel) and context.config.render_images:
                self.image_renderer.render(shape, canvas, context)
            elif isinstance(shape, TableModel) and context.config.render_tables:
                self.table_renderer.render(shape, canvas, context)
            elif isinstance(shape, ChartModel) and context.config.render_charts:
                self.chart_renderer.render(shape, canvas, context)
                if getattr(shape, "user_shapes", None) and context.config.render_shapes:
                    for us in shape.user_shapes:
                        self.shape_renderer.render(us, canvas, context)
            elif isinstance(shape, ConnectorModel) and context.config.render_shapes:
                self.connector_renderer.render(shape, canvas, context)
            elif isinstance(shape, GroupModel):
                self.group_renderer.render(shape, canvas, context)

        # End page
        canvas.end_page()
