"""
Table Element Renderer.
Computes table grid layout, renders cell background fills, individual cell borders, and cell text frames.
"""

from typing import Optional, List
import pymupdf
from ..canvas.base_canvas import BaseCanvas

from ..core.context import RenderContext
from ..core.models import (
    TableModel,
    TableCellModel,
    Rect2D,
    Point2D,
    FillType,
    StrokeModel,
)
from .base import BaseElementRenderer
from .text_renderer import TextRenderer


class TableRenderer(BaseElementRenderer):
    """
    Renders PowerPoint tables with custom cell formatting, spans, dynamic row heights, and borders.
    """
    def __init__(self, text_renderer: Optional[TextRenderer] = None):
        self.text_renderer = text_renderer or TextRenderer()

    def render(self, element: TableModel, canvas: BaseCanvas, context: RenderContext) -> None:
        if element is None or not element.cells or element.bounds.w <= 0:
            return

        table_x = element.bounds.x
        table_y = element.bounds.y

        # 1. Column widths: scale proportionally to match frame width.
        # Same as row heights: PowerPoint treats <a:gridCol w="..."> as
        # proportional weights when the sum doesn't match <a:ext cx="...">.
        col_widths = list(element.col_widths)
        if not col_widths:
            num_cols = len(element.cells[0]) if element.cells else 1
            col_widths = [element.bounds.w / num_cols] * num_cols
        
        sum_raw_w = sum(col_widths)
        frame_w = element.bounds.w
        if sum_raw_w > 0 and frame_w > 0 and abs(frame_w - sum_raw_w) > 0.1:
            scale_w = frame_w / sum_raw_w
            col_widths = [w * scale_w for w in col_widths]

        # Calculate grid cell X offsets exactly from column widths
        col_x_offsets: List[float] = [0.0]
        for w in col_widths:
            col_x_offsets.append(col_x_offsets[-1] + w)

        # 2. Row heights: OpenXML ISO/IEC 29500-1 §21.1.3.15 specifies <a:tr h="..."> is minimum height.
        # If cell content (text + insets) requires more height than <a:tr h>, the row expands to fit.
        row_heights = list(element.row_heights)
        if not row_heights:
            num_rows = len(element.cells)
            row_heights = [element.bounds.h / num_rows] * num_rows

        min_row_heights = list(row_heights)

        def _cell_has_text(c: TableCellModel) -> bool:
            if not c.text_frame or not c.text_frame.paragraphs:
                return False
            for p in c.text_frame.paragraphs:
                for r in p.runs:
                    if r.text and r.text.strip():
                        return True
            return False

        # Single-row cell content heights
        for r_idx, row in enumerate(element.cells):
            if r_idx >= len(min_row_heights):
                break
            for c_idx, cell in enumerate(row):
                if cell.is_merged_slave or cell.row_span > 1 or not _cell_has_text(cell):
                    continue
                end_c = min(c_idx + cell.col_span, len(col_x_offsets) - 1)
                cell_w = max(10.0, col_x_offsets[end_c] - col_x_offsets[c_idx])
                l_ins, t_ins, r_ins, b_ins = cell.insets
                block = self.text_renderer.layouter.layout_text_frame(
                    cell.text_frame, Rect2D(0, 0, cell_w, 1000.0)
                )
                num_lines = len(block.lines)
                # Use actual cell insets for height calculation
                cell_req_h = block.total_height + t_ins + b_ins
                if cell_req_h > min_row_heights[r_idx]:
                    min_row_heights[r_idx] = cell_req_h

        # Multi-row spanned cell content heights
        for r_idx, row in enumerate(element.cells):
            if r_idx >= len(min_row_heights):
                break
            for c_idx, cell in enumerate(row):
                if cell.is_merged_slave or cell.row_span <= 1 or not _cell_has_text(cell):
                    continue
                end_c = min(c_idx + cell.col_span, len(col_x_offsets) - 1)
                cell_w = max(10.0, col_x_offsets[end_c] - col_x_offsets[c_idx])
                l_ins, t_ins, r_ins, b_ins = cell.insets
                block = self.text_renderer.layouter.layout_text_frame(
                    cell.text_frame, Rect2D(0, 0, cell_w, 1000.0)
                )
                # Use actual cell insets for height calculation
                cell_req_h = block.total_height + t_ins + b_ins
                current_span_h = sum(min_row_heights[r_idx : r_idx + cell.row_span])
                if cell_req_h > current_span_h:
                    shortfall = cell_req_h - current_span_h
                    add_per_row = shortfall / cell.row_span
                    for k in range(r_idx, min(r_idx + cell.row_span, len(min_row_heights))):
                        min_row_heights[k] += add_per_row

        row_heights = min_row_heights

        # Calculate grid cell Y offsets from row heights
        row_y_offsets: List[float] = [0.0]
        for h in row_heights:
            row_y_offsets.append(row_y_offsets[-1] + h)



        # 3. Render cells
        for r_idx, row in enumerate(element.cells):
            for c_idx, cell in enumerate(row):
                if cell.is_merged_slave:
                    continue

                cell_x = table_x + col_x_offsets[c_idx]
                cell_y = table_y + row_y_offsets[r_idx]

                # Span calculation
                end_c = min(c_idx + cell.col_span, len(col_x_offsets) - 1)
                end_r = min(r_idx + cell.row_span, len(row_y_offsets) - 1)

                cell_w = col_x_offsets[end_c] - col_x_offsets[c_idx]
                cell_h = row_y_offsets[end_r] - row_y_offsets[r_idx]
                cell_rect = Rect2D(cell_x, cell_y, cell_w, cell_h)

                # 1. Cell Fill
                if cell.fill.fill_type != FillType.NONE:
                    canvas.draw_rect(cell_rect, fill=cell.fill, stroke=None)

                # 2. Cell Borders
                if cell.border_left:
                    canvas.draw_line(Point2D(cell_x, cell_y), Point2D(cell_x, cell_y + cell_h), stroke=cell.border_left)
                if cell.border_top:
                    canvas.draw_line(Point2D(cell_x, cell_y), Point2D(cell_x + cell_w, cell_y), stroke=cell.border_top)
                if cell.border_right:
                    canvas.draw_line(Point2D(cell_x + cell_w, cell_y), Point2D(cell_x + cell_w, cell_y + cell_h), stroke=cell.border_right)
                if cell.border_bottom:
                    canvas.draw_line(Point2D(cell_x, cell_y + cell_h), Point2D(cell_x + cell_w, cell_y + cell_h), stroke=cell.border_bottom)
                if cell.border_tl_br:
                    canvas.draw_line(Point2D(cell_x, cell_y), Point2D(cell_x + cell_w, cell_y + cell_h), stroke=cell.border_tl_br)
                if cell.border_bl_tr:
                    canvas.draw_line(Point2D(cell_x, cell_y + cell_h), Point2D(cell_x + cell_w, cell_y), stroke=cell.border_bl_tr)

                # 3. Cell Text Frame
                if cell.text_frame and cell.text_frame.paragraphs:
                    if cell.vert_rotation:
                        cell.text_frame.vert_rotation = cell.vert_rotation
                    self.text_renderer.render(cell.text_frame, canvas, context, bounds=cell_rect)



