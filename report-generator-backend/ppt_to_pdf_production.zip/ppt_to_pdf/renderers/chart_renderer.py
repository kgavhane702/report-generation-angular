"""
Chart Element Renderer (Backward-Compatibility Module).
Re-exports the decoupled ChartRenderer and utilities from ppt_to_pdf.renderers.chart.
"""

from .chart import (
    ChartRenderer,
    PlotEngine,
    AxisEngine,
    LegendEngine,
    DataLabelEngine,
    format_data_label_value,
    format_excel_date,
    compute_openxml_nice_bounds,
    generate_nice_ticks,
)

__all__ = [
    "ChartRenderer",
    "PlotEngine",
    "AxisEngine",
    "LegendEngine",
    "DataLabelEngine",
    "format_data_label_value",
    "format_excel_date",
    "compute_openxml_nice_bounds",
    "generate_nice_ticks",
]
