"""
Base Element Renderer Interface.
"""

from abc import ABC, abstractmethod
from typing import Any
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext


class BaseElementRenderer(ABC):
    """
    Abstract renderer for visual slide elements.
    """
    @abstractmethod
    def render(self, element: Any, canvas: BaseCanvas, context: RenderContext) -> None:
        """Renders the element to the vector canvas."""
        pass
