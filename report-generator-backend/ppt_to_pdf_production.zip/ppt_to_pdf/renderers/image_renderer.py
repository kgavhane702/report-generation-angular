"""
Image and Metafile (EMF/WMF) Element Renderer.
"""

from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import PictureModel, Rect2D, Point2D, ColorModel
from ..utils.image_utils import process_image_bytes, extract_emf_text_records
from .base import BaseElementRenderer


class ImageRenderer(BaseElementRenderer):
    """
    Renders bitmap images, SVG, and vector metafiles (EMF/WMF) onto the PDF canvas.
    """
    def render(self, element: PictureModel, canvas: BaseCanvas, context: RenderContext) -> None:
        if element is None or not element.image_bytes or element.bounds.w <= 0 or element.bounds.h <= 0:
            return

        processed = process_image_bytes(
            element.image_bytes,
            crop=element.crop_rect,
            target_dpi=context.config.dpi,
        )

        if processed:
            canvas.draw_image(
                image_bytes=processed,
                rect=element.bounds,
                rotation=element.rotation,
            )

        # EMF Vector Text Layer Extraction (Invisible Searchable Text Stream Tr=3)
        if element.image_bytes.startswith(b"\x01\x00\x00\x00"):
            emf_records = extract_emf_text_records(element.image_bytes)
            bx, by = element.bounds.x, element.bounds.y
            bw, bh = element.bounds.w, element.bounds.h
            for rec in emf_records:
                tx = bx + rec['norm_x'] * bw
                ty = by + rec['norm_y'] * bh
                font_sz = max(4.0, min(24.0, rec['norm_h'] * bh * 0.98))
                baseline_y = ty + rec['norm_h'] * bh * 0.85
                canvas.draw_text(
                    Point2D(tx, baseline_y),
                    rec['text'],
                    font_family="Calibri",
                    font_size=font_sz,
                    color=ColorModel(0.35, 0.35, 0.35, 1.0),
                    render_mode=3,
                )

        # Border / Stroke
        if element.stroke and element.stroke.width > 0:
            canvas.draw_rect(element.bounds, fill=None, stroke=element.stroke)

