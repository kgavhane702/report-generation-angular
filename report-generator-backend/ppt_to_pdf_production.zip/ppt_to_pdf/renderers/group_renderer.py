"""
Group Shape Element Renderer.
Handles coordinate frame transformations and recursive shape rendering within groups.
"""

from typing import Optional
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import (
    GroupModel,
    ShapeModel,
    PictureModel,
    TableModel,
    ChartModel,
    ConnectorModel,
    Rect2D,
    Point2D,
)
from .base import BaseElementRenderer


class GroupRenderer(BaseElementRenderer):
    """
    Renders group shapes by recursing into child elements with mapped coordinates.
    """
    def __init__(
        self,
        shape_renderer: Optional[BaseElementRenderer] = None,
        image_renderer: Optional[BaseElementRenderer] = None,
        table_renderer: Optional[BaseElementRenderer] = None,
        chart_renderer: Optional[BaseElementRenderer] = None,
        connector_renderer: Optional[BaseElementRenderer] = None,
    ):
        self.shape_renderer = shape_renderer
        self.image_renderer = image_renderer
        self.table_renderer = table_renderer
        self.chart_renderer = chart_renderer
        self.connector_renderer = connector_renderer

    def render(self, element: GroupModel, canvas: BaseCanvas, context: RenderContext) -> None:
        if element is None or not element.children:
            return

        # Calculate scale and translation for group coordinate system
        scale_x = 1.0
        scale_y = 1.0
        if element.ch_ext.x > 0:
            scale_x = element.bounds.w / element.ch_ext.x
        if element.ch_ext.y > 0:
            scale_y = element.bounds.h / element.ch_ext.y

        for child in element.children:
            # Map child coordinates from group coordinate space to absolute slide space
            if isinstance(child, (ShapeModel, PictureModel, TableModel, ChartModel, GroupModel)):
                child_rel_x = child.bounds.x - element.ch_off.x
                child_rel_y = child.bounds.y - element.ch_off.y
                mapped_bounds = Rect2D(
                    x=element.bounds.x + child_rel_x * scale_x,
                    y=element.bounds.y + child_rel_y * scale_y,
                    w=child.bounds.w * scale_x,
                    h=child.bounds.h * scale_y,
                )
                child.bounds = mapped_bounds
                if isinstance(child, TableModel):
                    if scale_x != 1.0 and child.col_widths:
                        child.col_widths = [w * scale_x for w in child.col_widths]
                    if scale_y != 1.0 and child.row_heights:
                        child.row_heights = [h * scale_y for h in child.row_heights]
            elif isinstance(child, ConnectorModel):
                child.start_point = Point2D(
                    x=element.bounds.x + (child.start_point.x - element.ch_off.x) * scale_x,
                    y=element.bounds.y + (child.start_point.y - element.ch_off.y) * scale_y,
                )
                child.end_point = Point2D(
                    x=element.bounds.x + (child.end_point.x - element.ch_off.x) * scale_x,
                    y=element.bounds.y + (child.end_point.y - element.ch_off.y) * scale_y,
                )
                if child.path_points:
                    child.path_points = [
                        Point2D(
                            x=element.bounds.x + (pt.x - element.ch_off.x) * scale_x,
                            y=element.bounds.y + (pt.y - element.ch_off.y) * scale_y,
                        )
                        for pt in child.path_points
                    ]

            if isinstance(child, ShapeModel) and self.shape_renderer:
                self.shape_renderer.render(child, canvas, context)
            elif isinstance(child, PictureModel) and self.image_renderer:
                self.image_renderer.render(child, canvas, context)
            elif isinstance(child, TableModel) and self.table_renderer:
                self.table_renderer.render(child, canvas, context)
            elif isinstance(child, ChartModel) and self.chart_renderer:
                self.chart_renderer.render(child, canvas, context)
                if getattr(child, "user_shapes", None) and self.shape_renderer:
                    for us in child.user_shapes:
                        self.shape_renderer.render(us, canvas, context)
            elif isinstance(child, ConnectorModel) and self.connector_renderer:
                self.connector_renderer.render(child, canvas, context)
            elif isinstance(child, GroupModel):
                self.render(child, canvas, context)
