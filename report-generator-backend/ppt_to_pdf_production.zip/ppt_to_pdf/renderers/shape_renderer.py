"""
AutoShape and Geometry Element Renderer.
Renders standard DrawingML shapes, fills, strokes, shadows, and nested text frames.
"""

from typing import Optional
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import ShapeModel, Rect2D, Point2D, FillType, StrokeModel, StrokeDashStyle
from .base import BaseElementRenderer
from .geometry_builder import GeometryBuilder
from .text_renderer import TextRenderer


class ShapeRenderer(BaseElementRenderer):
    """
    Renders PowerPoint auto shapes, custom paths, fills, borders, and text.
    """
    def __init__(self, text_renderer: Optional[TextRenderer] = None):
        self.text_renderer = text_renderer or TextRenderer()

    def render(self, element: ShapeModel, canvas: BaseCanvas, context: RenderContext) -> None:
        if element is None or element.bounds.w <= 0 or element.bounds.h <= 0:
            return

        bounds = element.bounds
        geom_name = element.preset_geom.lower()

        # 0. Handle shape rotation (e.g. 270 deg, 90 deg)
        if element.rotation and abs(element.rotation % 360) > 0.1:
            rot = element.rotation % 360
            if abs(rot - 270) < 1.0 or abs(rot - 90) < 1.0:
                cx = bounds.x + bounds.w / 2.0
                cy = bounds.y + bounds.h / 2.0
                bounds = Rect2D(cx - bounds.h / 2.0, cy - bounds.w / 2.0, bounds.h, bounds.w)
                if element.text_frame:
                    if element.text_frame.vert_rotation == "horz":
                        element.text_frame.vert_rotation = "vert270" if abs(rot - 270) < 1.0 else "vert"

        # 1. Draw Shadow if present
        if element.shadow and element.fill.fill_type != FillType.NONE:
            import math
            rad = math.radians(element.shadow.dir_deg)
            s_dx = element.shadow.dist * math.cos(rad)
            s_dy = element.shadow.dist * math.sin(rad)
            shadow_bounds = Rect2D(bounds.x + s_dx, bounds.y + s_dy, bounds.w, bounds.h)
            canvas.draw_rect(shadow_bounds, fill=element.fill, stroke=None)

        # 2. Draw Geometry Body (Fill & Stroke)
        if element.custom_geometry:
            canvas.draw_custom_geometry(bounds, element.custom_geometry, fill=element.fill, stroke=element.stroke)
        elif geom_name in ("roundrect", "roundrectangle"):
            corner_r = element.corner_radius if element.corner_radius is not None else min(bounds.w, bounds.h) * 0.15
            if corner_r <= 0.01:
                canvas.draw_rect(bounds, fill=element.fill, stroke=element.stroke)
            else:
                canvas.draw_rounded_rect(bounds, corner_radius=corner_r, fill=element.fill, stroke=element.stroke)
        elif geom_name in ("ellipse", "circle", "oval"):
            canvas.draw_ellipse(bounds, fill=element.fill, stroke=element.stroke)
        elif geom_name in ("rect", "rectangle"):
            canvas.draw_rect(bounds, fill=element.fill, stroke=element.stroke)
        else:
            # Check geometry builder presets
            poly_pts = GeometryBuilder.build_polygon(geom_name, element.bounds)
            if poly_pts:
                if element.rotation and abs(element.rotation % 360) > 0.1:
                    import math
                    rad = math.radians(element.rotation % 360)
                    cos_a = math.cos(rad)
                    sin_a = math.sin(rad)
                    cx, cy = element.bounds.center.x, element.bounds.center.y
                    rotated_pts = []
                    for p in poly_pts:
                        dx = p.x - cx
                        dy = p.y - cy
                        rx = cx + dx * cos_a - dy * sin_a
                        ry = cy + dx * sin_a + dy * cos_a
                        rotated_pts.append(Point2D(rx, ry))
                    poly_pts = rotated_pts
                canvas.draw_polygon(poly_pts, fill=element.fill, stroke=element.stroke)
            else:
                # Default fallback: rectangle
                canvas.draw_rect(bounds, fill=element.fill, stroke=element.stroke)

        # 3. Draw Text Frame if present
        if element.text_frame and element.text_frame.paragraphs:
            self.text_renderer.render(element.text_frame, canvas, context, bounds=bounds)
