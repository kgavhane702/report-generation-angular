"""
Text Frame Element Renderer.
Renders paragraphs, multi-font runs, bullet points, underlines, and strikethroughs onto the vector canvas.
Supports horizontal, vertical (90 deg), and vertical-270 (270 deg) text frames.
"""

from typing import Optional
import pymupdf
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import TextBoxModel, Rect2D, Point2D, StrokeModel, StrokeDashStyle, FillModel, FillType
from ..typography.text_layouter import TextLayouter
from ..typography.font_metrics import FontMetrics
from .base import BaseElementRenderer


class TextRenderer(BaseElementRenderer):
    """
    Renders text frames and rich multi-style typography onto the PDF canvas.
    """
    def __init__(self, layouter: Optional[TextLayouter] = None, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()
        self.layouter = layouter or TextLayouter(font_metrics=self.font_metrics)

    def render(self, element: TextBoxModel, canvas: BaseCanvas, context: RenderContext, bounds: Optional[Rect2D] = None) -> None:
        if element is None or bounds is None:
            return

        # Compute layout lines
        layout_block = self.layouter.layout_text_frame(element, bounds)
        vert_rot = element.vert_rotation or "horz"

        if vert_rot == "vert270":
            # Rotated 270 degrees in PowerPoint (flows UPWARDS bottom-to-top, baseline on right)
            m270 = pymupdf.Matrix(0, 1, -1, 0, 0, 0)
            l_ins, t_ins, r_ins, b_ins = element.insets

            for line in layout_block.lines:
                # 1. Draw bullet if present
                if line.bullet_text:
                    bullet_sz = line.bullet_size
                    draw_x = bounds.x + l_ins + line.y - 0.5
                    draw_y = bounds.y + bounds.h - b_ins - line.bullet_x
                    bullet_pt = Point2D(draw_x, draw_y)
                    canvas.draw_text(
                        point=bullet_pt,
                        text=line.bullet_text,
                        font_family=line.bullet_font or "Arial",
                        font_size=bullet_sz,
                        color=line.bullet_color or (line.fragments[0].color if line.fragments else context.color_engine.scheme_colors.get("dk1")),
                        morph=(bullet_pt, m270),
                    )

                # 2. Draw text fragments
                for frag in line.fragments:
                    frag_local_x = line.x + frag.x_offset
                    baseline_shift = frag.baseline_offset * frag.font_size
                    frag_local_y = line.y - baseline_shift
                    draw_x = bounds.x + l_ins + frag_local_y - 0.5
                    draw_y = bounds.y + bounds.h - b_ins - frag_local_x
                    pt = Point2D(draw_x, draw_y)
                    canvas.draw_text(
                        point=pt,
                        text=frag.text,
                        font_family=frag.font_family,
                        font_size=frag.font_size,
                        color=frag.color,
                        bold=frag.bold,
                        italic=frag.italic,
                        morph=(pt, m270),
                    )

        elif vert_rot == "vert":
            # Rotated 90 degrees in PowerPoint (flows top-to-bottom)
            l_ins, t_ins, r_ins, b_ins = element.insets

            for line in layout_block.lines:
                if line.bullet_text:
                    draw_x = bounds.x + l_ins + line.y
                    draw_y = bounds.y + t_ins + line.bullet_x
                    canvas.draw_text(
                        point=Point2D(draw_x, draw_y),
                        text=line.bullet_text,
                        font_family=line.bullet_font or "Arial",
                        font_size=line.bullet_size,
                        color=line.bullet_color or (line.fragments[0].color if line.fragments else context.color_engine.scheme_colors.get("dk1")),
                        rotation=90.0,
                    )

                for frag in line.fragments:
                    frag_local_x = line.x + frag.x_offset
                    draw_x = bounds.x + l_ins + line.y
                    draw_y = bounds.y + t_ins + frag_local_x
                    canvas.draw_text(
                        point=Point2D(draw_x, draw_y),
                        text=frag.text,
                        font_family=frag.font_family,
                        font_size=frag.font_size,
                        color=frag.color,
                        bold=frag.bold,
                        italic=frag.italic,
                        rotation=90.0,
                    )

        else:
            # Standard horizontal text layout
            for line in layout_block.lines:
                # 1. Draw bullet if present
                if line.bullet_text:
                    bullet_pt = Point2D(line.bullet_x, line.y)
                    canvas.draw_text(
                        point=bullet_pt,
                        text=line.bullet_text,
                        font_family=line.bullet_font or "Arial",
                        font_size=line.bullet_size,
                        color=line.bullet_color or (line.fragments[0].color if line.fragments else context.color_engine.scheme_colors.get("dk1")),
                        rotation=element.rotation,
                    )

                # 2. Draw text fragments
                for frag in line.fragments:
                    baseline_shift = frag.baseline_offset * frag.font_size
                    frag_pt = Point2D(line.x + frag.x_offset, line.y - baseline_shift)

                    # Highlight background
                    if frag.highlight_color and frag.highlight_color.a > 0.01:
                        hl_rect = Rect2D(
                            x=frag_pt.x,
                            y=line.y - frag.font_size * 0.82,
                            w=frag.width,
                            h=frag.font_size * 1.05,
                        )
                        canvas.draw_rect(
                            rect=hl_rect,
                            fill=FillModel(fill_type=FillType.SOLID, color=frag.highlight_color),
                        )

                    canvas.draw_text(
                        point=frag_pt,
                        text=frag.text,
                        font_family=frag.font_family,
                        font_size=frag.font_size,
                        color=frag.color,
                        bold=frag.bold,
                        italic=frag.italic,
                        rotation=element.rotation,
                    )

                    # Underline — position derived from font descender
                    if frag.underline:
                        desc_ratio = self.font_metrics.get_descender_ratio(frag.font_family, frag.bold, frag.italic)
                        underline_y = line.y + frag.font_size * abs(desc_ratio) * 0.5
                        canvas.draw_line(
                            start=Point2D(frag_pt.x, underline_y),
                            end=Point2D(frag_pt.x + frag.width, underline_y),
                            stroke=StrokeModel(color=frag.color, width=max(0.5, frag.font_size * 0.05)),
                        )

                    # Strikethrough — position at ~40% of ascender height
                    if frag.strikethrough:
                        asc_ratio = self.font_metrics.get_ascender_ratio(frag.font_family, frag.bold, frag.italic)
                        strike_y = line.y - frag.font_size * asc_ratio * 0.4
                        canvas.draw_line(
                            start=Point2D(frag_pt.x, strike_y),
                            end=Point2D(frag_pt.x + frag.width, strike_y),
                            stroke=StrokeModel(color=frag.color, width=max(0.5, frag.font_size * 0.05)),
                        )
