"""
DrawingML Preset Geometry Path & Polygon Generator.
Translates PowerPoint shape presets (rect, roundRect, ellipse, triangle, diamond, chevron, arrows, etc.)
into precise 2D vector polygon coordinates.
"""

from typing import List, Optional
from ..core.models import Rect2D, Point2D


class GeometryBuilder:
    """
    Generates polygon vertices for DrawingML preset shape geometries.
    """
    @staticmethod
    def build_polygon(preset_name: str, bounds: Rect2D) -> Optional[List[Point2D]]:
        name = preset_name.lower().replace("-", "").replace("_", "")
        l, t, r, b = bounds.left, bounds.top, bounds.right, bounds.bottom
        w, h = bounds.w, bounds.h
        cx, cy = bounds.center.x, bounds.center.y

        if name in ("rect", "rectangle"):
            return [Point2D(l, t), Point2D(r, t), Point2D(r, b), Point2D(l, b)]

        elif name in ("triangle", "isotriangle"):
            return [Point2D(cx, t), Point2D(r, b), Point2D(l, b)]

        elif name in ("rttriangle", "righttriangle"):
            return [Point2D(l, t), Point2D(r, b), Point2D(l, b)]

        elif name in ("diamond", "rhombus"):
            return [Point2D(cx, t), Point2D(r, cy), Point2D(cx, b), Point2D(l, cy)]

        elif name in ("parallelogram",):
            shift = w * 0.2
            return [Point2D(l + shift, t), Point2D(r, t), Point2D(r - shift, b), Point2D(l, b)]

        elif name in ("trapezoid",):
            shift = w * 0.2
            return [Point2D(l + shift, t), Point2D(r - shift, t), Point2D(r, b), Point2D(l, b)]

        elif name in ("hexagon",):
            shift = w * 0.25
            return [
                Point2D(l + shift, t),
                Point2D(r - shift, t),
                Point2D(r, cy),
                Point2D(r - shift, b),
                Point2D(l + shift, b),
                Point2D(l, cy),
            ]

        elif name in ("octagon",):
            shift_x = w * 0.2929
            shift_y = h * 0.2929
            return [
                Point2D(l + shift_x, t),
                Point2D(r - shift_x, t),
                Point2D(r, t + shift_y),
                Point2D(r, b - shift_y),
                Point2D(r - shift_x, b),
                Point2D(l + shift_x, b),
                Point2D(l, b - shift_y),
                Point2D(l, t + shift_y),
            ]

        elif name in ("pentagon",):
            return [
                Point2D(cx, t),
                Point2D(r, t + h * 0.38),
                Point2D(l + w * 0.81, b),
                Point2D(l + w * 0.19, b),
                Point2D(l, t + h * 0.38),
            ]

        elif name in ("chevron",):
            shift = w * 0.3
            return [
                Point2D(l, t),
                Point2D(r - shift, t),
                Point2D(r, cy),
                Point2D(r - shift, b),
                Point2D(l, b),
                Point2D(l + shift, cy),
            ]

        elif name in ("rightarrow",):
            head_w = w * 0.4
            stem_h = h * 0.3
            return [
                Point2D(l, cy - stem_h / 2),
                Point2D(r - head_w, cy - stem_h / 2),
                Point2D(r - head_w, t),
                Point2D(r, cy),
                Point2D(r - head_w, b),
                Point2D(r - head_w, cy + stem_h / 2),
                Point2D(l, cy + stem_h / 2),
            ]

        elif name in ("leftarrow",):
            head_w = w * 0.4
            stem_h = h * 0.3
            return [
                Point2D(l + head_w, t),
                Point2D(l + head_w, cy - stem_h / 2),
                Point2D(r, cy - stem_h / 2),
                Point2D(r, cy + stem_h / 2),
                Point2D(l + head_w, cy + stem_h / 2),
                Point2D(l + head_w, b),
                Point2D(l, cy),
            ]

        elif name in ("uparrow",):
            head_h = h * 0.4
            stem_w = w * 0.3
            return [
                Point2D(cx, t),
                Point2D(r, t + head_h),
                Point2D(cx + stem_w / 2, t + head_h),
                Point2D(cx + stem_w / 2, b),
                Point2D(cx - stem_w / 2, b),
                Point2D(cx - stem_w / 2, t + head_h),
                Point2D(l, t + head_h),
            ]

        elif name in ("downarrow",):
            head_h = h * 0.4
            stem_w = w * 0.3
            return [
                Point2D(cx - stem_w / 2, t),
                Point2D(cx + stem_w / 2, t),
                Point2D(cx + stem_w / 2, b - head_h),
                Point2D(r, b - head_h),
                Point2D(cx, b),
                Point2D(l, b - head_h),
                Point2D(cx - stem_w / 2, b - head_h),
            ]

        elif name in ("plus", "mathplus"):
            sw = w * 0.3
            sh = h * 0.3
            return [
                Point2D(cx - sw / 2, t),
                Point2D(cx + sw / 2, t),
                Point2D(cx + sw / 2, cy - sh / 2),
                Point2D(r, cy - sh / 2),
                Point2D(r, cy + sh / 2),
                Point2D(cx + sw / 2, cy + sh / 2),
                Point2D(cx + sw / 2, b),
                Point2D(cx - sw / 2, b),
                Point2D(cx - sw / 2, cy + sh / 2),
                Point2D(l, cy + sh / 2),
                Point2D(l, cy - sh / 2),
                Point2D(cx - sw / 2, cy - sh / 2),
            ]

        elif name in ("star5", "star"):
            # 5-pointed star
            import math
            pts = []
            for i in range(10):
                angle = math.radians(i * 36 - 90)
                r_dist = (w / 2) if (i % 2 == 0) else (w / 4)
                pts.append(Point2D(cx + r_dist * math.cos(angle), cy + r_dist * math.sin(angle)))
            return pts

        return None
