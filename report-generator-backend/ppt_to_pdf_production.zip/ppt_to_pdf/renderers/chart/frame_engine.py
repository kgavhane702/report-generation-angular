"""
Frame and Background Engine for PowerPoint Chart Rendering.

Encapsulates DrawingML shape properties (<c:chartSpace>/<c:spPr>) to render
chart frame background fills and outer border stroke boxes cleanly on the vector canvas.
"""

from typing import Optional
from ...canvas.base_canvas import BaseCanvas
from ...core.models import ChartModel, FillModel, StrokeModel, FillType, ColorModel


class FrameEngine:
    """
    Renders chart container background fills and bounding box outlines.
    """

    def render_background(self, chart: ChartModel, canvas: BaseCanvas) -> None:
        """
        Renders the chart space background fill if defined in OpenXML.
        """
        if chart is None or chart.fill_color is None:
            return
        if chart.bounds.w <= 0 or chart.bounds.h <= 0:
            return

        canvas.draw_rect(
            chart.bounds,
            fill=FillModel(fill_type=FillType.SOLID, color=chart.fill_color),
        )

    def render_border(self, chart: ChartModel, canvas: BaseCanvas) -> None:
        """
        Renders the chart space border box stroke if defined in OpenXML.
        """
        if chart is None or chart.border_color is None or chart.border_width <= 0:
            return
        if chart.bounds.w <= 0 or chart.bounds.h <= 0:
            return

        canvas.draw_rect(
            chart.bounds,
            stroke=StrokeModel(
                color=chart.border_color,
                width=chart.border_width,
            ),
        )
