"""
Shared chart mathematical utilities and formatting helpers.
"""

import re
from datetime import datetime, timedelta
from typing import List, Optional, Tuple
import numpy as np


def round_half_up(val: float) -> int:
    """Standard half-up rounding as used by Excel and PowerPoint."""
    if val >= 0:
        return int(np.floor(val + 0.5))
    return int(np.ceil(val - 0.5))


def format_data_label_value(val: Optional[float], format_code: str = "") -> str:
    """Formats a numeric value using OpenXML formatCode or intelligent fallback."""
    if val is None or np.isnan(val):
        return ""
    if abs(val) < 1e-7:
        val = 0.0

    if not format_code or format_code.lower() == "general":
        if abs(val - round(val)) < 1e-5:
            return f"{int(round(val))}"
        return f"{val:.1f}"

    # Handle multi-section format codes (positive;negative;zero;text)
    if ";" in format_code:
        sections = format_code.split(";")
        if abs(val) < 1e-6 and len(sections) >= 3:
            zero_sec = sections[2].strip()
            if '"-"' in zero_sec or '\"-\"' in zero_sec or zero_sec == "-" or "-" in zero_sec:
                return "-"
            if zero_sec in ('""', "''", ""):
                return ""
            format_code = zero_sec
        elif val < -1e-6 and len(sections) >= 2:
            format_code = sections[1]
        else:
            format_code = sections[0]

    fc_lower = format_code.lower()

    # Millions scaling (e.g. "€"#,##0"m", "$#,##0m", "0.0,,")
    if '"m"' in fc_lower or fc_lower.endswith('m') or (',,' in format_code and '%' not in format_code):
        prefix = ""
        for curr in ("€", "£", "¥", "$"):
            if curr in format_code:
                prefix = curr
                break
        scaled = (val / 1e6) if abs(val) >= 1e5 else val
        suffix = "m" if ('"m"' in fc_lower or fc_lower.endswith('m') or r'\m' in fc_lower) else ""
        has_comma = "#,##" in format_code or "0,0" in format_code
        val_str = f"{abs(round_half_up(scaled)):,}" if has_comma else f"{abs(round_half_up(scaled))}"
        if scaled < 0 and (r"\(" in format_code or "(" in format_code):
            return f"({val_str})"
        sign = "-" if (scaled < 0 and not prefix.startswith("-")) else ""
        return f"{prefix}{sign}{val_str}{suffix}"

    # Thousands scaling (e.g. "€"#,##0"k", "$#,##0k", "#,##0,_);[Red]\(#,##0,\)")
    has_trailing_comma = bool(re.search(r',(?=[_\);\\\]]|$)', format_code.replace(',,', '')))
    if '"k"' in fc_lower or fc_lower.endswith('k') or has_trailing_comma:
        prefix = ""
        for curr in ("€", "£", "¥", "$"):
            if curr in format_code:
                prefix = curr
                break
        scaled = (val / 1e3) if abs(val) >= 100 else val
        suffix = "k" if ('"k"' in fc_lower or fc_lower.endswith('k') or r'\k' in fc_lower) else ""
        if scaled < 0 and (r"\(" in format_code or "(" in format_code):
            return f"({abs(round_half_up(scaled)):,})"
        return f"{prefix}{round_half_up(scaled):,}{suffix}"

    # Billions scaling (e.g. "€"#,##0"bn", "$#,##0bn")
    if '"bn"' in fc_lower or fc_lower.endswith('bn'):
        prefix = ""
        for curr in ("€", "£", "¥", "$"):
            if curr in format_code:
                prefix = curr
                break
        scaled = (val / 1e9) if abs(val) >= 1e7 else val
        return f"{prefix}{round_half_up(scaled):,}bn"

    # Percentage formats: e.g. 0.0%, 0%, #,##0.0%, or literal '#,##0.0"%"'
    if "%" in format_code:
        is_literal_pct = ('"%"' in format_code) or (r"\%" in format_code)
        mult = 1.0 if is_literal_pct else 100.0
        match = re.search(r"0\.(0+)", format_code)
        if match:
            decimals = len(match.group(1))
            return f"{val * mult:.{decimals}f}%"
        elif "0" in format_code:
            return f"{round_half_up(val * mult):.0f}%"
        return f"{val * mult:.1f}%"

    # Currency formats: e.g. [$€-2] #,##0, $#,##0 or €#,##0.0
    prefix = ""
    is_neg = val < 0
    num_val = abs(val) if is_neg else val

    if "[$" in format_code:
        m = re.search(r"\[\$([^-\]]+)", format_code)
        if m:
            curr_sym = m.group(1).strip()
            has_space = bool(re.search(r"\[\$[^\]]+\](\s+|\\\s+)", format_code))
            space_str = " " if has_space else ""
            prefix = f"-{curr_sym}{space_str}" if is_neg else f"{curr_sym}{space_str}"
    else:
        for curr in ("€", "£", "¥", "$"):
            if curr in format_code:
                prefix = f"-{curr}" if is_neg else curr
                break

    # Number with decimals: e.g. #,##0.0 or 0.00
    match = re.search(r"\.(0+)", format_code)
    if match:
        decimals = len(match.group(1))
        formatted = f"{num_val:,.{decimals}f}"
    elif "#,##0" in format_code or "0" in format_code:
        formatted = f"{round_half_up(num_val):,}"
    else:
        formatted = f"{num_val:.1f}"

    if not prefix and is_neg:
        formatted = f"-{formatted}"

    return f"{prefix}{formatted}"


def format_date_by_numfmt(dt: datetime, format_code: Optional[str] = None) -> str:
    """Formats a datetime object based on OpenXML format code (e.g., 'mmm\\-yy' -> 'Aug-24')."""
    if not format_code:
        return dt.strftime("%b-%y")

    fc = format_code.replace("\\", "").lower()
    if "mmm-yy" in fc or "mmm-yyyy" in fc or "mmm" in fc:
        return dt.strftime("%b-%y")
    elif "yyyy" in fc:
        return dt.strftime("%Y")
    elif "mm/dd/yy" in fc or "m/d/yy" in fc:
        return dt.strftime("%m/%d/%y")
    elif "dd-mmm" in fc or "d-mmm" in fc:
        return dt.strftime("%d-%b")
    return dt.strftime("%b-%y")


def format_excel_date(date_str: str, format_code: Optional[str] = None) -> str:
    """Converts Excel serial date (e.g. '45505') to readable date string ('Aug-24')."""
    try:
        val = float(date_str)
        if 30000 <= val <= 60000:
            dt = datetime(1899, 12, 30) + timedelta(days=val)
            return format_date_by_numfmt(dt, format_code)
    except Exception:
        pass
    return date_str


def compute_calendar_axis_range(
    min_dt: datetime,
    max_dt: datetime,
    major_time_unit: Optional[str] = None,
    major_unit: Optional[float] = None,
) -> Tuple[List[datetime], float, float]:
    """
    Computes calendar anchor points and exact axis serial bounds (min_ser, max_ser).
    Quantizes axis bounds to full major unit boundaries.
    """
    unit = (major_time_unit or "months").lower()
    step = max(1, int(major_unit or 1))
    anchors: List[datetime] = []

    if unit == "years":
        cur_year = min_dt.year
        cur_dt = datetime(cur_year, 1, 1)
        while cur_dt <= max_dt:
            anchors.append(cur_dt)
            cur_dt = datetime(cur_dt.year + step, 1, 1)
        next_boundary = cur_dt
    elif unit == "days":
        cur_dt = min_dt
        while cur_dt <= max_dt:
            anchors.append(cur_dt)
            cur_dt += timedelta(days=step)
        next_boundary = cur_dt
    else:
        # Months (default)
        cur_dt = datetime(min_dt.year, min_dt.month, 1)
        while cur_dt <= max_dt:
            # If the last data point falls on day 1 of the month, that month represents the outer boundary, not a new interval
            if cur_dt.year == max_dt.year and cur_dt.month == max_dt.month and max_dt.day <= 1 and anchors:
                break
            anchors.append(cur_dt)
            m = cur_dt.month + step
            y = cur_dt.year + (m - 1) // 12
            m = ((m - 1) % 12) + 1
            cur_dt = datetime(y, m, 1)
        next_boundary = cur_dt

    if anchors:
        start_ser = float((min_dt - datetime(1899, 12, 30)).days)
        anchors[0] = min_dt
        end_ser = float((max_dt - datetime(1899, 12, 30)).days)
    else:
        start_ser = float((min_dt - datetime(1899, 12, 30)).days)
        end_ser = float((max_dt - datetime(1899, 12, 30)).days)

    return anchors, start_ser, end_ser


def generate_calendar_anchors(
    min_dt: datetime,
    max_dt: datetime,
    major_time_unit: Optional[str] = None,
    major_unit: Optional[float] = None,
) -> List[datetime]:
    """
    Generates standard calendar anchor dates (e.g., 1st of every N months or years)
    across a date range, adhering to OpenXML DrawingML dateAx specifications.
    """
    anchors, _, _ = compute_calendar_axis_range(min_dt, max_dt, major_time_unit, major_unit)
    return anchors


def compute_openxml_nice_bounds(data_min: float, data_max: float) -> Tuple[float, float, float]:
    """
    Computes OpenXML-standard nice min, max, and major unit step for chart value axes.
    Follows Microsoft Excel / PowerPoint automatic axis scaling algorithm.
    PowerPoint targets approximately 4 major intervals on the axis.
    """
    # Target number of intervals.
    # PowerPoint uses approximately 3.5 - 4.0 major intervals for auto-scaled axes.
    TARGET_INTERVALS = 3.8

    if data_min >= 0:
        raw_range = max(1e-5, data_max)
        raw_step = raw_range / 4.8
        mag = 10.0 ** np.floor(np.log10(max(1e-9, raw_step)))
        norm_step = raw_step / mag
        if norm_step <= 1.4:
            step = 1.0 * mag
        elif norm_step <= 3.05:
            step = 2.0 * mag
        elif norm_step <= 7.0:
            step = 5.0 * mag
        else:
            step = 10.0 * mag
        nice_max = np.ceil(round(data_max / step, 6)) * step
        if nice_max <= data_max:
            nice_max += step
        return 0.0, float(nice_max), float(step)
    elif data_max <= 0:
        raw_range = max(1e-5, abs(data_min))
        target_intervals = 8.5 if raw_range <= 2.5 else 3.8
        raw_step = raw_range / target_intervals
        mag = 10.0 ** np.floor(np.log10(max(1e-9, raw_step)))
        norm_step = raw_step / mag
        if norm_step <= 1.4:
            step = 1.0 * mag
        elif norm_step <= 3.0:
            step = 2.0 * mag
        elif norm_step <= 7.0:
            step = 5.0 * mag
        else:
            step = 10.0 * mag
        nice_min = np.floor(round(data_min / step, 6)) * step
        return float(nice_min), 0.0, float(step)
    else:
        raw_range = data_max - data_min
        raw_step = raw_range / 4.8
        mag = 10.0 ** np.floor(np.log10(max(1e-9, raw_step)))
        norm_step = raw_step / mag
        if norm_step <= 1.4:
            step = 1.0 * mag
        elif norm_step <= 3.0:
            step = 2.0 * mag
        elif norm_step <= 7.0:
            step = 5.0 * mag
        else:
            step = 10.0 * mag
        nice_min = np.floor(round(data_min / step, 6)) * step
        nice_max = np.ceil(round(data_max / step, 6)) * step
        return float(nice_min), float(nice_max), float(step)


def generate_nice_ticks(min_val: float, max_val: float, step: Optional[float] = None) -> List[float]:
    """Generates clean, human-friendly numeric tick steps."""
    if min_val >= max_val:
        return [min_val]

    if step is None or step <= 0:
        _, _, step = compute_openxml_nice_bounds(min_val, max_val)

    ticks = []
    curr = min_val
    while curr <= max_val + step * 0.01:
        ticks.append(round(curr, 6))
        curr += step

    return ticks
