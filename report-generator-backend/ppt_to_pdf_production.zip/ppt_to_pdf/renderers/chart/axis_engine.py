"""
Axis Engine for OpenXML DrawingML Charts.
Handles date calendar math, category discrete intervals, value tick scaling,
inverted axes, formatCode colors (e.g. [Red]), and rotated vector text via PyMuPDF.
"""

import math
from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Any
import numpy as np
import pymupdf

from ...canvas.base_canvas import BaseCanvas
from ...core.models import (
    ChartModel,
    ChartAxisModel,
    ChartType,
    ColorModel,
    StrokeModel,
    Point2D,
    Rect2D,
)
from ...core.context import RenderContext
from ...typography.font_metrics import FontMetrics
from .chart_utils import (
    format_data_label_value,
    format_excel_date,
    format_date_by_numfmt,
    generate_calendar_anchors,
    compute_calendar_axis_range,
    generate_nice_ticks,
)

_TICK_LABEL_GAP = 6.5  # pt gap from plot edge to nearest edge of tick label


class AxisEngine:
    """
    Renders vector axis spines, tick marks, and labels with full rotation & calendar support.
    """

    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()

    def _measure_text_width(
        self,
        text: str,
        font_family: str = "Calibri",
        font_size: float = 7.0,
        bold: bool = False,
    ) -> float:
        return self.font_metrics.measure_text_width(
            text, family=font_family, size=font_size, bold=bold
        )

    def draw_rotated_text(
        self,
        canvas: BaseCanvas,
        pivot: Point2D,
        text: str,
        font_family: str,
        font_size: float,
        color: ColorModel,
        rotation_deg: float = 0.0,
        bold: bool = False,
    ) -> None:
        """
        Draws text rotated around the pivot point.
        For negative rotation (e.g. -45°), anchors the end of the text right at the pivot.
        """
        rot_norm = round(rotation_deg) % 360
        if rot_norm == 0:
            canvas.draw_text(
                pivot,
                text,
                font_family=font_family,
                font_size=font_size,
                color=color,
                bold=bold,
            )
            return

        text_w = self._measure_text_width(text, font_family, font_size, bold=bold)
        rad = math.radians(rotation_deg)
        mat = pymupdf.Matrix(math.cos(rad), -math.sin(rad), math.sin(rad), math.cos(rad), 0, 0)

        # Shift start point so text rotates cleanly into the pivot
        p_start = Point2D(pivot.x - text_w, pivot.y)

        canvas.draw_text(
            p_start,
            text,
            font_family=font_family,
            font_size=font_size,
            color=color,
            bold=bold,
            morph=(pivot, mat),
        )

    def render_category_and_date_axes(
        self,
        chart: ChartModel,
        plot_rect: Rect2D,
        canvas: BaseCanvas,
        context: RenderContext,
    ) -> None:
        """Renders category and date axes with ticks, spine lines, and rotated labels."""
        categories = chart.categories
        if not categories or not chart.cat_axis or chart.cat_axis.is_deleted:
            return

        ca = chart.cat_axis
        px, py, pw, ph = plot_rect.x, plot_rect.y, plot_rect.w, plot_rect.h
        p_bottom = py + ph
        p_top = py

        cat_font_sz = ca.font_size if ca.font_size > 0 else 7.0
        cat_font_fam = ca.font_family or chart.font_family or "Arial"
        cat_font_clr = ca.font_color or ColorModel(0.35, 0.35, 0.35, 1.0)

        # Inverted value axis (maxMin) with autoZero crossing places category axis at bottom
        is_top_axis = ca.position == "t"
        if chart.val_axis and chart.val_axis.orientation == "maxMin":
            is_top_axis = False

        axis_line_y = p_top if is_top_axis else p_bottom
        if ca.crosses == "autoZero" and chart.val_axis and not is_top_axis:
            from .plot_engine import PlotEngine
            (prim_min, prim_max, prim_step, prim_range), _, _, _ = PlotEngine().determine_axis_ranges(chart)
            if prim_min < 0 < prim_max and prim_range > 0:
                axis_line_y = p_bottom - ((0.0 - prim_min) / prim_range) * ph

        # Determine tick mark and label anchor Y based on tickLblPos
        is_inverted = chart.val_axis and chart.val_axis.orientation == "maxMin"
        if ca.tick_label_pos == "low":
            tick_anchor_y = p_top if is_inverted else p_bottom
            tick_dir = -3.0 if is_inverted else 3.0
            is_label_top = bool(is_inverted)
        elif ca.tick_label_pos == "high":
            tick_anchor_y = p_bottom if is_inverted else p_top
            tick_dir = 3.0 if is_inverted else -3.0
            is_label_top = not is_inverted
        else:
            tick_anchor_y = axis_line_y
            tick_dir = -3.0 if is_top_axis else 3.0
            is_label_top = is_top_axis

        label_rot = ca.label_rotation

        # 1. Draw Axis Spine Line
        if ca.axis_line_width > 0:
            spine_color = ca.axis_line_color or ColorModel(0.51, 0.59, 0.67, 1.0)
            canvas.draw_line(
                Point2D(px, axis_line_y),
                Point2D(px + pw, axis_line_y),
                stroke=StrokeModel(color=spine_color, width=ca.axis_line_width),
            )

        if ca.tick_label_pos == "none":
            return

        bar_types = (
            ChartType.BAR,
            ChartType.COLUMN,
            ChartType.STACKED_BAR,
            ChartType.STACKED_COLUMN,
            ChartType.PERCENT_STACKED_BAR,
            ChartType.PERCENT_STACKED_COLUMN,
        )
        has_bars = any(
            (s.chart_type in bar_types if s.chart_type else chart.chart_type in bar_types)
            for s in chart.series_list
        )

        # Check for continuous Excel date series
        is_excel_date = False
        try:
            first_val = float(categories[0])
            if 30000 <= first_val <= 60000:
                is_excel_date = True
        except (ValueError, TypeError, IndexError):
            pass

        # 2. Continuous Date Axis (only for pure line/scatter/area charts without bars)
        if not has_bars and is_excel_date and (len(categories) > 15 or ca.axis_type == "date" or ca.major_time_unit is not None):
            try:
                numeric_dates = [float(c) for c in categories if c]
                min_ser = min(numeric_dates)
                max_ser = max(numeric_dates)
                min_dt = datetime(1899, 12, 30) + timedelta(days=min_ser)
                max_dt = datetime(1899, 12, 30) + timedelta(days=max_ser)

                # Generate calendar anchor points (e.g. 1st of each month or year) and full axis span
                month_anchors, axis_min_ser, axis_max_ser = compute_calendar_axis_range(
                    min_dt, max_dt, ca.major_time_unit, ca.major_unit
                )
                ser_span = max(1.0, axis_max_ser - axis_min_ser)

                # Dynamic collision auto-rotation: if labels collide horizontally, tilt -45°
                slot_w = pw / max(1, len(month_anchors)) if month_anchors else pw
                max_date_w = 0.0
                for m_dt in month_anchors:
                    ds = format_date_by_numfmt(m_dt, ca.num_fmt)
                    w = self._measure_text_width(ds, cat_font_fam, cat_font_sz)
                    if w > max_date_w:
                        max_date_w = w

                effective_date_rot = label_rot
                if effective_date_rot == 0.0 and max_date_w > slot_w - 1.5:
                    effective_date_rot = -45.0

                is_monthly = getattr(ca, "major_time_unit", None) == "months"
                step = int(ca.major_unit) if ca and ca.major_unit and ca.major_unit > 0 else 1
                total_intervals = len(month_anchors) - 1

                for idx, m_dt in enumerate(month_anchors):
                    if is_monthly and step > 1 and total_intervals > 0:
                        m_x = px + (idx / total_intervals) * pw
                    elif is_monthly and step == 1 and total_intervals > 0:
                        month_gap = pw / (total_intervals + 0.55)
                        m_x = px + idx * month_gap
                    else:
                        m_ser = float((m_dt - datetime(1899, 12, 30)).days)
                        m_frac = max(0.0, min(1.0, (m_ser - axis_min_ser) / ser_span)) if ser_span > 0 else 0.0
                        m_x = px + m_frac * pw

                    # Measure date label and check boundary fit
                    date_str = format_date_by_numfmt(m_dt, ca.num_fmt)
                    text_w = self._measure_text_width(date_str, cat_font_fam, cat_font_sz)

                    if effective_date_rot == 0:
                        text_x = m_x - text_w / 2.0
                        chart_right = chart.bounds.x + chart.bounds.w
                        if text_x + text_w > chart_right:
                            text_x = max(px, chart_right - text_w - 0.5)

                    # Draw tick mark
                    tick_len = 3.0
                    canvas.draw_line(
                        Point2D(m_x, tick_anchor_y),
                        Point2D(m_x, tick_anchor_y + tick_dir),
                        stroke=StrokeModel(
                            color=ca.axis_line_color or ColorModel(0.8, 0.8, 0.8, 1.0),
                            width=0.75,
                        ),
                    )

                    if effective_date_rot != 0:
                        # Rotated label positioning: offset from tick mark based on font size
                        tick_gap = tick_len + cat_font_sz * 1.05
                        pivot_y = tick_anchor_y - tick_gap if is_label_top else tick_anchor_y + tick_gap
                        self.draw_rotated_text(
                            canvas,
                            Point2D(m_x, pivot_y),
                            date_str,
                            cat_font_fam,
                            cat_font_sz,
                            cat_font_clr,
                            rotation_deg=effective_date_rot,
                        )
                    else:
                        axis_offset = ((ca.lbl_offset / 100.0) if ca else 1.0) * 6.0
                        if is_label_top:
                            line_y = p_top - 12.0
                        else:
                            line_y = tick_anchor_y + axis_offset
                        baseline_y = line_y + cat_font_sz * 0.8

                        canvas.draw_text(
                            Point2D(text_x, baseline_y),
                            date_str,
                            font_family=cat_font_fam,
                            font_size=cat_font_sz,
                            color=cat_font_clr,
                        )
                return
            except Exception:
                pass

        # 3. Discrete Category Axis
        num_categories = len(categories)
        cat_step = pw / max(1, num_categories)

        # Dynamic collision auto-rotation: if labels collide horizontally, tilt -45°
        max_cat_w = 0.0
        for c in categories:
            if c:
                t = format_excel_date(c, ca.num_fmt)
                for line in t.split("\n"):
                    words = line.strip().split() if " " in line.strip() and len(line.strip()) > 5 else [line.strip()]
                    for w_part in words:
                        w = self._measure_text_width(w_part, cat_font_fam, cat_font_sz)
                        if w > max_cat_w:
                            max_cat_w = w

        major_step = int(ca.major_unit) if (ca and ca.major_unit and ca.major_unit > 1) else 1
        if major_step > 1:
            sampled_indices = list(range(0, num_categories, major_step))
        elif label_rot != 0 or ca.major_time_unit == "months":
            sampled_indices = list(range(num_categories))
        elif num_categories > 15:
            step_idx = max(1, num_categories // 4)
            sampled_indices = list(range(0, num_categories, step_idx))
            if (num_categories - 1) not in sampled_indices:
                sampled_indices.append(num_categories - 1)
        else:
            sampled_indices = list(range(num_categories))

        # Dynamic collision auto-rotation: if labels collide horizontally, tilt -45°
        label_slot_w = major_step * cat_step
        effective_cat_rot = label_rot
        if effective_cat_rot == 0.0 and max_cat_w > label_slot_w + 4.0:
            effective_cat_rot = -45.0

        if ca.major_tick_mark in ("out", "cross", "in"):
            tick_len = 3.0
            for cat_idx in sampled_indices:
                t_x = px + cat_idx * cat_step
                canvas.draw_line(
                    Point2D(t_x, tick_anchor_y),
                    Point2D(t_x, tick_anchor_y + tick_dir),
                    stroke=StrokeModel(
                        color=ca.axis_line_color or ColorModel(0.8, 0.8, 0.8, 1.0),
                        width=0.75,
                    ),
                )

        for cat_idx in sampled_indices:
            if cat_idx >= len(categories):
                continue
            raw_cat = categories[cat_idx]
            if not raw_cat:
                continue

            cat_text = format_excel_date(raw_cat, ca.num_fmt)
            cat_center_x = px + (cat_idx + 0.5) * cat_step

            lines = cat_text.split("\n")

            for l_idx, line in enumerate(lines):
                line_str = line.strip()
                if not line_str:
                    continue

                if effective_cat_rot != 0:
                    tick_gap = 3.0 + cat_font_sz * 1.05
                    pivot_y = tick_anchor_y - tick_gap if is_label_top else tick_anchor_y + tick_gap
                    self.draw_rotated_text(
                        canvas,
                        Point2D(cat_center_x, pivot_y),
                        line_str,
                        cat_font_fam,
                        cat_font_sz,
                        cat_font_clr,
                        rotation_deg=effective_cat_rot,
                    )
                else:
                    axis_offset = ((ca.lbl_offset / 100.0) if ca else 1.0) * 6.0
                    if is_label_top:
                        line_y = p_top - 12.0 + l_idx * (cat_font_sz + 2.0)
                    else:
                        line_y = tick_anchor_y + axis_offset + l_idx * (cat_font_sz + 2.0)

                    baseline_y = line_y + cat_font_sz * 0.8
                    text_w = self._measure_text_width(line_str, cat_font_fam, cat_font_sz)
                    text_x = cat_center_x - text_w / 2.0

                    canvas.draw_text(
                        Point2D(text_x, baseline_y),
                        line_str,
                        font_family=cat_font_fam,
                        font_size=cat_font_sz,
                        color=cat_font_clr,
                    )

    def render_value_axes(
        self,
        chart: ChartModel,
        plot_rect: Rect2D,
        prim_range_tuple: Tuple[float, float, float, float],
        sec_range_tuple: Tuple[float, float, float, float],
        canvas: BaseCanvas,
    ) -> None:
        """Renders primary and secondary value axis numeric tick labels."""
        px, py, pw, ph = plot_rect.x, plot_rect.y, plot_rect.w, plot_rect.h
        p_bottom = py + ph
        p_top = py

        prim_min, prim_max, prim_step, _ = prim_range_tuple
        sec_min, sec_max, sec_step, _ = sec_range_tuple

        def _render_axis_ticks(
            ax_model: ChartAxisModel,
            y_min_val: float,
            y_max_val: float,
            step_val: float,
            is_right: bool,
        ):
            if ax_model.is_deleted or ax_model.tick_label_pos == "none":
                return
            ticks = generate_nice_ticks(y_min_val, y_max_val, step_val)
            font_sz = ax_model.font_size if ax_model.font_size > 0 else 7.0
            font_fam = ax_model.font_family or chart.font_family or "Arial"
            default_font_clr = ax_model.font_color or ColorModel(0.35, 0.35, 0.35, 1.0)
            is_inverted = ax_model.orientation == "maxMin"

            # Check for [Red] format code
            has_red_fmt = ax_model.num_fmt and "[red]" in ax_model.num_fmt.lower()

            # Draw vector major gridlines if enabled on the value axis
            if ax_model.show_major_gridlines and not is_right:
                g_color = ax_model.gridline_color or ColorModel(0.902, 0.918, 0.933, 1.0)
                g_width = max(0.5, ax_model.gridline_width)
                for t_val in ticks:
                    fraction = (t_val - y_min_val) / max(1e-5, y_max_val - y_min_val)
                    t_y = p_top + fraction * ph if is_inverted else p_bottom - fraction * ph
                    canvas.draw_line(
                        Point2D(px, t_y),
                        Point2D(px + pw, t_y),
                        stroke=StrokeModel(color=g_color, width=g_width),
                    )

            for t_val in ticks:
                t_str = format_data_label_value(t_val, ax_model.num_fmt or "#,##0")
                if not t_str:
                    continue

                fraction = (t_val - y_min_val) / max(1e-5, y_max_val - y_min_val)
                if is_inverted:
                    t_y = p_top + fraction * ph
                else:
                    t_y = p_bottom - fraction * ph

                # Select font color: red for negative numbers if formatCode contains [Red]
                if has_red_fmt and t_val < -1e-5:
                    font_clr = ColorModel.from_hex("#FF0000")
                else:
                    font_clr = default_font_clr

                text_w = self._measure_text_width(t_str, font_fam, font_sz)
                if is_right:
                    t_x = px + pw + _TICK_LABEL_GAP
                else:
                    t_x = px - _TICK_LABEL_GAP - text_w

                baseline_y = t_y + font_sz * 0.35
                canvas.draw_text(
                    Point2D(t_x, baseline_y),
                    t_str,
                    font_family=font_fam,
                    font_size=font_sz,
                    color=font_clr,
                )

        def _render_value_axis_line_and_ticks(
            ax_model: ChartAxisModel,
            y_min_val: float,
            y_max_val: float,
            step_val: float,
            is_right: bool,
        ):
            if ax_model.is_deleted or ax_model.axis_line_width <= 0:
                return

            spine_x = px + pw if is_right else px
            spine_color = ax_model.axis_line_color or ColorModel(0.51, 0.59, 0.67, 1.0)
            spine_width = ax_model.axis_line_width if ax_model.axis_line_width > 0 else 0.75

            # 1. Vertical spine line
            canvas.draw_line(
                Point2D(spine_x, p_top),
                Point2D(spine_x, p_bottom),
                stroke=StrokeModel(color=spine_color, width=spine_width),
            )

            # 2. Major tick marks
            if ax_model.major_tick_mark in ("out", "cross", "in"):
                tick_len = 3.0
                ticks = generate_nice_ticks(y_min_val, y_max_val, step_val)
                is_inverted = ax_model.orientation == "maxMin"
                for t_val in ticks:
                    fraction = (t_val - y_min_val) / max(1e-5, y_max_val - y_min_val)
                    t_y = p_top + fraction * ph if is_inverted else p_bottom - fraction * ph
                    if is_right:
                        t_x2 = spine_x + tick_len if ax_model.major_tick_mark in ("out", "cross") else spine_x - tick_len
                    else:
                        t_x2 = spine_x - tick_len if ax_model.major_tick_mark in ("out", "cross") else spine_x + tick_len
                    canvas.draw_line(
                        Point2D(spine_x, t_y),
                        Point2D(t_x2, t_y),
                        stroke=StrokeModel(color=spine_color, width=spine_width),
                    )

        if chart.val_axis and not chart.val_axis.is_deleted:
            _render_value_axis_line_and_ticks(chart.val_axis, prim_min, prim_max, prim_step, is_right=False)
            _render_axis_ticks(chart.val_axis, prim_min, prim_max, prim_step, is_right=False)
        if chart.sec_val_axis and not chart.sec_val_axis.is_deleted:
            _render_value_axis_line_and_ticks(chart.sec_val_axis, sec_min, sec_max, sec_step, is_right=True)
            _render_axis_ticks(chart.sec_val_axis, sec_min, sec_max, sec_step, is_right=True)
