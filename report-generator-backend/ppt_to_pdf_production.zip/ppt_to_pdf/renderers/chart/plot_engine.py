"""
Plot Area Image Generation Engine using Matplotlib.
Renders pure chart graphics (bars, columns, lines, areas, pies, scatter, dual axes, gridlines)
to a transparent high-DPI image buffer without text clutter.
"""

import io
from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Dict, Any
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg

from ...core.models import (
    ChartModel,
    ChartType,
    ChartSeriesGroup,
    ChartDataSeries,
    ChartAxisModel,
    ColorModel,
)
from ...core.context import RenderContext
from .chart_utils import (
    compute_openxml_nice_bounds,
    generate_nice_ticks,
    format_data_label_value,
    generate_calendar_anchors,
    compute_calendar_axis_range,
)


class PlotEngine:
    """
    Renders pure chart plot graphics in a 100% thread-safe manner.
    """

    def determine_axis_ranges(self, chart: ChartModel):
        """Calculates min, max, step, and span for primary and secondary value axes."""
        stacked_bar_types = (
            ChartType.STACKED_COLUMN,
            ChartType.PERCENT_STACKED_COLUMN,
            ChartType.STACKED_BAR,
            ChartType.PERCENT_STACKED_BAR,
        )
        bar_types = (
            ChartType.COLUMN,
            ChartType.BAR,
            ChartType.STACKED_COLUMN,
            ChartType.PERCENT_STACKED_COLUMN,
            ChartType.STACKED_BAR,
            ChartType.PERCENT_STACKED_BAR,
        )
        bar_series = [
            s for s in chart.series_list
            if (s.chart_type in bar_types if s.chart_type is not None else chart.chart_type in bar_types)
        ]
        is_stacked = any((s.chart_type in stacked_bar_types) for s in bar_series) or (
            chart.chart_type in stacked_bar_types
        )

        num_categories = (
            len(chart.categories)
            if chart.categories
            else max((len(s.values) for s in chart.series_list if s.values), default=1)
        )

        def _calc_range(
            axis_model: Optional[ChartAxisModel],
            series_subset: List[ChartDataSeries],
            is_stack: bool,
        ):
            if axis_model and axis_model.min_val is not None and axis_model.max_val is not None:
                step = axis_model.major_unit or ((axis_model.max_val - axis_model.min_val) / 5.0)
                return axis_model.min_val, axis_model.max_val, step, max(1e-5, axis_model.max_val - axis_model.min_val)

            if axis_model and axis_model.max_val is not None and axis_model.max_val > 0.0 and axis_model.min_val is None:
                n_max = axis_model.max_val
                n_min = 0.0
                if axis_model.major_unit is not None:
                    step = axis_model.major_unit
                else:
                    rng = max(1e-5, n_max - n_min)
                    raw_step = rng / 6.0
                    mag = 10.0 ** np.floor(np.log10(max(1e-9, raw_step)))
                    norm_step = raw_step / mag
                    if norm_step <= 1.25:
                        step = 1.0 * mag
                    elif norm_step <= 2.4:
                        step = 2.0 * mag
                    elif norm_step <= 5.0:
                        step = 5.0 * mag
                    else:
                        step = 10.0 * mag
                return n_min, n_max, step, max(1e-5, n_max - n_min)

            if is_stack:
                totals = [0.0] * num_categories
                for s in series_subset:
                    for idx, v in enumerate(s.values[:num_categories]):
                        if v is not None and not np.isnan(v):
                            totals[idx] += v
                d_min, d_max = 0.0, max(totals, default=100.0)
            else:
                all_v = [
                    v for s in series_subset
                    for v in s.values[:num_categories]
                    if (v is not None and not np.isnan(v))
                ]
                d_min = min(all_v) if all_v else 0.0
                d_max = max(all_v) if all_v else 100.0

            # If data labels are present above/outside bars/points, ensure adequate headroom
            has_outside_labels = any(
                (s.series_data_label and s.series_data_label.show_val and s.series_data_label.position in ("outEnd", "t", "bestFit"))
                or any(dl.show_val and dl.position in ("outEnd", "t", "bestFit") for dl in s.data_labels.values())
                for s in series_subset
            )

            inherited_mu = None
            if axis_model and axis_model.major_unit is not None:
                inherited_mu = axis_model.major_unit
            elif chart.sec_val_axis and chart.sec_val_axis.major_unit is not None and not has_visible_sec_axis:
                raw_mu = chart.sec_val_axis.major_unit
                if chart.sec_val_axis.num_fmt and "0.0,," in chart.sec_val_axis.num_fmt and raw_mu >= 1e5:
                    inherited_mu = raw_mu / 1e7
                elif chart.sec_val_axis.num_fmt and ",," in chart.sec_val_axis.num_fmt and raw_mu >= 1e5:
                    inherited_mu = raw_mu / 1e6
                elif chart.sec_val_axis.num_fmt and ("," in chart.sec_val_axis.num_fmt) and raw_mu >= 1e3:
                    inherited_mu = raw_mu / 1e3
                else:
                    inherited_mu = raw_mu

            if inherited_mu is not None:
                step = inherited_mu
                if axis_model and axis_model.min_val is not None:
                    n_min = axis_model.min_val
                elif d_min < 0 and d_max <= 0:
                    n_min = np.floor(round(d_min / step, 6)) * step
                elif d_min > 0 and (d_min / max(1e-5, d_max) > 0.6):
                    n_min = max(0.0, (np.floor(d_min / step) - 1.0) * step)
                else:
                    n_min = 0.0

                if axis_model and axis_model.max_val is not None:
                    n_max = axis_model.max_val
                elif d_min < 0 and d_max <= 0:
                    n_max = 0.0
                else:
                    n_max = np.ceil(d_max / step) * step
            else:
                n_min, n_max, step = compute_openxml_nice_bounds(d_min, d_max)
                if axis_model and axis_model.min_val is not None:
                    n_min = axis_model.min_val
                elif d_min > 0 and (d_min / max(1e-5, d_max) >= 0.85) and not is_stack:
                    # Clustered positive values (e.g. 54.8 to 58.9): Excel adjusts min to avoid flat bars
                    val_span = d_max - d_min
                    _, _, step = compute_openxml_nice_bounds(0.0, max(val_span * 2.5, d_max * 0.15))
                    if step < 5.0 and d_max >= 40.0:
                        step = 5.0
                    n_min = max(0.0, np.floor(d_min / step) * step)
                    n_max = np.ceil(d_max / step) * step
                    if n_max <= d_max:
                        n_max += step
                if axis_model and axis_model.max_val is not None:
                    n_max = axis_model.max_val

            return n_min, n_max, step, max(1e-5, n_max - n_min)

        has_visible_sec_axis = chart.sec_val_axis is not None and not chart.sec_val_axis.is_deleted
        if not has_visible_sec_axis:
            prim_series = chart.series_list
            sec_series = []
        else:
            prim_series = [s for s in chart.series_list if not s.use_secondary_axis]
            sec_series = [s for s in chart.series_list if s.use_secondary_axis]

        is_prim_stacked = any(
            ((s.chart_type in stacked_bar_types) if s.chart_type else (chart.chart_type in stacked_bar_types))
            for s in prim_series
            if (s.chart_type in bar_types if s.chart_type else chart.chart_type in bar_types)
        )
        is_sec_stacked = any(
            ((s.chart_type in stacked_bar_types) if s.chart_type else (chart.chart_type in stacked_bar_types))
            for s in sec_series
            if (s.chart_type in bar_types if s.chart_type else chart.chart_type in bar_types)
        )

        prim_min, prim_max, prim_step, prim_range = _calc_range(chart.val_axis, prim_series, is_prim_stacked)
        sec_min, sec_max, sec_step, sec_range = _calc_range(chart.sec_val_axis, sec_series, is_sec_stacked)

        return (prim_min, prim_max, prim_step, prim_range), (sec_min, sec_max, sec_step, sec_range), is_stacked, bar_series

    def generate_image(self, chart: ChartModel, context: RenderContext) -> Optional[bytes]:
        """Renders the graphical plot components to a PNG byte array."""
        theme_colors = [
            context.color_engine.scheme_colors.get("accent1", ColorModel.from_hex("#4F81BD")).to_hex(),
            context.color_engine.scheme_colors.get("accent2", ColorModel.from_hex("#C0504D")).to_hex(),
            context.color_engine.scheme_colors.get("accent3", ColorModel.from_hex("#9BBB59")).to_hex(),
            context.color_engine.scheme_colors.get("accent4", ColorModel.from_hex("#8064A2")).to_hex(),
            context.color_engine.scheme_colors.get("accent5", ColorModel.from_hex("#4BACC6")).to_hex(),
            context.color_engine.scheme_colors.get("accent6", ColorModel.from_hex("#F79646")).to_hex(),
        ]

        bw = max(1.0, chart.bounds.w)
        bh = max(1.0, chart.bounds.h)
        fig_w = bw / 72.0
        fig_h = bh / 72.0

        fig = Figure(figsize=(fig_w, fig_h), dpi=context.config.dpi)
        FigureCanvasAgg(fig)
        fig.patch.set_alpha(0.0)

        # Plot Area Layout
        if chart.plot_layout:
            pl = chart.plot_layout
            left = max(0.001, min(0.95, pl.x))
            width = max(0.05, min(0.999 - left, pl.w))
            top_margin = max(0.001, pl.y)
            raw_h = pl.h

            # Top margin for title if plot area starts at the very top
            if chart.title:
                t_sz = chart.title_font_size if chart.title_font_size > 0 else 8.0
                min_top_pt = t_sz * 1.5 + 3.0
                min_top_frac = min_top_pt / chart.bounds.h if chart.bounds.h > 0 else 0.12
                if top_margin < min_top_frac:
                    shift_top = min_top_frac - top_margin
                    top_margin = min_top_frac
                    raw_h = max(0.05, raw_h - shift_top)

            if chart.val_axis and chart.val_axis.orientation == "maxMin":
                if chart.bounds.h > 105.0:
                    bottom_rem = 1.0 - (top_margin + raw_h)
                    min_bottom = 23.8 / chart.bounds.h if chart.bounds.h > 0 else 0.20
                    if bottom_rem < min_bottom:
                        raw_h = max(0.05, 1.0 - top_margin - min_bottom)
            elif chart.cat_axis and not chart.cat_axis.is_deleted and chart.cat_axis.tick_label_pos in ("nextTo", "low"):
                cat_margin_pt = 22.5 if abs(chart.cat_axis.label_rotation) >= 20.0 else 12.0
                if chart.show_legend and (chart.legend_position == "b" or (chart.legend_layout and chart.legend_layout.y > 0.65)):
                    cat_margin_pt += 13.0
                min_bottom = cat_margin_pt / chart.bounds.h if chart.bounds.h > 0 else 0.25
                bottom_rem = 1.0 - (top_margin + raw_h)
                if bottom_rem < min_bottom:
                    raw_h = max(0.05, 1.0 - top_margin - min_bottom)

            # Ensure left margin accommodates left value axis labels inside chart bounds
            if chart.val_axis and not chart.val_axis.is_deleted and chart.val_axis.tick_label_pos not in ("none", None):
                val_sz = chart.val_axis.font_size if chart.val_axis.font_size > 0 else 7.0
                (p_min, p_max, p_step, _), _, _, _ = self.determine_axis_ranges(chart)
                ticks = generate_nice_ticks(p_min, p_max, p_step)
                max_w = max((len(format_data_label_value(t, chart.val_axis.num_fmt or "#,##0")) * val_sz * 0.55 for t in ticks), default=10.0)
                min_left = (max_w + 6.5 + 1.5) / chart.bounds.w if chart.bounds.w > 0 else 0.08
                if left < min_left:
                    shift = min_left - left
                    left = min_left
                    width = max(0.05, width - shift)

            # Ensure right margin so plot does not overflow or touch the right chart container border
            min_right = 3.0 / chart.bounds.w if chart.bounds.w > 0 else 0.01
            if left + width > 1.0 - min_right:
                width = max(0.05, 1.0 - min_right - left)

            height = max(0.05, min(0.999 - top_margin, raw_h))
            bottom = max(0.001, 1.0 - (top_margin + height))
            ax = fig.add_axes([left, bottom, width, height])
        else:
            pie_types = (ChartType.PIE, ChartType.DOUGHNUT)
            is_pie_chart = any(s.chart_type in pie_types for s in chart.series_list) or chart.chart_type in pie_types
            if is_pie_chart:
                if chart.legend_layout and chart.legend_layout.x > 0.4:
                    avail_w = chart.legend_layout.x
                elif chart.legend_position == "r" and chart.show_legend:
                    avail_w = 0.55
                else:
                    avail_w = 1.0
                top_m = 0.12 if chart.title else 0.05
                bot_m = 0.05
                h_sp = 1.0 - top_m - bot_m
                ax = fig.add_axes([0.02, bot_m, max(0.1, avail_w - 0.04), h_sp])
            else:
                ax = fig.add_subplot(111)

        ax.patch.set_alpha(0.0)

        # Chart title is rendered as crisp vector text in chart_renderer.py

        categories = chart.categories
        max_vals_len = max((len(s.values) for s in chart.series_list if s.values), default=0)
        num_categories = len(categories) if categories else max(1, max_vals_len)

        (prim_min, prim_max, prim_step, _), (sec_min, sec_max, sec_step, _), is_stacked, bar_series = self.determine_axis_ranges(chart)

        is_date_axis = False
        numeric_dates: List[float] = []
        axis_min_ser = 0.0
        axis_max_ser = float(num_categories - 1)
        # Bar/column charts in PowerPoint are ALWAYS discrete category slots.
        # Only pure line/area/scatter charts without bars can use continuous date timelines.
        if categories and not bar_series:
            try:
                parsed_dates = [float(c) for c in categories if c]
                if len(parsed_dates) == len(categories) and any(30000 <= d <= 60000 for d in parsed_dates):
                    numeric_dates = parsed_dates
                    is_date_axis = True
            except (ValueError, TypeError):
                is_date_axis = False

        if is_date_axis:
            x_indices = np.array(numeric_dates)
            min_ser = float(min(numeric_dates))
            max_ser = float(max(numeric_dates))
            ca = chart.cat_axis
            min_dt = datetime(1899, 12, 30) + timedelta(days=min_ser)
            max_dt = datetime(1899, 12, 30) + timedelta(days=max_ser)
            anchors, axis_min_ser, axis_max_ser = compute_calendar_axis_range(
                min_dt, max_dt, ca.major_time_unit if ca else None, ca.major_unit if ca else None
            )
        else:
            x_indices = np.arange(num_categories)

        pie_types = (ChartType.PIE, ChartType.DOUGHNUT)
        has_pie = any(s.chart_type in pie_types for s in chart.series_list) or chart.chart_type in pie_types

        is_bubble = chart.chart_type in (ChartType.BUBBLE, ChartType.SCATTER) and not chart.is_combo

        # 1. PIE / DOUGHNUT CHART
        if has_pie:
            if chart.series_list:
                first_series = chart.series_list[0]
                raw_vals = [abs(v) if (v is not None and not np.isnan(v)) else 0.0 for v in first_series.values]
                colors = [
                    first_series.point_colors[i].to_hex()
                    if i in first_series.point_colors
                    else theme_colors[i % len(theme_colors)]
                    for i in range(len(raw_vals))
                ]
                wedgeprops = (
                    dict(width=0.4, edgecolor="white", linewidth=1.0)
                    if (chart.chart_type == ChartType.DOUGHNUT or first_series.chart_type == ChartType.DOUGHNUT)
                    else dict(edgecolor="white", linewidth=1.0)
                )
                start_ang = 90.0 - getattr(chart, "first_slice_angle", 0.0)
                ax.set_aspect("equal", adjustable="box")
                ax.pie(
                    raw_vals,
                    radius=1.0,
                    labels=None,
                    colors=colors,
                    autopct=None,
                    startangle=start_ang,
                    counterclock=False,
                    wedgeprops=wedgeprops,
                )
                ax.set_xlim(-1.0, 1.0)
                ax.set_ylim(-1.0, 1.0)
                ax.axis("off")

        # 2. BUBBLE / SCATTER CHART
        elif is_bubble:
            x_axis = None
            y_axis = None
            for a in chart.axes:
                if a.position in ("b", "t"):
                    x_axis = a
                elif a.position in ("l", "r"):
                    y_axis = a

            if not x_axis and chart.val_axis:
                x_axis = chart.val_axis
            if not y_axis and chart.sec_val_axis:
                y_axis = chart.sec_val_axis

            all_x = [x for s in chart.series_list for x in s.x_values if x is not None and not np.isnan(x)]
            if x_axis and x_axis.min_val is not None and x_axis.max_val is not None:
                x_min, x_max = x_axis.min_val, x_axis.max_val
            elif all_x:
                x_min, x_max = min(all_x) * 0.9, max(all_x) * 1.1
            else:
                x_min, x_max = 0.0, 10.0

            all_y = [y for s in chart.series_list for y in s.values if y is not None and not np.isnan(y)]
            if y_axis and y_axis.min_val is not None and y_axis.max_val is not None:
                y_min, y_max = y_axis.min_val, y_axis.max_val
            elif all_y:
                y_min, y_max = min(all_y) * 0.9, max(all_y) * 1.1
            else:
                y_min, y_max = 0.0, 10.0

            ax.set_xlim(left=x_min, right=x_max)
            ax.set_ylim(bottom=y_min, top=y_max)

            for s_idx, series in enumerate(chart.series_list):
                c = series.color.to_hex() if series.color else theme_colors[s_idx % len(theme_colors)]
                edge_c = series.border_color.to_hex() if series.border_color else "#FFFFFF"
                alpha = series.color.a if series.color is not None else 1.0
                lw = max(0.5, series.border_width) if series.border_color else 0.5

                x_pts = series.x_values
                y_pts = series.values
                sz_pts = series.bubble_sizes if series.bubble_sizes else [10.0] * len(y_pts)

                pts_count = min(len(x_pts), len(y_pts))
                valid_x = []
                valid_y = []
                valid_sizes = []
                for i in range(pts_count):
                    x = x_pts[i]
                    y = y_pts[i]
                    sz = sz_pts[i] if i < len(sz_pts) else 10.0
                    if x is not None and y is not None and not np.isnan(x) and not np.isnan(y):
                        valid_x.append(x)
                        valid_y.append(y)
                        s_area = ((sz if (sz is not None and not np.isnan(sz)) else 10.0) * 4.2) ** 1.8
                        valid_sizes.append(max(20.0, s_area))

                if valid_x:
                    ax.scatter(
                        valid_x,
                        valid_y,
                        s=valid_sizes,
                        c=c,
                        edgecolors=edge_c,
                        linewidths=lw,
                        alpha=alpha,
                        zorder=3 + s_idx,
                    )

            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax.tick_params(axis="both", which="both", bottom=False, left=False, labelbottom=False, labelleft=False)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.spines["left"].set_visible(False)
            ax.spines["bottom"].set_visible(False)
            ax.grid(False)

        else:
            # 3. COLUMN / BAR / LINE / COMBO / DUAL AXES
            line_series_primary: List[Tuple[int, ChartDataSeries]] = []
            line_series_secondary: List[Tuple[int, ChartDataSeries]] = []

            for s_idx, s in enumerate(chart.series_list):
                s_type = s.chart_type or chart.chart_type
                if s_type in (
                    ChartType.COLUMN,
                    ChartType.BAR,
                    ChartType.STACKED_COLUMN,
                    ChartType.PERCENT_STACKED_COLUMN,
                    ChartType.STACKED_BAR,
                    ChartType.PERCENT_STACKED_BAR,
                ):
                    pass
                elif s_type in (ChartType.LINE, ChartType.AREA, ChartType.SCATTER):
                    if s.use_secondary_axis and chart.sec_val_axis:
                        line_series_secondary.append((s_idx, s))
                    else:
                        line_series_primary.append((s_idx, s))
                else:
                    line_series_primary.append((s_idx, s))

            bar_groups = [g for g in chart.series_groups if g.chart_type in (
                ChartType.COLUMN, ChartType.BAR, ChartType.STACKED_COLUMN,
                ChartType.PERCENT_STACKED_COLUMN, ChartType.STACKED_BAR, ChartType.PERCENT_STACKED_BAR
            )]
            if not bar_groups and bar_series:
                bar_groups = [ChartSeriesGroup(
                    chart_type=chart.chart_type,
                    series_list=bar_series,
                    gap_width=chart.gap_width,
                    overlap=chart.overlap,
                    grouping="stacked" if is_stacked else "clustered",
                )]

            # Check if secondary axis is required for either lines or bars
            has_sec = bool(chart.sec_val_axis and not chart.sec_val_axis.is_deleted) and (
                bool(line_series_secondary)
                or any(getattr(s, "use_secondary_axis", False) for s in chart.series_list)
            )
            ax2 = None
            if has_sec:
                ax2 = ax.twinx()
                ax2.patch.set_alpha(0.0)
                sec_va = chart.sec_val_axis
                ax2.set_ylim(bottom=sec_min, top=sec_max)
                if sec_va.orientation == "maxMin":
                    ax2.invert_yaxis()
                sec_ticks = generate_nice_ticks(sec_min, sec_max, sec_step)
                ax2.set_yticks(sec_ticks)
                ax2.set_yticklabels([])
                ax2.tick_params(axis="y", right=False, labelright=False)
                ax2.spines["right"].set_visible(False)
                ax2.spines["top"].set_visible(False)
                ax2.spines["left"].set_visible(False)

                # If primary has lines and secondary has bars, ensure primary (lines) renders on top of bars
                if line_series_primary and any(getattr(s, "use_secondary_axis", False) for s in bar_series):
                    ax.set_zorder(ax2.get_zorder() + 1)
                    ax.patch.set_visible(False)

            for group in bar_groups:
                grp_stacked = group.grouping in ("stacked", "percentStacked")
                grp_secondary = any(getattr(s, "use_secondary_axis", False) for s in group.series_list)
                target_bar_ax = ax2 if (grp_secondary and ax2 is not None) else ax
                gap_pct = group.gap_width if group.gap_width > 0 else 150.0
                overlap_pct = group.overlap

                if grp_stacked:
                    bar_width = 1.0 / (1.0 + gap_pct / 100.0)
                    bar_width = max(0.2, min(0.9, bar_width))
                    pos_bottoms = np.zeros(num_categories)
                    neg_bottoms = np.zeros(num_categories)

                    for s_idx, series in enumerate(group.series_list):
                        # Skip overlay total series named "Total" if they don't have point_colors
                        if series.name == "Total" and not series.point_colors:
                            continue

                        is_spacer = series.color is None and (series.border_width == 0.0 or series.border_color is None)
                        c = series.color.to_hex() if series.color else ("none" if is_spacer else theme_colors[s_idx % len(theme_colors)])
                        ec = series.border_color.to_hex() if series.border_color else ("none" if is_spacer else None)
                        lw = series.border_width if series.border_color else 0.0
                        hatch = None
                        vals = np.array([
                            v if (v is not None and not np.isnan(v)) else 0.0
                            for v in series.values[:num_categories]
                        ])
                        if len(vals) < num_categories:
                            vals = np.pad(vals, (0, num_categories - len(vals)))

                        # Positive stack (bars >= 0)
                        pos_mask = vals >= 0
                        pos_vals = np.where(pos_mask, vals, 0.0)
                        if np.any(pos_mask):
                            bars_pos = target_bar_ax.bar(
                                x_indices, pos_vals, bottom=pos_bottoms,
                                label=series.name, color=c, edgecolor=ec, linewidth=lw, hatch=hatch, width=bar_width
                            )
                            for b_idx, bar in enumerate(bars_pos):
                                if b_idx in series.point_colors:
                                    bar.set_color(series.point_colors[b_idx].to_hex())
                            pos_bottoms += pos_vals

                        # Negative stack (bars < 0)
                        neg_mask = vals < 0
                        neg_vals = np.where(neg_mask, vals, 0.0)
                        if np.any(neg_mask):
                            bars_neg = target_bar_ax.bar(
                                x_indices, neg_vals, bottom=neg_bottoms,
                                label="", color=c, edgecolor=ec, linewidth=lw, hatch=hatch, width=bar_width
                            )
                            for b_idx, bar in enumerate(bars_neg):
                                if b_idx in series.point_colors:
                                    bar.set_color(series.point_colors[b_idx].to_hex())
                            neg_bottoms += neg_vals

                else:
                    num_group_bars = len(group.series_list)
                    overlap_frac = overlap_pct / 100.0
                    gap_frac = gap_pct / 100.0
                    effective_denom = num_group_bars - (num_group_bars - 1) * overlap_frac + gap_frac
                    single_bar_width = max(0.1, min(0.85, 1.0 / max(0.5, effective_denom)))
                    step_between = single_bar_width * (1.0 - overlap_frac)

                    for b_i, series in enumerate(group.series_list):
                        c = series.color.to_hex() if series.color else theme_colors[b_i % len(theme_colors)]
                        ec = series.border_color.to_hex() if series.border_color else None
                        lw = series.border_width if series.border_color else 0.0
                        hatch = ".." if series.pattern_preset else None

                        vals = [
                            v if (v is not None and not np.isnan(v)) else 0.0
                            for v in series.values[:num_categories]
                        ]
                        if len(vals) < num_categories:
                            vals.extend([0.0] * (num_categories - len(vals)))

                        bar_offset = (b_i - (num_group_bars - 1) / 2.0) * step_between
                        offsets = x_indices + bar_offset
                        bars = target_bar_ax.bar(offsets, vals, width=single_bar_width, label=series.name, color=c, edgecolor=ec, linewidth=lw, hatch=hatch)

                        if series.pattern_preset:
                            preset_lower = series.pattern_preset.lower()
                            pct = 5
                            if preset_lower.startswith("pct"):
                                try:
                                    pct = int(preset_lower.replace("pct", ""))
                                except ValueError:
                                    pct = 5
                            h_alpha = max(0.5, min(0.9, 0.6 + (pct / 100.0) * 0.4))
                            h_lw = max(0.3, min(0.6, 0.35 + (pct / 100.0) * 0.1))
                            hatch_color = (0.25, 0.25, 0.25, h_alpha)
                            for bar in bars:
                                bar._hatch_color = hatch_color
                                if hasattr(bar, "set_hatch_linewidth"):
                                    bar.set_hatch_linewidth(h_lw)

                        for b_idx, bar in enumerate(bars):
                            if b_idx in series.point_colors:
                                bar.set_color(series.point_colors[b_idx].to_hex())

            # Line / Scatter Plotting
            dash_map = {
                "lgDash": (0, (6, 3)),
                "dash": (0, (4, 2)),
                "sysDash": (0, (4, 2)),
                "dot": (0, (1, 1)),
                "sysDot": (0, (1, 1)),
                "dashDot": (0, (4, 2, 1, 2)),
                "solid": "-",
            }
            marker_map = {
                "circle": "o",
                "square": "s",
                "diamond": "D",
                "triangle": "^",
                "none": None,
            }

            def _plot_lines(target_ax, l_series):
                for s_idx, series in l_series:
                    c = series.color.to_hex() if series.color else theme_colors[s_idx % len(theme_colors)]
                    raw_vals = series.values[:num_categories]
                    vals = [v if (v is not None and not np.isnan(v)) else np.nan for v in raw_vals]
                    if len(vals) < num_categories:
                        vals.extend([np.nan] * (num_categories - len(vals)))

                    ls = dash_map.get(series.dash_style, "-")
                    if series.border_width == 0.0 or series.dash_style == "none":
                        ls = "None"
                    lw = max(0.5, series.border_width) if ls != "None" else 0.0
                    m_sym = marker_map.get(series.marker_symbol, None)
                    m_clr = series.marker_color.to_hex() if series.marker_color else c

                    valid_pts = [(xi, vi) for xi, vi in zip(x_indices, vals) if not np.isnan(vi)]
                    if valid_pts:
                        xs_arr = np.array([pt[0] for pt in valid_pts], dtype=float)
                        ys_arr = np.array([pt[1] for pt in valid_pts], dtype=float)

                        # Smooth Spline Curve for series with smooth=True
                        if series.smooth and len(xs_arr) >= 3 and ls != "None" and lw > 0:
                            try:
                                from scipy.interpolate import pchip_interpolate
                                x_dense = np.linspace(xs_arr[0], xs_arr[-1], max(60, len(xs_arr) * 15))
                                y_dense = pchip_interpolate(xs_arr, ys_arr, x_dense)
                                target_ax.plot(
                                    x_dense, y_dense,
                                    label=series.name,
                                    color=c, linestyle=ls, linewidth=lw
                                )
                                if m_sym:
                                    target_ax.plot(
                                        xs_arr, ys_arr,
                                        linestyle="None",
                                        marker=m_sym,
                                        markersize=series.marker_size if series.marker_size > 0 else 5.0,
                                        markerfacecolor=m_clr,
                                        markeredgecolor=m_clr,
                                        markeredgewidth=0.5,
                                    )
                            except Exception:
                                target_ax.plot(
                                    xs_arr, ys_arr,
                                    label=series.name,
                                    color=c, linestyle=ls, linewidth=lw,
                                    marker=m_sym,
                                    markersize=series.marker_size if m_sym else 0,
                                    markerfacecolor=m_clr,
                                    markeredgecolor=m_clr,
                                    markeredgewidth=0.5 if m_sym else 0,
                                )
                        else:
                            target_ax.plot(
                                xs_arr, ys_arr,
                                label=series.name,
                                color=c, linestyle=ls, linewidth=lw,
                                marker=m_sym,
                                markersize=series.marker_size if m_sym else 0,
                                markerfacecolor=m_clr,
                                markeredgecolor=m_clr,
                                markeredgewidth=0.5 if m_sym else 0,
                            )

            _plot_lines(ax, line_series_primary)
            if line_series_secondary and ax2 is not None:
                _plot_lines(ax2, line_series_secondary)

            cross_between = "between"
            if chart.cat_axis and getattr(chart.cat_axis, "cross_between", None):
                cross_between = chart.cat_axis.cross_between
            elif chart.val_axis and getattr(chart.val_axis, "cross_between", None):
                cross_between = chart.val_axis.cross_between

            if is_date_axis:
                ax.set_xlim(left=axis_min_ser, right=axis_max_ser)
                ax.margins(x=0)
                if ax2 is not None:
                    ax2.set_xlim(left=axis_min_ser, right=axis_max_ser)
                    ax2.margins(x=0)
            elif not bar_series:
                if cross_between == "midCat":
                    ax.set_xlim(left=0, right=max(1, num_categories - 1))
                else:
                    ax.set_xlim(left=-0.5, right=num_categories - 0.5)
                ax.margins(x=0)
                if ax2 is not None:
                    if cross_between == "midCat":
                        ax2.set_xlim(left=0, right=max(1, num_categories - 1))
                    else:
                        ax2.set_xlim(left=-0.5, right=num_categories - 0.5)
                    ax2.margins(x=0)
            else:
                ax.set_xlim(left=-0.5, right=num_categories - 0.5)
                ax.margins(x=0)
                if ax2 is not None:
                    ax2.set_xlim(left=-0.5, right=num_categories - 0.5)
                    ax2.margins(x=0)

            if not is_date_axis:
                ax.set_xticks(x_indices)
            ax.set_xticklabels([])
            ax.tick_params(axis="x", bottom=False, labelbottom=False)

            if chart.val_axis:
                va = chart.val_axis
                ax.set_ylim(bottom=prim_min, top=prim_max)
                if va.orientation == "maxMin":
                    ax.invert_yaxis()

                prim_ticks = generate_nice_ticks(prim_min, prim_max, prim_step)
                ax.set_yticks(prim_ticks)

                ax.set_yticklabels([])
                ax.tick_params(axis="y", left=False, labelleft=False)
                ax.spines["left"].set_visible(False)

                if va.show_major_gridlines:
                    g_color = va.gridline_color.to_hex() if va.gridline_color else "#D9D9D9"
                    g_width = max(0.5, va.gridline_width)
                    ax.grid(True, axis="y", linestyle="-", linewidth=g_width, color=g_color, alpha=0.9)
                else:
                    ax.grid(False, axis="y")
            else:
                ax.grid(False, axis="y")

            if chart.cat_axis:
                ca = chart.cat_axis
                if ca.axis_line_width == 0:
                    ax.spines["bottom"].set_visible(False)
                elif ca.axis_line_color:
                    ax.spines["bottom"].set_color(ca.axis_line_color.to_hex())
                    ax.spines["bottom"].set_linewidth(ca.axis_line_width)

                if not ca.show_major_gridlines:
                    ax.grid(False, axis="x")

            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

        buf = io.BytesIO()
        fig.savefig(buf, format="png", transparent=True, dpi=context.config.dpi)
        return buf.getvalue()
