"""
Legend Layout Engine for OpenXML DrawingML Charts.
Supports exact manualLayout centered distribution, docked layouts (t, b, l, r, tr),
and precise OpenXML-standard swatch dimensions (19.2pt line samples vs 12.0pt bar rectangles).
"""

from typing import Optional
from ...canvas.base_canvas import BaseCanvas
from ...core.models import (
    ChartModel,
    ChartType,
    ChartDataSeries,
    ColorModel,
    FillModel,
    FillType,
    StrokeModel,
    Rect2D,
    Point2D,
)
from ...typography.font_metrics import FontMetrics

# OpenXML DrawingML Legend Standard Dimensions (derived from ISO/IEC 29500 & PowerPoint)
_SWATCH_WIDTH_LINE = 19.2   # pt for line/scatter/area legend swatch line
_SWATCH_WIDTH_BAR = 12.0    # pt for bar/column legend swatch rectangle
_SWATCH_TEXT_GAP = 2.0      # pt gap between swatch and label text
_INTER_ITEM_GAP = 12.5      # pt standard gap between consecutive legend items


class LegendEngine:
    """
    Renders vector chart legends with exact swatch positioning.
    """

    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()

    def _measure_text_width(
        self,
        text: str,
        font_family: str = "Calibri",
        font_size: float = 7.0,
        bold: bool = False,
    ) -> float:
        return self.font_metrics.measure_text_width(
            text, family=font_family, size=font_size, bold=bold
        )

    def _is_bar_series(self, series: ChartDataSeries, chart: ChartModel) -> bool:
        bar_types = (
            ChartType.COLUMN,
            ChartType.BAR,
            ChartType.STACKED_COLUMN,
            ChartType.PERCENT_STACKED_COLUMN,
            ChartType.STACKED_BAR,
            ChartType.PERCENT_STACKED_BAR,
        )
        s_type = series.chart_type or chart.chart_type
        return s_type in bar_types

    def render_legend(
        self,
        chart: ChartModel,
        plot_rect: Rect2D,
        is_stacked: bool,
        canvas: BaseCanvas,
    ) -> None:
        """Renders the legend swatches and labels."""
        if not chart.show_legend or len(chart.series_list) == 0:
            return

        cx, cy = chart.bounds.x, chart.bounds.y
        cw, ch = chart.bounds.w, chart.bounds.h
        px, py, pw, ph = plot_rect.x, plot_rect.y, plot_rect.w, plot_rect.h
        p_top = py

        pie_types = (ChartType.PIE, ChartType.DOUGHNUT)
        is_pie = any(s.chart_type in pie_types for s in chart.series_list) or chart.chart_type in pie_types
        if is_pie:
            first_series = chart.series_list[0] if chart.series_list else None
            if not chart.categories or not first_series:
                return

            theme_palette = [
                ColorModel.from_hex("#4F81BD"),
                ColorModel.from_hex("#C0504D"),
                ColorModel.from_hex("#9BBB59"),
                ColorModel.from_hex("#8064A2"),
                ColorModel.from_hex("#4BACC6"),
                ColorModel.from_hex("#F79646"),
            ]
            leg_font_sz = chart.legend_font_size if chart.legend_font_size > 0 else 7.0
            leg_font_fam = chart.legend_font_family or chart.font_family or "Arial"
            text_col = chart.legend_font_color or ColorModel(0.0, 0.0, 0.0, 1.0)
            sw_size = round(min(5.5, max(3.5, leg_font_sz * 0.65)), 1)
            sw_text_gap = 3.0

            if chart.legend_layout:
                leg_x = cx + chart.legend_layout.x * cw
                leg_y = cy + chart.legend_layout.y * ch
                leg_w = chart.legend_layout.w * cw
                leg_h = chart.legend_layout.h * ch
            elif chart.legend_position == "r":
                leg_x = cx + cw * 0.56
                leg_y = cy + ch * 0.22
                leg_w = cw * 0.40
                leg_h = ch * 0.70
            else:
                leg_x = px
                leg_y = py + ph + 8.0
                leg_w = pw
                leg_h = 20.0

            num_cats = len(chart.categories)
            item_h = max(leg_font_sz * 1.4 + 2.0, min(18.0, leg_h / max(1, num_cats)))
            cur_y = leg_y + 2.0

            for cat_idx, cat_name in enumerate(chart.categories):
                if cat_idx in first_series.point_colors:
                    cat_color = first_series.point_colors[cat_idx]
                else:
                    cat_color = theme_palette[cat_idx % len(theme_palette)]

                mid_y = cur_y + leg_font_sz * 0.4
                canvas.draw_rect(
                    Rect2D(leg_x, mid_y - sw_size / 2.0, sw_size, sw_size),
                    fill=FillModel(fill_type=FillType.SOLID, color=cat_color),
                    stroke=None,
                )
                baseline_y = mid_y + leg_font_sz * 0.35
                canvas.draw_text(
                    Point2D(leg_x + sw_size + sw_text_gap, baseline_y),
                    cat_name.strip(),
                    font_family=leg_font_fam,
                    font_size=leg_font_sz,
                    color=text_col,
                    bold=False,
                )
                cur_y += item_h
            return

        named_series = [s for s in chart.series_list if s.name and getattr(s, "show_in_legend", True)]
        if not named_series:
            return

        has_only_bars = all(self._is_bar_series(s, chart) for s in named_series)
        leg_font_sz = chart.legend_font_size if chart.legend_font_size > 0 else 7.0
        bar_sw_w = round(min(4.5, max(3.0, leg_font_sz * 0.5)), 2) if has_only_bars else _SWATCH_WIDTH_BAR

        def _draw_swatch(
            swatch_x: float,
            swatch_w: float,
            mid_y: float,
            series: ChartDataSeries,
        ):
            s_color = series.color or series.marker_color or ColorModel(0.2, 0.2, 0.2, 1.0)
            if self._is_bar_series(series, chart):
                sw_h = swatch_w if has_only_bars else round(min(5.0, max(3.5, leg_font_sz * 0.55)), 1)
                stroke = None
                if series.border_color:
                    stroke = StrokeModel(color=series.border_color, width=series.border_width or 0.75)
                canvas.draw_rect(
                    Rect2D(swatch_x, mid_y - sw_h / 2.0, swatch_w, sw_h),
                    fill=FillModel(fill_type=FillType.SOLID, color=s_color),
                    stroke=stroke,
                )
            elif series.marker_symbol and series.marker_symbol != "none" and (series.border_width == 0 or series.dash_style == "none" or series.chart_type == ChartType.SCATTER):
                m_color = series.marker_color or s_color
                rad = min(2.5, leg_font_sz * 0.35)
                canvas.draw_ellipse(
                    Rect2D(swatch_x + (swatch_w / 2.0) - rad, mid_y - rad, rad * 2.0, rad * 2.0),
                    fill=FillModel(fill_type=FillType.SOLID, color=m_color),
                )
            else:
                lw = max(1.5, series.border_width)
                canvas.draw_line(
                    Point2D(swatch_x, mid_y),
                    Point2D(swatch_x + swatch_w, mid_y),
                    stroke=StrokeModel(color=s_color, width=lw, dash_style=series.dash_style),
                )

        leg_font_fam = chart.legend_font_family or chart.font_family or "Arial"
        sw_text_gap = 1.8 if has_only_bars else _SWATCH_TEXT_GAP

        # 1. Manual Layout Mode (Exact Centered PowerPoint Flow)
        if chart.legend_layout:
            leg_x = cx + chart.legend_layout.x * cw
            leg_y = cy + chart.legend_layout.y * ch
            leg_w = chart.legend_layout.w * cw
            leg_h = chart.legend_layout.h * ch

            item_widths = []
            for series in named_series:
                s_name = series.name.strip()
                t_w = self._measure_text_width(s_name, leg_font_fam, leg_font_sz)
                sw_w = bar_sw_w if self._is_bar_series(series, chart) else _SWATCH_WIDTH_LINE
                item_w = sw_w + sw_text_gap + t_w
                item_widths.append((sw_w, t_w, item_w))

            num_items = len(named_series)
            total_content_w = sum(w for _, _, w in item_widths)

            # Check if legend requires 2-row grid (height accommodates 2 rows and items overflow or num_items >= 3)
            is_two_row = (leg_h >= leg_font_sz * 2.0) and (num_items >= 3) and (total_content_w + (num_items - 1) * 6.0 > leg_w)

            if is_two_row:
                num_cols = (num_items + 1) // 2
                col_w = leg_w / num_cols
                row_h = leg_h / 2.0
                # Calculate horizontal margin so columns look centered in the legend box
                max_w_per_col = [0.0] * num_cols
                for s_idx in range(num_items):
                    c = s_idx % num_cols
                    max_w_per_col[c] = max(max_w_per_col[c], item_widths[s_idx][2])
                grid_span = sum(max_w_per_col)
                grid_gap = max(10.0, (leg_w - grid_span) / max(1, num_cols))

                for s_idx, series in enumerate(named_series):
                    r = s_idx // num_cols
                    c = s_idx % num_cols
                    sw_w, t_w, item_w = item_widths[s_idx]
                    s_name = series.name.strip()
                    if chart.legend_font_color:
                        text_col = chart.legend_font_color
                    elif chart.chart_type == ChartType.LINE and not has_only_bars:
                        text_col = series.color or ColorModel(0.2, 0.2, 0.2, 1.0)
                    else:
                        text_col = ColorModel(0.0, 0.0, 0.0, 1.0)

                    mid_y = leg_y + (r + 0.5) * row_h
                    baseline_y = mid_y + leg_font_sz * 0.35
                    item_x = leg_x + c * col_w + (col_w - max_w_per_col[c]) / 2.0

                    _draw_swatch(item_x, sw_w, mid_y, series)
                    text_x = item_x + sw_w + sw_text_gap
                    canvas.draw_text(
                        Point2D(text_x, baseline_y),
                        s_name,
                        font_family=leg_font_fam,
                        font_size=leg_font_sz,
                        color=text_col,
                        bold=False,
                    )
            else:
                mid_y = leg_y + leg_h * 0.5
                baseline_y = mid_y + leg_font_sz * 0.35

                # Calculate appropriate inter-item gap
                if num_items > 1 and leg_w > total_content_w:
                    avail_gap = (leg_w - total_content_w) / (num_items - 1)
                    if has_only_bars:
                        inter_gap = min(12.0, max(5.0, avail_gap * 0.60))
                    elif num_items == 2:
                        inter_gap = min(60.0, max(14.0, avail_gap * 0.25))
                    else:
                        inter_gap = min(18.0, max(3.5, avail_gap))
                elif has_only_bars:
                    inter_gap = 7.5
                elif num_items == 2:
                    inter_gap = 14.0
                elif num_items > 2:
                    inter_gap = 12.5
                else:
                    inter_gap = _INTER_ITEM_GAP

                total_span = total_content_w + (num_items - 1) * inter_gap
                start_x = leg_x + max(0.0, (leg_w - total_span) / 2.0)

                curr_x = start_x

                for s_idx, series in enumerate(named_series):
                    sw_w, t_w, item_w = item_widths[s_idx]
                    s_name = series.name.strip()

                    if chart.legend_font_color:
                        text_col = chart.legend_font_color
                    elif chart.chart_type == ChartType.LINE and not has_only_bars:
                        text_col = series.color or ColorModel(0.2, 0.2, 0.2, 1.0)
                    else:
                        text_col = ColorModel(0.0, 0.0, 0.0, 1.0)

                    _draw_swatch(curr_x, sw_w, mid_y, series)

                    text_x = curr_x + sw_w + sw_text_gap
                    canvas.draw_text(
                        Point2D(text_x, baseline_y),
                        s_name,
                        font_family=leg_font_fam,
                        font_size=leg_font_sz,
                        color=text_col,
                        bold=False,
                    )

                    curr_x += item_w + inter_gap

        # 2. Docked Position Mode
        elif chart.legend_position in ("t", "tr", "r", "b"):
            if chart.legend_position == "b":
                leg_y = py + ph + 10.0
            elif chart.legend_position in ("t", "tr"):
                leg_y = p_top - 10.0
            else:
                leg_y = cy + ch / 2.0

            mid_y = leg_y + leg_font_sz * 0.4
            baseline_y = mid_y + leg_font_sz * 0.35

            item_widths = []
            for series in named_series:
                s_name = series.name.strip()
                t_w = self._measure_text_width(s_name, leg_font_fam, leg_font_sz)
                sw_w = bar_sw_w if self._is_bar_series(series, chart) else _SWATCH_WIDTH_LINE
                item_w = sw_w + sw_text_gap + t_w
                item_widths.append((sw_w, t_w, item_w))

            num_items = len(named_series)
            if has_only_bars:
                inter_gap = 3.5
            elif num_items == 2:
                inter_gap = 12.0
            else:
                inter_gap = _INTER_ITEM_GAP

            total_w = sum(w for _, _, w in item_widths) + max(0, num_items - 1) * inter_gap

            if chart.legend_position in ("t", "tr", "b"):
                start_x = px + pw / 2.0 - total_w / 2.0
            else:
                start_x = px + pw + 15.0

            curr_x = start_x

            for s_idx, series in enumerate(named_series):
                sw_w, t_w, item_w = item_widths[s_idx]
                s_name = series.name.strip()
                if chart.legend_font_color:
                    text_col = chart.legend_font_color
                elif chart.chart_type == ChartType.LINE and not has_only_bars:
                    text_col = series.color or ColorModel(0.2, 0.2, 0.2, 1.0)
                else:
                    text_col = ColorModel(0.0, 0.0, 0.0, 1.0)

                _draw_swatch(curr_x, sw_w, mid_y, series)

                text_x = curr_x + sw_w + sw_text_gap
                canvas.draw_text(
                    Point2D(text_x, baseline_y),
                    s_name,
                    font_family=leg_font_fam,
                    font_size=leg_font_sz,
                    color=text_col,
                    bold=False,
                )

                curr_x += item_w + inter_gap
