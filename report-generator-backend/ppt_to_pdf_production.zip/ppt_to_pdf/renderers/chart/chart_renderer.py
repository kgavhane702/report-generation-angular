"""
Decoupled Chart Element Renderer Orchestrator.
Coordinates PlotEngine, AxisEngine, LegendEngine, and DataLabelEngine
to render OpenXML DrawingML charts with exact vector typography and high-DPI graphics.
"""

from typing import Optional
from ...canvas.base_canvas import BaseCanvas
from ...core.context import RenderContext
from ...core.models import ChartModel, Rect2D, Point2D, ColorModel, FillModel, StrokeModel
from ...typography.font_metrics import FontMetrics
from ...utils.logger import get_logger
from ..base import BaseElementRenderer

from .plot_engine import PlotEngine
from .axis_engine import AxisEngine
from .legend_engine import LegendEngine
from .data_label_engine import DataLabelEngine
from .frame_engine import FrameEngine
from .chart_utils import (
    format_data_label_value,
    format_excel_date,
    compute_openxml_nice_bounds,
    generate_nice_ticks,
)

logger = get_logger(__name__)


class ChartRenderer(BaseElementRenderer):
    """
    Orchestrates the modular chart rendering pipeline.
    """

    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()
        self.plot_engine = PlotEngine()
        self.axis_engine = AxisEngine(font_metrics=self.font_metrics)
        self.legend_engine = LegendEngine(font_metrics=self.font_metrics)
        self.data_label_engine = DataLabelEngine(font_metrics=self.font_metrics)
        self.frame_engine = FrameEngine()

    def _compute_plot_rect(self, chart: ChartModel) -> Rect2D:
        """Calculates the absolute plot area rectangle in points."""
        cx, cy = chart.bounds.x, chart.bounds.y
        cw, ch = chart.bounds.w, chart.bounds.h

        if chart.plot_layout:
            pl = chart.plot_layout
            px = cx + pl.x * cw
            py = cy + pl.y * ch
            pw = pl.w * cw
            ph = pl.h * ch

            # When value axis is inverted (maxMin) the category axis labels appear
            # at the bottom. Only adjust ph if tick labels are positioned at nextTo/low
            # (i.e., at the actual bottom of the chart). If tickLblPos is "high" the
            # labels are at the top and no bottom margin adjustment is needed.
            if chart.val_axis and chart.val_axis.orientation == "maxMin":
                if chart.bounds.h > 105.0:
                    chart_bottom = cy + ch
                    min_bottom = 23.8
                    if chart_bottom - (py + ph) < min_bottom:
                        ph = max(10.0, chart_bottom - min_bottom - py)
            elif (chart.cat_axis and not chart.cat_axis.is_deleted
                    and chart.cat_axis.tick_label_pos in ("nextTo", "low")
                    and abs(chart.cat_axis.label_rotation) >= 20.0):
                chart_bottom = cy + ch
                min_bottom = 22.5
                if chart_bottom - (py + ph) < min_bottom:
                    ph = max(10.0, chart_bottom - min_bottom - py)

            # Ensure left margin accommodates left value axis labels inside chart bounds
            if chart.val_axis and not chart.val_axis.is_deleted and chart.val_axis.tick_label_pos not in ("none", None):
                val_sz = chart.val_axis.font_size if chart.val_axis.font_size > 0 else 7.0
                val_fam = chart.val_axis.font_family or chart.font_family or "Arial"
                (p_min, p_max, p_step, _), _, _, _ = self.plot_engine.determine_axis_ranges(chart)
                ticks = generate_nice_ticks(p_min, p_max, p_step)
                max_w = max((self.legend_engine._measure_text_width(
                    format_data_label_value(t, chart.val_axis.num_fmt or "#,##0"),
                    val_fam,
                    val_sz,
                ) for t in ticks), default=10.0)
                min_px = cx + max_w + 6.5 + 1.5
                if px < min_px:
                    shift = min_px - px
                    px = min_px
                    pw = max(10.0, pw - shift)

            # Ensure right margin so plot does not overflow or touch the right chart container border
            chart_right = cx + cw
            min_right_margin = 3.0
            if px + pw > chart_right - min_right_margin:
                pw = max(10.0, chart_right - min_right_margin - px)
        else:
            px = cx + 0.08 * cw
            py = cy + 0.05 * ch
            pw = 0.88 * cw
            ph = 0.85 * ch

        return Rect2D(x=px, y=py, w=pw, h=ph)

    def render(self, element: ChartModel, canvas: BaseCanvas, context: RenderContext) -> None:
        """Renders the chart element onto the PDF canvas."""
        if element is None or not element.series_list or element.bounds.w <= 0 or element.bounds.h <= 0:
            return

        try:
            # 0. Render chart background fill if present
            self.frame_engine.render_background(element, canvas)

            # 1. Determine axis ranges
            prim_range_tuple, sec_range_tuple, is_stacked, bar_series = self.plot_engine.determine_axis_ranges(element)

            # 2. Render plot area graphics (bars, lines, areas, pies) via matplotlib
            chart_bytes = self.plot_engine.generate_image(element, context)
            if chart_bytes:
                canvas.draw_image(chart_bytes, rect=element.bounds)

            # 3. Calculate absolute plot area bounds
            plot_rect = self._compute_plot_rect(element)

            # 4. Render category & date axes (with calendar math, spine lines, tick marks, and rotation)
            self.axis_engine.render_category_and_date_axes(element, plot_rect, canvas, context)

            # 5. Render value axes (ticks and labels for primary and secondary axes)
            self.axis_engine.render_value_axes(element, plot_rect, prim_range_tuple, sec_range_tuple, canvas)

            # 6. Render legend (manualLayout or docked positions with swatches)
            self.legend_engine.render_legend(element, plot_rect, is_stacked, canvas)

            # 7. Render data labels (stacked bars and continuous series)
            self.data_label_engine.render_data_labels(
                element, plot_rect, prim_range_tuple, sec_range_tuple, is_stacked, bar_series, canvas
            )

            # 8. Render chart title as crisp searchable vector text
            if element.title:
                t_sz = element.title_font_size if element.title_font_size > 0 else 8.0
                t_col = element.title_color or ColorModel(0.0, 0.0, 0.0, 1.0)
                t_fam = element.title_font_family or element.font_family or "Arial"
                t_bold = element.title_bold if element.title_bold is not None else False
                t_w = self.axis_engine._measure_text_width(element.title, t_fam, t_sz, bold=t_bold)
                t_x = element.bounds.x + max(0.0, (element.bounds.w - t_w) / 2.0)
                t_y = element.bounds.y + max(13.5, t_sz * 1.75)
                canvas.draw_text(
                    Point2D(t_x, t_y),
                    element.title,
                    font_family=t_fam,
                    font_size=t_sz,
                    color=t_col,
                    bold=t_bold,
                )

            # 9. Render chart frame border box if defined
            self.frame_engine.render_border(element, canvas)

        except Exception as e:
            logger.debug(f"Failed to render chart '{element.title or element.name}': {e}", exc_info=True)
