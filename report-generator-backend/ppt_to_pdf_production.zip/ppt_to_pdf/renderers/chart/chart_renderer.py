"""
Decoupled Chart Element Renderer Orchestrator.
Coordinates PlotEngine, AxisEngine, LegendEngine, and DataLabelEngine
to render OpenXML DrawingML charts with exact vector typography and high-DPI graphics.
"""

from typing import Optional
from ...canvas.base_canvas import BaseCanvas
from ...core.context import RenderContext
from ...core.models import ChartModel, ChartType, Rect2D, Point2D, ColorModel, FillModel, StrokeModel
from ...typography.font_metrics import FontMetrics
from ...utils.logger import get_logger
from ..base import BaseElementRenderer

from .plot_engine import PlotEngine
from .axis_engine import AxisEngine
from .legend_engine import LegendEngine
from .data_label_engine import DataLabelEngine
from .frame_engine import FrameEngine
from .chart_utils import (
    format_data_label_value,
    format_excel_date,
    compute_openxml_nice_bounds,
    generate_nice_ticks,
)

logger = get_logger(__name__)


class ChartRenderer(BaseElementRenderer):
    """
    Orchestrates the modular chart rendering pipeline.
    """

    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()
        self.plot_engine = PlotEngine()
        self.axis_engine = AxisEngine(font_metrics=self.font_metrics)
        self.legend_engine = LegendEngine(font_metrics=self.font_metrics)
        self.data_label_engine = DataLabelEngine(font_metrics=self.font_metrics)
        self.frame_engine = FrameEngine()

    def _compute_plot_rect(self, chart: ChartModel) -> Rect2D:
        """Calculates the absolute plot area rectangle in points."""
        cx, cy = chart.bounds.x, chart.bounds.y
        cw, ch = chart.bounds.w, chart.bounds.h

        if chart.plot_layout:
            pl = chart.plot_layout
            px = cx + pl.x * cw
            py = cy + pl.y * ch
            pw = pl.w * cw
            ph = pl.h * ch

            # Top margin for title if plot area starts at the very top
            if chart.title:
                t_sz = chart.title_font_size if chart.title_font_size > 0 else 8.0
                min_top_pt = t_sz * 1.5 + 3.0
                if py < cy + min_top_pt:
                    shift_top = (cy + min_top_pt) - py
                    py = cy + min_top_pt
                    ph = max(10.0, ph - shift_top)

            if chart.val_axis and chart.val_axis.orientation == "maxMin":
                if chart.bounds.h > 105.0:
                    chart_bottom = cy + ch
                    min_bottom = 23.8
                    if chart_bottom - (py + ph) < min_bottom:
                        ph = max(10.0, chart_bottom - min_bottom - py)
            elif chart.cat_axis and not chart.cat_axis.is_deleted and chart.cat_axis.tick_label_pos in ("nextTo", "low"):
                cat_margin_pt = 22.5 if abs(chart.cat_axis.label_rotation) >= 20.0 else 12.0
                if chart.show_legend and (chart.legend_position == "b" or (chart.legend_layout and chart.legend_layout.y > 0.65)):
                    cat_margin_pt += 13.0
                chart_bottom = cy + ch
                if chart_bottom - (py + ph) < cat_margin_pt:
                    ph = max(10.0, chart_bottom - cat_margin_pt - py)

            # Ensure left margin accommodates left value axis labels inside chart bounds
            if chart.val_axis and not chart.val_axis.is_deleted and chart.val_axis.tick_label_pos not in ("none", None):
                val_sz = chart.val_axis.font_size if chart.val_axis.font_size > 0 else 7.0
                val_fam = chart.val_axis.font_family or chart.font_family or "Arial"
                (p_min, p_max, p_step, _), _, _, _ = self.plot_engine.determine_axis_ranges(chart)
                ticks = generate_nice_ticks(p_min, p_max, p_step)
                max_w = max((self.legend_engine._measure_text_width(
                    format_data_label_value(t, chart.val_axis.num_fmt or "#,##0"),
                    val_fam,
                    val_sz,
                ) for t in ticks), default=10.0)
                min_px = cx + max_w + 6.5 + 1.5
                if px < min_px:
                    shift = min_px - px
                    px = min_px
                    pw = max(10.0, pw - shift)

            # Ensure right margin so plot does not overflow or touch the right chart container border
            chart_right = cx + cw
            min_right_margin = 3.0
            if px + pw > chart_right - min_right_margin:
                pw = max(10.0, chart_right - min_right_margin - px)
        else:
            pie_types = (ChartType.PIE, ChartType.DOUGHNUT)
            is_pie = any(s.chart_type in pie_types for s in chart.series_list) or chart.chart_type in pie_types
            if is_pie:
                if chart.legend_layout and chart.legend_layout.x > 0.4:
                    avail_w = chart.legend_layout.x * cw
                elif chart.legend_position == "r" and chart.show_legend:
                    avail_w = cw * 0.55
                else:
                    avail_w = cw
                top_m = (chart.title_font_size or 8.0) * 1.5 + 4.0 if chart.title else 0.05 * ch
                bot_m = 0.05 * ch
                px = cx + 0.02 * cw
                py = cy + top_m
                pw = max(10.0, avail_w - 0.04 * cw)
                ph = max(10.0, ch - top_m - bot_m)
            else:
                px = cx + 0.08 * cw
                py = cy + 0.02 * ch
                pw = 0.88 * cw
                ph = 0.88 * ch

        return Rect2D(x=px, y=py, w=pw, h=ph)

    def render(self, element: ChartModel, canvas: BaseCanvas, context: RenderContext) -> None:
        """Renders the chart element onto the PDF canvas."""
        if element is None or not element.series_list or element.bounds.w <= 0 or element.bounds.h <= 0:
            return

        try:
            # 0. Render chart background fill if present
            self.frame_engine.render_background(element, canvas)

            # 1. Determine axis ranges
            prim_range_tuple, sec_range_tuple, is_stacked, bar_series = self.plot_engine.determine_axis_ranges(element)

            # 2. Render plot area graphics (bars, lines, areas, pies) via matplotlib
            chart_bytes = self.plot_engine.generate_image(element, context)
            if chart_bytes:
                canvas.draw_image(chart_bytes, rect=element.bounds)

            # 3. Calculate absolute plot area bounds
            plot_rect = self._compute_plot_rect(element)

            # 4. Render category & date axes (with calendar math, spine lines, tick marks, and rotation)
            self.axis_engine.render_category_and_date_axes(element, plot_rect, canvas, context)

            # 5. Render value axes (ticks and labels for primary and secondary axes)
            self.axis_engine.render_value_axes(element, plot_rect, prim_range_tuple, sec_range_tuple, canvas)

            # 6. Render legend (manualLayout or docked positions with swatches)
            self.legend_engine.render_legend(element, plot_rect, is_stacked, canvas)

            # 7. Render data labels (stacked bars and continuous series)
            self.data_label_engine.render_data_labels(
                element, plot_rect, prim_range_tuple, sec_range_tuple, is_stacked, bar_series, canvas
            )

            # 8. Render chart title as crisp searchable vector text
            if element.title:
                t_sz = element.title_font_size if element.title_font_size > 0 else 8.0
                t_col = element.title_color or ColorModel(0.0, 0.0, 0.0, 1.0)
                t_fam = element.title_font_family or element.font_family or "Arial"
                t_bold = element.title_bold if element.title_bold is not None else False
                lines = [l.strip() for l in element.title.splitlines() if l.strip()]
                line_h = t_sz * 1.2
                start_y = element.bounds.y + max(10.0, t_sz * 1.3)
                for l_idx, line in enumerate(lines):
                    t_w = self.axis_engine._measure_text_width(line, t_fam, t_sz, bold=t_bold)
                    t_x = element.bounds.x + max(0.0, (element.bounds.w - t_w) / 2.0)
                    t_y = start_y + l_idx * line_h
                    canvas.draw_text(
                        Point2D(t_x, t_y),
                        line,
                        font_family=t_fam,
                        font_size=t_sz,
                        color=t_col,
                        bold=t_bold,
                    )

            # 9. Render chart frame border box if defined
            self.frame_engine.render_border(element, canvas)

        except Exception as e:
            logger.debug(f"Failed to render chart '{element.title or element.name}': {e}", exc_info=True)
