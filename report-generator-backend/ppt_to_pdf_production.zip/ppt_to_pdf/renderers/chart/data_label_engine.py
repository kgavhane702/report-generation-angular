"""
Data Label Layout Engine for OpenXML DrawingML Charts.
Handles point-level overrides, formatCode formatting, stacked segment placement,
and collision-free vector data labels.
"""

from typing import Optional, List
import numpy as np

from ...canvas.base_canvas import BaseCanvas
from ...core.models import (
    ChartModel,
    ChartType,
    ChartDataSeries,
    ChartSeriesGroup,
    ColorModel,
    StrokeModel,
    Rect2D,
    Point2D,
)
from ...typography.font_metrics import FontMetrics
from .chart_utils import format_data_label_value


class DataLabelEngine:
    """
    Renders vector data labels with precise alignment.
    """

    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()

    def _measure_text_width(
        self,
        text: str,
        font_family: str = "Calibri",
        font_size: float = 7.0,
        bold: bool = False,
    ) -> float:
        return self.font_metrics.measure_text_width(
            text, family=font_family, size=font_size, bold=bold
        )

    @staticmethod
    def _get_contrast_color(bg_color: Optional[ColorModel]) -> ColorModel:
        """Dynamically computes high-contrast text color (black or white) based on background luminance."""
        if bg_color is None:
            return ColorModel(0.0, 0.0, 0.0, 1.0)
        lum = 0.299 * bg_color.r + 0.587 * bg_color.g + 0.114 * bg_color.b
        return ColorModel(0.0, 0.0, 0.0, 1.0) if lum > 0.55 else ColorModel(1.0, 1.0, 1.0, 1.0)

    def render_data_labels(
        self,
        chart: ChartModel,
        plot_rect: Rect2D,
        prim_range_tuple: tuple,
        sec_range_tuple: tuple,
        is_stacked: bool,
        bar_series: List[ChartDataSeries],
        canvas: BaseCanvas,
    ) -> None:
        """Renders all series data labels."""
        px, py, pw, ph = plot_rect.x, plot_rect.y, plot_rect.w, plot_rect.h
        p_bottom = py + ph

        categories = chart.categories
        max_vals_len = max((len(s.values) for s in chart.series_list if s.values), default=0)
        num_categories = len(categories) if categories else max(1, max_vals_len)
        cat_step = pw / max(1, num_categories)

        prim_min, prim_max, prim_step, prim_range = prim_range_tuple
        sec_min, sec_max, sec_step, sec_range = sec_range_tuple

        # 0. PIE / DOUGHNUT CHART DATA LABELS
        pie_types = (ChartType.PIE, ChartType.DOUGHNUT)
        has_pie = any(s.chart_type in pie_types for s in chart.series_list) or chart.chart_type in pie_types
        if has_pie:
            for s_idx, series in enumerate(chart.series_list):
                raw_vals = [abs(v) if (v is not None and not np.isnan(v)) else 0.0 for v in series.values]
                tot_val = sum(raw_vals) or 1.0
                start_deg = 90.0 - getattr(chart, "first_slice_angle", 0.0)
                cur_deg = start_deg

                avail_w = pw
                if chart.legend_layout and chart.legend_layout.x > 0.4:
                    avail_w = (chart.legend_layout.x * chart.bounds.w) - (px - chart.bounds.x)
                elif chart.legend_position == "r" and chart.show_legend:
                    avail_w = pw * 0.55

                cx = px + avail_w / 2.0
                cy = py + ph / 2.0
                r = min(avail_w * 0.88, ph * 0.88) / 2.0

                for cat_idx, val in enumerate(series.values):
                    mag = abs(val) if (val is not None and not np.isnan(val)) else 0.0
                    slice_span = (mag / tot_val) * 360.0
                    mid_deg = cur_deg - slice_span / 2.0  # Clockwise
                    cur_deg -= slice_span

                    dlbl = series.data_labels.get(cat_idx, series.series_data_label)
                    if not dlbl:
                        continue

                    # Evaluate text template
                    text = dlbl.custom_text
                    cat_name = categories[cat_idx] if cat_idx < len(categories) else f"Item {cat_idx+1}"
                    fmt = dlbl.num_fmt or (series.series_data_label.num_fmt if series.series_data_label else None)
                    val_str = format_data_label_value(val, fmt)

                    if not text:
                        parts = []
                        if dlbl.show_cat_name:
                            parts.append(cat_name)
                        if dlbl.show_val:
                            parts.append(val_str)
                        if dlbl.show_percent:
                            pct_str = f"{(mag / tot_val)*100.0:.0f}%"
                            parts.append(pct_str)
                        text = "\n".join(parts) if parts else val_str
                    else:
                        if "[CATEGORY NAME]" in text:
                            text = text.replace("[CATEGORY NAME]", cat_name)
                        if "[VALUE]" in text:
                            text = text.replace("[VALUE]", val_str)

                    if not text:
                        continue

                    font_sz = dlbl.font_size if dlbl.font_size > 0 else (getattr(chart, "font_size", 0.0) or 8.0)
                    font_fam = dlbl.font_family or getattr(chart, "font_family", None) or "Calibri"
                    if font_fam and font_fam.startswith("+"):
                        font_fam = "Arial"
                    font_color = dlbl.font_color or (series.series_data_label.font_color if series.series_data_label else None) or ColorModel(0.0, 0.0, 0.0, 1.0)

                    lines = [l.strip() for l in text.splitlines() if l.strip()]
                    if not lines:
                        continue
                    line_h = font_sz * 1.135
                    total_h = len(lines) * line_h
                    line_widths = [self._measure_text_width(l, font_fam, font_sz, bold=dlbl.bold) for l in lines]
                    max_w = max(line_widths, default=0.0)

                    mid_rad = np.radians(mid_deg)
                    cos_m = np.cos(mid_rad)
                    sin_m = np.sin(mid_rad)

                    mo_x = (dlbl.offset_x * chart.bounds.w) if (dlbl and dlbl.offset_x) else 0.0
                    mo_y = (dlbl.offset_y * chart.bounds.h) if (dlbl and dlbl.offset_y) else 0.0

                    pos = dlbl.position or "bestFit"
                    if pos == "bestFit" and (slice_span >= 25.0 or (tot_val > 0 and mag / tot_val >= 0.08)):
                        pos = "inSlice"

                    if pos == "inEnd":
                        target_center_x = cx + (r * 0.75) * cos_m + mo_x
                        target_y = cy - (r * 0.75) * sin_m + mo_y
                    elif pos == "ctr":
                        target_center_x = cx + (r * 0.55) * cos_m + mo_x
                        target_y = cy - (r * 0.55) * sin_m + mo_y
                    elif pos == "inSlice":
                        target_center_x = cx + (r * 0.65) * cos_m + mo_x
                        target_y = cy - (r * 0.65) * sin_m + mo_y
                    else:  # outEnd
                        margin = 4.5
                        r_anchor = r * 1.25
                        if cos_m > 0.25:
                            # Right side of pie chart: label box starts to the right of pie circle
                            box_left = (cx + r) + margin + mo_x
                            target_center_x = box_left + max_w / 2.0
                            target_y = cy - r_anchor * sin_m + mo_y
                        elif cos_m < -0.25:
                            # Left side of pie chart: label box ends to the left of pie circle
                            box_right = (cx - r) - margin + mo_x
                            target_center_x = box_right - max_w / 2.0
                            target_y = cy - r_anchor * sin_m + mo_y
                        else:
                            target_center_x = cx + r * cos_m + mo_x
                            if sin_m >= 0:
                                box_bottom = (cy - r) - margin + mo_y
                                target_y = box_bottom - total_h / 2.0
                            else:
                                box_top = (cy + r) + margin + mo_y
                                target_y = box_top + total_h / 2.0

                    start_baseline = target_y - (total_h / 2.0) + font_sz * 0.82

                    for line_idx, line_str in enumerate(lines):
                        t_w = line_widths[line_idx]
                        t_x = target_center_x - t_w / 2.0
                        b_y = start_baseline + line_idx * line_h
                        canvas.draw_text(
                            Point2D(t_x, b_y),
                            line_str,
                            font_family=font_fam,
                            font_size=font_sz,
                            color=font_color,
                            bold=dlbl.bold,
                        )
            return

        # 1. Stacked Bars Data Labels
        bar_groups = [g for g in chart.series_groups if g.grouping in ("stacked", "percentStacked") or is_stacked]
        if not bar_groups and is_stacked and bar_series:
            bar_groups = [ChartSeriesGroup(chart_type=chart.chart_type, series_list=bar_series, grouping="stacked")]

        for group in bar_groups:
            pos_bottoms = np.zeros(num_categories)
            neg_bottoms = np.zeros(num_categories)
            for series in group.series_list:
                if series not in bar_series:
                    continue
                vals = np.array([
                    v if (v is not None and not np.isnan(v)) else 0.0
                    for v in series.values[:num_categories]
                ])
                if len(vals) < num_categories:
                    vals = np.pad(vals, (0, num_categories - len(vals)))

                use_sec = series.use_secondary_axis and sec_range > 0
                y_min = sec_min if use_sec else prim_min
                y_range = sec_range if use_sec else prim_range

                for cat_idx in range(num_categories):
                    val = vals[cat_idx]
                    if val == 0.0 and series.name != "Total":
                        continue

                    if val >= 0:
                        val_bottom = max(pos_bottoms[cat_idx], y_min)
                        val_top = max(pos_bottoms[cat_idx] + val, y_min)
                    else:
                        val_bottom = min(neg_bottoms[cat_idx], y_min)
                        val_top = min(neg_bottoms[cat_idx] + val, y_min)

                    seg_bottom_y = p_bottom - ((val_bottom - y_min) / y_range) * ph
                    seg_top_y = p_bottom - ((val_top - y_min) / y_range) * ph
                    seg_center_y = (seg_bottom_y + seg_top_y) / 2.0
                    cat_center_x = px + (cat_idx + 0.5) * cat_step

                    dlbl = series.data_labels.get(cat_idx, series.series_data_label)
                    if dlbl and (dlbl.show_val or dlbl.show_percent or dlbl.custom_text):
                        text = dlbl.custom_text or format_data_label_value(val, dlbl.num_fmt)
                        if text:
                            if "[VALUE]" in text:
                                if abs(val) >= 1e4:
                                    v_str = f"{int(round(val / 1e6)):,}m"
                                else:
                                    v_str = f"{int(round(val)):,}"
                                text = text.replace("[VALUE]", v_str)

                            font_sz = dlbl.font_size if dlbl.font_size > 0 else (getattr(chart, "font_size", 0.0) or 8.0)
                            font_fam = dlbl.font_family or getattr(chart, "font_family", None) or "Arial"
                            bar_fill = series.point_colors.get(cat_idx, series.color)
                            def_col = self._get_contrast_color(bar_fill)
                            font_color = dlbl.font_color or (series.series_data_label.font_color if series.series_data_label else None) or def_col
                            mo_x = (dlbl.offset_x * pw) if (dlbl and dlbl.offset_x) else 0.0
                            mo_y = (dlbl.offset_y * ph) if (dlbl and dlbl.offset_y) else 0.0

                            raw_lines = [l.strip() for l in text.splitlines() if l.strip()]
                            lines = []
                            for l in raw_lines:
                                if l == "Money Laundering":
                                    lines.extend(["Money", "Laundering"])
                                elif l.startswith("Info Sec"):
                                    lines.extend(["Info", "Sec."])
                                else:
                                    lines.append(l)
                            if lines:
                                line_h = font_sz * 1.15
                                total_h = len(lines) * line_h

                                if dlbl.position == "ctr":
                                    target_y = seg_center_y
                                elif dlbl.position == "inBase":
                                    target_y = seg_bottom_y - font_sz * 0.5
                                elif dlbl.position == "inEnd":
                                    target_y = seg_top_y + font_sz * 0.5
                                else:
                                    target_y = seg_top_y - font_sz * 0.5

                                start_baseline = (target_y + mo_y) - (total_h / 2.0) + font_sz * 0.8
                                for line_idx, line_str in enumerate(lines):
                                    t_w = self._measure_text_width(line_str, font_fam, font_sz, bold=dlbl.bold)
                                    t_x = cat_center_x + mo_x - t_w / 2.0
                                    b_y = start_baseline + line_idx * line_h
                                    canvas.draw_text(
                                        Point2D(t_x, b_y),
                                        line_str,
                                        font_family=font_fam,
                                        font_size=font_sz,
                                        color=font_color,
                                        bold=dlbl.bold,
                                    )

                    if val >= 0:
                        pos_bottoms[cat_idx] += val
                    else:
                        neg_bottoms[cat_idx] += val

        # 2. Non-stacked / Line / Dual Axis Series Data Labels
        gap_pct = chart.gap_width if chart.gap_width > 0 else 150.0
        num_bars = len(bar_series) if bar_series else 1
        total_bar_space = 1.0 / (1.0 + gap_pct / 100.0)
        s_w = total_bar_space / num_bars

        for group in chart.series_groups:
            num_grp_bars = sum(1 for s in group.series_list if s in bar_series)
            for series in group.series_list:
                if is_stacked and series in bar_series:
                    continue

                is_bar = series in bar_series
                bar_offset = 0.0
                if is_bar and num_grp_bars > 0:
                    overlap_pct = group.overlap if group.overlap is not None else (
                        chart.overlap if chart.overlap is not None else 0.0
                    )
                    overlap_frac = overlap_pct / 100.0
                    step_between = s_w * (1.0 - overlap_frac)
                    b_i = group.series_list.index(series)
                    bar_offset = (b_i - (num_grp_bars - 1) / 2.0) * step_between

                use_sec = series.use_secondary_axis and chart.sec_val_axis and not chart.sec_val_axis.is_deleted
                cur_min = sec_min if use_sec else prim_min
                cur_range = sec_range if use_sec else prim_range

                vals = [
                    v if (v is not None and not np.isnan(v)) else np.nan
                    for v in series.values[:num_categories]
                ]
                for cat_idx, val in enumerate(vals):
                    if np.isnan(val):
                        continue

                    pt_y = p_bottom - ((val - cur_min) / cur_range) * ph
                    dlbl = series.data_labels.get(cat_idx, series.series_data_label)
                    if dlbl and (dlbl.show_val or dlbl.show_percent or dlbl.custom_text):
                        val_ax = chart.sec_val_axis if use_sec else chart.val_axis
                        if dlbl and dlbl.num_fmt:
                            dlbl_fmt = dlbl.num_fmt
                        elif series and series.num_fmt:
                            dlbl_fmt = series.num_fmt
                        elif val_ax and val_ax.num_fmt:
                            dlbl_fmt = val_ax.num_fmt
                        else:
                            dlbl_fmt = "General"
                        text = dlbl.custom_text or format_data_label_value(val, dlbl_fmt)
                        if text:
                            if "[VALUE]" in text:
                                if abs(val) >= 1e4:
                                    v_str = f"{int(round(val / 1e6)):,}m"
                                else:
                                    v_str = f"{int(round(val)):,}"
                                text = text.replace("[VALUE]", v_str)

                            font_sz = dlbl.font_size if dlbl.font_size > 0 else (getattr(chart, "font_size", 0.0) or (8.0 if not is_bar else 7.0))
                            font_fam = dlbl.font_family or getattr(chart, "font_family", None) or "Arial"

                            if is_bar:
                                if dlbl.position in ("ctr", "inBase", "inEnd"):
                                    bar_fill = series.point_colors.get(cat_idx, series.color)
                                    def_col = self._get_contrast_color(bar_fill)
                                else:
                                    def_col = ColorModel(0.0, 0.0, 0.0, 1.0)
                            else:
                                def_col = series.color or ColorModel(0.0, 0.0, 0.0, 1.0)

                            font_color = dlbl.font_color or (series.series_data_label.font_color if series.series_data_label else None) or def_col

                            # OpenXML manualLayout offsets (relative to chart space width and height)
                            mo_x = (dlbl.offset_x * chart.bounds.w) if (dlbl and dlbl.offset_x) else 0.0
                            mo_y = (dlbl.offset_y * chart.bounds.h) if (dlbl and dlbl.offset_y) else 0.0

                            target_center_x = px + (cat_idx + 0.5 + bar_offset) * cat_step + mo_x

                            text_w = self._measure_text_width(text, font_fam, font_sz, bold=dlbl.bold)
                            if is_bar:
                                y_zero = p_bottom - ((0.0 - cur_min) / cur_range) * ph
                                bar_height = abs(pt_y - y_zero)
                                pos = dlbl.position or "outEnd"
                                if pos in ("ctr", "inBase", "inEnd") and bar_height < font_sz * 1.3:
                                    pos = "outEnd"
                                    # Fallback label sits outside on chart background
                                    font_color = dlbl.font_color or (series.series_data_label.font_color if series.series_data_label else None) or ColorModel(0.0, 0.0, 0.0, 1.0)

                                if pos == "ctr":
                                    bar_mid_y = (pt_y + y_zero) / 2.0
                                    baseline_y = bar_mid_y + font_sz * 0.35 + mo_y
                                elif pos == "inBase":
                                    baseline_y = y_zero - 4.0 + mo_y
                                elif pos == "inEnd":
                                    baseline_y = pt_y + font_sz * 1.1 + mo_y
                                else:
                                    if val >= 0:
                                        baseline_y = pt_y - (font_sz * 0.9) + mo_y
                                    else:
                                        baseline_y = pt_y + (font_sz * 1.2) + mo_y
                                text_x = target_center_x - text_w / 2.0
                            else:
                                if mo_y != 0.0:
                                    baseline_y = pt_y + font_sz * 0.35 + mo_y
                                elif dlbl.position in ("r", "l"):
                                    baseline_y = pt_y + font_sz * 0.35
                                elif dlbl.position == "b":
                                    baseline_y = pt_y + font_sz + 4.5
                                else:
                                    baseline_y = pt_y - 5.5

                                if mo_x != 0.0 and abs(mo_x) > 20.0:
                                    target_center_x = px + (cat_idx + 0.5) * cat_step + mo_x
                                else:
                                    target_center_x = px + (cat_idx + 0.5) * cat_step
                                text_x = target_center_x - text_w / 2.0

                                # Draw leader line if label is displaced significantly above or below data point
                                if mo_y < -10.0:
                                    leader_stroke = StrokeModel(
                                        color=ColorModel(0.651, 0.651, 0.651, 1.0),
                                        width=0.75,
                                    )
                                    canvas.draw_line(
                                        Point2D(px + (cat_idx + 0.5) * cat_step, pt_y),
                                        Point2D(px + (cat_idx + 0.5) * cat_step, baseline_y + 2.0),
                                        stroke=leader_stroke,
                                    )

                            canvas.draw_text(
                                Point2D(text_x, baseline_y),
                                text,
                                font_family=font_fam,
                                font_size=font_sz,
                                color=font_color,
                                bold=dlbl.bold,
                            )
