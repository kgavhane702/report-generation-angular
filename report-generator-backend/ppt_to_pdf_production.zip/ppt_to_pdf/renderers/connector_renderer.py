"""
Connector and Line Element Renderer.
Renders straight lines, polyline connectors, and arrowheads (triangle, stealth, diamond).
"""

import math
from typing import List, Optional
from ..canvas.base_canvas import BaseCanvas
from ..core.context import RenderContext
from ..core.models import ConnectorModel, Point2D, StrokeModel, FillModel, FillType
from .base import BaseElementRenderer


class ConnectorRenderer(BaseElementRenderer):
    """
    Renders straight and bent connector lines with optional arrowheads.
    """
    def render(self, element: ConnectorModel, canvas: BaseCanvas, context: RenderContext) -> None:
        if element is None:
            return

        pts = element.path_points if len(element.path_points) >= 2 else [element.start_point, element.end_point]
        if len(pts) < 2:
            return

        # 1. Draw Line / Polyline
        if len(pts) == 2:
            canvas.draw_line(pts[0], pts[1], stroke=element.stroke)
        else:
            canvas.draw_polyline(pts, stroke=element.stroke)

        # 2. Draw Arrowheads
        if element.head_type and element.head_type != "none":
            # Arrowhead at end point
            self._draw_arrowhead(canvas, pts[-2], pts[-1], element.stroke, element.head_type)

        if element.tail_type and element.tail_type != "none":
            # Arrowhead at start point
            self._draw_arrowhead(canvas, pts[1], pts[0], element.stroke, element.tail_type)

    def _draw_arrowhead(
        self,
        canvas: BaseCanvas,
        from_pt: Point2D,
        to_pt: Point2D,
        stroke: StrokeModel,
        arrow_type: str,
    ) -> None:
        dx = to_pt.x - from_pt.x
        dy = to_pt.y - from_pt.y
        length = math.hypot(dx, dy)
        if length < 1e-4:
            return

        ux = dx / length
        uy = dy / length

        # Perpendicular vector
        px = -uy
        py = ux

        head_len = max(4.0, stroke.width * 4.0)
        head_w = max(3.0, stroke.width * 2.5)

        base_x = to_pt.x - ux * head_len
        base_y = to_pt.y - uy * head_len

        # Triangle Arrowhead vertices
        p_left = Point2D(base_x + px * head_w, base_y + py * head_w)
        p_right = Point2D(base_x - px * head_w, base_y - py * head_w)

        fill = FillModel(fill_type=FillType.SOLID, color=stroke.color)
        canvas.draw_polygon([to_pt, p_left, p_right], fill=fill, stroke=stroke)
