"""
Command-Line Interface (CLI) for PPT to PDF Converter.
"""

import sys
import argparse
from pathlib import Path
from .config import ConversionConfig
from .api import PPT2PDFConverter
from .utils.logger import get_logger

logger = get_logger("ppt2pdf_cli")


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="ppt2pdf",
        description="Enterprise Pure-Python PowerPoint (.pptx) to PDF Converter",
    )
    parser.add_argument("input", help="Path to input .pptx presentation file or directory of presentations")
    parser.add_argument("-o", "--output", help="Path to output .pdf file or output directory", default=None)
    parser.add_argument("-s", "--slides", help="Selective slide range (e.g. '1-3, 5, 8-10', 'all')", default=None)
    parser.add_argument("-w", "--workers", type=int, default=None, help="Number of worker threads (default: auto-detected CPU count)")
    parser.add_argument("--dpi", type=int, default=300, help="DPI resolution for charts & images (default: 300)")
    parser.add_argument("--skip-hidden", action="store_true", help="Skip hidden/draft slides")
    parser.add_argument("--no-bookmarks", action="store_true", help="Disable automatic PDF bookmark TOC generation")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        logger.error(f"Input path not found: {input_path}")
        return 1

    config = ConversionConfig(
        dpi=args.dpi,
        workers=args.workers,
        slide_selection=args.slides,
        skip_hidden_slides=args.skip_hidden,
        generate_bookmarks=not args.no_bookmarks,
        verbose=args.verbose,
    )
    converter = PPT2PDFConverter(config=config)

    # Batch conversion for directory
    if input_path.is_dir():
        pptx_files = list(input_path.glob("*.pptx"))
        if not pptx_files:
            logger.warning(f"No .pptx files found in {input_path}")
            return 0

        out_dir = Path(args.output) if args.output else input_path
        out_dir.mkdir(parents=True, exist_ok=True)

        for pptx_file in pptx_files:
            out_pdf = out_dir / f"{pptx_file.stem}.pdf"
            logger.info(f"Converting: {pptx_file.name} -> {out_pdf.name}")
            try:
                converter.convert(pptx_file, out_pdf)
            except Exception as e:
                logger.error(f"Failed to convert {pptx_file.name}: {e}")

        logger.info(f"Batch conversion complete for {len(pptx_files)} presentations.")
        return 0

    # Single file conversion
    if args.output:
        out_pdf = Path(args.output)
    else:
        out_pdf = input_path.with_suffix(".pdf")

    logger.info(f"Converting '{input_path.name}' -> '{out_pdf.name}'...")
    try:
        def progress(curr, total):
            pct = int((curr / total) * 100)
            sys.stdout.write(f"\rProgress: [{curr}/{total}] ({pct}%)")
            sys.stdout.flush()

        converter.convert(input_path, out_pdf, progress_callback=progress)
        sys.stdout.write("\n")
        logger.info(f"Done! PDF saved to: {out_pdf}")
        return 0
    except Exception as e:
        logger.error(f"Conversion failed: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
