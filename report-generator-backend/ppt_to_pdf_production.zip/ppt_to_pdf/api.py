"""
Public Python API for PPT to PDF Conversion and Presentation DOM access.
"""

import io
from pathlib import Path
from typing import List, Optional, Union, Callable
from .config import ConversionConfig
from .core.engine import PPT2PDFEngine
from .openxml.package import PPTXPackage
from .openxml.master_resolver import MasterResolver
from .openxml.slide_parser import SlideParser
from .core.models import SlideModel, ShapeType, ChartType, ColorModel


class PPT2PDFConverter:
    """
    Main entry point for converting PowerPoint (.pptx) files to PDF.
    
    Example usage:
    ```python
    from ppt_to_pdf import PPT2PDFConverter, ConversionConfig
    
    converter = PPT2PDFConverter()
    converter.convert("presentation.pptx", "output.pdf")
    ```
    """
    def __init__(self, config: Optional[ConversionConfig] = None):
        self.config = config or ConversionConfig()
        self.engine = PPT2PDFEngine(config=self.config)

    def __enter__(self) -> "PPT2PDFConverter":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        pass

    def convert(
        self,
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> Path:
        """
        Converts a PowerPoint presentation to a PDF file on disk.
        """
        src = Path(input_path).resolve()
        dst = Path(output_path).resolve()
        dst.parent.mkdir(parents=True, exist_ok=True)

        self.engine.convert(
            source=src,
            destination=dst,
            slide_selection=slide_selection,
            progress_callback=progress_callback,
        )
        return dst

    def convert_bytes(
        self,
        pptx_bytes: bytes,
        slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
    ) -> bytes:
        """
        Converts PowerPoint presentation bytes to PDF bytes in-memory.
        """
        in_buf = io.BytesIO(pptx_bytes)
        out_buf = io.BytesIO()
        self.engine.convert(
            source=in_buf,
            destination=out_buf,
            slide_selection=slide_selection,
        )
        return out_buf.getvalue()


class Presentation:
    """
    Presentation Document Object Model (DOM).
    Provides structured access to slides, shapes, text, and tables,
    with direct PDF export capabilities.
    
    Example:
    ```python
    from ppt_to_pdf import Presentation
    
    with Presentation("deck.pptx") as pres:
        print(f"Total slides: {len(pres.slides)}")
        for slide in pres.slides:
            print(f"Slide {slide.slide_number}: {slide.title}")
        pres.save("deck.pdf")
    ```
    """
    def __init__(self, source: Union[str, Path, bytes, io.BytesIO]):
        self._source = source
        self._package = PPTXPackage(source)
        self._master_resolver = MasterResolver(self._package)
        self._slide_parser = SlideParser(self._package, master_resolver=self._master_resolver)
        self._slides: Optional[List[SlideModel]] = None

    def __enter__(self) -> "Presentation":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    @property
    def slides(self) -> List[SlideModel]:
        """Lazy-loaded list of parsed SlideModel objects in presentation order."""
        if self._slides is None:
            self._slides = []
            for idx, path in enumerate(self._package.slide_paths):
                slide = self._slide_parser.parse_slide(path, slide_index=idx)
                if slide:
                    self._slides.append(slide)
        return self._slides

    @property
    def slide_count(self) -> int:
        return len(self._package.slide_paths)

    def save(
        self,
        output_path: Union[str, Path],
        config: Optional[ConversionConfig] = None,
        slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
    ) -> Path:
        """Saves the presentation as a high-fidelity PDF document."""
        converter = PPT2PDFConverter(config=config)
        return converter.convert(self._source, output_path, slide_selection=slide_selection)

    def save_bytes(
        self,
        config: Optional[ConversionConfig] = None,
        slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
    ) -> bytes:
        """Exports the presentation to PDF bytes in-memory."""
        converter = PPT2PDFConverter(config=config)
        if isinstance(self._source, bytes):
            return converter.convert_bytes(self._source, slide_selection=slide_selection)
        elif isinstance(self._source, (str, Path)):
            return converter.convert_bytes(Path(self._source).read_bytes(), slide_selection=slide_selection)
        elif isinstance(self._source, io.BytesIO):
            return converter.convert_bytes(self._source.getvalue(), slide_selection=slide_selection)
        return b""

    def close(self) -> None:
        if self._package:
            self._package.close()


def convert(
    input_path: Union[str, Path],
    output_path: Union[str, Path],
    dpi: int = 300,
    slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
    skip_hidden_slides: bool = False,
    progress_callback: Optional[Callable[[int, int], None]] = None,
) -> Path:
    """
    Convenience function to convert a PPTX file to PDF with simple parameters.
    """
    cfg = ConversionConfig(
        dpi=dpi,
        slide_selection=slide_selection,
        skip_hidden_slides=skip_hidden_slides,
    )
    converter = PPT2PDFConverter(config=cfg)
    return converter.convert(input_path, output_path, progress_callback=progress_callback)
