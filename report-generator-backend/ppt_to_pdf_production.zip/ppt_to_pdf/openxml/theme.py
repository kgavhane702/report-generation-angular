"""
OpenXML Theme Parser.
Extracts color schemes and font schemes from ppt/theme/theme*.xml.
"""

import xml.etree.ElementTree as ET
from typing import Dict, Optional, Tuple
from ..core.models import ColorModel
from .constants import NS, qn
from .color_resolver import ColorEngine


class ThemeParser:
    """
    Parses theme definitions to extract default color palettes and font mappings.
    """
    def __init__(self, theme_root: Optional[ET.Element] = None):
        self.scheme_colors: Dict[str, ColorModel] = {}
        self.major_font: str = "Calibri"
        self.minor_font: str = "Calibri"
        if theme_root is not None:
            self.parse(theme_root)

    def parse(self, theme_root: ET.Element) -> None:
        # 1. Color Scheme: <a:themeElements>/<a:clrScheme>
        clr_scheme = theme_root.find(f".//{qn('a', 'clrScheme')}")
        if clr_scheme is not None:
            # First pass: extract srgbClr or sysClr
            for child in clr_scheme:
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                srgb = child.find(qn("a", "srgbClr"))
                if srgb is not None and srgb.get("val"):
                    self.scheme_colors[tag.lower()] = ColorModel.from_hex(srgb.get("val", "000000"))
                    continue
                sys_clr = child.find(qn("a", "sysClr"))
                if sys_clr is not None:
                    last_clr = sys_clr.get("lastClr")
                    if last_clr:
                        self.scheme_colors[tag.lower()] = ColorModel.from_hex(last_clr)
                        continue

        # 2. Font Scheme: <a:themeElements>/<a:fontScheme>
        font_scheme = theme_root.find(f".//{qn('a', 'fontScheme')}")
        if font_scheme is not None:
            major_latin = font_scheme.find(f"{qn('a', 'majorFont')}/{qn('a', 'latin')}")
            if major_latin is not None and major_latin.get("typeface"):
                self.major_font = major_latin.get("typeface", "Calibri")

            minor_latin = font_scheme.find(f"{qn('a', 'minorFont')}/{qn('a', 'latin')}")
            if minor_latin is not None and minor_latin.get("typeface"):
                self.minor_font = minor_latin.get("typeface", "Calibri")

    def create_color_engine(self) -> ColorEngine:
        """Returns a ColorEngine initialized with this theme's scheme colors."""
        return ColorEngine(scheme_colors=self.scheme_colors)
