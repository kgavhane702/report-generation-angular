"""
Slide Master & Slide Layout inheritance resolver.
Resolves the 4-tier hierarchy: Theme -> SlideMaster -> SlideLayout -> Slide.
Handles placeholder linking and background inheritance.
"""

import xml.etree.ElementTree as ET
from typing import Dict, Optional, Tuple, List
from ..core.models import (
    SlideModel,
    ShapeModel,
    FillModel,
    FillType,
    Rect2D,
    ColorModel,
)
from .constants import NS, qn, REL_SLIDE_LAYOUT, REL_SLIDE_MASTER, REL_THEME
from .package import PPTXPackage
from .theme import ThemeParser
from .color_resolver import ColorEngine
from .shape_parser import ShapeParser
from .text_parser import TextParser
from ..utils.units import hundredths_pt_to_pt, emu_to_pt


class MasterResolver:
    """
    Manages and caches Slide Masters, Slide Layouts, and Themes across the presentation.
    """
    def __init__(self, package: PPTXPackage):
        self.package = package
        self._theme_cache: Dict[str, ThemeParser] = {}
        self._layout_cache: Dict[str, ET.Element] = {}
        self._master_cache: Dict[str, ET.Element] = {}
        self._default_theme: Optional[ThemeParser] = None

        self._load_default_theme()

    def _load_default_theme(self) -> None:
        # Load theme1.xml if present
        theme_root = self.package.get_xml_root("ppt/theme/theme1.xml")
        if theme_root is not None:
            self._default_theme = ThemeParser(theme_root)
        else:
            self._default_theme = ThemeParser()

    def get_theme_for_slide(self, slide_part_path: str) -> ThemeParser:
        """Resolves the active theme for a given slide part path."""
        layout_path = self.package.get_target_by_rid(
            slide_part_path,
            self._find_rid_by_type(slide_part_path, REL_SLIDE_LAYOUT),
        ) if self._find_rid_by_type(slide_part_path, REL_SLIDE_LAYOUT) else None

        if layout_path:
            master_path = self.package.get_target_by_rid(
                layout_path,
                self._find_rid_by_type(layout_path, REL_SLIDE_MASTER),
            ) if self._find_rid_by_type(layout_path, REL_SLIDE_MASTER) else None

            if master_path:
                theme_path = self.package.get_target_by_rid(
                    master_path,
                    self._find_rid_by_type(master_path, REL_THEME),
                ) if self._find_rid_by_type(master_path, REL_THEME) else None

                if theme_path:
                    if theme_path not in self._theme_cache:
                        t_root = self.package.get_xml_root(theme_path)
                        if t_root is not None:
                            self._theme_cache[theme_path] = ThemeParser(t_root)
                    if theme_path in self._theme_cache:
                        return self._theme_cache[theme_path]

        return self._default_theme or ThemeParser()

    def resolve_background_fill(
        self,
        slide_root: ET.Element,
        slide_part_path: str,
        color_engine: ColorEngine,
    ) -> FillModel:
        """
        Resolves background fill following the cascade: Slide -> Layout -> Master -> Default White.
        """
        shape_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=slide_part_path)

        # 1. Slide background: <p:bg>
        bg = slide_root.find(f".//{qn('p', 'bg')}")
        if bg is not None:
            bg_pr = bg.find(f".//{qn('p', 'bgPr')}")
            if bg_pr is not None:
                fill = shape_parser._parse_fill(bg_pr)
                if fill.fill_type != FillType.NONE:
                    return fill

        # 2. Slide Layout background
        layout_rid = self._find_rid_by_type(slide_part_path, REL_SLIDE_LAYOUT)
        if layout_rid:
            layout_path = self.package.get_target_by_rid(slide_part_path, layout_rid)
            if layout_path:
                layout_root = self.package.get_xml_root(layout_path)
                if layout_root is not None:
                    l_bg = layout_root.find(f".//{qn('p', 'bg')}")
                    if l_bg is not None:
                        l_bg_pr = l_bg.find(f".//{qn('p', 'bgPr')}")
                        if l_bg_pr is not None:
                            l_shape_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=layout_path)
                            fill = l_shape_parser._parse_fill(l_bg_pr)
                            if fill.fill_type != FillType.NONE:
                                return fill

                    # 3. Slide Master background
                    master_rid = self._find_rid_by_type(layout_path, REL_SLIDE_MASTER)
                    if master_rid:
                        master_path = self.package.get_target_by_rid(layout_path, master_rid)
                        if master_path:
                            master_root = self.package.get_xml_root(master_path)
                            if master_root is not None:
                                m_bg = master_root.find(f".//{qn('p', 'bg')}")
                                if m_bg is not None:
                                    m_bg_pr = m_bg.find(f".//{qn('p', 'bgPr')}")
                                    if m_bg_pr is not None:
                                        m_shape_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=master_path)
                                        fill = m_shape_parser._parse_fill(m_bg_pr)
                                        if fill.fill_type != FillType.NONE:
                                            return fill

        # Default fallback: White
        return FillModel(fill_type=FillType.SOLID, color=ColorModel.white())

    def resolve_placeholder_shape(
        self,
        shape: ShapeModel,
        slide_part_path: str,
        color_engine: ColorEngine,
    ) -> None:
        """
        Links slide placeholder shape to its corresponding layout/master shape
        to inherit missing geometry, coordinates, or text styles (bold, size, color).
        """
        if not shape.is_placeholder:
            return

        layout_rid = self._find_rid_by_type(slide_part_path, REL_SLIDE_LAYOUT)
        if not layout_rid:
            return

        layout_path = self.package.get_target_by_rid(slide_part_path, layout_rid)
        if not layout_path:
            return

        layout_root = self.package.get_xml_root(layout_path)
        if layout_root is None:
            return

        # Search matching placeholder in layout spTree
        ph_match = self._find_placeholder_in_tree(layout_root, shape.placeholder_type, shape.placeholder_idx)
        current_source_path = layout_path

        # If not found in layout, search Slide Master spTree
        if ph_match is None:
            master_rid = self._find_rid_by_type(layout_path, REL_SLIDE_MASTER)
            if master_rid:
                master_path = self.package.get_target_by_rid(layout_path, master_rid)
                if master_path:
                    master_root = self.package.get_xml_root(master_path)
                    if master_root is not None:
                        ph_match = self._find_placeholder_in_tree(master_root, shape.placeholder_type, shape.placeholder_idx)
                        current_source_path = master_path

        if ph_match is not None:
            layout_shape_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=current_source_path)
            layout_shape = layout_shape_parser.parse_shape(ph_match)
            if layout_shape:
                if shape.bounds.w == 0 or shape.bounds.h == 0:
                    shape.bounds = layout_shape.bounds
                if shape.preset_geom == "rect" and layout_shape.preset_geom != "rect":
                    shape.preset_geom = layout_shape.preset_geom

            # Inherit text style defaults (color, bold, font size, insets, anchor)
            self._inherit_placeholder_text_styles(shape, ph_match, color_engine)

    def _inherit_placeholder_text_styles(
        self,
        shape: ShapeModel,
        layout_sp: ET.Element,
        color_engine: ColorEngine,
    ) -> None:
        if not shape.text_frame:
            return

        tx_body = layout_sp.find(qn("p", "txBody"))
        # 1. Inherit bodyPr insets & anchor if layout defines them
        layout_body_pr = tx_body.find(qn("a", "bodyPr"))
        if layout_body_pr is not None:
            if shape.text_frame.insets == (7.2, 3.6, 7.2, 3.6):
                l_ins = emu_to_pt(int(layout_body_pr.get("lIns", 0))) if "lIns" in layout_body_pr.attrib else 0.0
                t_ins = emu_to_pt(int(layout_body_pr.get("tIns", 0))) if "tIns" in layout_body_pr.attrib else 0.0
                r_ins = emu_to_pt(int(layout_body_pr.get("rIns", 0))) if "rIns" in layout_body_pr.attrib else 0.0
                b_ins = emu_to_pt(int(layout_body_pr.get("bIns", 0))) if "bIns" in layout_body_pr.attrib else 0.0
                shape.text_frame.insets = (l_ins, t_ins, r_ins, b_ins)
            anchor = layout_body_pr.get("anchor")
            if anchor in ("ctr", "mid"):
                from ..core.models import VerticalAlign
                shape.text_frame.vertical_align = VerticalAlign.MIDDLE
            elif anchor in ("b", "just"):
                from ..core.models import VerticalAlign
                shape.text_frame.vertical_align = VerticalAlign.BOTTOM

        # 2. Inherit text formatting (color, bold, size, font, alignment)
        def_r_pr = tx_body.find(f".//{qn('a', 'defRPr')}")
        inherit_bold = (def_r_pr.get("b") == "1") if (def_r_pr is not None and "b" in def_r_pr.attrib) else None
        inherit_size = hundredths_pt_to_pt(int(def_r_pr.get("sz"))) if (def_r_pr is not None and def_r_pr.get("sz")) else None
        inherit_color = color_engine.resolve_color_element(def_r_pr) if def_r_pr is not None else None

        inherit_font = None
        if def_r_pr is not None:
            latin = def_r_pr.find(qn("a", "latin"))
            if latin is not None and latin.get("typeface"):
                inherit_font = latin.get("typeface")

        # Inherit paragraph alignment from lstStyle or lvl1pPr / pPr
        inherit_align = None
        for p_tag in (qn("a", "lvl1pPr"), qn("a", "pPr")):
            p_elem = tx_body.find(f".//{p_tag}")
            if p_elem is not None and p_elem.get("algn"):
                algn_str = p_elem.get("algn")
                if algn_str in ("r", "right"):
                    from ..core.models import HorizontalAlign
                    inherit_align = HorizontalAlign.RIGHT
                elif algn_str in ("ctr", "center"):
                    from ..core.models import HorizontalAlign
                    inherit_align = HorizontalAlign.CENTER
                elif algn_str in ("just", "dist"):
                    from ..core.models import HorizontalAlign
                    inherit_align = HorizontalAlign.JUSTIFY
                elif algn_str in ("l", "left"):
                    from ..core.models import HorizontalAlign
                    inherit_align = HorizontalAlign.LEFT
                break

        for p in shape.text_frame.paragraphs:
            if inherit_align is not None and not getattr(p, "has_explicit_align", False):
                p.align = inherit_align
            for r in p.runs:
                if r.text == "\n":
                    continue
                if inherit_font and not getattr(r, "has_explicit_font", False):
                    r.font_family = inherit_font
                if inherit_color and not getattr(r, "has_explicit_color", False) and (r.color.r == 0.0 and r.color.g == 0.0 and r.color.b == 0.0):
                    r.color = inherit_color
                if inherit_bold is not None and not getattr(r, "has_explicit_bold", False):
                    r.bold = inherit_bold
                if inherit_size is not None and not getattr(r, "has_explicit_size", False):
                    r.font_size = inherit_size

    def get_master_and_layout_shapes(
        self,
        slide_part_path: str,
        color_engine: ColorEngine,
        slide_width: float,
        slide_height: float,
        slide_number: int,
    ) -> List[ShapeModel]:
        """
        Retrieves static branding shapes, headers, footers, logos, and divider lines
        defined on the Slide Master and Slide Layout.
        """
        shapes: List[ShapeModel] = []
        layout_rid = self._find_rid_by_type(slide_part_path, REL_SLIDE_LAYOUT)
        if not layout_rid:
            return shapes

        layout_path = self.package.get_target_by_rid(slide_part_path, layout_rid)
        if not layout_path:
            return shapes

        layout_root = self.package.get_xml_root(layout_path)
        if layout_root is None:
            return shapes

        # 1. Master shapes (if not hidden by layout)
        show_master_on_layout = (layout_root.get("showMasterSp", "1") != "0")
        if show_master_on_layout:
            master_rid = self._find_rid_by_type(layout_path, REL_SLIDE_MASTER)
            if master_rid:
                master_path = self.package.get_target_by_rid(layout_path, master_rid)
                if master_path:
                    master_root = self.package.get_xml_root(master_path)
                    if master_root is not None:
                        m_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=master_path)
                        m_sp_tree = master_root.find(f".//{qn('p', 'spTree')}")
                        if m_sp_tree is not None:
                            for child in m_sp_tree:
                                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                                if tag == "sp":
                                    nv_pr = child.find(f".//{qn('p', 'nvPr')}")
                                    ph = nv_pr.find(qn("p", "ph")) if nv_pr is not None else None
                                    if ph is None:
                                        s = m_parser.parse_shape(child)
                                        if s and s.bounds.w > 0 and s.bounds.h > 0 and s.bounds.x >= -5 and s.bounds.y >= -5:
                                            shapes.append(s)

        # 2. Layout static shapes
        l_parser = ShapeParser(self.package, color_engine=color_engine, current_part_path=layout_path)
        l_sp_tree = layout_root.find(f".//{qn('p', 'spTree')}")
        if l_sp_tree is not None:
            for child in l_sp_tree:
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                if tag == "sp":
                    nv_pr = child.find(f".//{qn('p', 'nvPr')}")
                    ph = nv_pr.find(qn("p", "ph")) if nv_pr is not None else None
                    if ph is None:
                        s = l_parser.parse_shape(child)
                        if s and s.bounds.w > 0 and s.bounds.h > 0 and s.bounds.x >= -5 and s.bounds.y >= -5:
                            shapes.append(s)

        return shapes

    def _find_placeholder_in_tree(
        self,
        root: ET.Element,
        ph_type: Optional[str],
        ph_idx: Optional[int],
    ) -> Optional[ET.Element]:
        # 1. Exact match on idx if provided and valid
        if ph_idx is not None and ph_idx != 4294967295:
            for sp in root.findall(f".//{qn('p', 'sp')}"):
                nv_sp_pr = sp.find(qn("p", "nvSpPr"))
                if nv_sp_pr is not None:
                    nv_pr = nv_sp_pr.find(qn("p", "nvPr"))
                    if nv_pr is not None:
                        ph = nv_pr.find(qn("p", "ph"))
                        if ph is not None:
                            idx_attr = ph.get("idx")
                            if idx_attr is not None and int(idx_attr) == ph_idx:
                                return sp

        # 2. Match on type
        if ph_type is not None:
            for sp in root.findall(f".//{qn('p', 'sp')}"):
                nv_sp_pr = sp.find(qn("p", "nvSpPr"))
                if nv_sp_pr is not None:
                    nv_pr = nv_sp_pr.find(qn("p", "nvPr"))
                    if nv_pr is not None:
                        ph = nv_pr.find(qn("p", "ph"))
                        if ph is not None:
                            match_type = ph.get("type", "body")
                            if match_type == ph_type or (ph_type in ("title", "ctrTitle") and match_type in ("title", "ctrTitle")):
                                return sp
        return None

    def _find_rid_by_type(self, part_path: str, rel_type: str) -> Optional[str]:
        rels = self.package.get_relationships(part_path)
        for r_id, (r_type, _) in rels.items():
            if r_type == rel_type:
                return r_id
        return None
