"""
OpenXML PresentationML and DrawingML parsing subsystem.
"""

from .constants import NS, qn
from .package import PPTXPackage
from .color_resolver import ColorEngine
from .theme import ThemeParser
from .master_resolver import MasterResolver
from .text_parser import TextParser
from .shape_parser import ShapeParser
from .table_parser import TableParser
from .chart_parser import ChartParser
from .slide_parser import SlideParser

__all__ = [
    "NS",
    "qn",
    "PPTXPackage",
    "ColorEngine",
    "ThemeParser",
    "MasterResolver",
    "TextParser",
    "ShapeParser",
    "TableParser",
    "ChartParser",
    "SlideParser",
]
