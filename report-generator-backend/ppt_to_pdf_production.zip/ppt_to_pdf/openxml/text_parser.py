"""
DrawingML TextFrame, Paragraph, Run, and Bullet parser.
"""

import xml.etree.ElementTree as ET
from typing import Optional, List, Tuple, Dict, Any
from ..core.models import (
    TextBoxModel,
    ParagraphModel,
    RunModel,
    TabStopModel,
    HorizontalAlign,
    VerticalAlign,
    ColorModel,
)
from ..utils.units import emu_to_pt, hundredths_pt_to_pt
from ..typography.glyph_engine import GlyphEngine
from .constants import NS, qn
from .color_resolver import ColorEngine


# OpenXML Symbol and Wingdings legacy bullet mapping to universal Unicode glyphs
SYMBOL_BULLET_MAP = {
    0xF1: "›",    # U+203A Right-pointing single angle quote / chevron
    0xF0F1: "›",
    0xB7: "•",    # U+2022 Bullet
    0xF0B7: "•",
    0xA7: "▪",    # U+25AA Black small square
    0xF0A7: "▪",
    0xD8: "›",    # U+203A Right chevron
    0xF0D8: "›",
    0xDE: "➔",    # U+2794 Right arrow
    0xF0DE: "➔",
    0xFC: "✔",    # U+2714 Checkmark
    0xF0FC: "✔",
    0x76: "❖",    # U+2756 Diamond
    0xF076: "❖",
    0x71: "❑",    # U+274F Square
    0xF071: "❑",
    0x6E: "■",    # U+25A0 Black square
    0xF06E: "■",
    0x6F: "○",    # U+25CB White circle
    0xF06F: "○",
    0x77: "⬡",    # U+2B21 Hexagon
    0xF077: "⬡",
    0xA8: "◻",    # U+25FB White square
    0xF0A8: "◻",
    0xA1: "●",    # U+25CF Black circle
    0xF0A1: "●",
    0xBF: "✔",    # U+2714 Checkmark
    0xF0BF: "✔",
    0x2D: "–",    # U+2013 En dash
}


def _int_to_roman(n: int) -> str:
    val = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    syb = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
    roman_num = ""
    i = 0
    while n > 0:
        for _ in range(n // val[i]):
            roman_num += syb[i]
            n -= val[i]
        i += 1
    return roman_num


def _format_auto_num(num_type: str, count: int) -> str:
    if count < 1:
        count = 1
    t = num_type.lower()
    if "arabicperiod" in t:
        return f"{count}."
    elif "arabicparenr" in t:
        return f"{count})"
    elif "arabicparenboth" in t:
        return f"({count})"
    elif "arabicplain" in t:
        return f"{count}"
    elif "alphalcperiod" in t:
        ch = chr(ord('a') + (count - 1) % 26)
        return f"{ch}."
    elif "alphalcparenr" in t:
        ch = chr(ord('a') + (count - 1) % 26)
        return f"{ch})"
    elif "alphalcparenboth" in t:
        ch = chr(ord('a') + (count - 1) % 26)
        return f"({ch})"
    elif "alphaucperiod" in t:
        ch = chr(ord('A') + (count - 1) % 26)
        return f"{ch}."
    elif "alphaucparenr" in t:
        ch = chr(ord('A') + (count - 1) % 26)
        return f"{ch})"
    elif "romanlcperiod" in t:
        return f"{_int_to_roman(count).lower()}."
    elif "romanlcparenr" in t:
        return f"{_int_to_roman(count).lower()})"
    elif "romanucperiod" in t:
        return f"{_int_to_roman(count)}."
    elif "romanucparenr" in t:
        return f"{_int_to_roman(count)})"
    return f"{count}."


def _map_bullet_character(char_val: str, font_name: Optional[str]) -> Tuple[str, Optional[str]]:
    return GlyphEngine.map_bullet_character(char_val, font_name)


class TextParser:
    """
    Parses OpenXML DrawingML text frames (<p:txBody> or <a:txBody>).
    """
    def __init__(
        self,
        color_engine: Optional[ColorEngine] = None,
        default_font: str = "Calibri",
        major_font: str = "Calibri Light",
        minor_font: str = "Calibri",
        relationships: Optional[Dict[str, Any]] = None,
    ):
        self.color_engine = color_engine or ColorEngine()
        self.default_font = default_font
        self.major_font = major_font
        self.minor_font = minor_font
        self.relationships = relationships or {}

    def _resolve_typeface(self, name: Optional[str]) -> str:
        if not name:
            return self.default_font
        if name.startswith("+mj"):
            return self.major_font
        if name.startswith("+mn"):
            return self.minor_font
        return name

    def parse_text_frame(self, tx_body_elem: Optional[ET.Element]) -> Optional[TextBoxModel]:
        if tx_body_elem is None:
            return None

        # 1. Body Properties: <a:bodyPr>
        body_pr = tx_body_elem.find(qn("a", "bodyPr"))
        insets = (7.2, 3.6, 7.2, 3.6)
        vert_align = VerticalAlign.TOP
        word_wrap = True
        columns = 1
        col_spacing = 0.0
        rotation = 0.0
        vert_rot = "horz"

        if body_pr is not None:
            l_ins = emu_to_pt(int(body_pr.get("lIns", 91440))) if "lIns" in body_pr.attrib else 7.2
            t_ins = emu_to_pt(int(body_pr.get("tIns", 45720))) if "tIns" in body_pr.attrib else 3.6
            r_ins = emu_to_pt(int(body_pr.get("rIns", 91440))) if "rIns" in body_pr.attrib else 7.2
            b_ins = emu_to_pt(int(body_pr.get("bIns", 45720))) if "bIns" in body_pr.attrib else 3.6
            insets = (l_ins, t_ins, r_ins, b_ins)

            anchor = body_pr.get("anchor", "t")
            if anchor in ("ctr", "mid"):
                vert_align = VerticalAlign.MIDDLE
            elif anchor in ("b", "just"):
                vert_align = VerticalAlign.BOTTOM

            wrap = body_pr.get("wrap", "square")
            word_wrap = (wrap != "none")

            if body_pr.get("numCol"):
                try:
                    columns = max(1, int(body_pr.get("numCol")))
                except ValueError:
                    columns = 1

            if body_pr.get("spcCol"):
                try:
                    col_spacing = emu_to_pt(int(body_pr.get("spcCol")))
                except ValueError:
                    col_spacing = 0.0

            rot = body_pr.get("rot")
            if rot:
                rotation = float(rot) / 60000.0

            vert_rot = body_pr.get("vert", "horz")

        # 2. List Styles: <a:lstStyle>
        lst_style_elem = tx_body_elem.find(qn("a", "lstStyle"))
        lst_style_defaults = self._parse_lst_style(lst_style_elem)

        # 3. Paragraphs: <a:p>
        paragraphs: List[ParagraphModel] = []
        auto_num_counters: Dict[Tuple[int, str], int] = {}
        frame_def_tab_size = 72.0
        if body_pr is not None and body_pr.get("defTabSz"):
            try:
                frame_def_tab_size = emu_to_pt(int(body_pr.get("defTabSz")))
            except ValueError:
                pass

        for p_elem in tx_body_elem.findall(qn("a", "p")):
            p_model = self._parse_paragraph(p_elem, lst_style_defaults, auto_num_counters, frame_def_tab_size=frame_def_tab_size)
            paragraphs.append(p_model)

        return TextBoxModel(
            paragraphs=paragraphs,
            insets=insets,
            vertical_align=vert_align,
            word_wrap=word_wrap,
            columns=columns,
            column_spacing=col_spacing,
            rotation=rotation,
            vert_rotation=vert_rot,
        )

    def _parse_lst_style(self, lst_style_elem: Optional[ET.Element]) -> Dict[int, Dict[str, Any]]:
        """Parses <a:lstStyle> into per-level default dictionaries (levels 0..8)."""
        levels: Dict[int, Dict[str, Any]] = {}
        if lst_style_elem is None:
            return levels

        for lvl_idx in range(9):
            lvl_tag = f"lvl{lvl_idx + 1}pPr"
            lvl_elem = lst_style_elem.find(qn("a", lvl_tag))
            if lvl_elem is not None:
                levels[lvl_idx] = self._extract_p_pr_properties(lvl_elem)

        return levels

    def _extract_p_pr_properties(self, p_pr: ET.Element) -> Dict[str, Any]:
        """Extracts paragraph and defRPr styling from a pPr or lvlNpPr XML element."""
        prop: Dict[str, Any] = {}

        # Alignment
        algn_attr = p_pr.get("algn")
        if algn_attr:
            if algn_attr in ("ctr", "center"):
                prop["align"] = HorizontalAlign.CENTER
            elif algn_attr in ("r", "right"):
                prop["align"] = HorizontalAlign.RIGHT
            elif algn_attr in ("just", "dist"):
                prop["align"] = HorizontalAlign.JUSTIFY
            else:
                prop["align"] = HorizontalAlign.LEFT

        # Margins & Indents
        if p_pr.get("marL"):
            prop["margin_left"] = emu_to_pt(int(p_pr.get("marL")))
        if p_pr.get("marR"):
            prop["margin_right"] = emu_to_pt(int(p_pr.get("marR")))
        if p_pr.get("indent"):
            prop["hanging_indent"] = emu_to_pt(int(p_pr.get("indent")))

        # Spacing
        spc_bef = p_pr.find(qn("a", "spcBef"))
        if spc_bef is not None:
            spc_pts = spc_bef.find(qn("a", "spcPts"))
            if spc_pts is not None and spc_pts.get("val"):
                prop["space_before"] = hundredths_pt_to_pt(int(spc_pts.get("val")))
            else:
                spc_pct = spc_bef.find(qn("a", "spcPct"))
                if spc_pct is not None and spc_pct.get("val"):
                    prop["space_before_pct"] = float(spc_pct.get("val")) / 100000.0

        spc_aft = p_pr.find(qn("a", "spcAft"))
        if spc_aft is not None:
            spc_pts = spc_aft.find(qn("a", "spcPts"))
            if spc_pts is not None and spc_pts.get("val"):
                prop["space_after"] = hundredths_pt_to_pt(int(spc_pts.get("val")))
            else:
                spc_pct = spc_aft.find(qn("a", "spcPct"))
                if spc_pct is not None and spc_pct.get("val"):
                    prop["space_after_pct"] = float(spc_pct.get("val")) / 100000.0

        # Line Spacing
        ln_spc = p_pr.find(qn("a", "lnSpc"))
        if ln_spc is not None:
            spc_pts = ln_spc.find(qn("a", "spcPts"))
            if spc_pts is not None and spc_pts.get("val"):
                prop["line_spacing"] = hundredths_pt_to_pt(int(spc_pts.get("val")))
                prop["line_spacing_exact"] = True
            else:
                spc_pct = ln_spc.find(qn("a", "spcPct"))
                if spc_pct is not None and spc_pct.get("val"):
                    prop["line_spacing"] = float(spc_pct.get("val")) / 100000.0
                    prop["line_spacing_exact"] = False

        # Bullets
        if p_pr.find(qn("a", "buNone")) is not None:
            prop["bullet_char"] = None
            prop["has_bu_none"] = True
        else:
            bu_char = p_pr.find(qn("a", "buChar"))
            if bu_char is not None and bu_char.get("char"):
                prop["bullet_char"] = bu_char.get("char")
            bu_font = p_pr.find(qn("a", "buFont"))
            if bu_font is not None and bu_font.get("typeface"):
                prop["bullet_font"] = bu_font.get("typeface")
            bu_clr = p_pr.find(qn("a", "buClr"))
            if bu_clr is not None:
                prop["bullet_color"] = self.color_engine.resolve_solid_fill(bu_clr) or self.color_engine.resolve_color_element(bu_clr)
            bu_sz_pct = p_pr.find(qn("a", "buSzPct"))
            if bu_sz_pct is not None and bu_sz_pct.get("val"):
                prop["bullet_size_pct"] = float(bu_sz_pct.get("val")) / 100000.0
            bu_sz_pts = p_pr.find(qn("a", "buSzPts"))
            if bu_sz_pts is not None and bu_sz_pts.get("val"):
                prop["bullet_size_pts"] = hundredths_pt_to_pt(int(bu_sz_pts.get("val")))
            bu_auto_num = p_pr.find(qn("a", "buAutoNum"))
            if bu_auto_num is not None:
                prop["auto_num_type"] = bu_auto_num.get("type", "arabicPeriod")
                if bu_auto_num.get("startAt"):
                    try:
                        prop["auto_num_start"] = int(bu_auto_num.get("startAt"))
                    except ValueError:
                        prop["auto_num_start"] = 1

        # Tab Stops & Default Tab Size
        if p_pr.get("defTabSz"):
            try:
                prop["def_tab_size"] = emu_to_pt(int(p_pr.get("defTabSz")))
            except ValueError:
                pass

        tab_lst = p_pr.find(qn("a", "tabLst"))
        if tab_lst is not None:
            tabs = []
            for tab_elem in tab_lst.findall(qn("a", "tab")):
                pos_val = tab_elem.get("pos")
                algn_val = tab_elem.get("algn", "l")
                if pos_val:
                    tabs.append(TabStopModel(pos=emu_to_pt(int(pos_val)), align=algn_val))
            if tabs:
                prop["tab_stops"] = tabs

        # Default Run Properties: <a:defRPr>
        def_r_pr = p_pr.find(qn("a", "defRPr"))
        if def_r_pr is not None:
            if def_r_pr.get("sz"):
                prop["def_size"] = hundredths_pt_to_pt(int(def_r_pr.get("sz")))
            if def_r_pr.get("b") is not None:
                prop["def_bold"] = (def_r_pr.get("b") in ("1", "true"))
            if def_r_pr.get("i") is not None:
                prop["def_italic"] = (def_r_pr.get("i") in ("1", "true"))
            if def_r_pr.get("u") and def_r_pr.get("u") != "none":
                prop["def_underline"] = True
            if def_r_pr.get("strike") and def_r_pr.get("strike") != "noStrike":
                prop["def_strikethrough"] = True
            latin = def_r_pr.find(qn("a", "latin"))
            if latin is not None and latin.get("typeface"):
                prop["def_font"] = self._resolve_typeface(latin.get("typeface"))
            clr = self.color_engine.resolve_solid_fill(def_r_pr) or self.color_engine.resolve_color_element(def_r_pr)
            if clr:
                prop["def_color"] = clr

        return prop

    def _parse_paragraph(
        self,
        p_elem: ET.Element,
        lst_style_defaults: Dict[int, Dict[str, Any]],
        auto_num_counters: Dict[Tuple[int, str], int],
        frame_def_tab_size: float = 72.0,
    ) -> ParagraphModel:
        p_pr = p_elem.find(qn("a", "pPr"))
        indent_level = 0
        if p_pr is not None and p_pr.get("lvl"):
            try:
                indent_level = int(p_pr.get("lvl"))
            except ValueError:
                indent_level = 0

        # Start with level defaults from lstStyle
        lvl_props = lst_style_defaults.get(indent_level, {})

        align = lvl_props.get("align", HorizontalAlign.LEFT)
        margin_left = lvl_props.get("margin_left", 0.0)
        margin_right = lvl_props.get("margin_right", 0.0)
        hanging_indent = lvl_props.get("hanging_indent", 0.0)
        space_before = lvl_props.get("space_before", 0.0)
        space_after = lvl_props.get("space_after", 0.0)
        line_spacing = lvl_props.get("line_spacing", 1.0)
        line_spacing_exact = lvl_props.get("line_spacing_exact", False)
        tab_stops = list(lvl_props.get("tab_stops", []))
        def_tab_size = lvl_props.get("def_tab_size", frame_def_tab_size)

        bullet_char = lvl_props.get("bullet_char")
        bullet_font = lvl_props.get("bullet_font")
        bullet_color = lvl_props.get("bullet_color")
        bullet_size_pct = lvl_props.get("bullet_size_pct")
        bullet_size_pts = lvl_props.get("bullet_size_pts")
        auto_num_type = lvl_props.get("auto_num_type")
        auto_num_start = lvl_props.get("auto_num_start", 1)

        def_font = lvl_props.get("def_font", self.default_font)
        def_size = lvl_props.get("def_size", 14.0)
        def_color = lvl_props.get("def_color", ColorModel.black())
        def_bold = lvl_props.get("def_bold", False)
        def_italic = lvl_props.get("def_italic", False)
        def_underline = lvl_props.get("def_underline", False)
        def_strikethrough = lvl_props.get("def_strikethrough", False)
        has_explicit_align = False

        if p_pr is not None:
            direct_props = self._extract_p_pr_properties(p_pr)
            if "align" in direct_props:
                align = direct_props["align"]
                has_explicit_align = True
            if "margin_left" in direct_props:
                margin_left = direct_props["margin_left"]
            if "margin_right" in direct_props:
                margin_right = direct_props["margin_right"]
            if "hanging_indent" in direct_props:
                hanging_indent = direct_props["hanging_indent"]
            if "space_before" in direct_props:
                space_before = direct_props["space_before"]
            elif "space_before_pct" in direct_props:
                space_before = direct_props["space_before_pct"] * def_size
            if "space_after" in direct_props:
                space_after = direct_props["space_after"]
            elif "space_after_pct" in direct_props:
                space_after = direct_props["space_after_pct"] * def_size
            if "line_spacing" in direct_props:
                line_spacing = direct_props["line_spacing"]
                line_spacing_exact = direct_props.get("line_spacing_exact", False)
            if "tab_stops" in direct_props:
                tab_stops = direct_props["tab_stops"]

            if direct_props.get("has_bu_none"):
                bullet_char = None
                auto_num_type = None
            else:
                if "bullet_char" in direct_props:
                    bullet_char = direct_props["bullet_char"]
                if "bullet_font" in direct_props:
                    bullet_font = direct_props["bullet_font"]
                if "bullet_color" in direct_props:
                    bullet_color = direct_props["bullet_color"]
                if "bullet_size_pct" in direct_props:
                    bullet_size_pct = direct_props["bullet_size_pct"]
                if "bullet_size_pts" in direct_props:
                    bullet_size_pts = direct_props["bullet_size_pts"]
                if "auto_num_type" in direct_props:
                    auto_num_type = direct_props["auto_num_type"]
                if "auto_num_start" in direct_props:
                    auto_num_start = direct_props["auto_num_start"]

            if "def_font" in direct_props:
                def_font = direct_props["def_font"]
            if "def_size" in direct_props:
                def_size = direct_props["def_size"]
            if "def_color" in direct_props:
                def_color = direct_props["def_color"]
            if "def_bold" in direct_props:
                def_bold = direct_props["def_bold"]
            if "def_italic" in direct_props:
                def_italic = direct_props["def_italic"]
            if "def_underline" in direct_props:
                def_underline = direct_props["def_underline"]
            if "def_strikethrough" in direct_props:
                def_strikethrough = direct_props["def_strikethrough"]
            if "def_tab_size" in direct_props:
                def_tab_size = direct_props["def_tab_size"]

        # Resolve bullets: AutoNum or Symbol/Char
        if auto_num_type:
            counter_key = (indent_level, auto_num_type)
            if counter_key not in auto_num_counters:
                auto_num_counters[counter_key] = auto_num_start
            else:
                auto_num_counters[counter_key] += 1
            curr_count = auto_num_counters[counter_key]
            bullet_char = _format_auto_num(auto_num_type, curr_count)
            bullet_font = def_font
        else:
            # Paragraph without auto_num breaks the numbering sequence
            keys_to_del = [k for k in auto_num_counters if k[0] >= indent_level]
            for k in keys_to_del:
                del auto_num_counters[k]
            if bullet_char:
                bullet_char, bullet_font = _map_bullet_character(bullet_char, bullet_font)

        # Runs & Line Breaks: <a:r>, <a:br>, <a:fld>
        runs: List[RunModel] = []
        for child in p_elem:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if tag == "r":
                run = self._parse_run(
                    child,
                    def_font=def_font,
                    def_size=def_size,
                    def_color=def_color,
                    def_bold=def_bold,
                    def_italic=def_italic,
                    def_underline=def_underline,
                    def_strikethrough=def_strikethrough,
                )
                runs.append(run)
            elif tag == "br":
                r_pr = child.find(qn("a", "rPr"))
                br_size = hundredths_pt_to_pt(int(r_pr.get("sz"))) if (r_pr is not None and r_pr.get("sz")) else def_size
                runs.append(RunModel(
                    text="\n",
                    font_family=def_font,
                    font_size=br_size,
                    color=def_color,
                    bold=def_bold,
                    italic=def_italic,
                    underline=def_underline,
                    strikethrough=def_strikethrough,
                ))
            elif tag == "fld":
                t_elem = child.find(qn("a", "t"))
                if t_elem is not None and t_elem.text:
                    r_pr = child.find(qn("a", "rPr"))
                    run = self._parse_run_with_pr(
                        t_elem.text,
                        r_pr,
                        def_font=def_font,
                        def_size=def_size,
                        def_color=def_color,
                        def_bold=def_bold,
                        def_italic=def_italic,
                        def_underline=def_underline,
                        def_strikethrough=def_strikethrough,
                    )
                    runs.append(run)

        # Check endParaRPr for paragraph default font size/family
        end_r_pr = p_elem.find(qn("a", "endParaRPr"))
        if end_r_pr is not None:
            if end_r_pr.get("sz"):
                try:
                    def_size = hundredths_pt_to_pt(int(end_r_pr.get("sz")))
                except ValueError:
                    pass
            lat = end_r_pr.find(qn("a", "latin"))
            if lat is not None and lat.get("typeface"):
                def_font = lat.get("typeface")

        return ParagraphModel(
            runs=runs,
            align=align,
            has_explicit_align=has_explicit_align,
            line_spacing=line_spacing,
            line_spacing_exact=line_spacing_exact,
            space_before=space_before,
            space_after=space_after,
            bullet_char=bullet_char,
            bullet_font=bullet_font,
            bullet_color=bullet_color,
            bullet_size_pct=bullet_size_pct,
            bullet_size_pts=bullet_size_pts,
            auto_num_type=auto_num_type,
            auto_num_start=auto_num_start,
            indent_level=indent_level,
            margin_left=margin_left,
            margin_right=margin_right,
            hanging_indent=hanging_indent,
            tab_stops=tab_stops,
            def_tab_size=def_tab_size,
            default_font_size=def_size,
            default_font_family=def_font,
        )

    def _parse_run(
        self,
        r_elem: ET.Element,
        def_font: str,
        def_size: float,
        def_color: ColorModel,
        def_bold: bool = False,
        def_italic: bool = False,
        def_underline: bool = False,
        def_strikethrough: bool = False,
    ) -> RunModel:
        t_elem = r_elem.find(qn("a", "t"))
        text = t_elem.text if (t_elem is not None and t_elem.text is not None) else ""
        sym_elem = r_elem.find(qn("a", "sym"))
        if not text and sym_elem is not None:
            char_hex = sym_elem.get("char", "")
            if char_hex:
                try:
                    text = chr(int(char_hex, 16))
                except Exception:
                    text = char_hex
            if sym_elem.get("font"):
                def_font = sym_elem.get("font")

        r_pr = r_elem.find(qn("a", "rPr"))
        return self._parse_run_with_pr(
            text,
            r_pr,
            def_font=def_font,
            def_size=def_size,
            def_color=def_color,
            def_bold=def_bold,
            def_italic=def_italic,
            def_underline=def_underline,
            def_strikethrough=def_strikethrough,
        )

    def _parse_run_with_pr(
        self,
        text: str,
        r_pr: Optional[ET.Element],
        def_font: str,
        def_size: float,
        def_color: ColorModel,
        def_bold: bool = False,
        def_italic: bool = False,
        def_underline: bool = False,
        def_strikethrough: bool = False,
    ) -> RunModel:
        font_family = def_font
        font_size = def_size
        color = def_color
        highlight_color: Optional[ColorModel] = None
        bold = def_bold
        italic = def_italic
        underline = def_underline
        strikethrough = def_strikethrough
        baseline_offset = 0.0
        hyperlink_target: Optional[str] = None

        has_explicit_font = False
        has_explicit_size = False
        has_explicit_bold = False
        has_explicit_color = False

        if r_pr is not None:
            if "b" in r_pr.attrib:
                bold = (r_pr.get("b") in ("1", "true"))
                has_explicit_bold = True
            if "i" in r_pr.attrib:
                italic = (r_pr.get("i") in ("1", "true"))
            if r_pr.get("u") is not None:
                underline = (r_pr.get("u") != "none")
            if r_pr.get("strike") is not None:
                strikethrough = (r_pr.get("strike") != "noStrike")
            if r_pr.get("sz"):
                font_size = hundredths_pt_to_pt(int(r_pr.get("sz")))
                has_explicit_size = True
            if r_pr.get("baseline"):
                baseline_offset = float(r_pr.get("baseline")) / 100000.0
                if baseline_offset != 0:
                    font_size = round(font_size * 0.66, 2)
            character_spacing = 0.0
            if r_pr.get("spc"):
                try:
                    character_spacing = hundredths_pt_to_pt(int(r_pr.get("spc")))
                except ValueError:
                    pass

            latin = r_pr.find(qn("a", "latin"))
            ea = r_pr.find(qn("a", "ea"))
            cs = r_pr.find(qn("a", "cs"))
            sym = r_pr.find(qn("a", "sym"))

            cjk_names = ("gothic", "simsun", "meiryo", "mingliu", "song", "heiti", "fangsong", "kai", "mincho", "\uff2d\uff33", "\u30b4\u30b7\u30c3\u30af")
            has_cjk_text = any(0x4E00 <= ord(c) <= 0x9FFF or 0x3040 <= ord(c) <= 0x30FF or 0xAC00 <= ord(c) <= 0xD7AF for c in text)

            if sym is not None and sym.get("typeface") and any(s in sym.get("typeface").lower() for s in ("wingdings", "symbol", "webdings")):
                font_family = self._resolve_typeface(sym.get("typeface"))
                has_explicit_font = True
            elif latin is not None and latin.get("typeface"):
                font_family = self._resolve_typeface(latin.get("typeface"))
                has_explicit_font = True
            elif ea is not None and ea.get("typeface"):
                ea_tf = ea.get("typeface")
                is_cjk_typeface = any(cn in ea_tf.lower() for cn in cjk_names)
                if not is_cjk_typeface or has_cjk_text:
                    font_family = self._resolve_typeface(ea_tf)
                    has_explicit_font = True
            elif cs is not None and cs.get("typeface") and any(ord(c) >= 0x0590 for c in text):
                font_family = self._resolve_typeface(cs.get("typeface"))
                has_explicit_font = True
            elif sym is not None and sym.get("typeface"):
                font_family = self._resolve_typeface(sym.get("typeface"))
                has_explicit_font = True

            # Color resolution: solidFill is strictly font color
            resolved_color = self.color_engine.resolve_solid_fill(r_pr)
            if resolved_color:
                color = resolved_color
                has_explicit_color = True

            # Highlight resolution: text background highlight
            highlight_color = self.color_engine.resolve_highlight(r_pr)

            hlink = r_pr.find(qn("a", "hlinkClick"))
            if hlink is not None and hlink.get(qn("r", "id")):
                r_id = hlink.get(qn("r", "id"))
                if r_id in self.relationships:
                    hyperlink_target = self.relationships[r_id].get("target")

        # Decode symbols, PUA, and sanitize control characters with GlyphEngine
        text, font_family = GlyphEngine.decode_glyph_run(text, font_family)

        return RunModel(
            text=text,
            font_family=font_family,
            font_size=font_size,
            color=color,
            highlight_color=highlight_color,
            has_explicit_font=has_explicit_font,
            has_explicit_size=has_explicit_size,
            has_explicit_bold=has_explicit_bold,
            has_explicit_color=has_explicit_color,
            bold=bold,
            italic=italic,
            underline=underline,
            strikethrough=strikethrough,
            baseline_offset=baseline_offset,
            character_spacing=character_spacing,
            hyperlink_target=hyperlink_target,
        )
