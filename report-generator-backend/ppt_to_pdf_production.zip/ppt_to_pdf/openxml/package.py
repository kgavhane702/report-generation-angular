"""
PPTX package reader and OpenXML relationship graph resolver.
"""

import io
import posixpath
import zipfile
import threading
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Union, Tuple
from ..core.exceptions import PPTXPackageError
from .constants import NS, qn, REL_SLIDE, REL_SLIDE_LAYOUT, REL_SLIDE_MASTER, REL_THEME, REL_IMAGE, REL_CHART


class PPTXPackage:
    """
    Manages access to the contents of a PPTX (OpenXML) zip package.
    Thread-safe implementation.
    """
    def __init__(self, source: Union[str, Path, bytes, io.BytesIO]):
        self._zip: Optional[zipfile.ZipFile] = None
        self._xml_cache: Dict[str, ET.Element] = {}
        self._rels_cache: Dict[str, Dict[str, Tuple[str, str]]] = {}  # part_path -> {rId: (Type, Target)}
        self._slide_width_emu: int = 9144000  # Default 10 inches (720 pt)
        self._slide_height_emu: int = 6858000  # Default 7.5 inches (540 pt)
        self._slide_part_paths: List[str] = []
        self._lock = threading.Lock()
        
        self._open_package(source)
        self._inspect_presentation()

    def _open_package(self, source: Union[str, Path, bytes, io.BytesIO]) -> None:
        try:
            if isinstance(source, (str, Path)):
                self._zip = zipfile.ZipFile(str(source), 'r')
            elif isinstance(source, bytes):
                self._zip = zipfile.ZipFile(io.BytesIO(source), 'r')
            elif isinstance(source, io.BytesIO):
                self._zip = zipfile.ZipFile(source, 'r')
            else:
                raise PPTXPackageError(f"Unsupported source type: {type(source)}")
        except Exception as e:
            raise PPTXPackageError(f"Failed to open PPTX zip package: {e}") from e

    def get_part_bytes(self, part_path: str) -> Optional[bytes]:
        """Reads raw binary bytes from a package part path (e.g. 'ppt/media/image1.png')."""
        norm_path = posixpath.normpath(part_path.lstrip("/"))
        with self._lock:
            if self._zip is None:
                return None
            try:
                return self._zip.read(norm_path)
            except KeyError:
                # Case-insensitive fallback search
                lower_path = norm_path.lower()
                for name in self._zip.namelist():
                    if name.lower() == lower_path:
                        return self._zip.read(name)
                return None

    def get_xml_root(self, part_path: str) -> Optional[ET.Element]:
        """Parses and caches XML element tree root for a part path."""
        norm_path = posixpath.normpath(part_path.lstrip("/"))
        with self._lock:
            if norm_path in self._xml_cache:
                return self._xml_cache[norm_path]

        raw = self.get_part_bytes(norm_path)
        if raw is None:
            return None

        try:
            root = ET.fromstring(raw)
            with self._lock:
                self._xml_cache[norm_path] = root
            return root
        except Exception:
            return None

    def get_relationships(self, part_path: str) -> Dict[str, Tuple[str, str]]:
        """
        Returns relationship map {rId: (Type, Target)} for a part.
        Target is returned as an absolute package path or external URI.
        """
        norm_path = posixpath.normpath(part_path.lstrip("/"))
        with self._lock:
            if norm_path in self._rels_cache:
                return self._rels_cache[norm_path]

        # Relationship part naming convention:
        # 'ppt/presentation.xml' -> 'ppt/_rels/presentation.xml.rels'
        # '' (package root) -> '_rels/.rels'
        dir_name, file_name = posixpath.split(norm_path)
        rels_path = posixpath.join(dir_name, "_rels", f"{file_name}.rels") if file_name else "_rels/.rels"

        rels: Dict[str, Tuple[str, str]] = {}
        rels_root = self.get_xml_root(rels_path)
        if rels_root is not None:
            for rel in rels_root.findall(qn("rel", "Relationship")):
                r_id = rel.get("Id", "")
                r_type = rel.get("Type", "")
                target = rel.get("Target", "")
                target_mode = rel.get("TargetMode", "Internal")

                if target_mode == "External" or target.startswith("http://") or target.startswith("https://") or target.startswith("mailto:"):
                    resolved_target = target
                else:
                    resolved_target = posixpath.normpath(posixpath.join(dir_name, target))

                rels[r_id] = (r_type, resolved_target)

        with self._lock:
            self._rels_cache[norm_path] = rels
        return rels

    def get_target_by_rid(self, part_path: str, r_id: str) -> Optional[str]:
        """Resolves target part path for a given relationship ID on a part."""
        rels = self.get_relationships(part_path)
        if r_id in rels:
            return rels[r_id][1]
        return None

    def _inspect_presentation(self) -> None:
        """Inspects presentation.xml to extract slide dimensions and slide order."""
        pres_root = self.get_xml_root("ppt/presentation.xml")
        if pres_root is None:
            # Fallback: scan ppt/slides/
            self._discover_slides_fallback()
            return

        # Slide Dimensions: <p:sldSz cx="..." cy="..."/>
        sld_sz = pres_root.find(qn("p", "sldSz"))
        if sld_sz is not None:
            self._slide_width_emu = int(sld_sz.get("cx", 9144000))
            self._slide_height_emu = int(sld_sz.get("cy", 6858000))

        # Slide Order from <p:sldIdLst>
        pres_rels = self.get_relationships("ppt/presentation.xml")
        sld_id_lst = pres_root.find(qn("p", "sldIdLst"))
        discovered: List[str] = []

        if sld_id_lst is not None:
            for sld_id in sld_id_lst.findall(qn("p", "sldId")):
                r_id = sld_id.get(qn("r", "id"))
                if r_id and r_id in pres_rels:
                    discovered.append(pres_rels[r_id][1])

        if discovered:
            self._slide_part_paths = discovered
        else:
            self._discover_slides_fallback()

    def _discover_slides_fallback(self) -> None:
        """Fallback: lists all slide*.xml in ppt/slides/ sorted naturally."""
        import re
        slides = []
        for name in self._zip.namelist():
            if name.startswith("ppt/slides/slide") and name.endswith(".xml"):
                slides.append(name)
        
        def natural_sort_key(s):
            return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', str(s))]

        self._slide_part_paths = sorted(slides, key=natural_sort_key)

    @property
    def slide_dimensions_emu(self) -> Tuple[int, int]:
        return (self._slide_width_emu, self._slide_height_emu)

    @property
    def slide_paths(self) -> List[str]:
        return self._slide_part_paths

    def close(self) -> None:
        if self._zip:
            self._zip.close()
            self._zip = None
