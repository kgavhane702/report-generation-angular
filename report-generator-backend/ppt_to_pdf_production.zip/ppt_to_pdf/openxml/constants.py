"""
OpenXML namespaces, constants, and tag definitions.
"""

# OpenXML XML Namespaces
NS = {
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'rel': 'http://schemas.openxmlformats.org/package/2006/relationships',
    'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
    'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
    'p14': 'http://schemas.microsoft.com/office/powerpoint/2010/main',
    'p15': 'http://schemas.microsoft.com/office/powerpoint/2012/main',
    'p16': 'http://schemas.microsoft.com/office/powerpoint/2015/main',
    'a14': 'http://schemas.microsoft.com/office/drawing/2010/main',
    'a16': 'http://schemas.microsoft.com/office/drawing/2014/main',
    'c14': 'http://schemas.microsoft.com/office/drawing/2007/8/2/chart',
    'c16': 'http://schemas.microsoft.com/office/drawing/2014/chart',
    'c16r2': 'http://schemas.microsoft.com/office/drawing/2015/06/chart',
    'dgm': 'http://schemas.openxmlformats.org/drawingml/2006/diagram',
    'v': 'urn:schemas-microsoft-com:vml',
}

# Relationship Types
REL_SLIDE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide"
REL_SLIDE_LAYOUT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout"
REL_SLIDE_MASTER = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster"
REL_THEME = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme"
REL_IMAGE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
REL_CHART = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart"
REL_NOTES = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide"
REL_HYPERLINK = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink"


def qn(namespace_prefix: str, tag: str) -> str:
    """Helper to return Clark notation {uri}tag for a namespace prefix and tag name."""
    uri = NS.get(namespace_prefix, "")
    return f"{{{uri}}}{tag}"
