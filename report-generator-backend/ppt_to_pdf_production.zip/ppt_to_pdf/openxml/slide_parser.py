"""
Slide XML Parser.
Traverses slide element trees (<p:spTree>) in visual Z-order,
orchestrates shape, picture, table, chart, connector, and group parsing,
and constructs the intermediate SlideModel AST.
"""

import xml.etree.ElementTree as ET
from typing import List, Optional, Union
from ..core.models import (
    SlideModel,
    ShapeModel,
    PictureModel,
    TableModel,
    ChartModel,
    ConnectorModel,
    GroupModel,
)
from ..utils.units import emu_to_pt
from .constants import NS, qn, REL_NOTES
from .package import PPTXPackage
from .master_resolver import MasterResolver
from .shape_parser import ShapeParser
from .table_parser import TableParser
from .chart_parser import ChartParser
from .text_parser import TextParser


class SlideParser:
    """
    Parses a single slide part into a complete SlideModel AST.
    """
    def __init__(self, package: PPTXPackage, master_resolver: Optional[MasterResolver] = None):
        self.package = package
        self.master_resolver = master_resolver or MasterResolver(package)

    def parse_slide(self, slide_part_path: str, slide_index: int) -> Optional[SlideModel]:
        slide_root = self.package.get_xml_root(slide_part_path)
        if slide_root is None:
            return None

        # Hidden slide flag: <p:sld show="0">
        is_hidden = (slide_root.get("show") == "0")

        # Active Theme & Color Engine
        theme = self.master_resolver.get_theme_for_slide(slide_part_path)
        color_engine = theme.create_color_engine()
        text_parser = TextParser(
            color_engine=color_engine,
            default_font=theme.minor_font or "Calibri",
            major_font=theme.major_font,
            minor_font=theme.minor_font,
        )

        # Slide dimensions
        w_emu, h_emu = self.package.slide_dimensions_emu
        width_pt = emu_to_pt(w_emu)
        height_pt = emu_to_pt(h_emu)

        # Background fill
        bg_fill = self.master_resolver.resolve_background_fill(slide_root, slide_part_path, color_engine)

        # Element Parsers
        shape_parser = ShapeParser(self.package, color_engine=color_engine, text_parser=text_parser, current_part_path=slide_part_path)
        table_parser = TableParser(package=self.package, color_engine=color_engine, text_parser=text_parser)
        chart_parser = ChartParser(self.package, color_engine=color_engine, default_font=theme.minor_font)

        # Traverse Shape Tree: <p:cSld>/<p:spTree>
        slide_shapes: List[Union[ShapeModel, PictureModel, TableModel, ChartModel, ConnectorModel, GroupModel]] = []
        slide_title = ""

        # 1. Master & Layout branding shapes (logos, headers, footers)
        show_master = (slide_root.get("showMasterSp", "1") != "0")
        if show_master:
            master_shapes = self.master_resolver.get_master_and_layout_shapes(
                slide_part_path=slide_part_path,
                color_engine=color_engine,
                slide_width=width_pt,
                slide_height=height_pt,
                slide_number=slide_index + 1,
            )
            slide_shapes.extend(master_shapes)

        # 2. Slide's own shape tree
        sp_tree = slide_root.find(f".//{qn('p', 'spTree')}")
        if sp_tree is not None:
            for child in sp_tree:
                tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag

                if tag == "sp":
                    s = shape_parser.parse_shape(child)
                    if s:
                        self.master_resolver.resolve_placeholder_shape(s, slide_part_path, color_engine)
                        slide_shapes.append(s)
                        if not slide_title and s.is_placeholder and s.placeholder_type in ("title", "ctrTitle") and s.text_frame:
                            slide_title = s.text_frame.plain_text.strip()
                elif tag == "pic":
                    p = shape_parser.parse_picture(child)
                    if p:
                        slide_shapes.append(p)
                elif tag == "cxnSp":
                    c = shape_parser.parse_connector(child)
                    if c:
                        slide_shapes.append(c)
                elif tag == "grpSp":
                    g = shape_parser.parse_group(child)
                    if g:
                        slide_shapes.append(g)
                elif tag == "graphicFrame":
                    nv_gf_pr = child.find(qn("p", "nvGraphicFramePr"))
                    c_nv_pr = nv_gf_pr.find(qn("p", "cNvPr")) if nv_gf_pr is not None else None
                    if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
                        continue
                    # Check for Chart or Table
                    if child.find(f".//{qn('c', 'chart')}") is not None:
                        chart = chart_parser.parse_chart_frame(child, slide_part_path)
                        if chart:
                            slide_shapes.append(chart)
                    elif child.find(f".//{qn('a', 'tbl')}") is not None:
                        tbl = table_parser.parse_table_frame(child)
                        if tbl and tbl.bounds.w > 1.0 and tbl.bounds.h > 1.0:
                            slide_shapes.append(tbl)
                    else:
                        pic_elem = child.find(f".//{qn('p', 'pic')}")
                        if pic_elem is not None:
                            pic = shape_parser.parse_picture(pic_elem)
                            if pic and pic.image_bytes:
                                slide_shapes.append(pic)

        # Apply dynamic slide numbers
        self._apply_slide_number(slide_shapes, slide_index + 1)

        # Speaker notes (if requested)
        notes_text = self._parse_notes(slide_part_path)

        return SlideModel(
            index=slide_index,
            slide_number=slide_index + 1,
            title=slide_title or f"Slide {slide_index + 1}",
            width=width_pt,
            height=height_pt,
            background_fill=bg_fill,
            shapes=slide_shapes,
            is_hidden=is_hidden,
            notes_text=notes_text,
        )

    def _apply_slide_number(self, shapes: List, slide_num: int) -> None:
        num_str = str(slide_num)
        for s in shapes:
            if hasattr(s, "text_frame") and s.text_frame:
                is_num_ph = getattr(s, "placeholder_type", None) == "sldNum" or "Slide Number" in getattr(s, "name", "")
                for p in s.text_frame.paragraphs:
                    for r in p.runs:
                        if getattr(r, "is_slide_number", False) or r.text in ("‹#›", "<#>", "#") or "‹#›" in r.text or "<#>" in r.text:
                            r.text = r.text.replace("‹#›", num_str).replace("<#>", num_str).replace("#", num_str)
                            if is_num_ph and (r.font_size == 14.0 or r.font_size == 11.0):
                                r.font_size = 8.15
                        elif is_num_ph and r.text == num_str:
                            if r.font_size == 14.0 or r.font_size == 11.0:
                                r.font_size = 8.15

    def _parse_notes(self, slide_part_path: str) -> str:
        notes_rid = None
        rels = self.package.get_relationships(slide_part_path)
        for r_id, (r_type, target) in rels.items():
            if r_type == REL_NOTES:
                notes_rid = r_id
                break

        if not notes_rid:
            return ""

        notes_path = self.package.get_target_by_rid(slide_part_path, notes_rid)
        if not notes_path:
            return ""

        notes_root = self.package.get_xml_root(notes_path)
        if notes_root is None:
            return ""

        text_pieces = []
        for t in notes_root.findall(f".//{qn('a', 't')}"):
            if t.text:
                text_pieces.append(t.text)

        return "\n".join(text_pieces)
