"""
DrawingML and PresentationML Shape, Geometry, Fill, Stroke, and Shadow parser.
"""

import xml.etree.ElementTree as ET
from typing import Optional, Tuple, List, Union, Any
from ..core.models import (
    ShapeModel,
    PictureModel,
    ConnectorModel,
    GroupModel,
    Rect2D,
    Point2D,
    FillModel,
    FillType,
    GradientStop,
    StrokeModel,
    StrokeDashStyle,
    ShadowModel,
    ColorModel,
    CustomGeometryModel,
    CustomGeometryPath,
)
from ..utils.units import emu_to_pt, angle_to_degrees
from .constants import NS, qn
from .color_resolver import ColorEngine
from .text_parser import TextParser
from .package import PPTXPackage


class ShapeParser:
    """
    Parses OpenXML presentation elements: <p:sp>, <p:pic>, <p:cxnSp>, <p:grpSp>.
    """
    def __init__(
        self,
        package: PPTXPackage,
        color_engine: Optional[ColorEngine] = None,
        text_parser: Optional[TextParser] = None,
        current_part_path: str = "",
    ):
        self.package = package
        self.color_engine = color_engine or ColorEngine()
        self.text_parser = text_parser or TextParser(color_engine=self.color_engine)
        self.current_part_path = current_part_path

    def parse_shape(self, sp_elem: ET.Element) -> Optional[ShapeModel]:
        # Non-visual properties: <p:nvSpPr>
        nv_sp_pr = sp_elem.find(qn("p", "nvSpPr"))
        c_nv_pr = nv_sp_pr.find(qn("p", "cNvPr")) if nv_sp_pr is not None else None
        if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
            return None
        sp_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        # Placeholder info
        is_placeholder = False
        ph_type = None
        ph_idx = None
        nv_pr = nv_sp_pr.find(qn("p", "nvPr")) if nv_sp_pr is not None else None
        if nv_pr is not None:
            ph = nv_pr.find(qn("p", "ph"))
            if ph is not None:
                is_placeholder = True
                ph_type = ph.get("type", "body")
                idx_str = ph.get("idx")
                ph_idx = int(idx_str) if idx_str else None

        # Shape properties: <p:spPr>
        sp_pr = sp_elem.find(qn("p", "spPr"))
        bounds, rot, flip_h, flip_v = self._parse_transform(sp_pr)
        preset_geom, custom_path, custom_geom, corner_radius = self._parse_geometry(sp_pr, bounds)
        fill = self._parse_fill(sp_pr)
        stroke = self._parse_stroke(sp_pr)
        shadow = self._parse_shadow(sp_pr)

        # Text Frame: <p:txBody>
        tx_body = sp_elem.find(qn("p", "txBody"))
        text_frame = self.text_parser.parse_text_frame(tx_body)

        return ShapeModel(
            id=sp_id,
            name=name,
            bounds=bounds,
            preset_geom=preset_geom,
            custom_path=custom_path,
            custom_geometry=custom_geom,
            corner_radius=corner_radius,
            rotation=rot,
            flip_h=flip_h,
            flip_v=flip_v,
            fill=fill,
            stroke=stroke,
            shadow=shadow,
            text_frame=text_frame,
            is_placeholder=is_placeholder,
            placeholder_type=ph_type,
            placeholder_idx=ph_idx,
        )

    def parse_picture(self, pic_elem: ET.Element) -> Optional[PictureModel]:
        nv_pic_pr = pic_elem.find(qn("p", "nvPicPr"))
        c_nv_pr = nv_pic_pr.find(qn("p", "cNvPr")) if nv_pic_pr is not None else None
        if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
            return None
        sp_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        sp_pr = pic_elem.find(qn("p", "spPr"))
        bounds, rot, flip_h, flip_v = self._parse_transform(sp_pr)
        stroke = self._parse_stroke(sp_pr)
        shadow = self._parse_shadow(sp_pr)

        # Image source from <p:blipFill>
        blip_fill = pic_elem.find(qn("p", "blipFill"))
        image_bytes: Optional[bytes] = None
        crop_rect: Optional[Tuple[float, float, float, float]] = None
        image_format = "png"

        if blip_fill is not None:
            blip = blip_fill.find(qn("a", "blip"))
            if blip is not None:
                r_id = blip.get(qn("r", "embed"))
                if r_id:
                    target_part = self.package.get_target_by_rid(self.current_part_path, r_id)
                    if target_part:
                        image_bytes = self.package.get_part_bytes(target_part)
                        image_format = target_part.split(".")[-1].lower()

            src_rect = blip_fill.find(qn("a", "srcRect"))
            if src_rect is not None:
                l = float(src_rect.get("l", 0)) / 100000.0
                t = float(src_rect.get("t", 0)) / 100000.0
                r = float(src_rect.get("r", 0)) / 100000.0
                b = float(src_rect.get("b", 0)) / 100000.0
                crop_rect = (l, t, r, b)

        return PictureModel(
            id=sp_id,
            name=name,
            bounds=bounds,
            image_bytes=image_bytes,
            image_format=image_format,
            crop_rect=crop_rect,
            rotation=rot,
            flip_h=flip_h,
            flip_v=flip_v,
            stroke=stroke,
            shadow=shadow,
        )

    def parse_connector(self, cxn_elem: ET.Element) -> Optional[ConnectorModel]:
        nv_cxn_pr = cxn_elem.find(qn("p", "nvCxnSpPr"))
        c_nv_pr = nv_cxn_pr.find(qn("p", "cNvPr")) if nv_cxn_pr is not None else None
        if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
            return None
        sp_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        sp_pr = cxn_elem.find(qn("p", "spPr"))
        bounds, rot, flip_h, flip_v = self._parse_transform(sp_pr)
        stroke = self._parse_stroke(sp_pr) or StrokeModel(color=ColorModel.black(), width=1.0)

        # Connector start/end points
        start_pt = Point2D(bounds.left, bounds.top)
        end_pt = Point2D(bounds.right, bounds.bottom)
        if flip_h:
            start_pt.x, end_pt.x = end_pt.x, start_pt.x
        if flip_v:
            start_pt.y, end_pt.y = end_pt.y, start_pt.y

        # Arrowheads from <a:ln>/<a:headEnd> and <a:tailEnd>
        head_type = None
        tail_type = None
        if sp_pr is not None:
            ln = sp_pr.find(qn("a", "ln"))
            if ln is not None:
                head = ln.find(qn("a", "headEnd"))
                if head is not None and head.get("type") and head.get("type") != "none":
                    head_type = head.get("type")
                tail = ln.find(qn("a", "tailEnd"))
                if tail is not None and tail.get("type") and tail.get("type") != "none":
                    tail_type = tail.get("type")

        return ConnectorModel(
            id=sp_id,
            name=name,
            start_point=start_pt,
            end_point=end_pt,
            path_points=[start_pt, end_pt],
            stroke=stroke,
            head_type=head_type,
            tail_type=tail_type,
        )

    def parse_group(self, grp_elem: ET.Element) -> Optional[GroupModel]:
        nv_grp_pr = grp_elem.find(qn("p", "nvGrpSpPr"))
        c_nv_pr = nv_grp_pr.find(qn("p", "cNvPr")) if nv_grp_pr is not None else None
        if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
            return None
        grp_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        grp_pr = grp_elem.find(qn("p", "grpSpPr"))
        bounds = Rect2D(0, 0, 0, 0)
        ch_off = Point2D(0, 0)
        ch_ext = Point2D(0, 0)
        rot = 0.0
        flip_h = False
        flip_v = False

        if grp_pr is not None:
            xfrm = grp_pr.find(qn("a", "xfrm"))
            if xfrm is not None:
                rot = angle_to_degrees(xfrm.get("rot"))
                flip_h = (xfrm.get("flipH") == "1")
                flip_v = (xfrm.get("flipV") == "1")

                off = xfrm.find(qn("a", "off"))
                ext = xfrm.find(qn("a", "ext"))
                if off is not None and ext is not None:
                    bounds = Rect2D(
                        x=emu_to_pt(int(off.get("x", 0))),
                        y=emu_to_pt(int(off.get("y", 0))),
                        w=emu_to_pt(int(ext.get("cx", 0))),
                        h=emu_to_pt(int(ext.get("cy", 0))),
                    )

                ch_off_elem = xfrm.find(qn("a", "chOff"))
                ch_ext_elem = xfrm.find(qn("a", "chExt"))
                if ch_off_elem is not None:
                    ch_off = Point2D(
                        emu_to_pt(int(ch_off_elem.get("x", 0))),
                        emu_to_pt(int(ch_off_elem.get("y", 0))),
                    )
                if ch_ext_elem is not None:
                    ch_ext = Point2D(
                        emu_to_pt(int(ch_ext_elem.get("cx", 0))),
                        emu_to_pt(int(ch_ext_elem.get("cy", 0))),
                    )

        # Children shapes
        children: List[Any] = []
        for child in grp_elem:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if tag == "sp":
                s = self.parse_shape(child)
                if s:
                    children.append(s)
            elif tag == "pic":
                p = self.parse_picture(child)
                if p:
                    children.append(p)
            elif tag == "cxnSp":
                c = self.parse_connector(child)
                if c:
                    children.append(c)
            elif tag == "grpSp":
                g = self.parse_group(child)
                if g:
                    children.append(g)
            elif tag == "graphicFrame":
                nv_gf_pr = child.find(qn("p", "nvGraphicFramePr"))
                c_nv_pr = nv_gf_pr.find(qn("p", "cNvPr")) if nv_gf_pr is not None else None
                if c_nv_pr is not None and c_nv_pr.get("hidden") == "1":
                    continue
                if child.find(f".//{qn('c', 'chart')}") is not None:
                    from .chart_parser import ChartParser
                    cp = ChartParser(
                        self.package,
                        self.color_engine,
                        default_font=self.text_parser.default_font if self.text_parser else None,
                    )
                    chart = cp.parse_chart_frame(child, self.current_part_path)
                    if chart:
                        children.append(chart)
                elif child.find(f".//{qn('a', 'tbl')}") is not None:
                    from .table_parser import TableParser
                    tp = TableParser(self.package, self.color_engine, self.text_parser)
                    tbl = tp.parse_table_frame(child)
                    if tbl and tbl.bounds.w > 1.0 and tbl.bounds.h > 1.0:
                        children.append(tbl)

        return GroupModel(
            id=grp_id,
            name=name,
            bounds=bounds,
            ch_off=ch_off,
            ch_ext=ch_ext,
            rotation=rot,
            flip_h=flip_h,
            flip_v=flip_v,
            children=children,
        )

    def _parse_transform(self, sp_pr: Optional[ET.Element]) -> Tuple[Rect2D, float, bool, bool]:
        if sp_pr is None:
            return (Rect2D(0, 0, 0, 0), 0.0, False, False)

        xfrm = sp_pr.find(qn("a", "xfrm"))
        if xfrm is None:
            return (Rect2D(0, 0, 0, 0), 0.0, False, False)

        rot = angle_to_degrees(xfrm.get("rot"))
        flip_h = (xfrm.get("flipH") == "1")
        flip_v = (xfrm.get("flipV") == "1")

        off = xfrm.find(qn("a", "off"))
        ext = xfrm.find(qn("a", "ext"))

        x = emu_to_pt(int(off.get("x", 0))) if off is not None else 0.0
        y = emu_to_pt(int(off.get("y", 0))) if off is not None else 0.0
        w = emu_to_pt(int(ext.get("cx", 0))) if ext is not None else 0.0
        h = emu_to_pt(int(ext.get("cy", 0))) if ext is not None else 0.0

        return (Rect2D(x, y, w, h), rot, flip_h, flip_v)

    def _parse_fill(self, sp_pr: Optional[ET.Element]) -> FillModel:
        if sp_pr is None:
            return FillModel(fill_type=FillType.NONE)

        # 1. No Fill: <a:noFill>
        if sp_pr.find(qn("a", "noFill")) is not None:
            return FillModel(fill_type=FillType.NONE)

        # 2. Solid Fill: <a:solidFill>
        solid_fill = sp_pr.find(qn("a", "solidFill"))
        if solid_fill is not None:
            color = self.color_engine.resolve_color_element(solid_fill)
            if color:
                return FillModel(fill_type=FillType.SOLID, color=color)

        # 3. Gradient Fill: <a:gradFill>
        grad_fill = sp_pr.find(qn("a", "gradFill"))
        if grad_fill is not None:
            stops: List[GradientStop] = []
            gs_lst = grad_fill.find(qn("a", "gsLst"))
            if gs_lst is not None:
                for gs in gs_lst.findall(qn("a", "gs")):
                    pos = float(gs.get("pos", 0)) / 100000.0
                    c = self.color_engine.resolve_color_element(gs)
                    if c:
                        stops.append(GradientStop(position=pos, color=c))

            grad_angle = 90.0
            lin = grad_fill.find(qn("a", "lin"))
            if lin is not None and lin.get("ang"):
                grad_angle = angle_to_degrees(lin.get("ang"))

            return FillModel(
                fill_type=FillType.GRADIENT,
                gradient_stops=stops,
                gradient_angle=grad_angle,
            )

        # 4. Blip / Image Fill: <a:blipFill>
        blip_fill = sp_pr.find(qn("a", "blipFill"))
        if blip_fill is not None:
            blip = blip_fill.find(qn("a", "blip"))
            if blip is not None:
                r_id = blip.get(qn("r", "embed"))
                if r_id:
                    target_part = self.package.get_target_by_rid(self.current_part_path, r_id)
                    if target_part:
                        img_data = self.package.get_part_bytes(target_part)
                        return FillModel(fill_type=FillType.BLIP, image_bytes=img_data)

        return FillModel(fill_type=FillType.NONE)

    def _parse_stroke(self, sp_pr: Optional[ET.Element]) -> Optional[StrokeModel]:
        if sp_pr is None:
            return None

        ln = sp_pr.find(qn("a", "ln"))
        if ln is None:
            return None

        if ln.find(qn("a", "noFill")) is not None:
            return None

        # Width in EMUs (default 1 pt if omitted)
        w_attr = ln.get("w")
        width_pt = emu_to_pt(int(w_attr)) if w_attr else 0.75

        # Dash style
        dash_style = StrokeDashStyle.SOLID
        prst_dash = ln.find(qn("a", "prstDash"))
        if prst_dash is not None and prst_dash.get("val"):
            try:
                dash_style = StrokeDashStyle(prst_dash.get("val"))
            except ValueError:
                dash_style = StrokeDashStyle.SOLID

        # Color
        color = self.color_engine.resolve_color_element(ln)
        if color is None:
            solid_fill = ln.find(qn("a", "solidFill"))
            if solid_fill is not None:
                color = self.color_engine.resolve_color_element(solid_fill)

        if color is None:
            color = ColorModel.black()

        return StrokeModel(color=color, width=width_pt, dash_style=dash_style)

    def _parse_shadow(self, sp_pr: Optional[ET.Element]) -> Optional[ShadowModel]:
        if sp_pr is None:
            return None

        effect_lst = sp_pr.find(qn("a", "effectLst"))
        if effect_lst is None:
            return None

        outer_shdw = effect_lst.find(qn("a", "outerShdw"))
        if outer_shdw is None:
            return None

        blur_rad = emu_to_pt(int(outer_shdw.get("blurRad", 0)))
        dist = emu_to_pt(int(outer_shdw.get("dist", 0)))
        dir_deg = angle_to_degrees(outer_shdw.get("dir", 0))

        color = self.color_engine.resolve_color_element(outer_shdw) or ColorModel(0, 0, 0, 0.35)
        return ShadowModel(color=color, blur_rad=blur_rad, dist=dist, dir_deg=dir_deg)

    def _parse_geometry(self, sp_pr: Optional[ET.Element], bounds: Optional[Rect2D] = None) -> Tuple[str, Optional[str], Optional[CustomGeometryModel], Optional[float]]:
        if sp_pr is None:
            return ("rect", None, None, None)

        prst_geom = sp_pr.find(qn("a", "prstGeom"))
        if prst_geom is not None:
            prst_name = prst_geom.get("prst", "rect")
            corner_radius = None
            if prst_name == "roundRect":
                # Check adjustment list: <a:avLst><a:gd name="adj" fmla="val ..."/>
                av_lst = prst_geom.find(qn("a", "avLst"))
                if av_lst is not None:
                    gd = av_lst.find(qn("a", "gd"))
                    if gd is not None:
                        fmla = gd.get("fmla", "")
                        if fmla.startswith("val"):
                            parts = fmla.split()
                            if len(parts) > 1:
                                adj_val = float(parts[1]) / 100000.0
                                ref_dim = min(bounds.w, bounds.h) if bounds and bounds.w > 0 and bounds.h > 0 else 50.0
                                corner_radius = ref_dim * adj_val
                if corner_radius is None:
                    ref_dim = min(bounds.w, bounds.h) if bounds and bounds.w > 0 and bounds.h > 0 else 50.0
                    corner_radius = min(12.0, ref_dim * 0.1)

            return (prst_name, None, None, corner_radius)

        cust_geom = sp_pr.find(qn("a", "custGeom"))
        if cust_geom is not None:
            custom_geom_model = self._parse_custom_geometry(cust_geom)
            return ("custom", "custGeom", custom_geom_model, None)

        return ("rect", None, None, None)

    def _parse_custom_geometry(self, cust_geom: ET.Element) -> Optional[CustomGeometryModel]:
        path_lst = cust_geom.find(qn("a", "pathLst"))
        if path_lst is None:
            return None

        paths: List[CustomGeometryPath] = []
        for path_elem in path_lst.findall(qn("a", "path")):
            w_attr = path_elem.get("w")
            h_attr = path_elem.get("h")
            p_w = float(w_attr) if w_attr else 1.0
            p_h = float(h_attr) if h_attr else 1.0

            subpaths: List[List[Point2D]] = []
            cur_pts: List[Point2D] = []

            for cmd in path_elem:
                c_tag = cmd.tag.split("}")[-1] if "}" in cmd.tag else cmd.tag
                if c_tag == "moveTo":
                    if cur_pts:
                        subpaths.append(cur_pts)
                        cur_pts = []
                    pt = cmd.find(qn("a", "pt"))
                    if pt is not None:
                        x_val = float(pt.get("x", 0))
                        y_val = float(pt.get("y", 0))
                        cur_pts.append(Point2D(x_val, y_val))
                elif c_tag == "lnTo":
                    pt = cmd.find(qn("a", "pt"))
                    if pt is not None:
                        x_val = float(pt.get("x", 0))
                        y_val = float(pt.get("y", 0))
                        cur_pts.append(Point2D(x_val, y_val))
                elif c_tag == "close":
                    if cur_pts:
                        if len(cur_pts) > 1 and cur_pts[0] != cur_pts[-1]:
                            cur_pts.append(Point2D(cur_pts[0].x, cur_pts[0].y))
                        subpaths.append(cur_pts)
                        cur_pts = []

            if cur_pts:
                subpaths.append(cur_pts)

            if subpaths:
                paths.append(CustomGeometryPath(width=p_w, height=p_h, subpaths=subpaths))

        return CustomGeometryModel(paths=paths) if paths else None
