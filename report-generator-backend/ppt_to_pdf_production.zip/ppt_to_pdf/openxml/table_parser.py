"""
DrawingML Table Parser.
Extracts table grids, column widths, row heights, multi-span cells, cell fills, borders, and cell text frames.
"""

import xml.etree.ElementTree as ET
from typing import Optional, List, Tuple
from ..core.models import (
    TableModel,
    TableCellModel,
    Rect2D,
    FillModel,
    FillType,
    StrokeModel,
    StrokeDashStyle,
    ColorModel,
)
from ..utils.units import emu_to_pt
from .constants import NS, qn
from .color_resolver import ColorEngine
from .text_parser import TextParser


class TableParser:
    """
    Parses OpenXML Table definitions (<a:tbl>) within graphic frames.
    """
    def __init__(self, package=None, color_engine: Optional[ColorEngine] = None, text_parser: Optional[TextParser] = None):
        self.package = package
        self.color_engine = color_engine or ColorEngine()
        self.text_parser = text_parser or TextParser(color_engine=self.color_engine)
        self.table_styles = {}
        if package is not None:
            ts_root = package.get_xml_root("ppt/tableStyles.xml")
            if ts_root is not None:
                for ts in ts_root.findall(f".//{qn('a', 'tblStyle')}"):
                    s_id = ts.get("styleId")
                    if s_id:
                        self.table_styles[s_id] = ts

    def parse_table_frame(self, gf_elem: ET.Element) -> Optional[TableModel]:
        # Non-visual properties
        c_nv_pr = gf_elem.find(f".//{qn('p', 'cNvPr')}")
        table_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        # Transform: <p:xfrm>
        xfrm = gf_elem.find(qn("p", "xfrm"))
        bounds = Rect2D(0, 0, 0, 0)
        if xfrm is not None:
            off = xfrm.find(qn("a", "off"))
            ext = xfrm.find(qn("a", "ext"))
            if off is not None and ext is not None:
                bounds = Rect2D(
                    x=emu_to_pt(int(off.get("x", 0))),
                    y=emu_to_pt(int(off.get("y", 0))),
                    w=emu_to_pt(int(ext.get("cx", 0))),
                    h=emu_to_pt(int(ext.get("cy", 0))),
                )

        tbl = gf_elem.find(f".//{qn('a', 'tbl')}")
        if tbl is None:
            return None

        # 1. Grid columns: <a:tblGrid>/<a:gridCol>
        col_widths: List[float] = []
        tbl_grid = tbl.find(qn("a", "tblGrid"))
        if tbl_grid is not None:
            for grid_col in tbl_grid.findall(qn("a", "gridCol")):
                w_emu = int(grid_col.get("w", 0))
                col_widths.append(emu_to_pt(w_emu))

        # Table style & flags
        tbl_pr = tbl.find(qn("a", "tblPr"))
        style_elem = None
        first_row = False
        last_row = False
        first_col = False
        last_col = False
        band_row = False
        band_col = False
        if tbl_pr is not None:
            first_row = (tbl_pr.get("firstRow") == "1")
            last_row = (tbl_pr.get("lastRow") == "1")
            first_col = (tbl_pr.get("firstCol") == "1")
            last_col = (tbl_pr.get("lastCol") == "1")
            band_row = (tbl_pr.get("bandRow") == "1")
            band_col = (tbl_pr.get("bandCol") == "1")
            tbl_style_elem = tbl_pr.find(qn("a", "tableStyleId"))
            if tbl_style_elem is not None and tbl_style_elem.text:
                style_elem = self.table_styles.get(tbl_style_elem.text)

        # 2. Rows: <a:tr>
        row_elems = tbl.findall(qn("a", "tr"))
        num_rows = len(row_elems)
        num_cols = len(col_widths)
        row_heights: List[float] = []
        cells: List[List[TableCellModel]] = []

        for r_idx, tr in enumerate(row_elems):
            h_emu = int(tr.get("h", 0))
            row_heights.append(emu_to_pt(h_emu))

            row_cells: List[TableCellModel] = []
            for c_idx, tc in enumerate(tr.findall(qn("a", "tc"))):
                cell_model = self._parse_cell(
                    tc, r_idx, c_idx, num_rows, num_cols, style_elem,
                    first_row, last_row, first_col, last_col, band_row, band_col
                )
                row_cells.append(cell_model)
            cells.append(row_cells)

        return TableModel(
            id=table_id,
            name=name,
            bounds=bounds,
            col_widths=col_widths,
            row_heights=row_heights,
            cells=cells,
        )

    def _parse_cell(
        self,
        tc: ET.Element,
        row: int,
        col: int,
        num_rows: int = 1,
        num_cols: int = 1,
        style_elem: Optional[ET.Element] = None,
        first_row: bool = False,
        last_row: bool = False,
        first_col: bool = False,
        last_col: bool = False,
        band_row: bool = False,
        band_col: bool = False,
    ) -> TableCellModel:
        grid_span = int(tc.get("gridSpan", 1))
        row_span = int(tc.get("rowSpan", 1))
        h_merge = (tc.get("hMerge") == "1")
        v_merge = (tc.get("vMerge") == "1")
        is_merged_slave = h_merge or v_merge

        tc_pr = tc.find(qn("a", "tcPr"))
        fill = FillModel(fill_type=FillType.NONE)
        border_l = None
        border_t = None
        border_r = None
        border_b = None
        insets = (5.0, 3.0, 5.0, 3.0)

        # Borders
        border_tl_br = None
        border_bl_tr = None
        vert_rotation = "horz"

        horz_overflow = "clip"
        has_explicit_fill = False
        if tc_pr is not None:
            # Margins / padding insets
            # ISO/IEC 29500-1 §21.1.3.16 default cell margins: marL=7.2pt, marT=3.6pt, marR=7.2pt, marB=3.6pt
            mar_l = emu_to_pt(int(tc_pr.get("marL"))) if "marL" in tc_pr.attrib else 7.2
            mar_t = emu_to_pt(int(tc_pr.get("marT"))) if "marT" in tc_pr.attrib else 3.6
            mar_r = emu_to_pt(int(tc_pr.get("marR"))) if "marR" in tc_pr.attrib else 7.2
            mar_b = emu_to_pt(int(tc_pr.get("marB"))) if "marB" in tc_pr.attrib else 3.6
            # Standard DrawingML cell stroke clearance (0.5pt minimum) prevents border collisions
            insets = (max(0.5, mar_l), mar_t, max(0.5, mar_r), mar_b)

            # Direct Fill
            solid_fill = tc_pr.find(qn("a", "solidFill"))
            if solid_fill is not None:
                clr = self.color_engine.resolve_color_element(solid_fill)
                if clr:
                    fill = FillModel(fill_type=FillType.SOLID, color=clr)
                    has_explicit_fill = True
            elif tc_pr.find(qn("a", "noFill")) is not None:
                has_explicit_fill = True

            # Borders
            border_l = self._parse_border(tc_pr.find(qn("a", "lnL")))
            border_t = self._parse_border(tc_pr.find(qn("a", "lnT")))
            border_r = self._parse_border(tc_pr.find(qn("a", "lnR")))
            border_b = self._parse_border(tc_pr.find(qn("a", "lnB")))
            border_tl_br = self._parse_border(tc_pr.find(qn("a", "lnTlToBr")))
            border_bl_tr = self._parse_border(tc_pr.find(qn("a", "lnBlToTr")))

            # Vertical rotation
            vert_rotation = tc_pr.get("vert", "horz")
            horz_overflow = tc_pr.get("horzOverflow", "clip")

        # Fallback to TableStyle background fill if no direct cell fill
        if not has_explicit_fill and style_elem is not None:
            section_names = []
            if row == 0 and first_row:
                section_names.append("firstRow")
            elif row == num_rows - 1 and last_row:
                section_names.append("lastRow")
            if col == 0 and first_col:
                section_names.append("firstCol")
            elif col == num_cols - 1 and last_col:
                section_names.append("lastCol")
            if band_row and (row % 2 == 1):
                section_names.append("band1H")
            elif band_row and (row % 2 == 0):
                section_names.append("band2H")
            if band_col and (col % 2 == 1):
                section_names.append("band1V")
            elif band_col and (col % 2 == 0):
                section_names.append("band2V")
            section_names.append("wholeTbl")

            for sec_name in section_names:
                sec = style_elem.find(qn("a", sec_name))
                if sec is not None:
                    tc_style = sec.find(qn("a", "tcStyle"))
                    if tc_style is not None:
                        fill_container = tc_style.find(qn("a", "fill"))
                        if fill_container is not None:
                            s_fill = fill_container.find(qn("a", "solidFill"))
                            if s_fill is not None:
                                clr = self.color_engine.resolve_color_element(s_fill)
                                if clr and (clr.r < 0.99 or clr.g < 0.99 or clr.b < 0.99):
                                    fill = FillModel(fill_type=FillType.SOLID, color=clr)
                                    break

            # Borders
            border_l = self._parse_border(tc_pr.find(qn("a", "lnL")))
            border_t = self._parse_border(tc_pr.find(qn("a", "lnT")))
            border_r = self._parse_border(tc_pr.find(qn("a", "lnR")))
            border_b = self._parse_border(tc_pr.find(qn("a", "lnB")))
            border_tl_br = self._parse_border(tc_pr.find(qn("a", "lnTlToBr")))
            border_bl_tr = self._parse_border(tc_pr.find(qn("a", "lnBlToTr")))

            # Vertical rotation
            vert_rotation = tc_pr.get("vert", "horz")
            horz_overflow = tc_pr.get("horzOverflow", "clip")

        # Cell Text
        tx_body = tc.find(qn("a", "txBody"))
        text_frame = self.text_parser.parse_text_frame(tx_body)
        if text_frame is not None:
            # Apply cell insets to text frame
            text_frame.insets = insets
            text_frame.vert_rotation = vert_rotation
            # Apply vertical alignment from tcPr anchor
            if tc_pr is not None and "anchor" in tc_pr.attrib:
                anchor_val = tc_pr.get("anchor", "t")
                if anchor_val in ("ctr", "mid"):
                    from ..core.models import VerticalAlign
                    text_frame.vertical_align = VerticalAlign.MIDDLE
                elif anchor_val in ("b", "just"):
                    from ..core.models import VerticalAlign
                    text_frame.vertical_align = VerticalAlign.BOTTOM
                else:
                    from ..core.models import VerticalAlign
                    text_frame.vertical_align = VerticalAlign.TOP


        return TableCellModel(
            row=row,
            col=col,
            row_span=row_span,
            col_span=grid_span,
            is_merged_slave=is_merged_slave,
            fill=fill,
            border_left=border_l,
            border_top=border_t,
            border_right=border_r,
            border_bottom=border_b,
            border_tl_br=border_tl_br,
            border_bl_tr=border_bl_tr,
            text_frame=text_frame,
            insets=insets,
            vert_rotation=vert_rotation,
        )

    def _parse_border(self, ln_elem: Optional[ET.Element]) -> Optional[StrokeModel]:
        if ln_elem is None:
            return None
        if ln_elem.find(qn("a", "noFill")) is not None:
            return None

        w_attr = ln_elem.get("w")
        width_pt = emu_to_pt(int(w_attr)) if w_attr else 0.5

        clr = self.color_engine.resolve_color_element(ln_elem) or ColorModel.from_hex("#D0D0D0")
        return StrokeModel(color=clr, width=width_pt, dash_style=StrokeDashStyle.SOLID)
