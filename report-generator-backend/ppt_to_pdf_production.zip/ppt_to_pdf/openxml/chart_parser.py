"""
OpenXML Chart Parser.
Parses DrawingML chart XML definitions (Bar, Column, Stacked, Line, Pie, Doughnut, Area, Scatter, Bubble, Radar)
supporting Combo Charts, Dual Axes, data labels with number formatting, axis scaling & gridlines, and theme colors.
"""

import xml.etree.ElementTree as ET
from typing import Optional, List, Dict, Tuple, Any
from ..core.models import (
    ChartModel,
    ChartType,
    ChartSeriesGroup,
    ChartDataSeries,
    ChartDataLabel,
    ChartAxisModel,
    Rect2D,
    ColorModel,
)
from ..utils.units import emu_to_pt
from .constants import NS, qn
from .color_resolver import ColorEngine
from .package import PPTXPackage


class ChartParser:
    """
    Parses OpenXML Chart definitions from ppt/charts/chart*.xml.
    """
    def __init__(
        self,
        package: PPTXPackage,
        color_engine: Optional[ColorEngine] = None,
        default_font: Optional[str] = None,
    ):
        self.package = package
        self.color_engine = color_engine or ColorEngine()
        self.default_font = default_font

    def parse_chart_frame(self, gf_elem: ET.Element, current_part_path: str) -> Optional[ChartModel]:
        # Non-visual info
        c_nv_pr = gf_elem.find(f".//{qn('p', 'cNvPr')}")
        chart_id = c_nv_pr.get("id", "") if c_nv_pr is not None else ""
        name = c_nv_pr.get("name", "") if c_nv_pr is not None else ""

        # Transform: <p:xfrm>
        xfrm = gf_elem.find(qn("p", "xfrm"))
        bounds = Rect2D(0, 0, 0, 0)
        if xfrm is not None:
            off = xfrm.find(qn("a", "off"))
            ext = xfrm.find(qn("a", "ext"))
            if off is not None and ext is not None:
                bounds = Rect2D(
                    x=emu_to_pt(int(off.get("x", 0))),
                    y=emu_to_pt(int(off.get("y", 0))),
                    w=emu_to_pt(int(ext.get("cx", 0))),
                    h=emu_to_pt(int(ext.get("cy", 0))),
                )

        # Find chart relationship ID: <c:chart r:id="..."/>
        chart_elem = gf_elem.find(f".//{qn('c', 'chart')}")
        if chart_elem is None:
            return None

        r_id = chart_elem.get(qn("r", "id"))
        if not r_id:
            return None

        chart_part_path = self.package.get_target_by_rid(current_part_path, r_id)
        if not chart_part_path:
            return None

        chart_root = self.package.get_xml_root(chart_part_path)
        if chart_root is None:
            return None

        # Check for themeOverride relationship for this chart
        active_color_engine = self.color_engine
        chart_rels = self.package.get_relationships(chart_part_path)
        for rel_id, rel_data in chart_rels.items():
            rel_type, rel_target = rel_data if isinstance(rel_data, tuple) else ("", rel_data)
            if "themeOverride" in rel_type or "themeOverride" in str(rel_target):
                theme_override_root = self.package.get_xml_root(rel_target)
                if theme_override_root is not None:
                    from .theme import ThemeParser
                    tp = ThemeParser(theme_override_root)
                    active_color_engine = tp.create_color_engine()
                break

        # Apply clrMapOvr if present in chart
        clr_map_ovr = chart_root.find(qn("c", "clrMapOvr"))
        if clr_map_ovr is not None:
            for mapped_attr, target_val in clr_map_ovr.attrib.items():
                if target_val in active_color_engine.scheme_colors:
                    active_color_engine.scheme_colors[mapped_attr.lower()] = active_color_engine.scheme_colors[target_val]
        else:
            if "dk1" in active_color_engine.scheme_colors:
                active_color_engine.scheme_colors["tx1"] = active_color_engine.scheme_colors["dk1"]
            if "lt1" in active_color_engine.scheme_colors:
                active_color_engine.scheme_colors["bg1"] = active_color_engine.scheme_colors["lt1"]
            if "dk2" in active_color_engine.scheme_colors:
                active_color_engine.scheme_colors["tx2"] = active_color_engine.scheme_colors["dk2"]
            if "lt2" in active_color_engine.scheme_colors:
                active_color_engine.scheme_colors["bg2"] = active_color_engine.scheme_colors["lt2"]

        return self._parse_chart_xml(chart_root, chart_id, name, bounds, color_engine=active_color_engine)

    def _parse_chart_xml(
        self,
        chart_root: ET.Element,
        chart_id: str,
        name: str,
        bounds: Rect2D,
        color_engine: Optional[ColorEngine] = None,
    ) -> ChartModel:
        ce = color_engine or self.color_engine

        # Chart space shape properties: <c:chartSpace>/<c:spPr>
        border_color: Optional[ColorModel] = None
        border_width: float = 0.0
        fill_color: Optional[ColorModel] = None

        chart_sp_pr = chart_root.find(qn("c", "spPr"))
        if chart_sp_pr is not None:
            if chart_sp_pr.find(qn("a", "noFill")) is None:
                for fill_tag in ("solidFill", "gradFill", "blipFill"):
                    f_elem = chart_sp_pr.find(qn("a", fill_tag))
                    if f_elem is not None:
                        fill_color = ce.resolve_color_element(f_elem)
                        break
            ln_elem = chart_sp_pr.find(qn("a", "ln"))
            if ln_elem is not None:
                if ln_elem.find(qn("a", "noFill")) is None:
                    w_attr = ln_elem.get("w")
                    border_width = emu_to_pt(int(w_attr)) if w_attr else 0.75
                    border_color = ce.resolve_color_element(ln_elem)

        # Chart title: <c:chart>/<c:title>
        title = ""
        title_font_size = 9.0
        title_font_family: Optional[str] = None
        title_bold: Optional[bool] = None
        title_color = None
        title_elem = chart_root.find(f".//{qn('c', 'title')}")
        if title_elem is not None:
            tx_elem = title_elem.find(f".//{qn('a', 't')}")
            if tx_elem is not None and tx_elem.text:
                title = tx_elem.text
            else:
                runs = title_elem.findall(f".//{qn('a', 'r')}")
                if runs:
                    title = "".join(r.findtext(qn("a", "t"), "") for r in runs)
            # In DrawingML text, <a:rPr> inherits from <a:pPr>/<a:defRPr>
            r_pr = title_elem.find(f".//{qn('a', 'rPr')}")
            def_rpr = title_elem.find(f".//{qn('a', 'defRPr')}")
            for pr in (def_rpr, r_pr):
                if pr is None:
                    continue
                sz = pr.get("sz")
                if sz:
                    try:
                        title_font_size = int(sz) / 100.0
                    except ValueError:
                        pass
                if pr.get("b") in ("1", "true"):
                    title_bold = True
                elif pr.get("b") in ("0", "false"):
                    title_bold = False
                latin = pr.find(qn("a", "latin"))
                if latin is not None and latin.get("typeface"):
                    title_font_family = latin.get("typeface")
                col = ce.resolve_color_element(pr)
                if col:
                    title_color = col

        # Global chart text properties from <c:chartSpace>/<c:txPr>
        global_font_size = 7.0
        global_font_family: Optional[str] = self.default_font
        global_font_color = None
        cs_tx_pr = chart_root.find(qn("c", "txPr"))
        if cs_tx_pr is not None:
            def_rpr = cs_tx_pr.find(f".//{qn('a', 'defRPr')}")
            if def_rpr is not None:
                sz = def_rpr.get("sz")
                if sz:
                    try:
                        global_font_size = int(sz) / 100.0
                    except ValueError:
                        pass
                latin = def_rpr.find(qn("a", "latin"))
                if latin is not None and latin.get("typeface"):
                    global_font_family = latin.get("typeface")
                global_font_color = ce.resolve_color_element(def_rpr)

        # Legend: <c:legend>
        show_legend = True
        legend_pos = "r"
        legend_layout: Optional[Rect2D] = None
        legend_font_size = global_font_size
        legend_font_family: Optional[str] = global_font_family
        legend_font_color: Optional[ColorModel] = global_font_color
        legend_elem = chart_root.find(f".//{qn('c', 'legend')}")
        if legend_elem is not None:
            pos_elem = legend_elem.find(qn("c", "legendPos"))
            if pos_elem is not None:
                legend_pos = pos_elem.get("val", "r")
            leg_manual = legend_elem.find(f"{qn('c', 'layout')}/{qn('c', 'manualLayout')}")
            if leg_manual is not None:
                try:
                    lx = float(leg_manual.find(qn("c", "x")).get("val", 0)) if leg_manual.find(qn("c", "x")) is not None else 0.0
                    ly = float(leg_manual.find(qn("c", "y")).get("val", 0)) if leg_manual.find(qn("c", "y")) is not None else 0.0
                    lw = float(leg_manual.find(qn("c", "w")).get("val", 1)) if leg_manual.find(qn("c", "w")) is not None else 1.0
                    lh = float(leg_manual.find(qn("c", "h")).get("val", 1)) if leg_manual.find(qn("c", "h")) is not None else 1.0
                    legend_layout = Rect2D(x=lx, y=ly, w=lw, h=lh)
                except Exception:
                    pass
            def_rpr = legend_elem.find(f".//{qn('a', 'defRPr')}")
            if def_rpr is not None:
                if def_rpr.get("sz"):
                    try:
                        legend_font_size = int(def_rpr.get("sz")) / 100.0
                    except ValueError:
                        pass
                latin = def_rpr.find(qn("a", "latin"))
                if latin is not None and latin.get("typeface"):
                    legend_font_family = latin.get("typeface")
                legend_font_color = ce.resolve_color_element(def_rpr)
        else:
            show_legend = False

        # Plot Area: <c:plotArea>
        plot_area = chart_root.find(f".//{qn('c', 'plotArea')}")
        if plot_area is None:
            return ChartModel(
                id=chart_id,
                name=name,
                bounds=bounds,
                title=title,
                title_font_size=title_font_size,
                title_font_family=title_font_family or global_font_family,
                title_bold=title_bold,
                title_color=title_color,
                font_family=global_font_family,
                font_size=global_font_size,
                legend_layout=legend_layout,
                legend_font_size=legend_font_size,
                legend_font_family=legend_font_family,
                legend_font_color=legend_font_color,
                border_color=border_color,
                border_width=border_width,
                fill_color=fill_color,
            )

        # Plot Area Manual Layout: <c:layout>/<c:manualLayout>
        plot_layout: Optional[Rect2D] = None
        manual_layout = plot_area.find(f"{qn('c', 'layout')}/{qn('c', 'manualLayout')}")
        if manual_layout is not None:
            try:
                x_val = float(manual_layout.find(qn("c", "x")).get("val", 0)) if manual_layout.find(qn("c", "x")) is not None else 0.0
                y_val = float(manual_layout.find(qn("c", "y")).get("val", 0)) if manual_layout.find(qn("c", "y")) is not None else 0.0
                w_val = float(manual_layout.find(qn("c", "w")).get("val", 1)) if manual_layout.find(qn("c", "w")) is not None else 1.0
                h_val = float(manual_layout.find(qn("c", "h")).get("val", 1)) if manual_layout.find(qn("c", "h")) is not None else 1.0
                plot_layout = Rect2D(x=x_val, y=y_val, w=w_val, h=h_val)
            except Exception:
                pass

        # Parse Axes first so we can associate series with specific axes
        axes: List[ChartAxisModel] = []
        cat_axis: Optional[ChartAxisModel] = None
        val_axis: Optional[ChartAxisModel] = None
        sec_val_axis: Optional[ChartAxisModel] = None

        for child in plot_area:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if tag in ("catAx", "valAx", "dateAx", "serAx"):
                axis_model = self._parse_axis(
                    child,
                    tag,
                    color_engine=ce,
                    default_font_size=global_font_size,
                    default_font_family=global_font_family,
                    default_font_color=global_font_color,
                )
                axes.append(axis_model)
                if tag in ("catAx", "dateAx") and cat_axis is None and not axis_model.is_deleted:
                    cat_axis = axis_model
                elif tag == "valAx" and not axis_model.is_deleted:
                    if val_axis is None:
                        val_axis = axis_model
                    elif sec_val_axis is None:
                        sec_val_axis = axis_model

        # Fallback if all axes were marked deleted
        if cat_axis is None:
            cat_cands = [a for a in axes if a.axis_type in ("cat", "date", "catAx", "dateAx")]
            if cat_cands:
                cat_axis = cat_cands[0]
        if val_axis is None:
            val_cands = [a for a in axes if a.axis_type in ("val", "valAx")]
            if val_cands:
                val_axis = val_cands[0]

        # Extract series from all plot sections
        series_list: List[ChartDataSeries] = []
        categories: List[str] = []
        chart_types_found: List[ChartType] = []
        series_groups: List[ChartSeriesGroup] = []
        gap_width = 150.0
        overlap = 0.0

        for child in plot_area:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if not tag.endswith("Chart"):
                continue

            # Associated axes IDs
            plot_ax_ids = [a.get("val") for a in child.findall(qn("c", "axId")) if a.get("val")]
            uses_sec_axis = False
            if sec_val_axis and not sec_val_axis.is_deleted and sec_val_axis.axis_id in plot_ax_ids:
                uses_sec_axis = True

            grouping = "clustered"
            grp_elem = child.find(qn("c", "grouping"))
            if grp_elem is not None:
                grouping = grp_elem.get("val", "clustered")

            bar_dir = "col"
            dir_elem = child.find(qn("c", "barDir"))
            if dir_elem is not None:
                bar_dir = dir_elem.get("val", "col")

            plot_chart_type = ChartType.COLUMN
            grp_gap_width = 150.0
            grp_overlap = 0.0

            if tag == "barChart":
                if bar_dir == "bar":
                    if grouping == "stacked":
                        plot_chart_type = ChartType.STACKED_BAR
                    elif grouping == "percentStacked":
                        plot_chart_type = ChartType.PERCENT_STACKED_BAR
                    else:
                        plot_chart_type = ChartType.BAR
                else:
                    if grouping == "stacked":
                        plot_chart_type = ChartType.STACKED_COLUMN
                    elif grouping == "percentStacked":
                        plot_chart_type = ChartType.PERCENT_STACKED_COLUMN
                    else:
                        plot_chart_type = ChartType.COLUMN

                gap_elem = child.find(qn("c", "gapWidth"))
                if gap_elem is not None:
                    try:
                        grp_gap_width = float(gap_elem.get("val", 150))
                    except ValueError:
                        pass
                ovlp_elem = child.find(qn("c", "overlap"))
                if ovlp_elem is not None:
                    try:
                        grp_overlap = float(ovlp_elem.get("val", 0))
                    except ValueError:
                        pass

                gap_width = grp_gap_width
                overlap = grp_overlap

            elif tag == "lineChart":
                plot_chart_type = ChartType.LINE
            elif tag == "pieChart":
                plot_chart_type = ChartType.PIE
            elif tag == "doughnutChart":
                plot_chart_type = ChartType.DOUGHNUT
            elif tag == "areaChart":
                plot_chart_type = ChartType.AREA
            elif tag == "scatterChart":
                plot_chart_type = ChartType.SCATTER
            elif tag == "bubbleChart":
                plot_chart_type = ChartType.BUBBLE
            elif tag == "radarChart":
                plot_chart_type = ChartType.RADAR

            chart_types_found.append(plot_chart_type)

            plot_dlbls = child.find(qn("c", "dLbls"))
            default_dlbl = (
                self._parse_data_label_element(
                    plot_dlbls,
                    color_engine=ce,
                    default_font_size=global_font_size,
                    default_font_family=global_font_family,
                )
                if plot_dlbls is not None
                else None
            )

            # Parse Series: <c:ser>
            group_series: List[ChartDataSeries] = []
            for ser in child.findall(qn("c", "ser")):
                ser_data = self._parse_series(
                    ser,
                    plot_chart_type,
                    default_dlbl,
                    color_engine=ce,
                    default_font_size=global_font_size,
                    default_font_family=global_font_family,
                )
                if ser_data:
                    # Filter out empty or broken series (#REF! or zero points)
                    if not ser_data.values and not ser_data.x_values and not ser_data.bubble_sizes:
                        continue
                    if ser_data.name and "#REF!" in ser_data.name:
                        continue
                    ser_data.use_secondary_axis = uses_sec_axis
                    group_series.append(ser_data)
                    series_list.append(ser_data)
                    if not categories and ser_data.categories:
                        categories = ser_data.categories

            series_groups.append(ChartSeriesGroup(
                chart_type=plot_chart_type,
                series_list=group_series,
                is_secondary=uses_sec_axis,
                gap_width=grp_gap_width,
                overlap=grp_overlap,
                grouping=grouping,
                ax_ids=plot_ax_ids,
            ))

        primary_chart_type = chart_types_found[0] if chart_types_found else ChartType.COLUMN
        is_combo = len(chart_types_found) > 1 or len(set(s.chart_type for s in series_list if s.chart_type)) > 1
        # OpenXML standard rule: If chart has <c:title> without explicit text and autoTitleDeleted != 1,
        # single series name becomes the chart title.
        if not title and title_elem is not None and len(series_list) == 1 and series_list[0].name:
            title = series_list[0].name

        return ChartModel(
            id=chart_id,
            name=name,
            bounds=bounds,
            chart_type=primary_chart_type,
            is_combo=is_combo,
            title=title,
            title_font_size=title_font_size,
            title_font_family=title_font_family or global_font_family,
            title_bold=title_bold,
            title_color=title_color,
            font_family=global_font_family,
            font_size=global_font_size,
            series_list=series_list,
            series_groups=series_groups,
            categories=categories,
            axes=axes,
            cat_axis=cat_axis,
            val_axis=val_axis,
            sec_val_axis=sec_val_axis,
            plot_layout=plot_layout,
            gap_width=gap_width,
            overlap=overlap,
            show_legend=show_legend,
            legend_position=legend_pos,
            legend_layout=legend_layout,
            legend_font_size=legend_font_size,
            legend_font_family=legend_font_family,
            legend_font_color=legend_font_color,
            border_color=border_color,
            border_width=border_width,
            fill_color=fill_color,
        )

    def _parse_axis(
        self,
        ax_elem: ET.Element,
        axis_type: str,
        color_engine: Optional[ColorEngine] = None,
        default_font_size: float = 7.0,
        default_font_family: Optional[str] = None,
        default_font_color: Optional[ColorModel] = None,
    ) -> ChartAxisModel:
        ce = color_engine or self.color_engine
        ax_id_elem = ax_elem.find(qn("c", "axId"))
        ax_id = ax_id_elem.get("val", "") if ax_id_elem is not None else ""
        pos_elem = ax_elem.find(qn("c", "axPos"))
        position = pos_elem.get("val", "l") if pos_elem is not None else "l"

        is_deleted = False
        del_elem = ax_elem.find(qn("c", "delete"))
        if del_elem is not None and del_elem.get("val") in ("1", "true"):
            is_deleted = True

        min_val = None
        max_val = None
        log_scale = False
        orientation = "minMax"
        scaling = ax_elem.find(qn("c", "scaling"))
        if scaling is not None:
            orient_elem = scaling.find(qn("c", "orientation"))
            if orient_elem is not None and orient_elem.get("val"):
                orientation = orient_elem.get("val")
            min_elem = scaling.find(qn("c", "min"))
            if min_elem is not None and min_elem.get("val"):
                try:
                    min_val = float(min_elem.get("val"))
                except ValueError:
                    pass
            max_elem = scaling.find(qn("c", "max"))
            if max_elem is not None and max_elem.get("val"):
                try:
                    max_val = float(max_elem.get("val"))
                except ValueError:
                    pass
            log_elem = scaling.find(qn("c", "logBase"))
            if log_elem is not None:
                log_scale = True

        major_unit = None
        unit_elem = ax_elem.find(qn("c", "majorUnit"))
        if unit_elem is not None and unit_elem.get("val"):
            try:
                major_unit = float(unit_elem.get("val"))
            except ValueError:
                pass

        major_time_unit = None
        time_unit_elem = ax_elem.find(qn("c", "majorTimeUnit"))
        if time_unit_elem is not None and time_unit_elem.get("val"):
            major_time_unit = time_unit_elem.get("val")

        base_time_unit = None
        base_unit_elem = ax_elem.find(qn("c", "baseTimeUnit"))
        if base_unit_elem is not None and base_unit_elem.get("val"):
            base_time_unit = base_unit_elem.get("val")

        major_tick_mark = "none"
        tm_elem = ax_elem.find(qn("c", "majorTickMark"))
        if tm_elem is not None and tm_elem.get("val"):
            major_tick_mark = tm_elem.get("val")

        num_fmt = None
        nf_elem = ax_elem.find(qn("c", "numFmt"))
        if nf_elem is not None:
            num_fmt = nf_elem.get("formatCode")

        tick_label_pos = "nextTo"
        tlp_elem = ax_elem.find(qn("c", "tickLblPos"))
        if tlp_elem is not None:
            tick_label_pos = tlp_elem.get("val", "nextTo")

        # Gridlines
        show_major_gridlines = False
        gridline_color = None
        gridline_width = 0.5
        maj_grid = ax_elem.find(qn("c", "majorGridlines"))
        if maj_grid is not None:
            sp_pr = maj_grid.find(qn("c", "spPr"))
            if sp_pr is not None:
                ln = sp_pr.find(qn("a", "ln"))
                if ln is not None:
                    if ln.find(qn("a", "noFill")) is not None:
                        show_major_gridlines = False
                    else:
                        show_major_gridlines = True
                        w = ln.get("w")
                        if w:
                            try:
                                gridline_width = emu_to_pt(int(w))
                            except ValueError:
                                pass
                        gridline_color = ce.resolve_color_element(ln)
                else:
                    show_major_gridlines = True
                    gridline_color = ce.resolve_color_element(sp_pr)
            else:
                show_major_gridlines = True

        axis_line_color = None
        axis_line_width = 0.5
        axis_line_dash = "solid"
        sp_pr = ax_elem.find(qn("c", "spPr"))
        if sp_pr is not None:
            ln = sp_pr.find(qn("a", "ln"))
            if ln is not None:
                if ln.find(qn("a", "noFill")) is not None:
                    axis_line_width = 0.0
                else:
                    w = ln.get("w")
                    if w:
                        try:
                            axis_line_width = emu_to_pt(int(w))
                        except ValueError:
                            pass
                    axis_line_color = ce.resolve_color_element(ln)
                    prst_dash = ln.find(qn("a", "prstDash"))
                    if prst_dash is not None:
                        axis_line_dash = prst_dash.get("val", "solid")

        cross_between = "between"
        cb_elem = ax_elem.find(qn("c", "crossBetween"))
        if cb_elem is not None and cb_elem.get("val"):
            cross_between = cb_elem.get("val")

        font_size = default_font_size
        font_color = default_font_color
        font_family = default_font_family
        label_rotation = 0.0
        tx_pr = ax_elem.find(qn("c", "txPr"))
        if tx_pr is not None:
            body_pr = tx_pr.find(f".//{qn('a', 'bodyPr')}")
            if body_pr is not None and body_pr.get("rot"):
                try:
                    # DrawingML rotation is in 60,000ths of a degree
                    raw_rot = float(body_pr.get("rot")) / 60000.0
                    # Values outside [-360, 360] (such as Office sentinel -60000000 = -1000 deg) denote default/unrotated
                    if -360.0 <= raw_rot <= 360.0:
                        label_rotation = raw_rot
                    else:
                        label_rotation = 0.0
                except ValueError:
                    pass

            def_rpr = tx_pr.find(f".//{qn('a', 'defRPr')}")
            if def_rpr is not None:
                sz = def_rpr.get("sz")
                if sz:
                    try:
                        font_size = int(sz) / 100.0
                    except ValueError:
                        pass
                font_color = ce.resolve_color_element(def_rpr)
                latin = def_rpr.find(qn("a", "latin"))
                if latin is not None and latin.get("typeface"):
                    font_family = latin.get("typeface")

        lbl_offset = 100.0
        lbl_offset_elem = ax_elem.find(qn("c", "lblOffset"))
        if lbl_offset_elem is not None and lbl_offset_elem.get("val"):
            try:
                lbl_offset = float(lbl_offset_elem.get("val"))
            except ValueError:
                pass

        crosses = "autoZero"
        crosses_elem = ax_elem.find(qn("c", "crosses"))
        if crosses_elem is not None and crosses_elem.get("val"):
            crosses = crosses_elem.get("val")

        crosses_at = None
        crosses_at_elem = ax_elem.find(qn("c", "crossesAt"))
        if crosses_at_elem is not None and crosses_at_elem.get("val"):
            try:
                crosses_at = float(crosses_at_elem.get("val"))
            except ValueError:
                pass

        return ChartAxisModel(
            axis_id=ax_id,
            axis_type=axis_type,
            position=position,
            is_deleted=is_deleted,
            min_val=min_val,
            max_val=max_val,
            major_unit=major_unit,
            major_time_unit=major_time_unit,
            base_time_unit=base_time_unit,
            major_tick_mark=major_tick_mark,
            label_rotation=label_rotation,
            cross_between=cross_between,
            orientation=orientation,
            log_scale=log_scale,
            num_fmt=num_fmt,
            tick_label_pos=tick_label_pos,
            show_major_gridlines=show_major_gridlines,
            gridline_color=gridline_color,
            gridline_width=gridline_width,
            axis_line_color=axis_line_color,
            axis_line_width=axis_line_width,
            axis_line_dash=axis_line_dash,
            lbl_offset=lbl_offset,
            font_size=font_size,
            font_color=font_color,
            font_family=font_family,
            crosses=crosses,
            crosses_at=crosses_at,
        )

    def _parse_data_label_element(
        self,
        dlbl_elem: ET.Element,
        color_engine: Optional[ColorEngine] = None,
        default_font_size: float = 7.0,
        default_font_family: Optional[str] = None,
    ) -> ChartDataLabel:
        ce = color_engine or self.color_engine
        show_val = False
        show_cat_name = False
        show_ser_name = False
        show_percent = False
        show_legend_key = False

        sv = dlbl_elem.find(qn("c", "showVal"))
        if sv is not None and sv.get("val") in ("1", "true"):
            show_val = True
        scn = dlbl_elem.find(qn("c", "showCatName"))
        if scn is not None and scn.get("val") in ("1", "true"):
            show_cat_name = True
        ssn = dlbl_elem.find(qn("c", "showSerName"))
        if ssn is not None and ssn.get("val") in ("1", "true"):
            show_ser_name = True
        sp = dlbl_elem.find(qn("c", "showPercent"))
        if sp is not None and sp.get("val") in ("1", "true"):
            show_percent = True
        slk = dlbl_elem.find(qn("c", "showLegendKey"))
        if slk is not None and slk.get("val") in ("1", "true"):
            show_legend_key = True

        num_fmt = ""
        nf = dlbl_elem.find(qn("c", "numFmt"))
        if nf is not None:
            num_fmt = nf.get("formatCode", "")

        pos = "bestFit"
        pos_elem = dlbl_elem.find(qn("c", "dLblPos"))
        if pos_elem is not None:
            pos = pos_elem.get("val", "bestFit")

        font_size = default_font_size
        font_family = default_font_family
        font_color = None
        bold = False

        tx_pr = dlbl_elem.find(qn("c", "txPr"))
        if tx_pr is not None:
            def_rpr = tx_pr.find(f".//{qn('a', 'defRPr')}")
            if def_rpr is not None:
                sz = def_rpr.get("sz")
                if sz:
                    try:
                        font_size = int(sz) / 100.0
                    except ValueError:
                        pass
                font_color = ce.resolve_color_element(def_rpr)
                bold = def_rpr.get("b") in ("1", "true")
                latin = def_rpr.find(qn("a", "latin"))
                if latin is not None and latin.get("typeface"):
                    font_family = latin.get("typeface")

        offset_x = 0.0
        offset_y = 0.0
        ml = dlbl_elem.find(f"{qn('c', 'layout')}/{qn('c', 'manualLayout')}")
        if ml is not None:
            x_elem = ml.find(qn("c", "x"))
            y_elem = ml.find(qn("c", "y"))
            if x_elem is not None and x_elem.get("val"):
                try:
                    offset_x = float(x_elem.get("val"))
                except ValueError:
                    pass
            if y_elem is not None and y_elem.get("val"):
                try:
                    offset_y = float(y_elem.get("val"))
                except ValueError:
                    pass

        custom_text = None
        tx_elem = dlbl_elem.find(qn("c", "tx"))
        if tx_elem is not None:
            rich = tx_elem.find(qn("c", "rich"))
            if rich is not None:
                lines = []
                for p in rich.findall(qn("a", "p")):
                    line_parts = []
                    for ch in p:
                        tag = ch.tag.split("}")[-1]
                        if tag in ("r", "fld"):
                            t = ch.find(qn("a", "t"))
                            if t is not None and t.text:
                                line_parts.append(t.text)
                        elif tag == "br":
                            line_parts.append("\n")
                    if line_parts:
                        lines.append("".join(line_parts))
                if lines:
                    custom_text = "\n".join(lines)
            else:
                v = tx_elem.find(f".//{qn('c', 'v')}")
                if v is not None and v.text:
                    custom_text = v.text

            if font_color is None:
                font_color = ce.resolve_color_element(tx_elem)

        return ChartDataLabel(
            show_val=show_val,
            show_cat_name=show_cat_name,
            show_ser_name=show_ser_name,
            show_percent=show_percent,
            show_legend_key=show_legend_key,
            num_fmt=num_fmt,
            position=pos,
            font_size=font_size,
            font_family=font_family,
            font_color=font_color,
            bold=bold,
            offset_x=offset_x,
            offset_y=offset_y,
            custom_text=custom_text,
        )

    def _parse_series(
        self,
        ser_elem: ET.Element,
        chart_type: ChartType,
        default_dlbl: Optional[ChartDataLabel] = None,
        color_engine: Optional[ColorEngine] = None,
        default_font_size: float = 7.0,
        default_font_family: Optional[str] = None,
    ) -> Optional[ChartDataSeries]:
        ce = color_engine or self.color_engine
        # Series name: <c:tx>
        ser_name = ""
        tx = ser_elem.find(qn("c", "tx"))
        if tx is not None:
            v = tx.find(f".//{qn('c', 'v')}")
            if v is not None and v.text:
                ser_name = v.text
            else:
                t = tx.find(f".//{qn('a', 't')}")
                if t is not None and t.text:
                    ser_name = t.text

        # Series styling from <c:spPr>
        color = None
        border_color = None
        border_width = 1.0
        dash_style = "solid"
        pattern_preset = None
        background_color = None

        sp_pr = ser_elem.find(qn("c", "spPr"))
        if sp_pr is not None:
            patt_fill = sp_pr.find(f".//{qn('a', 'pattFill')}")
            if patt_fill is not None:
                pattern_preset = patt_fill.get("prst", "")
                bg_clr = patt_fill.find(qn("a", "bgClr"))
                fg_clr = patt_fill.find(qn("a", "fgClr"))
                if bg_clr is not None:
                    color = ce.resolve_color_element(bg_clr)
                else:
                    color = ColorModel(1.0, 1.0, 1.0, 1.0)
                if fg_clr is not None:
                    border_color = ce.resolve_color_element(fg_clr)
            else:
                color = ce.resolve_color_element(sp_pr)

            ln = sp_pr.find(qn("a", "ln"))
            if ln is not None:
                if ln.find(qn("a", "noFill")) is not None:
                    border_width = 0.0
                else:
                    w = ln.get("w")
                    if w:
                        try:
                            border_width = emu_to_pt(int(w))
                        except ValueError:
                            pass
                    ln_col = ce.resolve_color_element(ln)
                    if ln_col is not None:
                        border_color = ln_col
                    prst_dash = ln.find(qn("a", "prstDash"))
                    if prst_dash is not None:
                        dash_style = prst_dash.get("val", "solid")

        if color is None and border_color is not None and chart_type == ChartType.LINE:
            color = border_color

        # Marker styling: <c:marker>
        marker_symbol = None
        marker_size = 5.0
        marker_color = None
        marker_elem = ser_elem.find(qn("c", "marker"))
        if marker_elem is not None:
            sym_elem = marker_elem.find(qn("c", "symbol"))
            if sym_elem is not None:
                marker_symbol = sym_elem.get("val", "none")
            sz_elem = marker_elem.find(qn("c", "size"))
            if sz_elem is not None:
                try:
                    marker_size = float(sz_elem.get("val", 5))
                except ValueError:
                    pass
            m_sppr = marker_elem.find(qn("c", "spPr"))
            if m_sppr is not None:
                marker_color = self.color_engine.resolve_color_element(m_sppr)

        # Smooth lines: <c:smooth val="1"/>
        smooth = False
        sm_elem = ser_elem.find(qn("c", "smooth"))
        if sm_elem is not None and sm_elem.get("val") in ("1", "true"):
            smooth = True

        # Custom per-point colors: <c:dPt>
        point_colors: Dict[int, ColorModel] = {}
        for dpt in ser_elem.findall(qn("c", "dPt")):
            idx_elem = dpt.find(qn("c", "idx"))
            if idx_elem is not None:
                try:
                    idx = int(idx_elem.get("val", "0"))
                    dpt_sppr = dpt.find(qn("c", "spPr"))
                    if dpt_sppr is not None:
                        pt_color = self.color_engine.resolve_color_element(dpt_sppr)
                        if pt_color:
                            point_colors[idx] = pt_color
                except ValueError:
                    pass

        # Data Labels: series-level <c:dLbls> and point-level <c:dLbl>
        data_labels: Dict[int, ChartDataLabel] = {}
        series_dlbl = default_dlbl
        ser_dlbls = ser_elem.find(qn("c", "dLbls"))
        if ser_dlbls is not None:
            parsed_ser_dlbl = self._parse_data_label_element(
                ser_dlbls,
                color_engine=ce,
                default_font_size=default_font_size,
                default_font_family=default_font_family,
            )
            series_dlbl = parsed_ser_dlbl

            for dlbl in ser_dlbls.findall(qn("c", "dLbl")):
                idx_elem = dlbl.find(qn("c", "idx"))
                if idx_elem is not None:
                    try:
                        idx = int(idx_elem.get("val", "0"))
                        pt_dlbl = self._parse_data_label_element(
                            dlbl,
                            color_engine=ce,
                            default_font_size=default_font_size,
                            default_font_family=default_font_family,
                        )
                        if not pt_dlbl.num_fmt and series_dlbl and series_dlbl.num_fmt:
                            pt_dlbl.num_fmt = series_dlbl.num_fmt
                        if pt_dlbl.position == "bestFit" and series_dlbl and series_dlbl.position != "bestFit":
                            pt_dlbl.position = series_dlbl.position
                        if pt_dlbl.font_color is None and series_dlbl and series_dlbl.font_color is not None:
                            pt_dlbl.font_color = series_dlbl.font_color
                        if not pt_dlbl.font_family and series_dlbl and series_dlbl.font_family:
                            pt_dlbl.font_family = series_dlbl.font_family
                        if pt_dlbl.font_size == default_font_size and series_dlbl and series_dlbl.font_size != default_font_size:
                            pt_dlbl.font_size = series_dlbl.font_size
                        if not pt_dlbl.bold and series_dlbl and series_dlbl.bold:
                            pt_dlbl.bold = series_dlbl.bold
                        data_labels[idx] = pt_dlbl
                    except ValueError:
                        pass

        # Categories: <c:cat>
        categories: List[str] = []
        cat = ser_elem.find(qn("c", "cat"))
        if cat is not None:
            for pt in cat.findall(f".//{qn('c', 'pt')}"):
                v = pt.find(qn("c", "v"))
                categories.append(v.text if v is not None and v.text else "")

        # Values: <c:val> or <c:yVal>
        values: List[Optional[float]] = []
        val_elem = ser_elem.find(qn("c", "val"))
        if val_elem is None:
            val_elem = ser_elem.find(qn("c", "yVal"))

        if val_elem is not None:
            pts = val_elem.findall(f".//{qn('c', 'pt')}")
            has_idx = any(pt.get("idx") is not None for pt in pts)
            if has_idx:
                max_idx = max((int(pt.get("idx", 0)) for pt in pts if pt.get("idx") is not None), default=0)
                values = [None] * (max_idx + 1)
                for pt in pts:
                    idx_str = pt.get("idx")
                    if idx_str is not None:
                        try:
                            idx = int(idx_str)
                            v = pt.find(qn("c", "v"))
                            if v is not None and v.text is not None and v.text != "#N/A":
                                values[idx] = float(v.text)
                        except (ValueError, IndexError):
                            pass
            else:
                for pt in pts:
                    v = pt.find(qn("c", "v"))
                    if v is not None and v.text is not None and v.text != "#N/A":
                        try:
                            values.append(float(v.text))
                        except ValueError:
                            values.append(None)
                    else:
                        values.append(None)

        # X-Values (scatter/bubble): <c:xVal>
        x_values: List[Optional[float]] = []
        x_elem = ser_elem.find(qn("c", "xVal"))
        if x_elem is not None:
            pts = x_elem.findall(f".//{qn('c', 'pt')}")
            has_idx = any(pt.get("idx") is not None for pt in pts)
            if has_idx:
                max_idx = max((int(pt.get("idx", 0)) for pt in pts if pt.get("idx") is not None), default=0)
                x_values = [None] * (max_idx + 1)
                for pt in pts:
                    idx_str = pt.get("idx")
                    if idx_str is not None:
                        try:
                            idx = int(idx_str)
                            v = pt.find(qn("c", "v"))
                            if v is not None and v.text is not None and v.text != "#N/A":
                                x_values[idx] = float(v.text)
                        except (ValueError, IndexError):
                            pass
            else:
                for pt in pts:
                    v = pt.find(qn("c", "v"))
                    if v is not None and v.text is not None and v.text != "#N/A":
                        try:
                            x_values.append(float(v.text))
                        except ValueError:
                            x_values.append(None)
                    else:
                        x_values.append(None)

        # Bubble Sizes: <c:bubbleSize>
        bubble_sizes: List[Optional[float]] = []
        sz_elem = ser_elem.find(qn("c", "bubbleSize"))
        if sz_elem is not None:
            pts = sz_elem.findall(f".//{qn('c', 'pt')}")
            has_idx = any(pt.get("idx") is not None for pt in pts)
            if has_idx:
                max_idx = max((int(pt.get("idx", 0)) for pt in pts if pt.get("idx") is not None), default=0)
                bubble_sizes = [None] * (max_idx + 1)
                for pt in pts:
                    idx_str = pt.get("idx")
                    if idx_str is not None:
                        try:
                            idx = int(idx_str)
                            v = pt.find(qn("c", "v"))
                            if v is not None and v.text is not None and v.text != "#N/A":
                                bubble_sizes[idx] = float(v.text)
                        except (ValueError, IndexError):
                            pass
            else:
                for pt in pts:
                    v = pt.find(qn("c", "v"))
                    if v is not None and v.text is not None and v.text != "#N/A":
                        try:
                            bubble_sizes.append(float(v.text))
                        except ValueError:
                            bubble_sizes.append(None)
                    else:
                        bubble_sizes.append(None)

        return ChartDataSeries(
            name=ser_name,
            chart_type=chart_type,
            categories=categories,
            values=values,
            x_values=x_values,
            bubble_sizes=bubble_sizes,
            color=color,
            border_color=border_color,
            border_width=border_width,
            dash_style=dash_style,
            marker_symbol=marker_symbol,
            marker_size=marker_size,
            marker_color=marker_color,
            point_colors=point_colors,
            data_labels=data_labels,
            series_data_label=series_dlbl,
            smooth=smooth,
            pattern_preset=pattern_preset,
            background_color=background_color,
        )
