"""
DrawingML Color Resolver Engine.
Resolves srgbClr, schemeClr, sysClr, prstClr and all OpenXML color transforms
(lumMod, lumOff, tint, shade, satMod, alpha, inv, comp).
"""

import colorsys
import xml.etree.ElementTree as ET
from typing import Dict, Optional, Tuple
from ..core.models import ColorModel
from .constants import NS, qn

PRESET_COLORS: Dict[str, str] = {
    "black": "#000000",
    "white": "#FFFFFF",
    "red": "#FF0000",
    "green": "#008000",
    "blue": "#0000FF",
    "yellow": "#FFFF00",
    "cyan": "#00FFFF",
    "magenta": "#FF00FF",
    "gray": "#808080",
    "grey": "#808080",
    "lightGray": "#D3D3D3",
    "darkGray": "#A9A9A9",
    "orange": "#FFA500",
    "purple": "#800080",
    "brown": "#A52A2A",
    "navy": "#000080",
    "teal": "#008080",
    "silver": "#C0C0C0",
    "gold": "#FFD700",
}

SYS_COLORS: Dict[str, str] = {
    "window": "#FFFFFF",
    "windowText": "#000000",
    "windowFrame": "#000000",
    "btnFace": "#F0F0F0",
    "btnText": "#000000",
    "btnHighlight": "#FFFFFF",
    "btnShadow": "#A0A0A0",
    "highlight": "#0078D7",
    "highlightText": "#FFFFFF",
    "hotLight": "#0066CC",
    "infoBk": "#FFFFE1",
    "infoText": "#000000",
    "menu": "#F0F0F0",
    "menuText": "#000000",
    "3dDkShadow": "#696969",
    "3dLight": "#E3E3E3",
    "activeBorder": "#B4B4B4",
    "activeCaption": "#99B4D1",
    "appWorkspace": "#ABABAB",
    "background": "#000000",
    "captionText": "#000000",
    "grayText": "#6D6D6D",
    "inactiveBorder": "#F4F7FC",
    "inactiveCaption": "#BFCDDB",
    "inactiveCaptionText": "#000000",
    "menuBar": "#F0F0F0",
    "menuHighlight": "#0078D7",
    "scrollBar": "#C8C8C8",
}


class ColorEngine:
    """
    Evaluates DrawingML color elements with full support for scheme colors and modifier pipelines.
    """
    def __init__(self, scheme_colors: Optional[Dict[str, ColorModel]] = None):
        self.scheme_colors: Dict[str, ColorModel] = scheme_colors or {
            "dk1": ColorModel.from_hex("#000000"),
            "lt1": ColorModel.from_hex("#FFFFFF"),
            "dk2": ColorModel.from_hex("#1F497D"),
            "lt2": ColorModel.from_hex("#EEECE1"),
            "accent1": ColorModel.from_hex("#4F81BD"),
            "accent2": ColorModel.from_hex("#C0504D"),
            "accent3": ColorModel.from_hex("#9BBB59"),
            "accent4": ColorModel.from_hex("#8064A2"),
            "accent5": ColorModel.from_hex("#4BACC6"),
            "accent6": ColorModel.from_hex("#F79646"),
            "hlink": ColorModel.from_hex("#0000FF"),
            "folHlink": ColorModel.from_hex("#800080"),
            "tx1": ColorModel.from_hex("#000000"),
            "tx2": ColorModel.from_hex("#1F497D"),
            "bg1": ColorModel.from_hex("#FFFFFF"),
            "bg2": ColorModel.from_hex("#EEECE1"),
        }

    def resolve_solid_fill(self, elem: Optional[ET.Element]) -> Optional[ColorModel]:
        """
        Extracts and resolves the solid fill color (<a:solidFill>) from a property container
        without accidentally reading highlight or outline colors.
        """
        if elem is None:
            return None

        tag_name = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        if tag_name == "noFill" or elem.find(qn("a", "noFill")) is not None:
            return None

        solid_fill = elem if tag_name == "solidFill" else elem.find(qn("a", "solidFill"))
        if solid_fill is not None:
            for child in solid_fill:
                c_tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                if c_tag in ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr"):
                    base_color = self._extract_base_color(child, c_tag)
                    if base_color is not None:
                        return self._apply_transforms(base_color, child)
        return None

    def resolve_highlight(self, elem: Optional[ET.Element]) -> Optional[ColorModel]:
        """
        Extracts and resolves the text highlight color (<a:highlight>) from a run property container.
        """
        if elem is None:
            return None

        tag_name = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        highlight = elem if tag_name == "highlight" else elem.find(qn("a", "highlight"))
        if highlight is not None:
            for child in highlight:
                c_tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
                if c_tag in ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr"):
                    base_color = self._extract_base_color(child, c_tag)
                    if base_color is not None:
                        return self._apply_transforms(base_color, child)
        return None

    def resolve_line_color(self, elem: Optional[ET.Element]) -> Optional[ColorModel]:
        """
        Extracts and resolves the line/outline color (<a:ln>) from a shape or run property container.
        """
        if elem is None:
            return None

        tag_name = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
        ln_elem = elem if tag_name == "ln" else elem.find(qn("a", "ln"))
        if ln_elem is not None:
            return self.resolve_solid_fill(ln_elem) or self.resolve_color_element(ln_elem)
        return None

    def resolve_color_element(self, color_elem: Optional[ET.Element]) -> Optional[ColorModel]:
        """
        Parses any DrawingML color container element (e.g. <a:solidFill>, <a:srgbClr>, <a:schemeClr>, etc.)
        and returns a fully resolved ColorModel.
        """
        if color_elem is None:
            return None

        # Check if color_elem itself is a direct color tag
        tag_name = color_elem.tag.split("}")[-1] if "}" in color_elem.tag else color_elem.tag
        if tag_name in ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr"):
            base_color = self._extract_base_color(color_elem, tag_name)
            if base_color is not None:
                return self._apply_transforms(base_color, color_elem)
            return None

        # Check for noFill explicitly
        if color_elem.find(qn("a", "noFill")) is not None or tag_name == "noFill":
            return None

        # Check for direct solidFill first
        sf = self.resolve_solid_fill(color_elem)
        if sf is not None:
            return sf

        # Search for direct color children (ignoring nested highlight/effects)
        for target in color_elem:
            c_tag = target.tag.split("}")[-1] if "}" in target.tag else target.tag
            if c_tag in ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr"):
                base_color = self._extract_base_color(target, c_tag)
                if base_color is not None:
                    return self._apply_transforms(base_color, target)

        # Fallback for deep structures (like gradient stops, shadows), skipping highlight
        for target in color_elem.iter():
            if "highlight" in target.tag:
                continue
            c_tag = target.tag.split("}")[-1] if "}" in target.tag else target.tag
            if c_tag in ("srgbClr", "schemeClr", "sysClr", "prstClr", "scrgbClr", "hslClr"):
                base_color = self._extract_base_color(target, c_tag)
                if base_color is not None:
                    return self._apply_transforms(base_color, target)

        return None

    def _extract_base_color(self, elem: ET.Element, tag_name: str) -> Optional[ColorModel]:
        val = elem.get("val", "")

        if tag_name == "srgbClr":
            if val:
                return ColorModel.from_hex(val)
        elif tag_name == "schemeClr":
            # Map scheme color key
            key = val.lower()
            if key in self.scheme_colors:
                c = self.scheme_colors[key]
                return ColorModel(c.r, c.g, c.b, c.a)
            # Map tx/bg aliases
            if key in ("tx1", "tx2", "bg1", "bg2"):
                mapped = {"tx1": "dk1", "tx2": "dk2", "bg1": "lt1", "bg2": "lt2"}.get(key, "dk1")
                if mapped in self.scheme_colors:
                    c = self.scheme_colors[mapped]
                    return ColorModel(c.r, c.g, c.b, c.a)
            # Default fallback for unknown scheme color
            return ColorModel.from_hex("#333333")
        elif tag_name == "sysClr":
            last_clr = elem.get("lastClr")
            if last_clr:
                return ColorModel.from_hex(last_clr)
            if val in SYS_COLORS:
                return ColorModel.from_hex(SYS_COLORS[val])
            return ColorModel.black()
        elif tag_name == "prstClr":
            if val in PRESET_COLORS:
                return ColorModel.from_hex(PRESET_COLORS[val])
            return ColorModel.black()
        elif tag_name == "scrgbClr":
            r = int(elem.get("r", 0)) / 100000.0
            g = int(elem.get("g", 0)) / 100000.0
            b = int(elem.get("b", 0)) / 100000.0
            return ColorModel(max(0.0, min(1.0, r)), max(0.0, min(1.0, g)), max(0.0, min(1.0, b)), 1.0)
        elif tag_name == "hslClr":
            hue = int(elem.get("hue", 0)) / 60000.0 / 360.0
            sat = int(elem.get("sat", 0)) / 100000.0
            lum = int(elem.get("lum", 0)) / 100000.0
            rgb = colorsys.hls_to_rgb(hue, lum, sat)
            return ColorModel(rgb[0], rgb[1], rgb[2], 1.0)

        return None

    def _apply_transforms(self, color: ColorModel, elem: ET.Element) -> ColorModel:
        r, g, b, a = color.r, color.g, color.b, color.a

        for child in elem:
            t_tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            t_val = child.get("val")

            if t_tag == "alpha":
                if t_val:
                    a = float(t_val) / 100000.0
            elif t_tag == "lumMod":
                # Multiplies HLS Luminance by lumMod %
                if t_val:
                    mod = float(t_val) / 100000.0
                    h, l, s = colorsys.rgb_to_hls(r, g, b)
                    l = max(0.0, min(1.0, l * mod))
                    r, g, b = colorsys.hls_to_rgb(h, l, s)
            elif t_tag == "lumOff":
                # Offsets HLS Luminance by lumOff %
                if t_val:
                    off = float(t_val) / 100000.0
                    h, l, s = colorsys.rgb_to_hls(r, g, b)
                    l = max(0.0, min(1.0, l + off))
                    r, g, b = colorsys.hls_to_rgb(h, l, s)
            elif t_tag == "tint":
                # Tint: blends towards white (1.0) in linear space, with standard sRGB gamma compensation
                if t_val:
                    tint = float(t_val) / 100000.0
                    r_lin = r * tint + (1.0 - tint)
                    g_lin = g * tint + (1.0 - tint)
                    b_lin = b * tint + (1.0 - tint)
                    r = (r_lin ** (1.0 / 2.2)) if r_lin > 0 else 0.0
                    g = (g_lin ** (1.0 / 2.2)) if g_lin > 0 else 0.0
                    b = (b_lin ** (1.0 / 2.2)) if b_lin > 0 else 0.0
            elif t_tag == "shade":
                # Shade: blends towards black (0.0)
                if t_val:
                    shade = float(t_val) / 100000.0
                    r = r * shade
                    g = g * shade
                    b = b * shade
            elif t_tag == "satMod":
                if t_val:
                    s_mod = float(t_val) / 100000.0
                    h, l, s = colorsys.rgb_to_hls(r, g, b)
                    s = max(0.0, min(1.0, s * s_mod))
                    r, g, b = colorsys.hls_to_rgb(h, l, s)
            elif t_tag == "inv":
                r, g, b = 1.0 - r, 1.0 - g, 1.0 - b

        return ColorModel(
            max(0.0, min(1.0, r)),
            max(0.0, min(1.0, g)),
            max(0.0, min(1.0, b)),
            max(0.0, min(1.0, a)),
        )
