"""
Test suite for PPT to PDF conversion engine.
"""

import os
import unittest
from pathlib import Path
import pymupdf
from ppt_to_pdf import PPT2PDFConverter, ConversionConfig, convert


class TestPPT2PDFConverter(unittest.TestCase):
    def setUp(self):
        self.sample_pptx = Path("sample_ppt.pptx")
        self.output_pdf = Path("test_output.pdf")

    def tearDown(self):
        if self.output_pdf.exists():
            try:
                self.output_pdf.unlink()
            except Exception:
                pass

    def test_slide_slice_conversion(self):
        """Test converting a slice of slides (1-3) to PDF."""
        if not self.sample_pptx.exists():
            self.skipTest("sample_ppt.pptx not found")

        converter = PPT2PDFConverter(config=ConversionConfig(slide_selection="1-3", dpi=150))
        converter.convert(self.sample_pptx, self.output_pdf)

        self.assertTrue(self.output_pdf.exists(), "Output PDF file was not created.")
        self.assertGreater(self.output_pdf.stat().st_size, 1000, "Output PDF is too small or empty.")

        # Open with PyMuPDF to inspect page count and dimensions
        doc = pymupdf.open(str(self.output_pdf))
        self.assertEqual(len(doc), 3, f"Expected 3 pages in PDF, got {len(doc)}")
        doc.close()

    def test_in_memory_bytes_conversion(self):
        """Test in-memory bytes conversion."""
        if not self.sample_pptx.exists():
            self.skipTest("sample_ppt.pptx not found")

        raw_bytes = self.sample_pptx.read_bytes()
        converter = PPT2PDFConverter(config=ConversionConfig(slide_selection="1", dpi=150))
        pdf_bytes = converter.convert_bytes(raw_bytes)

    def test_presentation_dom_and_context_manager(self):
        """Test Presentation DOM inspection and save() method."""
        if not self.sample_pptx.exists():
            self.skipTest("sample_ppt.pptx not found")

        from ppt_to_pdf import Presentation
        with Presentation(self.sample_pptx) as prs:
            self.assertEqual(prs.slide_count, 58)
            # Inspect first slide
            first_slide = prs.slides[0]
            self.assertEqual(first_slide.slide_number, 1)
            self.assertGreater(len(first_slide.shapes), 0)

    def test_threaded_parallel_conversion(self):
        """Test multi-threaded parallel conversion of slides."""
        if not self.sample_pptx.exists():
            self.skipTest("sample_ppt.pptx not found")

        converter = PPT2PDFConverter(config=ConversionConfig(slide_selection="1-6", workers=4, dpi=150))
        converter.convert(self.sample_pptx, self.output_pdf)

        self.assertTrue(self.output_pdf.exists())
        doc = pymupdf.open(str(self.output_pdf))
        self.assertEqual(len(doc), 6)
        doc.close()

    def test_table_dimensions_and_single_line_euro_figures(self):
        """Test that tables preserve exact XML grid column widths and row heights."""
        if not self.sample_pptx.exists():
            self.skipTest("sample_ppt.pptx not found")

        from ppt_to_pdf import Presentation
        with Presentation(self.sample_pptx) as prs:
            # Check slide 5 and slide 8 table models have parsed grid dimensions
            slide5 = prs.slides[4]
            slide8 = prs.slides[7]
            tbl5 = [s for s in slide5.shapes if getattr(s, "cells", None)][0]
            tbl8 = [s for s in slide8.shapes if getattr(s, "cells", None)][0]

            # Verify grid dimensions are non-empty and match expected column/row counts
            self.assertTrue(len(tbl5.col_widths) > 0)
            self.assertTrue(len(tbl5.row_heights) > 0)
            self.assertTrue(len(tbl8.col_widths) > 0)
            self.assertTrue(len(tbl8.row_heights) > 0)

            # Verify exact col_widths sum matches grid (within pt rounding)
            self.assertAlmostEqual(sum(tbl8.col_widths), 370.4, delta=1.0)
            # Verify slide 8 has 7 columns and 13 rows
            self.assertEqual(len(tbl8.col_widths), 7)
            self.assertEqual(len(tbl8.row_heights), 13)

        # Convert slide 8 and verify text is rendered
        converter = PPT2PDFConverter(config=ConversionConfig(slide_selection="8", dpi=150))
        converter.convert(self.sample_pptx, self.output_pdf)
        doc = pymupdf.open(str(self.output_pdf))
        page = doc[0]
        full_text = page.get_text().replace("\xa0", " ").replace("\xad", "-").replace("\u2010", "-")
        # Verify key content is present
        self.assertIn("Unless stated otherwise", full_text)
        self.assertIn("Non-IG ratio", full_text)
        self.assertIn("10.6%", full_text)

        self.assertIn("10.6%", full_text)

        doc.close()



if __name__ == "__main__":
    unittest.main()
