"""
Decoupled Glyph and Unicode Decoding Engine.
Handles sanitization, normalization, legacy symbol/wingdings PUA glyph remapping,
and fallback font determination for universal vector PDF rendering.
"""

from typing import Tuple, Optional, Dict

# Comprehensive Wingdings / Webdings / Symbol legacy character mapping to universal Unicode glyphs
SYMBOL_GLYPH_MAP: Dict[int, str] = {
    # Bullets & Shapes
    0x6E: "■",    # U+25A0 Black square
    0xF06E: "■",
    0x6F: "○",    # U+25CB White circle
    0xF06F: "○",
    0x70: "▼",    # U+25BC Black down-pointing triangle
    0xF070: "▼",
    0x71: "❑",    # U+274F Lower right drop-shadowed white square
    0xF071: "❑",
    0x75: "▲",    # U+25B2 Black up-pointing triangle
    0xF075: "▲",
    0x76: "❖",    # U+2756 Black diamond minus white X
    0xF076: "❖",
    0x77: "⬡",    # U+2B21 White hexagon
    0xF077: "⬡",
    0x78: "⬢",    # U+2B22 Black hexagon
    0xF078: "⬢",
    0xA1: "●",    # U+25CF Black circle
    0xF0A1: "●",
    0xA7: "▪",    # U+25AA Black small square
    0xF0A7: "▪",
    0xA8: "◻",    # U+25FB White square
    0xF0A8: "◻",
    0xB7: "•",    # U+2022 Bullet
    0xF0B7: "•",
    0xB0: "°",    # Degree
    0xF0B0: "°",

    # Chevrons & Arrows
    0xD8: "›",    # U+203A Single right-pointing angle quote
    0xF0D8: "›",
    0xDE: "➔",    # U+2794 Heavy wide-headed rightwards arrow
    0xF0DE: "➔",
    0xE9: "➔",    # Right arrow
    0xF0E9: "➔",
    0xEA: "⬅",    # Left arrow
    0xF0EA: "⬅",
    0xEB: "⬆",    # Up arrow
    0xF0EB: "⬆",
    0xEC: "⬇",    # Down arrow
    0xF0EC: "⬇",
    0xED: "⬈",    # North east arrow
    0xF0ED: "⬈",
    0xEE: "⬊",    # South east arrow
    0xF0EE: "⬊",
    0xF1: "›",    # Right chevron
    0xF0F1: "›",
    0xD9: "‹",    # Left chevron
    0xF0D9: "‹",

    # Status / Indicators / Checks
    0xFC: "✔",    # U+2714 Heavy checkmark
    0xF0FC: "✔",
    0xFB: "✗",    # U+2717 Heavy ballot X
    0xF0FB: "✗",
    0xBF: "✔",    # Checkmark
    0xF0BF: "✔",
    0x2D: "–",    # En dash
    0xF02D: "–",
    0x7E: "≈",    # Almost equal
    0xF07E: "≈",
    0xB9: "≠",    # Not equal
    0xF0B9: "≠",
    0xA3: "≤",    # Less-than or equal
    0xF0A3: "≤",
    0xB3: "≥",    # Greater-than or equal
    0xF0B3: "≥",
    0x44: "Δ",    # Greek capital Delta
    0xF044: "Δ",
    0x6D: "μ",    # Greek small mu
    0xF06D: "μ",
    0x70: "π",    # Greek pi (in Symbol font)
}

# Windows-1252 control / extended character mappings
WIN1252_CONTROL_MAP: Dict[int, str] = {
    0x82: "‚",
    0x84: "„",
    0x85: "…",
    0x86: "†",
    0x87: "‡",
    0x88: "ˆ",
    0x89: "‰",
    0x8A: "Š",
    0x8B: "‹",
    0x8C: "Œ",
    0x91: "‘",
    0x92: "’",
    0x93: "“",
    0x94: "”",
    0x95: "•",
    0x96: "–",
    0x97: "—",
    0x98: " ",  # Small tilde / legacy marker in PPT -> normalize to space
    0x99: "™",
    0x9A: "š",
    0x9B: "›",
    0x9C: "œ",
    0x9F: "Ÿ",
    0xA0: " ",  # Non-breaking space
    0xAD: "",   # Soft hyphen
    0x200B: "", # Zero-width space
    0x200C: "", # Zero-width non-joiner
    0x200D: "", # Zero-width joiner
    0x200E: "", # Left-to-right mark
    0x200F: "", # Right-to-left mark
    0x2003: " ", # Em space
    0x2002: " ", # En space
    0x2009: " ", # Thin space
}


class GlyphEngine:
    """
    Decoupled engine for sanitizing text runs, mapping legacy symbol/wingdings glyphs,
    and resolving appropriate unicode-compatible vector fonts.
    """

    @staticmethod
    def is_symbol_font(font_name: Optional[str]) -> bool:
        """Checks if font family is a legacy symbol/dingbat font."""
        if not font_name:
            return False
        fn = font_name.lower()
        return any(s in fn for s in ("wingdings", "webdings", "symbol", "marlett", "dingbats"))

    @classmethod
    def sanitize_text(cls, text: str) -> str:
        """
        Strips invisible zero-width characters and normalizes control characters.
        """
        if not text:
            return ""
        
        out = []
        for ch in text:
            code = ord(ch)
            if code in WIN1252_CONTROL_MAP:
                out.append(WIN1252_CONTROL_MAP[code])
            elif 0x00 <= code < 0x20 and code not in (0x09, 0x0A, 0x0D):
                # Ignore ASCII control codes (except tab, newline, CR)
                continue
            elif 0x7F <= code <= 0x9F and code in WIN1252_CONTROL_MAP:
                out.append(WIN1252_CONTROL_MAP[code])
            else:
                out.append(ch)
        return "".join(out)

    @classmethod
    def decode_glyph_run(cls, text: str, font_family: Optional[str]) -> Tuple[str, Optional[str]]:
        """
        Decodes a text run, transforming any symbol font characters or PUA codepoints
        into universal Unicode characters with compatible font fallback.

        :param text: Raw text from OpenXML <a:t> or <a:sym>
        :param font_family: Declared font family
        :return: (decoded_text, resolved_font_family)
        """
        if not text:
            return ("", font_family)

        is_sym = cls.is_symbol_font(font_family)
        has_symbol_conversion = False
        decoded_chars = []

        for ch in text:
            code = ord(ch)

            # 1. PUA legacy symbol ranges (0xF000..0xF0FF)
            if 0xF000 <= code <= 0xF0FF:
                low_byte = code - 0xF000
                if code in SYMBOL_GLYPH_MAP:
                    decoded_chars.append(SYMBOL_GLYPH_MAP[code])
                    has_symbol_conversion = True
                elif low_byte in SYMBOL_GLYPH_MAP:
                    decoded_chars.append(SYMBOL_GLYPH_MAP[low_byte])
                    has_symbol_conversion = True
                else:
                    decoded_chars.append(ch)
            # 2. Declared symbol/wingdings font with 7-bit / 8-bit characters
            elif is_sym:
                if code in SYMBOL_GLYPH_MAP:
                    decoded_chars.append(SYMBOL_GLYPH_MAP[code])
                    has_symbol_conversion = True
                else:
                    low_byte = code & 0xFF
                    if low_byte in SYMBOL_GLYPH_MAP:
                        decoded_chars.append(SYMBOL_GLYPH_MAP[low_byte])
                        has_symbol_conversion = True
                    elif ch == "o":
                        decoded_chars.append("○")
                        has_symbol_conversion = True
                    elif ch == "q":
                        decoded_chars.append("❑")
                        has_symbol_conversion = True
                    elif ch in ("v", "u"):
                        decoded_chars.append("❖")
                        has_symbol_conversion = True
                    elif ch in ("-", "–", "—"):
                        decoded_chars.append("–")
                        has_symbol_conversion = True
                    elif ch == "p":
                        decoded_chars.append("▼")
                        has_symbol_conversion = True
                    elif ch == "t":
                        decoded_chars.append("▲")
                        has_symbol_conversion = True
                    elif ch == "u":
                        decoded_chars.append("▲")
                        has_symbol_conversion = True
                    else:
                        decoded_chars.append(ch)
            # 3. Control code sanitization
            elif code in WIN1252_CONTROL_MAP:
                decoded_chars.append(WIN1252_CONTROL_MAP[code])
            else:
                decoded_chars.append(ch)

        decoded_text = "".join(decoded_chars)

        # If we converted legacy symbols to universal Unicode, switch font from Wingdings/Symbol
        # to a standard universal font (Arial/Calibri/Segoe UI) so the PDF engine renders it without rectangles
        resolved_font = font_family
        if has_symbol_conversion and is_sym:
            resolved_font = "Segoe UI" if "segoe" in (font_family or "").lower() else "Arial"

        return (decoded_text, resolved_font)

    @classmethod
    def map_bullet_character(cls, char_val: str, font_name: Optional[str]) -> Tuple[str, Optional[str]]:
        """
        Maps a single bullet point character to a standard Unicode glyph and font.
        """
        if not char_val:
            return ("", font_name)
        return cls.decode_glyph_run(char_val, font_name)
