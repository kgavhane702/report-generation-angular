"""
Cross-platform Font Manager.
Discovers and caches system fonts across Windows, macOS, and Linux.
Resolves font family names and styles (regular, bold, italic, bold-italic) to exact TTF/OTF font paths.
"""

import os
import sys
import threading
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from ..utils.logger import get_logger

logger = get_logger(__name__)


class FontManager:
    """
    Manages font discovery, font aliases, and font file resolution across platforms.
    Thread-safe implementation.
    """
    def __init__(self, additional_dirs: Optional[List[Union[str, Path]]] = None, fallback_font: str = "Arial"):
        self.fallback_font_name = fallback_font
        self._font_cache: Dict[str, str] = {}  # normalized_key -> font_file_path
        self._system_scanned = False
        self._additional_dirs = additional_dirs or []
        self._lock = threading.Lock()
        self._scan_system_fonts()

    def _scan_system_fonts(self) -> None:
        if self._system_scanned:
            return

        font_dirs: List[Path] = []

        # Windows
        if sys.platform.startswith("win"):
            win_dir = os.environ.get("WINDIR", "C:\\Windows")
            font_dirs.append(Path(win_dir) / "Fonts")
            local_app_data = os.environ.get("LOCALAPPDATA")
            if local_app_data:
                font_dirs.append(Path(local_app_data) / "Microsoft" / "Windows" / "Fonts")

        # macOS
        elif sys.platform == "darwin":
            font_dirs.extend([
                Path("/System/Library/Fonts"),
                Path("/Library/Fonts"),
                Path.home() / "Library" / "Fonts",
            ])

        # Linux / Unix
        else:
            font_dirs.extend([
                Path("/usr/share/fonts"),
                Path("/usr/local/share/fonts"),
                Path.home() / ".fonts",
                Path.home() / ".local" / "share" / "fonts",
            ])

        # Additional user-specified directories
        for d in self._additional_dirs:
            p = Path(d)
            if p.exists() and p.is_dir():
                font_dirs.append(p)

        # Scan directories
        for f_dir in font_dirs:
            if not f_dir.exists():
                continue
            try:
                for root, _, files in os.walk(f_dir):
                    for file in files:
                        ext = file.lower().split(".")[-1]
                        if ext in ("ttf", "otf", "ttc"):
                            full_path = str(Path(root) / file)
                            self._index_font_file(file, full_path)
            except Exception as e:
                logger.debug(f"Error scanning font dir {f_dir}: {e}")

        self._system_scanned = True

    def _index_font_file(self, filename: str, full_path: str) -> None:
        base = filename.lower().replace(" ", "").replace("-", "").replace("_", "")
        name_only = base.split(".")[0]
        with self._lock:
            self._font_cache[name_only] = full_path

    def resolve_font_path(
        self,
        family: str,
        bold: bool = False,
        italic: bool = False,
    ) -> Optional[str]:
        """
        Resolves a font family and style to an on-disk font file path (.ttf/.otf).
        """
        import re
        # Strip parenthetical annotations like (Body), (Headings), (Theme)
        raw_clean = re.sub(r"[\(\[\{].*?[\)\]\}]", "", family).strip()
        clean_family = raw_clean.lower().replace(" ", "").replace("-", "").replace("_", "").replace("+", "")
        if clean_family in ("mnlt", "minorfont", "mjlt", "majorfont", "theme"):
            clean_family = "calibri"

        style_suffixes = []
        if bold and italic:
            style_suffixes = ["bolditalic", "bi", "boldoblique", "z", "bdi", "b"]
        elif bold:
            style_suffixes = ["bold", "bd", "b", "black", "heavy", "medium"]
        elif italic:
            style_suffixes = ["italic", "it", "i", "oblique"]
        else:
            style_suffixes = ["regular", "reg", "r", "book", "roman", ""]

        with self._lock:
            for s in style_suffixes:
                key = f"{clean_family}{s}"
                if key in self._font_cache:
                    return self._font_cache[key]

            if clean_family in self._font_cache:
                return self._font_cache[clean_family]

            alias_map = {
                "deutschebanktext": ["calibri", "arial", "liberationsans"],
                "deutschebank": ["calibri", "arial", "liberationsans"],
                "deutschebankdisplay": ["calibri", "arial", "liberationsans"],
                "mnlt": ["calibri", "arial"],
                "mjlt": ["calibri", "arial"],
                "corporatesans": ["calibri", "arial"],
                "din": ["calibri", "arial"],
                "helveticaneue": ["arial", "liberationsans"],
                "helveticaneuelight": ["arial", "calibrilight"],
                "calibri": ["arial", "liberationsans", "dejavusans", "freesans"],
                "calibrilight": ["arial", "liberationsans", "dejavusans"],
                "segoeui": ["calibri", "arial", "tahoma", "liberationsans"],
                "timesnewroman": ["times", "liberationserif", "dejavuserif"],
                "helvetica": ["arial", "liberationsans"],
                "wingdings2": ["wingdng2"],
                "wingdings3": ["wingdng3"],
                "wingdings": ["wingding"],
                "symbol": ["symbol"],
                "webdings": ["webdings"],
            }


            if clean_family in alias_map:
                for alias in alias_map[clean_family]:
                    for s in style_suffixes:
                        a_key = f"{alias}{s}"
                        if a_key in self._font_cache:
                            return self._font_cache[a_key]
                    if alias in self._font_cache:
                        return self._font_cache[alias]

            fallback_clean = self.fallback_font_name.lower().replace(" ", "")
            for s in style_suffixes:
                f_key = f"{fallback_clean}{s}"
                if f_key in self._font_cache:
                    return self._font_cache[f_key]
            if fallback_clean in self._font_cache:
                return self._font_cache[fallback_clean]

            if self._font_cache:
                return next(iter(self._font_cache.values()))

        return None
