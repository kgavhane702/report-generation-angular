"""
Text Layouter and Word Wrapping Engine.
Breaks paragraphs and multi-font runs into formatted lines with accurate positioning,
bullet offsets, hanging indents, and vertical alignments.

Architecture:
- Run-level width measurement captures proper kerning within each run
- Two-pass word wrap: detect wrap points, then re-measure full line fragments
- Font-metric-based baseline and line height calculations (no hardcoded multipliers)
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from ..core.models import (
    TextBoxModel,
    ParagraphModel,
    RunModel,
    HorizontalAlign,
    VerticalAlign,
    ColorModel,
    Rect2D,
    Point2D,
)
from .font_metrics import FontMetrics


@dataclass
class LayoutFragment:
    """A segment of text in a single line with uniform font, size, and color."""
    text: str
    font_family: str
    font_size: float
    color: ColorModel
    bold: bool
    italic: bool
    underline: bool
    strikethrough: bool
    width: float
    x_offset: float  # Relative to line start
    baseline_offset: float = 0.0
    character_spacing: float = 0.0
    highlight_color: Optional[ColorModel] = None


@dataclass
class LayoutLine:
    """A single rendered line of text."""
    fragments: List[LayoutFragment] = field(default_factory=list)
    x: float = 0.0
    y: float = 0.0  # Baseline Y
    width: float = 0.0
    height: float = 14.0
    bullet_text: Optional[str] = None
    bullet_font: Optional[str] = None
    bullet_color: Optional[ColorModel] = None
    bullet_size: float = 12.0
    bullet_x: float = 0.0


@dataclass
class LayoutBlock:
    """Computed layout of a full text frame."""
    lines: List[LayoutLine] = field(default_factory=list)
    total_height: float = 0.0


class TextLayouter:
    """
    Computes visual layout lines for a TextBoxModel within a given bounding rectangle.
    Uses font-metric-accurate measurements for all text positioning.
    """
    def __init__(self, font_metrics: Optional[FontMetrics] = None):
        self.font_metrics = font_metrics or FontMetrics()

    def layout_text_frame(self, text_box: TextBoxModel, bounds: Rect2D) -> LayoutBlock:
        l_ins, t_ins, r_ins, b_ins = text_box.insets
        is_vertical = text_box.vert_rotation in ("vert270", "vert")

        # When insets are explicitly 0, honor them as 0 (no magic fallback values)
        effective_r_ins = r_ins
        effective_l_ins = l_ins

        if is_vertical:
            avail_w = max(10.0, bounds.h - t_ins - b_ins)
            avail_h = max(10.0, bounds.w - l_ins - r_ins)
        else:
            avail_w = max(10.0, bounds.w - effective_l_ins - effective_r_ins)
            avail_h = max(1.0, bounds.h - t_ins - b_ins)

        num_cols = max(1, text_box.columns)
        col_spc = text_box.column_spacing if text_box.column_spacing > 0 else (18.0 if num_cols > 1 else 0.0)
        col_w = max(10.0, (avail_w - (num_cols - 1) * col_spc) / num_cols) if num_cols > 1 else avail_w

        if num_cols > 1 and not is_vertical:
            # Multi-column layout with height-balanced column flow
            laid_paras = []
            total_content_height = 0.0
            for p_idx, para in enumerate(text_box.paragraphs):
                p_lines = self._layout_paragraph(para, col_w, word_wrap=text_box.word_wrap)
                p_h = sum(l.height for l in p_lines)
                if p_idx > 0:
                    p_h += para.space_before
                if p_idx < len(text_box.paragraphs) - 1:
                    p_h += para.space_after
                laid_paras.append((para, p_lines, p_h))
                total_content_height += p_h

            target_col_h = max(avail_h, (total_content_height + 0.1) / num_cols) if avail_h > 10.0 else (total_content_height / num_cols)

            final_lines: List[LayoutLine] = []
            base_x = bounds.x + l_ins
            base_y = bounds.y + t_ins
            max_col_h = 0.0

            col_idx = 0
            current_y = 0.0

            for p_idx, (para, para_lines, p_h) in enumerate(laid_paras):
                para_before = para.space_before if p_idx > 0 else 0.0
                para_after = para.space_after if p_idx < len(laid_paras) - 1 else 0.0
                para_lines_h = sum(l.height for l in para_lines)

                if current_y > 0 and (current_y + para_before + para_lines_h > target_col_h + 1.0) and col_idx < num_cols - 1:
                    max_col_h = max(max_col_h, current_y)
                    col_idx += 1
                    current_y = 0.0

                if current_y > 0:
                    current_y += para_before

                col_x_offset = col_idx * (col_w + col_spc)

                for line in para_lines:
                    main_family = line.fragments[0].font_family if line.fragments else "Arial"
                    main_bold = line.fragments[0].bold if line.fragments else False
                    main_italic = line.fragments[0].italic if line.fragments else False
                    main_size = line.fragments[0].font_size if line.fragments else 11.0
                    asc_ratio = self.font_metrics.get_ascender_ratio(main_family, main_bold, main_italic)
                    line_baseline = current_y + line.height * asc_ratio
                    line.x += base_x + col_x_offset
                    line.y = base_y + line_baseline
                    if line.bullet_text:
                        line.bullet_x += base_x + col_x_offset
                    current_y += line.height
                    final_lines.append(line)

                current_y += para_after

            max_col_h = max(max_col_h, current_y)
            return LayoutBlock(lines=final_lines, total_height=max_col_h)

        # Standard single-column flow
        raw_lines: List[LayoutLine] = []
        current_y_offset = 0.0

        for p_idx, para in enumerate(text_box.paragraphs):
            if p_idx > 0:
                current_y_offset += para.space_before

            para_lines = self._layout_paragraph(para, avail_w, word_wrap=text_box.word_wrap)
            for line in para_lines:
                main_family = line.fragments[0].font_family if line.fragments else "Arial"
                main_bold = line.fragments[0].bold if line.fragments else False
                main_italic = line.fragments[0].italic if line.fragments else False
                main_size = line.fragments[0].font_size if line.fragments else 11.0
                asc_ratio = self.font_metrics.get_ascender_ratio(main_family, main_bold, main_italic)
                line.y = current_y_offset + line.height * asc_ratio
                current_y_offset += line.height
                raw_lines.append(line)

            # Space after is only applied between paragraphs, never after the last paragraph
            if p_idx < len(text_box.paragraphs) - 1:
                current_y_offset += para.space_after

        total_text_height = current_y_offset

        # Vertical Alignment Offset
        v_offset = 0.0
        if text_box.vertical_align == VerticalAlign.MIDDLE:
            v_offset = (avail_h - total_text_height) / 2.0
        elif text_box.vertical_align == VerticalAlign.BOTTOM and raw_lines:
            # Use actual font descender for precise bottom alignment
            last_line = raw_lines[-1]
            last_family = last_line.fragments[0].font_family if last_line.fragments else "Arial"
            last_bold = last_line.fragments[0].bold if last_line.fragments else False
            last_italic = last_line.fragments[0].italic if last_line.fragments else False
            last_size = last_line.fragments[0].font_size if last_line.fragments else 11.0
            desc_ratio = self.font_metrics.get_descender_ratio(last_family, last_bold, last_italic)
            # descender is negative, so last_line.y + last_size * abs(desc_ratio) = bottom of text
            last_line_bottom = last_line.y + last_size * abs(desc_ratio)
            v_offset = max(0.0, avail_h - last_line_bottom)
        elif text_box.vertical_align == VerticalAlign.BOTTOM:
            v_offset = max(0.0, avail_h - total_text_height)

        final_lines: List[LayoutLine] = []
        if is_vertical:
            for line in raw_lines:
                line.y += v_offset
                final_lines.append(line)
        else:
            base_x = bounds.x + l_ins
            base_y = bounds.y + t_ins + v_offset
            for line in raw_lines:
                line.x += base_x
                line.y += base_y
                if line.bullet_text:
                    line.bullet_x += base_x
                final_lines.append(line)

        return LayoutBlock(lines=final_lines, total_height=total_text_height)

    def _layout_paragraph(self, para: ParagraphModel, max_w: float, word_wrap: bool = True) -> List[LayoutLine]:
        if not para.runs:
            # Blank line
            def_sz = getattr(para, "default_font_size", 12.0) or 12.0
            def_fam = getattr(para, "default_font_family", "Arial") or "Arial"
            def_h = self.font_metrics.get_line_height(def_sz, para.line_spacing, exact=para.line_spacing_exact, family=def_fam)
            return [LayoutLine(fragments=[], height=def_h)]

        default_font_size = para.runs[0].font_size if para.runs else 11.0
        default_font_family = para.runs[0].font_family if para.runs else "Arial"
        default_bold = para.runs[0].bold if para.runs else False
        default_italic = para.runs[0].italic if para.runs else False

        if para.bullet_size_pts is not None:
            bullet_sz = para.bullet_size_pts
        elif para.bullet_size_pct is not None:
            bullet_sz = default_font_size * para.bullet_size_pct
        else:
            bullet_sz = default_font_size

        # Indentation & Bullets following OpenXML DrawingML spec
        hanging_val = abs(para.hanging_indent) if para.hanging_indent != 0 else 0.0
        if para.bullet_char:
            bullet_w = self.font_metrics.measure_text_width(
                para.bullet_char + " ", para.bullet_font or "Arial", bullet_sz
            )
            if para.hanging_indent < 0:
                bullet_x_pos = max(0.0, para.margin_left + para.hanging_indent)
                first_line_x = max(para.margin_left, bullet_x_pos + bullet_w)
                other_lines_x = max(0.0, para.margin_left)
            elif para.margin_left > 0:
                bullet_x_pos = max(0.0, para.margin_left - bullet_w)
                first_line_x = max(para.margin_left, bullet_w)
                other_lines_x = first_line_x
            else:
                bullet_x_pos = 0.0
                first_line_x = bullet_w
                other_lines_x = first_line_x
        else:
            if para.hanging_indent < 0:
                first_line_x = max(0.0, para.margin_left + para.hanging_indent)
                other_lines_x = max(0.0, para.margin_left)
            else:
                first_line_x = max(0.0, para.margin_left + para.hanging_indent)
                other_lines_x = max(0.0, para.margin_left)
            bullet_x_pos = 0.0

        # Break runs into words and tab tokens
        words_with_style = []
        for run in para.runs:
            text = run.text
            if not text:
                continue

            lines = text.split("\n")
            for i, l_text in enumerate(lines):
                if i > 0:
                    words_with_style.append(("\n", run))
                if l_text:
                    tab_tokens = l_text.split("\t")
                    for t_idx, t_tok in enumerate(tab_tokens):
                        if t_idx > 0:
                            words_with_style.append(("\t", run))
                        if t_tok:
                            parts = t_tok.split(" ")
                            for j, p in enumerate(parts):
                                if not p:
                                    if j < len(parts) - 1:
                                        words_with_style.append((" ", run))
                                    continue
                                has_space = (j < len(parts) - 1)
                                if "-" in p and not p.startswith("-") and not p.endswith("-") and len(p) > 2:
                                    subparts = p.split("-")
                                    for s_idx, sp in enumerate(subparts):
                                        if s_idx < len(subparts) - 1:
                                            tok = sp + "-"
                                        else:
                                            tok = sp + (" " if has_space else "")
                                        if tok:
                                            words_with_style.append((tok, run))
                                else:
                                    word = p + (" " if has_space else "")
                                    if word:
                                        words_with_style.append((word, run))

        lines: List[LayoutLine] = []
        current_frags: List[LayoutFragment] = []
        current_line_w = 0.0
        max_font_size = 0.0
        max_font_family = default_font_family
        max_font_bold = default_bold
        max_font_italic = default_italic

        for w_idx, (word, run) in enumerate(words_with_style):
            # Strict boundary wrapping with 0.2pt subpixel slack matching DrawingML dimensions
            subpixel_tolerance = 0.2
            mar_r = getattr(para, "margin_right", 0.0)
            cur_line_avail_w = max(10.0, max_w - mar_r - (first_line_x if len(lines) == 0 else other_lines_x) + subpixel_tolerance)

            if word == "\n":
                line_sz = max_font_size if max_font_size > 0.0 else (run.font_size if run else default_font_size)
                line_obj = self._finalize_line(
                    current_frags, para, line_sz, lines, first_line_x, other_lines_x, max_w,
                    bullet_x_pos, bullet_sz=bullet_sz, is_terminal=True,
                    line_family=max_font_family, line_bold=max_font_bold, line_italic=max_font_italic,
                )
                lines.append(line_obj)
                current_frags = []
                current_line_w = 0.0
                max_font_size = 0.0
                max_font_family = default_font_family
                max_font_bold = default_bold
                max_font_italic = default_italic
                continue

            if word == "\t":
                cur_line_start_x = first_line_x if len(lines) == 0 else other_lines_x
                cur_frame_pos = cur_line_start_x + current_line_w
                next_tab_pos = None
                if para.tab_stops:
                    for ts in para.tab_stops:
                        if ts.pos > cur_frame_pos + 1.0:
                            if ts.align == "r":
                                # Look ahead to measure remaining words on this line
                                rem_w = 0.0
                                for fw, fr in words_with_style[w_idx + 1:]:
                                    if fw in ("\n", "\t"):
                                        break
                                    rem_w += self.font_metrics.measure_text_width(
                                        fw, fr.font_family, fr.font_size, bold=fr.bold, italic=fr.italic
                                    )
                                next_tab_pos = max(cur_frame_pos + 4.0, ts.pos - rem_w)
                            else:
                                next_tab_pos = ts.pos
                            break
                if next_tab_pos is None:
                    tab_interval = getattr(para, "def_tab_size", 54.0) or 54.0
                    next_tab_pos = (int(cur_frame_pos // tab_interval) + 1) * tab_interval

                current_line_w = max(current_line_w + 4.0, next_tab_pos - cur_line_start_x)
                continue

            char_spc = getattr(run, "character_spacing", 0.0)
            w_width = self.font_metrics.measure_text_width(
                word, run.font_family, run.font_size, bold=run.bold, italic=run.italic, character_spacing=char_spc
            )
            w_visible = self.font_metrics.measure_text_width(
                word.rstrip(" "), run.font_family, run.font_size, bold=run.bold, italic=run.italic, character_spacing=char_spc
            )

            # Check if word overflows current line:
            overflow_slack = 0.5
            if word_wrap and current_frags and (current_line_w + w_visible > cur_line_avail_w + overflow_slack):
                line_sz = max_font_size if max_font_size > 0.0 else default_font_size
                line_obj = self._finalize_line(
                    current_frags, para, line_sz, lines, first_line_x, other_lines_x, max_w,
                    bullet_x_pos, bullet_sz=bullet_sz, is_terminal=False,
                    line_family=max_font_family, line_bold=max_font_bold, line_italic=max_font_italic,
                )
                lines.append(line_obj)
                current_frags = []
                current_line_w = 0.0
                max_font_size = run.font_size
                max_font_family = run.font_family
                max_font_bold = run.bold
                max_font_italic = run.italic
            else:
                if run.font_size > max_font_size:
                    max_font_size = run.font_size
                    max_font_family = run.font_family
                    max_font_bold = run.bold
                    max_font_italic = run.italic
                elif run.font_size == max_font_size and max_font_size == 0.0:
                    max_font_size = run.font_size

            frag = LayoutFragment(
                text=word,
                font_family=run.font_family,
                font_size=run.font_size,
                color=run.color,
                bold=run.bold,
                italic=run.italic,
                underline=run.underline,
                strikethrough=run.strikethrough,
                width=w_width,
                x_offset=current_line_w,
                baseline_offset=run.baseline_offset,
                character_spacing=char_spc,
                highlight_color=run.highlight_color,
            )

            current_frags.append(frag)
            current_line_w += w_width

        if current_frags:
            line_sz = max_font_size if max_font_size > 0.0 else default_font_size
            line_obj = self._finalize_line(
                current_frags, para, line_sz, lines, first_line_x, other_lines_x, max_w,
                bullet_x_pos, bullet_sz=bullet_sz, is_terminal=True,
                line_family=max_font_family, line_bold=max_font_bold, line_italic=max_font_italic,
            )
            lines.append(line_obj)

        return lines

    def _finalize_line(
        self,
        fragments: List[LayoutFragment],
        para: ParagraphModel,
        max_font_size: float,
        existing_lines: List[LayoutLine],
        first_x: float,
        other_x: float,
        avail_w: float,
        bullet_x_pos: float,
        bullet_sz: float = 12.0,
        is_terminal: bool = False,
        line_family: str = "Arial",
        line_bold: bool = False,
        line_italic: bool = False,
    ) -> LayoutLine:
        # Merge contiguous fragments of matching style and re-measure for kerning accuracy
        merged_fragments: List[LayoutFragment] = []
        for frag in fragments:
            if not merged_fragments:
                merged_fragments.append(frag)
                continue
            prev = merged_fragments[-1]
            is_same_style = (
                prev.font_family == frag.font_family and
                abs(prev.font_size - frag.font_size) < 0.01 and
                prev.color == frag.color and
                prev.highlight_color == frag.highlight_color and
                prev.bold == frag.bold and
                prev.italic == frag.italic and
                prev.underline == frag.underline and
                prev.strikethrough == frag.strikethrough and
                abs(prev.baseline_offset - frag.baseline_offset) < 0.01 and
                abs(prev.character_spacing - frag.character_spacing) < 0.001
            )
            is_contiguous = abs((prev.x_offset + prev.width) - frag.x_offset) < 0.5
            if is_same_style and is_contiguous:
                # Re-measure merged text for kerning accuracy instead of summing widths
                merged_text = prev.text + frag.text
                merged_width = self.font_metrics.measure_run_width(
                    merged_text, prev.font_family, prev.font_size,
                    bold=prev.bold, italic=prev.italic, character_spacing=prev.character_spacing
                )
                merged_fragments[-1] = LayoutFragment(
                    text=merged_text,
                    font_family=prev.font_family,
                    font_size=prev.font_size,
                    color=prev.color,
                    bold=prev.bold,
                    italic=prev.italic,
                    underline=prev.underline,
                    strikethrough=prev.strikethrough,
                    width=merged_width,
                    x_offset=prev.x_offset,
                    baseline_offset=prev.baseline_offset,
                    character_spacing=prev.character_spacing,
                    highlight_color=prev.highlight_color,
                )
            else:
                merged_fragments.append(frag)

        fragments = merged_fragments

        # If any fragment's width changed due to kerning re-measurement,
        # adjust subsequent contiguous fragments accordingly while preserving tab/gap offsets
        if len(fragments) > 1:
            adjusted_frags = [fragments[0]]
            for i in range(1, len(fragments)):
                prev_orig_end = fragments[i-1].x_offset + fragments[i-1].width
                cur_frag = fragments[i]
                # If this fragment was contiguous to the previous one, align it to previous fragment's new end
                if abs(cur_frag.x_offset - prev_orig_end) < 1.0:
                    new_x = adjusted_frags[-1].x_offset + adjusted_frags[-1].width
                else:
                    new_x = cur_frag.x_offset
                adjusted_frags.append(LayoutFragment(
                    text=cur_frag.text,
                    font_family=cur_frag.font_family,
                    font_size=cur_frag.font_size,
                    color=cur_frag.color,
                    bold=cur_frag.bold,
                    italic=cur_frag.italic,
                    underline=cur_frag.underline,
                    strikethrough=cur_frag.strikethrough,
                    width=cur_frag.width,
                    x_offset=new_x,
                    baseline_offset=cur_frag.baseline_offset,
                    highlight_color=cur_frag.highlight_color,
                ))
            fragments = adjusted_frags

        is_first = (len(existing_lines) == 0)
        start_x = first_x if is_first else other_x
        line_w = sum(f.width for f in fragments)
        cur_avail = max(10.0, avail_w - start_x)

        # Horizontal alignment offset and Justification
        # Exclude trailing whitespace from center and right alignment positioning
        visible_line_w = line_w
        if fragments and fragments[-1].text:
            last_text = fragments[-1].text
            trimmed = last_text.rstrip(" \t\xa0")
            if len(trimmed) < len(last_text):
                trailing_ws = last_text[len(trimmed):]
                last_frag = fragments[-1]
                char_spc = getattr(last_frag, "character_spacing", 0.0)
                trailing_w = self.font_metrics.measure_run_width(
                    trailing_ws, last_frag.font_family, last_frag.font_size,
                    bold=last_frag.bold, italic=last_frag.italic, character_spacing=char_spc
                )
                visible_line_w = max(0.0, line_w - trailing_w)

        align_offset = 0.0
        if para.align == HorizontalAlign.CENTER:
            align_offset = (cur_avail - visible_line_w) / 2.0
        elif para.align == HorizontalAlign.RIGHT:
            align_offset = max(0.0, cur_avail - visible_line_w)
        elif para.align == HorizontalAlign.JUSTIFY and not is_terminal:
            rem_w = cur_avail - line_w
            if 0 < rem_w < cur_avail * 0.4:
                # Split fragments containing spaces into individual word fragments without trailing spaces
                word_frags = []
                for f in fragments:
                    if not f.text:
                        continue
                    f_spc = getattr(f, "character_spacing", 0.0)
                    if not f.text.strip():
                        # Fragment is purely whitespace
                        space_w = self.font_metrics.measure_run_width(
                            f.text, f.font_family, f.font_size, bold=f.bold, italic=f.italic, character_spacing=f_spc
                        )
                        word_frags.append(("", f, 0.0, space_w, True))
                        continue

                    # If text starts with spaces, account for leading spaces
                    leading_spaces = len(f.text) - len(f.text.lstrip(" "))
                    space_w = self.font_metrics.measure_run_width(
                        " ", f.font_family, f.font_size, bold=f.bold, italic=f.italic, character_spacing=f_spc
                    )
                    if leading_spaces > 0:
                        word_frags.append(("", f, 0.0, space_w * leading_spaces, True))

                    words = [w for w in f.text.split(" ") if w]
                    for w_idx, word in enumerate(words):
                        w_w = self.font_metrics.measure_run_width(
                            word, f.font_family, f.font_size, bold=f.bold, italic=f.italic, character_spacing=f_spc
                        )
                        is_space_after = (w_idx < len(words) - 1) or f.text.endswith(" ")
                        word_frags.append((word, f, w_w, space_w, is_space_after))

                total_gaps = sum(1 for _, _, _, _, is_space in word_frags[:-1] if is_space)
                if total_gaps > 0:
                    space_boost = rem_w / total_gaps
                    justified_frags = []
                    cur_x = 0.0
                    for w_idx, (part, f, w_w, space_w, is_space) in enumerate(word_frags):
                        justified_frags.append(LayoutFragment(
                            text=part,
                            font_family=f.font_family,
                            font_size=f.font_size,
                            color=f.color,
                            bold=f.bold,
                            italic=f.italic,
                            underline=f.underline,
                            strikethrough=f.strikethrough,
                            width=w_w,
                            x_offset=cur_x,
                            baseline_offset=f.baseline_offset,
                            highlight_color=f.highlight_color,
                        ))
                        cur_x += w_w
                        if is_space and w_idx < len(word_frags) - 1:
                            cur_x += space_w + space_boost
                    fragments = justified_frags
                    line_w = cur_x

        # Line height from actual font metrics
        line_h = self.font_metrics.get_line_height(
            max_font_size, para.line_spacing, exact=para.line_spacing_exact,
            family=line_family, bold=line_bold, italic=line_italic,
        )

        # Bullet
        bullet_text = None
        bullet_font = None
        bullet_color = None
        bullet_x = 0.0
        if is_first and para.bullet_char:
            bullet_text = para.bullet_char
            bullet_font = para.bullet_font or (fragments[0].font_family if fragments else "Arial")
            bullet_color = para.bullet_color or (fragments[0].color if fragments else ColorModel.black())
            bullet_x = bullet_x_pos

        return LayoutLine(
            fragments=fragments,
            x=start_x + align_offset,
            width=line_w,
            height=line_h,
            bullet_text=bullet_text,
            bullet_font=bullet_font,
            bullet_color=bullet_color,
            bullet_size=bullet_sz,
            bullet_x=bullet_x,
        )
