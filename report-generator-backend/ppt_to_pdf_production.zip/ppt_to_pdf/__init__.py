"""
Autonomous Pure-Python PowerPoint (.pptx) to PDF Converter.
============================================================
Platform-independent, standalone PPTX-to-PDF rendering engine.
Zero external proprietary or Office dependencies (No Aspose, No MS Office, No LibreOffice).
"""

__version__ = "1.0.0"

from .config import ConversionConfig
from .api import PPT2PDFConverter, Presentation, convert
from .core.models import ShapeType, ChartType, FillType, StrokeDashStyle, ColorModel
from .core.exceptions import (
    PPT2PDFException,
    PPTXPackageError,
    PPTXParseError,
    FontResolutionError,
    RenderError,
)

__all__ = [
    "PPT2PDFConverter",
    "Presentation",
    "ConversionConfig",
    "convert",
    "ShapeType",
    "ChartType",
    "FillType",
    "StrokeDashStyle",
    "ColorModel",
    "PPT2PDFException",
    "PPTXPackageError",
    "PPTXParseError",
    "FontResolutionError",
    "RenderError",
]
