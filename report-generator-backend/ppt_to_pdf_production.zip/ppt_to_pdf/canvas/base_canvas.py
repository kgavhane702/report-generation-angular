"""
Abstract Vector Canvas Interface for PDF generation.
Decouples rendering logic from the concrete PDF output engine.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Tuple, Union, Any
from pathlib import Path
import io
from ..core.models import (
    Rect2D,
    Point2D,
    FillModel,
    StrokeModel,
    ColorModel,
)


class BaseCanvas(ABC):
    """
    Abstract vector canvas for drawing slide elements to a PDF document.
    """
    @abstractmethod
    def begin_page(self, width: float, height: float) -> None:
        """Starts a new PDF page with the given width and height in points."""
        pass

    @abstractmethod
    def end_page(self) -> None:
        """Finalizes the current PDF page."""
        pass

    @abstractmethod
    def draw_rect(self, rect: Rect2D, fill: Optional[FillModel] = None, stroke: Optional[StrokeModel] = None) -> None:
        """Draws a rectangle with optional fill and stroke."""
        pass

    @abstractmethod
    def draw_rounded_rect(
        self,
        rect: Rect2D,
        corner_radius: float,
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        """Draws a rounded rectangle."""
        pass

    @abstractmethod
    def draw_ellipse(self, rect: Rect2D, fill: Optional[FillModel] = None, stroke: Optional[StrokeModel] = None) -> None:
        """Draws an ellipse/circle inscribed in the given bounding box."""
        pass

    @abstractmethod
    def draw_polygon(
        self,
        points: List[Point2D],
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        """Draws a closed polygon."""
        pass

    @abstractmethod
    def draw_custom_geometry(
        self,
        bounds: Rect2D,
        custom_geom: Any,
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        """Draws a compound vector custom geometry (such as corporate logos)."""
        pass

    @abstractmethod
    def draw_polyline(
        self,
        points: List[Point2D],
        stroke: StrokeModel,
    ) -> None:
        """Draws an open polyline."""
        pass

    @abstractmethod
    def draw_line(
        self,
        start: Point2D,
        end: Point2D,
        stroke: StrokeModel,
    ) -> None:
        """Draws a straight line."""
        pass

    @abstractmethod
    def draw_bezier(
        self,
        p1: Point2D,
        p2: Point2D,
        p3: Point2D,
        p4: Point2D,
        stroke: StrokeModel,
    ) -> None:
        """Draws a cubic bezier curve."""
        pass

    @abstractmethod
    def draw_image(
        self,
        image_bytes: bytes,
        rect: Rect2D,
        rotation: float = 0.0,
    ) -> None:
        """Draws a bitmap or vector-raster image."""
        pass

    @abstractmethod
    def draw_text(
        self,
        point: Point2D,
        text: str,
        font_family: str,
        font_size: float,
        color: ColorModel,
        bold: bool = False,
        italic: bool = False,
        rotation: float = 0.0,
        morph: Optional[Tuple[Point2D, Any]] = None,
        render_mode: int = 0,
    ) -> None:
        """Draws a text string at the specified baseline point with optional rotation or transformation morph matrix."""
        pass


    @abstractmethod
    def add_bookmark(self, title: str, page_number: int, level: int = 1) -> None:
        """Adds a table-of-contents / bookmark outline item to the PDF."""
        pass

    @abstractmethod
    def save(self, target: Union[str, Path, io.BytesIO]) -> None:
        """Saves the PDF document to a file path or binary buffer."""
        pass
