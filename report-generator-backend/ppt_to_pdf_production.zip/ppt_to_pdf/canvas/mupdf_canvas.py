"""
High-Performance Vector PDF Canvas Implementation using PyMuPDF (pymupdf).
"""

import io
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any
import pymupdf
from ..core.models import (
    Rect2D,
    Point2D,
    FillModel,
    FillType,
    StrokeModel,
    StrokeDashStyle,
    ColorModel,
)
from ..typography.font_manager import FontManager
from ..utils.logger import get_logger
from .base_canvas import BaseCanvas

logger = get_logger(__name__)


class MuPDFCanvas(BaseCanvas):
    """
    Vector PDF canvas backed by PyMuPDF.
    """
    def __init__(self, font_manager: Optional[FontManager] = None):
        self.doc = pymupdf.open()
        self.current_page: Optional[pymupdf.Page] = None
        self.font_manager = font_manager or FontManager()
        self._font_tag_cache: Dict[Tuple[str, bool, bool], str] = {}
        self._toc_entries: List[List[Union[int, str]]] = []
        self._page_count = 0
        self._active_shape: Optional[pymupdf.Shape] = None

    def _get_shape(self) -> Optional[pymupdf.Shape]:
        if self.current_page is None:
            return None
        if self._active_shape is None:
            self._active_shape = self.current_page.new_shape()
        return self._active_shape

    def _flush_shape(self) -> None:
        if self._active_shape is not None:
            try:
                self._active_shape.commit()
            except Exception as e:
                logger.debug(f"Failed to commit shape batch: {e}")
            finally:
                self._active_shape = None

    def begin_page(self, width: float, height: float) -> None:
        self._flush_shape()
        self.current_page = self.doc.new_page(width=width, height=height)
        self._page_count += 1
        # Font tags are registered per-page via insert_font; clear cache
        # so fonts are re-registered for the new page
        self._font_tag_cache.clear()

    def end_page(self) -> None:
        self._flush_shape()
        self.current_page = None

    def _get_dash_pattern(self, dash_style: Union[StrokeDashStyle, str], width: float) -> Optional[str]:
        if dash_style in (StrokeDashStyle.DASH, StrokeDashStyle.SYS_DASH, "dash", "sysDash"):
            return f"[{width * 4:.1f} {width * 2:.1f}] 0"
        elif dash_style in (StrokeDashStyle.DOT, StrokeDashStyle.SYS_DOT, "dot", "sysDot"):
            return f"[{width:.1f} {width * 2:.1f}] 0"
        elif dash_style in (StrokeDashStyle.DASH_DOT, "dashDot"):
            return f"[{width * 4:.1f} {width * 2:.1f} {width:.1f} {width * 2:.1f}] 0"
        elif dash_style in (StrokeDashStyle.LG_DASH, "lgDash"):
            return f"[{width * 8:.1f} {width * 3:.1f}] 0"
        return None

    def _has_visible_paint(self, fill: Optional[FillModel], stroke: Optional[StrokeModel]) -> bool:
        has_fill = (fill is not None and fill.fill_type != FillType.NONE and (fill.color is not None or bool(fill.gradient_stops)))
        has_stroke = (stroke is not None and stroke.width > 0 and stroke.color is not None)
        return has_fill or has_stroke

    def _apply_shape_finish(
        self,
        shape: pymupdf.Shape,
        fill: Optional[FillModel],
        stroke: Optional[StrokeModel],
        closePath: bool = True,
    ) -> None:
        fill_rgb = None
        fill_alpha = 1.0
        if fill and fill.fill_type == FillType.SOLID and fill.color:
            fill_rgb = fill.color.to_rgb_tuple()
            fill_alpha = fill.color.a
        elif fill and fill.fill_type == FillType.GRADIENT and fill.gradient_stops:
            fill_rgb = fill.gradient_stops[0].color.to_rgb_tuple()
            fill_alpha = fill.gradient_stops[0].color.a

        stroke_rgb = None
        stroke_w = 0.0
        stroke_alpha = 0.0
        dashes = None
        if stroke and stroke.width > 0:
            stroke_rgb = stroke.color.to_rgb_tuple()
            stroke_w = stroke.width
            stroke_alpha = stroke.color.a
            dashes = self._get_dash_pattern(stroke.dash_style, stroke.width)

        # If neither fill nor stroke is present, do not draw an outline
        if fill_rgb is None and stroke_rgb is None:
            return

        shape.finish(
            fill=fill_rgb,
            color=stroke_rgb,
            width=stroke_w,
            fill_opacity=fill_alpha if fill_rgb is not None else 0.0,
            stroke_opacity=stroke_alpha,
            dashes=dashes,
            closePath=closePath,
        )

    def draw_rect(self, rect: Rect2D, fill: Optional[FillModel] = None, stroke: Optional[StrokeModel] = None) -> None:
        if self.current_page is None or rect.w <= 0 or rect.h <= 0 or not self._has_visible_paint(fill, stroke):
            return
        shape = self.current_page.new_shape()
        shape.draw_rect(pymupdf.Rect(rect.left, rect.top, rect.right, rect.bottom))
        self._apply_shape_finish(shape, fill, stroke)
        shape.commit()

    def draw_rounded_rect(
        self,
        rect: Rect2D,
        corner_radius: float,
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        if self.current_page is None or rect.w <= 0 or rect.h <= 0 or not self._has_visible_paint(fill, stroke):
            return
        shape = self.current_page.new_shape()
        min_dim = min(rect.w, rect.h)
        radius_ratio = max(0.01, min(0.49, corner_radius / min_dim)) if min_dim > 0 else 0.15
        shape.draw_rect(
            pymupdf.Rect(rect.left, rect.top, rect.right, rect.bottom),
            radius=radius_ratio,
        )
        self._apply_shape_finish(shape, fill, stroke)
        shape.commit()

    def draw_ellipse(self, rect: Rect2D, fill: Optional[FillModel] = None, stroke: Optional[StrokeModel] = None) -> None:
        if self.current_page is None or rect.w <= 0 or rect.h <= 0 or not self._has_visible_paint(fill, stroke):
            return
        shape = self.current_page.new_shape()
        shape.draw_oval(pymupdf.Rect(rect.left, rect.top, rect.right, rect.bottom))
        self._apply_shape_finish(shape, fill, stroke)
        shape.commit()

    def draw_polygon(
        self,
        points: List[Point2D],
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        if self.current_page is None or len(points) < 3 or not self._has_visible_paint(fill, stroke):
            return
        shape = self.current_page.new_shape()
        pts = [pymupdf.Point(p.x, p.y) for p in points]
        if pts[0] != pts[-1]:
            pts.append(pts[0])
        shape.draw_polyline(pts)
        self._apply_shape_finish(shape, fill, stroke)
        shape.commit()

    def draw_custom_geometry(
        self,
        bounds: Rect2D,
        custom_geom: Any,
        fill: Optional[FillModel] = None,
        stroke: Optional[StrokeModel] = None,
    ) -> None:
        if self.current_page is None or not custom_geom or not getattr(custom_geom, "paths", None) or bounds.w <= 0 or bounds.h <= 0 or not self._has_visible_paint(fill, stroke):
            return

        shape = self.current_page.new_shape()
        for path in custom_geom.paths:
            p_w = path.width if path.width > 0 else 1.0
            p_h = path.height if path.height > 0 else 1.0
            scale_x = bounds.w / p_w
            scale_y = bounds.h / p_h

            for spath in path.subpaths:
                if len(spath) >= 2:
                    pts = [
                        pymupdf.Point(bounds.x + p.x * scale_x, bounds.y + p.y * scale_y)
                        for p in spath
                    ]
                    shape.draw_polyline(pts)

        self._apply_shape_finish(shape, fill, stroke)
        shape.commit()

    def draw_polyline(self, points: List[Point2D], stroke: StrokeModel) -> None:
        if self.current_page is None or len(points) < 2 or stroke is None or stroke.width <= 0:
            return
        shape = self.current_page.new_shape()
        pts = [pymupdf.Point(p.x, p.y) for p in points]
        shape.draw_polyline(pts)
        self._apply_shape_finish(shape, None, stroke, closePath=False)
        shape.commit()

    def draw_line(self, start: Point2D, end: Point2D, stroke: StrokeModel) -> None:
        if self.current_page is None or stroke is None or stroke.width <= 0:
            return
        shape = self.current_page.new_shape()
        shape.draw_line(pymupdf.Point(start.x, start.y), pymupdf.Point(end.x, end.y))
        self._apply_shape_finish(shape, None, stroke, closePath=False)
        shape.commit()

    def draw_bezier(
        self,
        p1: Point2D,
        p2: Point2D,
        p3: Point2D,
        p4: Point2D,
        stroke: StrokeModel,
    ) -> None:
        if self.current_page is None or stroke is None or stroke.width <= 0:
            return
        shape = self.current_page.new_shape()
        shape.draw_bezier(
            pymupdf.Point(p1.x, p1.y),
            pymupdf.Point(p2.x, p2.y),
            pymupdf.Point(p3.x, p3.y),
            pymupdf.Point(p4.x, p4.y),
        )
        self._apply_shape_finish(shape, None, stroke, closePath=False)
        shape.commit()

    def draw_image(
        self,
        image_bytes: bytes,
        rect: Rect2D,
        rotation: float = 0.0,
    ) -> None:
        if self.current_page is None or not image_bytes or rect.w <= 0 or rect.h <= 0:
            return
        self._flush_shape()
        try:
            mupdf_rect = pymupdf.Rect(rect.left, rect.top, rect.right, rect.bottom)
            self.current_page.insert_image(mupdf_rect, stream=image_bytes, rotate=int(round(rotation)), keep_proportion=False)
        except Exception as e:
            logger.debug(f"Failed to insert image onto PDF canvas: {e}")

    def _resolve_font_name(self, family: str, bold: bool, italic: bool) -> str:
        key = (family.lower(), bold, italic)
        if key in self._font_tag_cache:
            return self._font_tag_cache[key]

        font_path = self.font_manager.resolve_font_path(family, bold=bold, italic=italic)
        font_tag = "helv"
        if font_path and self.current_page:
            try:
                # Register font into page with family name prefix
                safe_family = re.sub(r"[^a-zA-Z0-9]", "", family) or "Font"
                clean_tag = f"F_{safe_family}_{len(self._font_tag_cache) + 1}"
                self.current_page.insert_font(fontname=clean_tag, fontfile=font_path)
                font_tag = clean_tag
            except Exception as e:
                logger.debug(f"Font embedding fallback for {family}: {e}")
                # Fallback to standard PDF base14 fonts
                if bold and italic:
                    font_tag = "hebi"
                elif bold:
                    font_tag = "hebo"
                elif italic:
                    font_tag = "heit"
                else:
                    font_tag = "helv"
        else:
            if bold and italic:
                font_tag = "hebi"
            elif bold:
                font_tag = "hebo"
            elif italic:
                font_tag = "heit"
            else:
                font_tag = "helv"

        self._font_tag_cache[key] = font_tag
        return font_tag

    def draw_text(
        self,
        point: Point2D,
        text: str,
        font_family: str,
        font_size: float,
        color: ColorModel,
        bold: bool = False,
        italic: bool = False,
        rotation: float = 0.0,
        morph: Optional[Tuple[Point2D, Any]] = None,
        render_mode: int = 0,
    ) -> None:
        if self.current_page is None or not text:
            return
        self._flush_shape()
        font_tag = self._resolve_font_name(font_family, bold, italic)
        rot_val = int(round(rotation)) % 360
        morph_tuple = None
        if morph is not None:
            m_pt, m_mat = morph
            m_p = pymupdf.Point(m_pt.x, m_pt.y)
            if hasattr(m_mat, "a"):
                m_m = pymupdf.Matrix(m_mat.a, m_mat.b, m_mat.c, m_mat.d, m_mat.e, m_mat.f)
            else:
                m_m = m_mat
            morph_tuple = (m_p, m_m)

        try:
            self.current_page.insert_text(
                pymupdf.Point(point.x, point.y),
                text,
                fontname=font_tag,
                fontsize=font_size,
                color=color.to_rgb_tuple(),
                rotate=rot_val if morph_tuple is None else 0,
                morph=morph_tuple,
                render_mode=render_mode,
            )
        except Exception as e:
            # Fallback using standard helvetica
            try:
                self.current_page.insert_text(
                    pymupdf.Point(point.x, point.y),
                    text,
                    fontname="helv",
                    fontsize=font_size,
                    color=color.to_rgb_tuple(),
                    rotate=rot_val if morph_tuple is None else 0,
                    morph=morph_tuple,
                    render_mode=render_mode,
                )
            except Exception:
                pass


    def add_bookmark(self, title: str, page_number: int, level: int = 1) -> None:
        if title:
            self._toc_entries.append([level, title, page_number])

    def insert_pdf_from_canvas(self, other_canvas: "MuPDFCanvas") -> None:
        """Inserts all pages from another MuPDFCanvas into this master canvas."""
        other_canvas._flush_shape()
        self._flush_shape()
        self.doc.insert_pdf(other_canvas.doc)
        self._page_count += len(other_canvas.doc)

    def to_bytes(self) -> bytes:
        """Returns the current document as compressed, subsetted PDF bytes."""
        self._flush_shape()
        try:
            self.doc.subset_fonts()
        except Exception:
            pass
        return self.doc.tobytes(garbage=3, deflate=True, deflate_fonts=True, deflate_images=True, clean=True)

    def save(self, target: Union[str, Path, io.BytesIO]) -> None:
        self._flush_shape()
        if self._toc_entries:
            try:
                self.doc.set_toc(self._toc_entries)
            except Exception as e:
                logger.debug(f"Failed to set TOC: {e}")

        # Metadata
        self.doc.set_metadata({
            "producer": "Pure Python PPTX2PDF Vector Engine",
            "creator": "Autonomous PPT to PDF Converter",
        })

        # Font subsetting & stream compression for lightweight PDF size
        try:
            self.doc.subset_fonts()
        except Exception:
            pass

        if isinstance(target, (str, Path)):
            self.doc.save(
                str(target),
                garbage=3,
                deflate=True,
                deflate_fonts=True,
                deflate_images=True,
                clean=True,
            )
        elif isinstance(target, io.BytesIO):
            out_bytes = self.doc.tobytes(
                garbage=3,
                deflate=True,
                deflate_fonts=True,
                deflate_images=True,
                clean=True,
            )
            target.write(out_bytes)

        self.doc.close()
