"""
Exception hierarchy for PPT to PDF converter.
"""


class PPT2PDFException(Exception):
    """Base exception for all PPT to PDF conversion errors."""
    pass


class PPTXPackageError(PPT2PDFException):
    """Raised when an error occurs while unpacking or reading the PPTX zip structure."""
    pass


class PPTXParseError(PPT2PDFException):
    """Raised when an OpenXML XML parsing error occurs."""
    pass


class FontResolutionError(PPT2PDFException):
    """Raised when a required font cannot be loaded or resolved."""
    pass


class RenderError(PPT2PDFException):
    """Raised when an element fails to render to the PDF canvas."""
    pass


class UnsupportedFeatureError(PPT2PDFException):
    """Raised when an unsupported presentation feature is encountered."""
    pass
