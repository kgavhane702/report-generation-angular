"""
Strongly-typed intermediate AST Object Models for parsed PowerPoint slides and shapes.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Any, Union
from .transform import Rect2D, Point2D


class FillType(Enum):
    NONE = auto()
    SOLID = auto()
    GRADIENT = auto()
    BLIP = auto()  # Image / texture fill
    PATTERN = auto()


class StrokeDashStyle(Enum):
    SOLID = "solid"
    DASH = "dash"
    DOT = "dot"
    DASH_DOT = "dashDot"
    LG_DASH = "lgDash"
    LG_DASH_DOT = "lgDashDot"
    SYS_DASH = "sysDash"
    SYS_DOT = "sysDot"


class HorizontalAlign(Enum):
    LEFT = "l"
    CENTER = "ctr"
    RIGHT = "r"
    JUSTIFY = "just"


class VerticalAlign(Enum):
    TOP = "t"
    MIDDLE = "mid"
    BOTTOM = "b"


class ShapeType(Enum):
    NOT_DEFINED = "notDefined"
    RECTANGLE = "rect"
    ROUND_CORNER_RECTANGLE = "roundRect"
    ELLIPSE = "ellipse"
    TRIANGLE = "triangle"
    RIGHT_TRIANGLE = "rtTriangle"
    DIAMOND = "diamond"
    PARALLELOGRAM = "parallelogram"
    TRAPEZOID = "trapezoid"
    HEXAGON = "hexagon"
    OCTAGON = "octagon"
    CHEVRON = "chevron"
    RIGHT_ARROW = "rightArrow"
    LEFT_ARROW = "leftArrow"
    UP_ARROW = "upArrow"
    DOWN_ARROW = "downArrow"
    FIVE_POINTED_STAR = "star5"
    PLUS = "plus"
    LINE = "line"
    CONNECTOR = "connector"
    TABLE = "table"
    PICTURE = "picture"
    CHART = "chart"
    GROUP = "group"
    CUSTOM = "custom"


class ChartType(Enum):
    BAR = "barChart"
    COLUMN = "colChart"
    STACKED_BAR = "barStackedChart"
    STACKED_COLUMN = "colStackedChart"
    PERCENT_STACKED_BAR = "barPercentStackedChart"
    PERCENT_STACKED_COLUMN = "colPercentStackedChart"
    LINE = "lineChart"
    PIE = "pieChart"
    DOUGHNUT = "doughnutChart"
    AREA = "areaChart"
    SCATTER = "scatterChart"
    BUBBLE = "bubbleChart"
    RADAR = "radarChart"
    UNKNOWN = "unknownChart"


@dataclass
class ColorModel:
    """Represents an RGBA color with normalized floats [0.0, 1.0]."""
    r: float = 0.0
    g: float = 0.0
    b: float = 0.0
    a: float = 1.0

    @classmethod
    def from_hex(cls, hex_str: str, alpha: float = 1.0) -> "ColorModel":
        s = hex_str.lstrip("#")
        if len(s) == 6:
            r = int(s[0:2], 16) / 255.0
            g = int(s[2:4], 16) / 255.0
            b = int(s[4:6], 16) / 255.0
            return cls(r, g, b, alpha)
        elif len(s) == 8:
            r = int(s[0:2], 16) / 255.0
            g = int(s[2:4], 16) / 255.0
            b = int(s[4:6], 16) / 255.0
            a = int(s[6:8], 16) / 255.0
            return cls(r, g, b, a)
        return cls(0.0, 0.0, 0.0, alpha)

    @classmethod
    def from_rgb255(cls, r: int, g: int, b: int, a: float = 1.0) -> "ColorModel":
        return cls(r / 255.0, g / 255.0, b / 255.0, a)

    @classmethod
    def black(cls) -> "ColorModel":
        return cls(0.0, 0.0, 0.0, 1.0)

    @classmethod
    def white(cls) -> "ColorModel":
        return cls(1.0, 1.0, 1.0, 1.0)

    @classmethod
    def transparent(cls) -> "ColorModel":
        return cls(0.0, 0.0, 0.0, 0.0)

    def to_rgb_tuple(self) -> Tuple[float, float, float]:
        return (self.r, self.g, self.b)

    def to_rgba_tuple(self) -> Tuple[float, float, float, float]:
        return (self.r, self.g, self.b, self.a)

    def to_hex(self) -> str:
        ir = int(round(self.r * 255))
        ig = int(round(self.g * 255))
        ib = int(round(self.b * 255))
        return f"#{ir:02X}{ig:02X}{ib:02X}"


@dataclass
class GradientStop:
    position: float  # 0.0 to 1.0
    color: ColorModel


@dataclass
class FillModel:
    fill_type: FillType = FillType.NONE
    color: Optional[ColorModel] = None
    gradient_stops: List[GradientStop] = field(default_factory=list)
    gradient_angle: float = 90.0  # In degrees
    image_bytes: Optional[bytes] = None


@dataclass
class StrokeModel:
    color: ColorModel = field(default_factory=ColorModel.black)
    width: float = 1.0  # In points
    dash_style: StrokeDashStyle = StrokeDashStyle.SOLID
    opacity: float = 1.0


@dataclass
class ShadowModel:
    color: ColorModel = field(default_factory=lambda: ColorModel(0.0, 0.0, 0.0, 0.35))
    blur_rad: float = 4.0
    dist: float = 3.0
    dir_deg: float = 45.0


@dataclass
class RunModel:
    text: str = ""
    font_family: str = "Arial"
    font_size: float = 12.0  # In points
    color: ColorModel = field(default_factory=ColorModel.black)
    highlight_color: Optional[ColorModel] = None
    has_explicit_font: bool = False
    has_explicit_size: bool = False
    has_explicit_bold: bool = False
    has_explicit_color: bool = False
    bold: bool = False
    italic: bool = False
    underline: bool = False
    strikethrough: bool = False
    baseline_offset: float = 0.0  # Superscript / Subscript percentage
    character_spacing: float = 0.0  # Character spacing (tracking) in points
    hyperlink_target: Optional[str] = None


@dataclass
class TabStopModel:
    pos: float = 0.0  # Position in points from left margin
    align: str = "l"  # 'l', 'r', 'ctr', 'dec'


@dataclass
class ParagraphModel:
    runs: List[RunModel] = field(default_factory=list)
    align: HorizontalAlign = HorizontalAlign.LEFT
    has_explicit_align: bool = False
    line_spacing: float = 1.2  # Multiplier or absolute pt
    line_spacing_exact: bool = False  # True if line_spacing is in absolute points
    space_before: float = 0.0  # In points
    space_after: float = 0.0  # In points
    bullet_char: Optional[str] = None
    bullet_font: Optional[str] = None
    bullet_color: Optional[ColorModel] = None
    bullet_size_pct: Optional[float] = None  # Multiplier of font size
    bullet_size_pts: Optional[float] = None  # Exact points
    auto_num_type: Optional[str] = None
    auto_num_start: int = 1
    indent_level: int = 0
    margin_left: float = 0.0  # In points
    margin_right: float = 0.0  # In points
    hanging_indent: float = 0.0  # In points
    tab_stops: List[TabStopModel] = field(default_factory=list)
    def_tab_size: float = 72.0  # Default tab stop interval in points (1.0 in = 72pt)
    default_font_size: float = 14.0  # Default font size for empty lines or endParaRPr
    default_font_family: str = "Arial"  # Default font family for empty lines or endParaRPr

    @property
    def plain_text(self) -> str:
        return "".join(r.text for r in self.runs)


@dataclass
class TextBoxModel:
    paragraphs: List[ParagraphModel] = field(default_factory=list)
    insets: Tuple[float, float, float, float] = (7.2, 3.6, 7.2, 3.6)  # left, top, right, bottom in pt
    vertical_align: VerticalAlign = VerticalAlign.TOP
    word_wrap: bool = True
    columns: int = 1
    column_spacing: float = 0.0  # In points
    rotation: float = 0.0
    vert_rotation: str = "horz"  # 'horz', 'vert', 'vert270', 'eaVert', 'wordArtVert'

    @property
    def plain_text(self) -> str:
        return "\n".join(p.plain_text for p in self.paragraphs)



@dataclass
class CustomGeometryPath:
    width: float = 1.0
    height: float = 1.0
    fill_rule: str = "evenOdd"
    subpaths: List[List[Point2D]] = field(default_factory=list)


@dataclass
class CustomGeometryModel:
    paths: List[CustomGeometryPath] = field(default_factory=list)


@dataclass
class ShapeModel:
    id: str = ""
    name: str = ""
    bounds: Rect2D = field(default_factory=lambda: Rect2D(0, 0, 0, 0))
    preset_geom: str = "rect"
    custom_path: Optional[str] = None
    custom_geometry: Optional[CustomGeometryModel] = None
    corner_radius: Optional[float] = None
    rotation: float = 0.0
    flip_h: bool = False
    flip_v: bool = False
    fill: FillModel = field(default_factory=FillModel)
    stroke: Optional[StrokeModel] = None
    shadow: Optional[ShadowModel] = None
    text_frame: Optional[TextBoxModel] = None
    is_placeholder: bool = False
    placeholder_type: Optional[str] = None
    placeholder_idx: Optional[int] = None


@dataclass
class PictureModel:
    id: str = ""
    name: str = ""
    bounds: Rect2D = field(default_factory=lambda: Rect2D(0, 0, 0, 0))
    image_bytes: Optional[bytes] = None
    image_format: str = "png"
    crop_rect: Optional[Tuple[float, float, float, float]] = None  # l, t, r, b (0.0 - 1.0)
    rotation: float = 0.0
    flip_h: bool = False
    flip_v: bool = False
    stroke: Optional[StrokeModel] = None
    shadow: Optional[ShadowModel] = None


@dataclass
class ConnectorModel:
    id: str = ""
    name: str = ""
    start_point: Point2D = field(default_factory=lambda: Point2D(0, 0))
    end_point: Point2D = field(default_factory=lambda: Point2D(0, 0))
    path_points: List[Point2D] = field(default_factory=list)
    stroke: StrokeModel = field(default_factory=StrokeModel)
    head_type: Optional[str] = None
    tail_type: Optional[str] = None


@dataclass
class TableCellModel:
    row: int = 0
    col: int = 0
    row_span: int = 1
    col_span: int = 1
    is_merged_slave: bool = False
    fill: FillModel = field(default_factory=FillModel)
    border_left: Optional[StrokeModel] = None
    border_top: Optional[StrokeModel] = None
    border_right: Optional[StrokeModel] = None
    border_bottom: Optional[StrokeModel] = None
    border_tl_br: Optional[StrokeModel] = None  # Top-left to bottom-right diagonal
    border_bl_tr: Optional[StrokeModel] = None  # Bottom-left to top-right diagonal
    text_frame: Optional[TextBoxModel] = None
    insets: Tuple[float, float, float, float] = (7.2, 3.6, 7.2, 3.6)
    vert_rotation: str = "horz"  # "horz", "vert", "vert270", "wordArtVert"


@dataclass
class TableModel:
    id: str = ""
    name: str = ""
    bounds: Rect2D = field(default_factory=lambda: Rect2D(0, 0, 0, 0))
    col_widths: List[float] = field(default_factory=list)
    row_heights: List[float] = field(default_factory=list)
    cells: List[List[TableCellModel]] = field(default_factory=list)


@dataclass
class ChartDataLabel:
    show_val: bool = False
    show_cat_name: bool = False
    show_ser_name: bool = False
    show_percent: bool = False
    show_legend_key: bool = False
    num_fmt: str = ""
    position: str = "bestFit"  # ctr, inEnd, inBase, outEnd, t, b, l, r, bestFit
    font_size: float = 7.0
    font_family: Optional[str] = None
    font_color: Optional[ColorModel] = None
    bold: bool = False
    custom_text: Optional[str] = None
    offset_x: float = 0.0  # OpenXML <c:dLbl>/<c:layout>/<c:manualLayout>/<c:x> (fraction of plot width)
    offset_y: float = 0.0  # OpenXML <c:dLbl>/<c:layout>/<c:manualLayout>/<c:y> (fraction of plot height)


@dataclass
class ChartAxisModel:
    axis_id: str = ""
    axis_type: str = "val"  # 'cat', 'val', 'date', 'ser'
    position: str = "l"  # 'l', 'r', 't', 'b'
    is_deleted: bool = False
    min_val: Optional[float] = None
    max_val: Optional[float] = None
    major_unit: Optional[float] = None
    log_scale: bool = False
    num_fmt: Optional[str] = None
    tick_label_pos: str = "nextTo"  # 'none', 'nextTo', 'high', 'low'
    show_major_gridlines: bool = False
    show_minor_gridlines: bool = False
    gridline_color: Optional[ColorModel] = None
    gridline_width: float = 0.5
    axis_line_color: Optional[ColorModel] = None
    axis_line_width: float = 0.5
    orientation: str = "minMax"  # 'minMax' or 'maxMin'
    major_time_unit: Optional[str] = None  # 'days', 'months', 'years'
    base_time_unit: Optional[str] = None  # 'days', 'months', 'years'
    major_tick_mark: str = "none"  # 'none', 'out', 'in', 'cross'
    label_rotation: float = 0.0  # Rotation in degrees (e.g. -45.0, -90.0)
    cross_between: str = "between"  # 'between' or 'midCat'
    axis_line_dash: str = "solid"
    lbl_offset: float = 100.0  # OpenXML <c:lblOffset val="..."> (100 = 100% default distance)
    font_size: float = 7.0
    font_color: Optional[ColorModel] = None
    font_family: str = "Calibri"
    crosses: str = "autoZero"  # 'autoZero', 'max', 'min'
    crosses_at: Optional[float] = None


@dataclass
class ChartDataSeries:
    name: str = ""
    chart_type: Optional[ChartType] = None  # Specific chart type for combo charts
    categories: List[str] = field(default_factory=list)
    values: List[Optional[float]] = field(default_factory=list)
    x_values: List[Optional[float]] = field(default_factory=list)
    bubble_sizes: List[Optional[float]] = field(default_factory=list)
    color: Optional[ColorModel] = None
    border_color: Optional[ColorModel] = None
    border_width: float = 1.0
    dash_style: str = "solid"  # solid, lgDash, dash, dot, sysDot, etc.
    marker_symbol: Optional[str] = None  # none, circle, square, diamond, triangle, etc.
    marker_size: float = 5.0
    marker_color: Optional[ColorModel] = None
    point_colors: Dict[int, ColorModel] = field(default_factory=dict)
    data_labels: Dict[int, ChartDataLabel] = field(default_factory=dict)
    series_data_label: Optional[ChartDataLabel] = None
    axis_id: Optional[str] = None
    use_secondary_axis: bool = False
    smooth: bool = False
    pattern_preset: Optional[str] = None
    background_color: Optional[ColorModel] = None


@dataclass
class ChartSeriesGroup:
    chart_type: ChartType
    series_list: List[ChartDataSeries] = field(default_factory=list)
    is_secondary: bool = False
    gap_width: float = 150.0
    overlap: float = 0.0
    grouping: str = "clustered"
    ax_ids: List[str] = field(default_factory=list)


@dataclass
class ChartModel:
    id: str = ""
    name: str = ""
    bounds: Rect2D = field(default_factory=lambda: Rect2D(0, 0, 0, 0))
    chart_type: ChartType = ChartType.COLUMN
    is_combo: bool = False
    title: str = ""
    title_font_size: float = 9.0
    title_font_family: Optional[str] = None
    title_bold: Optional[bool] = None
    title_color: Optional[ColorModel] = None
    font_family: Optional[str] = None
    font_size: float = 7.0
    series_list: List[ChartDataSeries] = field(default_factory=list)
    series_groups: List[ChartSeriesGroup] = field(default_factory=list)
    categories: List[str] = field(default_factory=list)
    axes: List[ChartAxisModel] = field(default_factory=list)
    cat_axis: Optional[ChartAxisModel] = None
    val_axis: Optional[ChartAxisModel] = None
    sec_val_axis: Optional[ChartAxisModel] = None
    plot_layout: Optional[Rect2D] = None  # Manual layout percentages (x, y, w, h in 0.0 - 1.0)
    gap_width: float = 150.0  # Percentage e.g. 80, 150
    overlap: float = 0.0  # Percentage e.g. 100, 0
    show_legend: bool = True
    legend_position: str = "r"  # r, l, t, b, tr
    legend_layout: Optional[Rect2D] = None  # Manual legend layout percentages
    legend_font_size: float = 7.0
    legend_font_family: Optional[str] = None
    legend_font_color: Optional[ColorModel] = None
    show_gridlines: bool = True
    x_axis_title: str = ""
    y_axis_title: str = ""
    secondary_series_list: List[ChartDataSeries] = field(default_factory=list)
    border_color: Optional[ColorModel] = None
    border_width: float = 0.0
    fill_color: Optional[ColorModel] = None


@dataclass
class GroupModel:
    id: str = ""
    name: str = ""
    bounds: Rect2D = field(default_factory=lambda: Rect2D(0, 0, 0, 0))
    ch_off: Point2D = field(default_factory=lambda: Point2D(0, 0))
    ch_ext: Point2D = field(default_factory=lambda: Point2D(0, 0))
    rotation: float = 0.0
    flip_h: bool = False
    flip_v: bool = False
    children: List[Union[ShapeModel, PictureModel, TableModel, ChartModel, ConnectorModel, "GroupModel"]] = field(default_factory=list)


@dataclass
class SlideModel:
    index: int = 0
    slide_number: int = 1
    title: str = ""
    width: float = 720.0  # In points
    height: float = 540.0  # In points
    background_fill: FillModel = field(default_factory=FillModel)
    shapes: List[Union[ShapeModel, PictureModel, TableModel, ChartModel, ConnectorModel, GroupModel]] = field(default_factory=list)
    is_hidden: bool = False
    notes_text: str = ""
