"""
RenderContext passed through the rendering pipeline.
Maintains state, affine matrix stack for groups, font managers, color engines, and slide dimensions.
"""

from typing import List, Optional, Any
from .transform import AffineMatrix, Rect2D, Point2D
from ..config import ConversionConfig


class RenderContext:
    def __init__(
        self,
        slide_width: float = 720.0,
        slide_height: float = 540.0,
        config: Optional[ConversionConfig] = None,
        font_manager: Optional[Any] = None,
        color_engine: Optional[Any] = None,
        slide_number: int = 1,
        total_slides: int = 1,
    ):
        self.slide_width = float(slide_width)
        self.slide_height = float(slide_height)
        self.config = config or ConversionConfig()
        self.font_manager = font_manager
        self.color_engine = color_engine
        self.slide_number = slide_number
        self.total_slides = total_slides
        self._matrix_stack: List[AffineMatrix] = [AffineMatrix.identity()]

    @property
    def current_matrix(self) -> AffineMatrix:
        return self._matrix_stack[-1]

    def push_matrix(self, matrix: AffineMatrix) -> None:
        """Pushes a new combined matrix onto the transformation stack."""
        new_top = self.current_matrix.multiply(matrix)
        self._matrix_stack.append(new_top)

    def pop_matrix(self) -> AffineMatrix:
        """Pops the top matrix from the stack."""
        if len(self._matrix_stack) > 1:
            return self._matrix_stack.pop()
        return self._matrix_stack[0]

    def transform_point(self, p: Point2D) -> Point2D:
        return self.current_matrix.transform_point(p)

    def transform_rect(self, r: Rect2D) -> Rect2D:
        return self.current_matrix.transform_rect(r)
