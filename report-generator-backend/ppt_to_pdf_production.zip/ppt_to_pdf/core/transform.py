"""
2D Geometry, point, rectangle, and affine transformation matrix utilities.
Handles translation, scaling, rotation, flipH, flipV, and hierarchical coordinate mapping.
"""

import math
from dataclasses import dataclass
from typing import Tuple, List


@dataclass
class Point2D:
    """Represents a 2D coordinate point in points (pt)."""
    x: float
    y: float

    def tuple(self) -> Tuple[float, float]:
        return (self.x, self.y)


@dataclass
class Rect2D:
    """Represents a 2D bounding rectangle in points (pt)."""
    x: float
    y: float
    w: float
    h: float

    @property
    def left(self) -> float:
        return self.x

    @property
    def top(self) -> float:
        return self.y

    @property
    def right(self) -> float:
        return self.x + self.w

    @property
    def bottom(self) -> float:
        return self.y + self.h

    @property
    def center(self) -> Point2D:
        return Point2D(self.x + self.w / 2.0, self.y + self.h / 2.0)

    def contains(self, p: Point2D) -> bool:
        return self.left <= p.x <= self.right and self.top <= p.y <= self.bottom

    def tuple(self) -> Tuple[float, float, float, float]:
        return (self.x, self.y, self.w, self.h)

    def to_ltrb(self) -> Tuple[float, float, float, float]:
        return (self.left, self.top, self.right, self.bottom)


class AffineMatrix:
    """
    Standard 3x3 2D Affine Transformation Matrix:
    [ a  c  tx ]
    [ b  d  ty ]
    [ 0  0  1  ]
    """
    def __init__(self, a: float = 1.0, b: float = 0.0, c: float = 0.0, d: float = 1.0, tx: float = 0.0, ty: float = 0.0):
        self.a = float(a)
        self.b = float(b)
        self.c = float(c)
        self.d = float(d)
        self.tx = float(tx)
        self.ty = float(ty)

    @classmethod
    def identity(cls) -> "AffineMatrix":
        return cls(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

    @classmethod
    def translation(cls, tx: float, ty: float) -> "AffineMatrix":
        return cls(1.0, 0.0, 0.0, 1.0, tx, ty)

    @classmethod
    def scaling(cls, sx: float, sy: float) -> "AffineMatrix":
        return cls(sx, 0.0, 0.0, sy, 0.0, 0.0)

    @classmethod
    def rotation(cls, angle_degrees: float, cx: float = 0.0, cy: float = 0.0) -> "AffineMatrix":
        rad = math.radians(angle_degrees)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        # Rotate around (cx, cy)
        m = cls.translation(cx, cy)
        r = cls(cos_a, sin_a, -sin_a, cos_a, 0.0, 0.0)
        m2 = cls.translation(-cx, -cy)
        return m.multiply(r).multiply(m2)

    def multiply(self, other: "AffineMatrix") -> "AffineMatrix":
        """Multiplies self * other."""
        return AffineMatrix(
            a=self.a * other.a + self.c * other.b,
            b=self.b * other.a + self.d * other.b,
            c=self.a * other.c + self.c * other.d,
            d=self.b * other.c + self.d * other.d,
            tx=self.a * other.tx + self.c * other.ty + self.tx,
            ty=self.b * other.tx + self.d * other.ty + self.ty,
        )

    def transform_point(self, p: Point2D) -> Point2D:
        """Transforms a 2D point."""
        nx = self.a * p.x + self.c * p.y + self.tx
        ny = self.b * p.x + self.d * p.y + self.ty
        return Point2D(nx, ny)

    def transform_rect(self, rect: Rect2D) -> Rect2D:
        """Transforms bounding box corners and computes the new axis-aligned bounding box."""
        pts = [
            self.transform_point(Point2D(rect.left, rect.top)),
            self.transform_point(Point2D(rect.right, rect.top)),
            self.transform_point(Point2D(rect.right, rect.bottom)),
            self.transform_point(Point2D(rect.left, rect.bottom)),
        ]
        min_x = min(p.x for p in pts)
        max_x = max(p.x for p in pts)
        min_y = min(p.y for p in pts)
        max_y = max(p.y for p in pts)
        return Rect2D(min_x, min_y, max_x - min_x, max_y - min_y)
