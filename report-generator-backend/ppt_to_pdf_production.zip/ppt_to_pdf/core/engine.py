"""
PPT2PDFEngine Pipeline Orchestrator.
Coordinates package inspection, slide slicing, OpenXML parsing, typography layout,
and multi-threaded vector PDF canvas generation.
"""

import os
import io
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional, Union, Callable, Tuple, Dict
import pymupdf
from ..config import ConversionConfig
from ..typography.font_metrics import FontMetrics
from ..typography.font_manager import FontManager
from ..openxml.package import PPTXPackage
from ..openxml.master_resolver import MasterResolver
from ..openxml.slide_parser import SlideParser
from ..canvas.mupdf_canvas import MuPDFCanvas
from ..renderers.slide_renderer import SlideRenderer
from ..utils.logger import get_logger
from .context import RenderContext
from .exceptions import PPT2PDFException

logger = get_logger(__name__)


def parse_slide_range(selection: Union[str, int, slice, List[int], None], total_slides: int) -> List[int]:
    """
    Parses slide range specifications (1-based human indexing) into 0-based slide indices.
    """
    if selection is None or selection == "all" or selection == "*":
        return list(range(total_slides))

    if isinstance(selection, slice):
        return list(range(total_slides))[selection]

    if isinstance(selection, int):
        idx = selection - 1 if selection > 0 else total_slides + selection
        if 0 <= idx < total_slides:
            return [idx]
        raise IndexError(f"Slide index {selection} out of range (total slides: {total_slides})")

    if isinstance(selection, (list, tuple)):
        indices = []
        for item in selection:
            indices.extend(parse_slide_range(item, total_slides))
        return indices

    if isinstance(selection, str):
        indices = []
        for token in selection.split(","):
            token = token.strip()
            if not token:
                continue
            if "-" in token:
                parts = token.split("-", 1)
                start_str, end_str = parts[0].strip(), parts[1].strip()
                if start_str and not end_str:
                    s_idx = int(start_str) - 1
                    e_idx = total_slides
                elif not start_str and end_str:
                    s_idx = 0
                    e_idx = int(end_str)
                else:
                    s_idx = int(start_str) - 1
                    e_idx = int(end_str)
                s_idx = max(0, min(s_idx, total_slides))
                e_idx = max(0, min(e_idx, total_slides))
                indices.extend(list(range(s_idx, e_idx)))
            else:
                s_num = int(token)
                idx = s_num - 1 if s_num > 0 else total_slides + s_num
                if 0 <= idx < total_slides:
                    indices.append(idx)
        return indices

    return list(range(total_slides))


def _process_slide_worker(args: Tuple[str, int, int, int, dict, List[str], str]) -> Tuple[int, Optional[bytes], str]:
    """Top-level standalone worker function for multi-process parallel slide rendering."""
    source_path, s_idx, out_idx, total_selected, config_dict, additional_font_dirs, fallback_font = args
    from ..config import ConversionConfig
    from ..typography.font_manager import FontManager
    from ..typography.font_metrics import FontMetrics
    from ..openxml.package import PPTXPackage
    from ..openxml.master_resolver import MasterResolver
    from ..openxml.slide_parser import SlideParser
    from ..renderers.slide_renderer import SlideRenderer
    from ..canvas.mupdf_canvas import MuPDFCanvas
    from .context import RenderContext

    cfg = ConversionConfig(**config_dict)
    fm = FontManager(additional_dirs=additional_font_dirs, fallback_font=fallback_font)
    shared_metrics = FontMetrics(font_manager=fm)
    pkg = PPTXPackage(source_path)
    try:
        mr = MasterResolver(pkg)
        sp = SlideParser(pkg, master_resolver=mr)
        slide_path = pkg.slide_paths[s_idx]
        slide_model = sp.parse_slide(slide_path, slide_index=s_idx)
        if slide_model is None or (slide_model.is_hidden and cfg.skip_hidden_slides):
            return (out_idx, None, "")

        canvas = MuPDFCanvas(font_manager=fm)
        ctx = RenderContext(
            slide_width=slide_model.width,
            slide_height=slide_model.height,
            config=cfg,
            font_manager=fm,
            color_engine=mr.get_theme_for_slide(slide_path).create_color_engine(),
            slide_number=out_idx + 1,
            total_slides=total_selected,
        )

        sr = SlideRenderer(font_metrics=shared_metrics)
        sr.render_slide(slide_model, canvas, ctx)
        pdf_bytes = canvas.to_bytes()
        return (out_idx, pdf_bytes, slide_model.title)
    finally:
        pkg.close()


class PPT2PDFEngine:
    """
    Core conversion engine with multi-process parallel slide rendering.
    """
    def __init__(self, config: Optional[ConversionConfig] = None):
        self.config = config or ConversionConfig()
        self.font_manager = FontManager(
            additional_dirs=self.config.additional_font_dirs,
            fallback_font=self.config.fallback_font,
        )

    def _determine_workers(self, num_slides: int) -> int:
        if self.config.workers is not None and self.config.workers > 0:
            return min(self.config.workers, num_slides)
        cpu_count = os.cpu_count() or 4
        return min(max(1, cpu_count), num_slides, 32)

    def convert(
        self,
        source: Union[str, Path, bytes, io.BytesIO],
        destination: Union[str, Path, io.BytesIO],
        slide_selection: Optional[Union[str, int, slice, List[int]]] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> None:
        start_time = time.time()
        package = PPTXPackage(source)
        try:
            slide_paths = package.slide_paths
            total_available = len(slide_paths)
            if total_available == 0:
                raise PPT2PDFException("No slides found in the presentation.")

            effective_selection = slide_selection if slide_selection is not None else self.config.slide_selection
            selected_indices = parse_slide_range(effective_selection, total_available)
            total_selected = len(selected_indices)

            master_resolver = MasterResolver(package)
            workers = self._determine_workers(total_selected)

            if workers <= 1 or total_selected <= 1:
                converted_count = self._convert_sequential(
                    package, master_resolver, slide_paths, selected_indices, destination, progress_callback
                )
            else:
                converted_count = self._convert_parallel(
                    source, package, master_resolver, slide_paths, selected_indices, destination, workers, progress_callback
                )

            elapsed = time.time() - start_time
            logger.info(f"Successfully converted {converted_count} slides to PDF in {elapsed:.2f}s using {workers} worker(s)")

        finally:
            package.close()

    def _convert_sequential(
        self,
        package: PPTXPackage,
        master_resolver: MasterResolver,
        slide_paths: List[str],
        selected_indices: List[int],
        destination: Union[str, Path, io.BytesIO],
        progress_callback: Optional[Callable[[int, int], None]],
    ) -> int:
        slide_parser = SlideParser(package, master_resolver=master_resolver)
        shared_metrics = FontMetrics(font_manager=self.font_manager)
        slide_renderer = SlideRenderer(font_metrics=shared_metrics)
        canvas = MuPDFCanvas(font_manager=self.font_manager)

        converted_count = 0
        for out_idx, s_idx in enumerate(selected_indices):
            slide_path = slide_paths[s_idx]
            slide_model = slide_parser.parse_slide(slide_path, slide_index=s_idx)
            if slide_model is None or (slide_model.is_hidden and self.config.skip_hidden_slides):
                continue

            context = RenderContext(
                slide_width=slide_model.width,
                slide_height=slide_model.height,
                config=self.config,
                font_manager=self.font_manager,
                color_engine=master_resolver.get_theme_for_slide(slide_path).create_color_engine(),
                slide_number=converted_count + 1,
                total_slides=len(selected_indices),
            )

            slide_renderer.render_slide(slide_model, canvas, context)
            converted_count += 1

            if progress_callback:
                progress_callback(out_idx + 1, len(selected_indices))

        canvas.save(destination)
        return converted_count

    def _render_thread_task(
        self,
        package: PPTXPackage,
        master_resolver: MasterResolver,
        slide_path: str,
        s_idx: int,
        out_idx: int,
        total_selected: int,
    ) -> Tuple[int, Optional[MuPDFCanvas], str]:
        slide_parser = SlideParser(package, master_resolver=master_resolver)
        slide_model = slide_parser.parse_slide(slide_path, slide_index=s_idx)
        if slide_model is None or (slide_model.is_hidden and self.config.skip_hidden_slides):
            return (out_idx, None, "")

        canvas = MuPDFCanvas(font_manager=self.font_manager)
        context = RenderContext(
            slide_width=slide_model.width,
            slide_height=slide_model.height,
            config=self.config,
            font_manager=self.font_manager,
            color_engine=master_resolver.get_theme_for_slide(slide_path).create_color_engine(),
            slide_number=out_idx + 1,
            total_slides=total_selected,
        )

        slide_renderer = SlideRenderer(font_metrics=FontMetrics(font_manager=self.font_manager))
        slide_renderer.render_slide(slide_model, canvas, context)
        return (out_idx, canvas, slide_model.title)

    def _convert_parallel(
        self,
        source: Union[str, Path, bytes, io.BytesIO],
        package: PPTXPackage,
        master_resolver: MasterResolver,
        slide_paths: List[str],
        selected_indices: List[int],
        destination: Union[str, Path, io.BytesIO],
        workers: int,
        progress_callback: Optional[Callable[[int, int], None]],
    ) -> int:
        from concurrent.futures import ProcessPoolExecutor
        total_selected = len(selected_indices)
        rendered_bytes_or_canvas: Dict[int, Tuple[Union[bytes, MuPDFCanvas, None], str]] = {}
        completed_count = 0

        # If source is a physical file on disk, use true multi-process parallelism across all CPU cores
        if isinstance(source, (str, Path)) and os.path.isfile(str(source)):
            source_path_str = str(Path(source).resolve())
            config_dict = {
                "dpi": self.config.dpi,
                "embed_fonts": self.config.embed_fonts,
                "fallback_font": self.config.fallback_font,
                "skip_hidden_slides": self.config.skip_hidden_slides,
                "include_speaker_notes": self.config.include_speaker_notes,
                "generate_bookmarks": self.config.generate_bookmarks,
                "canvas_backend": self.config.canvas_backend,
                "render_charts": self.config.render_charts,
                "render_tables": self.config.render_tables,
                "render_shapes": self.config.render_shapes,
                "render_images": self.config.render_images,
                "render_backgrounds": self.config.render_backgrounds,
                "workers": self.config.workers,
            }
            args_list = [
                (
                    source_path_str,
                    s_idx,
                    out_idx,
                    total_selected,
                    config_dict,
                    self.config.additional_font_dirs,
                    self.config.fallback_font,
                )
                for out_idx, s_idx in enumerate(selected_indices)
            ]

            try:
                with ProcessPoolExecutor(max_workers=workers) as executor:
                    futures = [executor.submit(_process_slide_worker, arg) for arg in args_list]
                    for future in as_completed(futures):
                        out_idx, pdf_bytes, title = future.result()
                        rendered_bytes_or_canvas[out_idx] = (pdf_bytes, title)
                        completed_count += 1
                        if progress_callback:
                            progress_callback(completed_count, total_selected)
            except Exception as e:
                logger.debug(f"ProcessPoolExecutor fallback to ThreadPoolExecutor: {e}")
                rendered_bytes_or_canvas.clear()
                completed_count = 0

        # Fallback to ThreadPoolExecutor if in-memory buffer or ProcessPool failed
        if not rendered_bytes_or_canvas:
            with ThreadPoolExecutor(max_workers=workers) as executor:
                future_to_idx = {
                    executor.submit(
                        self._render_thread_task,
                        package,
                        master_resolver,
                        slide_paths[s_idx],
                        s_idx,
                        out_idx,
                        total_selected,
                    ): out_idx
                    for out_idx, s_idx in enumerate(selected_indices)
                }

                for future in as_completed(future_to_idx):
                    out_idx, canvas, title = future.result()
                    rendered_bytes_or_canvas[out_idx] = (canvas, title)
                    completed_count += 1
                    if progress_callback:
                        progress_callback(completed_count, total_selected)

        # In-order master assembly
        master_canvas = MuPDFCanvas(font_manager=self.font_manager)
        converted_count = 0

        for out_idx in range(total_selected):
            item, title = rendered_bytes_or_canvas.get(out_idx, (None, ""))
            if item is None:
                continue

            if isinstance(item, bytes) and len(item) > 0:
                sub_doc = pymupdf.open(stream=item, filetype="pdf")
                master_canvas.doc.insert_pdf(sub_doc)
                converted_count += 1
                if self.config.generate_bookmarks and title:
                    master_canvas.add_bookmark(title=title, page_number=master_canvas._page_count)
            elif isinstance(item, MuPDFCanvas) and len(item.doc) > 0:
                master_canvas.insert_pdf_from_canvas(item)
                converted_count += 1
                if self.config.generate_bookmarks and title:
                    master_canvas.add_bookmark(title=title, page_number=master_canvas._page_count)

        master_canvas.save(destination)
        return converted_count
