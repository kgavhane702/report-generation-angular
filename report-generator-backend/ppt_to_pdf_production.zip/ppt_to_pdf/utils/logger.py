"""
Logging configuration for PPT to PDF converter.
"""

import logging
import sys

LOGGER_NAME = "ppt_to_pdf"


def get_logger(name: str = LOGGER_NAME, level: int = logging.INFO) -> logging.Logger:
    """Returns a configured logger instance."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            fmt="[%(levelname)s] %(asctime)s - %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(level)
    return logger
