"""
Unit conversion utilities for PowerPoint (OpenXML) and PDF dimensions.
OpenXML uses English Metric Units (EMU):
1 inch = 914,400 EMUs
1 pt = 12,700 EMUs
1 cm = 360,000 EMUs
PDF uses Points (pt):
72 points = 1 inch
"""

import math

EMU_PER_INCH = 914400
EMU_PER_PT = 12700
EMU_PER_CM = 360000
EMU_PER_MM = 36000
PT_PER_INCH = 72.0


def emu_to_pt(emu: float | int | None) -> float:
    """Converts EMUs (English Metric Units) to Points."""
    if emu is None:
        return 0.0
    return float(emu) / EMU_PER_PT


def pt_to_emu(pt: float | int | None) -> int:
    """Converts Points to EMUs."""
    if pt is None:
        return 0
    return int(round(float(pt) * EMU_PER_PT))


def emu_to_inch(emu: float | int | None) -> float:
    """Converts EMUs to Inches."""
    if emu is None:
        return 0.0
    return float(emu) / EMU_PER_INCH


def pt_to_inch(pt: float | int | None) -> float:
    """Converts Points to Inches."""
    if pt is None:
        return 0.0
    return float(pt) / PT_PER_INCH


def angle_to_degrees(angle_val: float | int | None) -> float:
    """
    Converts PowerPoint angle representations (usually 60000ths of a degree) to degrees.
    """
    if angle_val is None:
        return 0.0
    val = float(angle_val)
    # DrawingML angles are typically specified in 60,000ths of a degree (cd)
    if abs(val) > 360:
        return val / 60000.0
    return val


def angle_to_radians(angle_val: float | int | None) -> float:
    """Converts PowerPoint angle representation to radians."""
    deg = angle_to_degrees(angle_val)
    return math.radians(deg)


def hundredths_pt_to_pt(val: float | int | None) -> float:
    """
    DrawingML font sizes (sz) are stored in 100ths of a point (e.g. 1800 = 18pt).
    """
    if val is None:
        return 12.0
    return float(val) / 100.0
