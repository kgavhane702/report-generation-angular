"""
Image processing utilities for PPT to PDF conversion.
Handles format conversions, EMF/WMF metafile rasterization, cropping, and color conversions.
"""

import io
from typing import Tuple, Optional
from PIL import Image
from .logger import get_logger

logger = get_logger(__name__)


def process_image_bytes(
    image_bytes: bytes,
    crop: Optional[Tuple[float, float, float, float]] = None,
    target_dpi: int = 300,
) -> Optional[bytes]:
    """
    Processes image bytes (including EMF/WMF) into a clean, PDF-ready PNG or JPEG byte stream.
    
    :param image_bytes: Raw binary bytes of the image
    :param crop: Optional tuple (left, top, right, bottom) crop ratios between 0.0 and 1.0 (from DrawingML srcRect)
    :param target_dpi: Target DPI resolution
    :return: Processed image bytes in PNG format, or None if invalid.
    """
    if not image_bytes:
        return None

    try:
        img = Image.open(io.BytesIO(image_bytes))
        
        # Apply crop if provided (in relative percentages)
        if crop:
            l, t, r, b = crop
            w, h = img.size
            # OpenXML srcRect: l=left%, t=top%, r=right%, b=bottom% cropped away
            crop_box = (
                int(round(l * w)),
                int(round(t * h)),
                int(round((1.0 - r) * w)),
                int(round((1.0 - b) * h)),
            )
            # Ensure valid non-inverted crop box
            if crop_box[2] > crop_box[0] and crop_box[3] > crop_box[1]:
                img = img.crop(crop_box)

        # Convert image modes if necessary
        if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
            # Keep alpha channel
            output_format = "PNG"
        elif img.mode != "RGB":
            img = img.convert("RGB")
            output_format = "PNG"
        else:
            output_format = "PNG"

        out_buffer = io.BytesIO()
        img.save(out_buffer, format=output_format, dpi=(target_dpi, target_dpi))
        return out_buffer.getvalue()

    except Exception as e:
        logger.debug(f"Failed to process image bytes: {e}")
        # Try raw pass-through if PNG/JPG
        if image_bytes.startswith(b"\x89PNG") or image_bytes.startswith(b"\xff\xd8\xff"):
            return image_bytes
        return None


def get_image_dimensions(image_bytes: bytes) -> Tuple[int, int]:
    """Returns (width, height) in pixels of the image."""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        return img.size
    except Exception:
        return (0, 0)


def extract_emf_text_records(emf_data: bytes) -> list:
    """
    Extracts embedded vector text records from an EMF metafile binary.
    Returns list of dicts: [{'text': str, 'norm_x': float, 'norm_y': float, 'norm_w': float, 'norm_h': float, 'font_size': float}]
    """
    if not emf_data or len(emf_data) < 88 or not emf_data.startswith(b"\x01\x00\x00\x00"):
        return []

    import struct
    try:
        rclBounds = struct.unpack('<iiii', emf_data[8:24])
        right = max(1, rclBounds[2])
        bottom = max(1, rclBounds[3])

        records = []
        offset = 0

        while offset < len(emf_data) - 8:
            iType, nSize = struct.unpack('<II', emf_data[offset:offset+8])
            if nSize < 8:
                break

            # EMR_EXTTEXTOUTW = 84, EMR_EXTTEXTOUTA = 83
            if iType in (83, 84):
                rec_body = emf_data[offset+8:offset+nSize]
                if len(rec_body) >= 68:
                    bx0, by0, bx1, by1 = struct.unpack('<iiii', rec_body[:16])
                    nChars, offString = struct.unpack('<II', rec_body[36:44])
                    str_offset = offset + offString
                    if iType == 84:
                        raw_str = emf_data[str_offset:str_offset + nChars * 2]
                        text = raw_str.decode('utf-16-le', errors='ignore')
                    else:
                        raw_str = emf_data[str_offset:str_offset + nChars]
                        text = raw_str.decode('latin1', errors='ignore')

                    text = text.strip()
                    if text:
                        norm_x0 = max(0.0, bx0 / right)
                        norm_y0 = max(0.0, by0 / bottom)
                        norm_w = max(0.001, (bx1 - bx0) / right)
                        norm_h = max(0.001, (by1 - by0) / bottom)
                        font_sz = max(5.0, (by1 - by0) * 0.75)
                        records.append({
                            'text': text,
                            'norm_x': norm_x0,
                            'norm_y': norm_y0,
                            'norm_w': norm_w,
                            'norm_h': norm_h,
                            'font_size': font_sz,
                        })

            offset += nSize

        return records
    except Exception:
        return []

