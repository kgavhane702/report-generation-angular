"""
Package executable entry point for python -m ppt_to_pdf.
"""

import sys
from .cli import main

if __name__ == "__main__":
    sys.exit(main())
