"""
Global configuration dataclass and options for PPT to PDF conversion.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Union
from pathlib import Path


@dataclass
class ConversionConfig:
    """
    Configuration options for PPT to PDF conversion.
    """
    # Output visual settings
    dpi: int = 300
    embed_fonts: bool = True
    fallback_font: str = "Arial"
    additional_font_dirs: List[Union[str, Path]] = field(default_factory=list)
    
    # Slide selection and processing
    slide_selection: Optional[Union[str, int, slice, List[int]]] = None
    skip_hidden_slides: bool = False
    include_speaker_notes: bool = False
    generate_bookmarks: bool = True
    
    # Canvas backend selection: "mupdf" (default & fastest) or "reportlab"
    canvas_backend: str = "mupdf"
    
    # Rendering fidelity flags
    render_charts: bool = True
    render_tables: bool = True
    render_shapes: bool = True
    render_images: bool = True
    render_backgrounds: bool = True
    
    # Performance & Concurrency
    workers: Optional[int] = None  # None/0 = auto (os.cpu_count()), 1 = sequential, >1 = explicit threads
    
    # Logging and diagnostics
    verbose: bool = False
    debug: bool = False
