param (
    [string]$pptxPath = "d:\app\ppt-pdf-conversion\sample_ppt.pptx",
    [string]$pdfPath = "d:\app\ppt-pdf-conversion\ground_truth\ground_truth.pdf"
)

$gtDir = [System.IO.Path]::GetDirectoryName($pdfPath)
if (-not (Test-Path $gtDir)) {
    New-Item -ItemType Directory -Path $gtDir -Force | Out-Null
}

$ppt = New-Object -ComObject PowerPoint.Application
try {
    # Open(FileName, ReadOnly, Untitled, WithWindow)
    # WithWindow = msoFalse (0)
    $pres = $ppt.Presentations.Open($pptxPath, -1, 0, 0)
    
    # 32 = ppSaveAsPDF
    $pres.SaveAs($pdfPath, 32)
    $pres.Close()

    Write-Host "SUCCESS: Exported native PowerPoint PDF to $pdfPath"
} catch {
    Write-Error $_
} finally {
    $ppt.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($ppt) | Out-Null
    [System.GC]::Collect()
}
