"""
Ground Truth Generator using native Microsoft PowerPoint COM automation.
Exports sample_ppt.pptx to native PDF, extracts high-res PNGs, and saves structured ground truth text data.
"""

import os
import sys
import json
import pathlib
import pymupdf
import win32com.client

BASE_DIR = pathlib.Path(__file__).parent.parent.resolve()
GT_DIR = BASE_DIR / "ground_truth"
GT_SLIDES_DIR = GT_DIR / "slides"
PPTX_PATH = BASE_DIR / "sample_ppt.pptx"
GT_PDF_PATH = GT_DIR / "ground_truth.pdf"
GT_META_PATH = GT_DIR / "ground_truth_metadata.json"


def generate_ground_truth():
    GT_DIR.mkdir(exist_ok=True)
    GT_SLIDES_DIR.mkdir(exist_ok=True)

    print(f"Generating Ground Truth from native PowerPoint: {PPTX_PATH.name}")
    
    # 1. Convert PPTX to PDF using native MS PowerPoint COM
    ppt_app = win32com.client.DispatchEx("PowerPoint.Application")
    ppt_app.Visible = 1
    
    try:
        abs_pptx = str(PPTX_PATH)
        abs_pdf = str(GT_PDF_PATH)
        
        pres = ppt_app.Presentations.Open(abs_pptx, ReadOnly=True, Untitled=False, WithWindow=False)
        # 32 = ppSaveAsPDF
        pres.SaveAs(abs_pdf, 32)
        pres.Close()
        print(f"Exported native PowerPoint PDF to: {GT_PDF_PATH}")
    finally:
        ppt_app.Quit()

    # 2. Extract slide images and structured text blocks
    doc = pymupdf.open(str(GT_PDF_PATH))
    slides_meta = []

    print(f"Extracting {len(doc)} slide images and text metadata at 150 DPI...")
    for idx, page in enumerate(doc):
        slide_num = idx + 1
        img_path = GT_SLIDES_DIR / f"slide_{slide_num}.png"
        pix = page.get_pixmap(dpi=150)
        pix.save(str(img_path))

        # Extract detailed text blocks and spans
        page_dict = page.get_text("dict")
        blocks_data = []

        for b in page_dict.get("blocks", []):
            if b.get("type") != 0:  # 0 = text
                continue
            
            lines_data = []
            for line in b.get("lines", []):
                spans_data = []
                line_text = ""
                for span in line.get("spans", []):
                    span_text = span.get("text", "")
                    line_text += span_text
                    spans_data.append({
                        "text": span_text,
                        "font": span.get("font", ""),
                        "size": round(span.get("size", 0.0), 2),
                        "color": span.get("color", 0),
                        "bbox": [round(coord, 2) for coord in span.get("bbox", [])],
                        "flags": span.get("flags", 0),
                    })
                
                lines_data.append({
                    "text": line_text.strip(),
                    "bbox": [round(coord, 2) for coord in line.get("bbox", [])],
                    "spans": spans_data
                })

            if lines_data:
                blocks_data.append({
                    "bbox": [round(coord, 2) for coord in b.get("bbox", [])],
                    "lines": lines_data
                })

        slides_meta.append({
            "slide_num": slide_num,
            "width": page.rect.width,
            "height": page.rect.height,
            "blocks": blocks_data
        })

    with open(GT_META_PATH, "w", encoding="utf-8") as f:
        json.dump(slides_meta, f, indent=2, ensure_ascii=False)

    print(f"Saved ground truth metadata to: {GT_META_PATH}")
    print(f"Ground Truth setup completed successfully for {len(doc)} slides!")


if __name__ == "__main__":
    generate_ground_truth()
