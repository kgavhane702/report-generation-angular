"""
Advanced PPT-to-PDF Diff Engine.

Provides deep visual, structural, and typographic comparison between
generated PDF output and native PowerPoint Ground Truth:
1. 3-Panel High-Resolution Visual Diff (Original Ground Truth | Generated Output | Heatmap & Overlay)
2. Bounding Box & Alignment Error Detection (del_x, del_y, del_h, empty space)
3. Line Pitch & Line Spacing Verification
4. Character-level & Word Wrap Exactness Scoring
5. Comprehensive Console & JSON Reporting
"""

import os
import sys
import json
import argparse
import difflib
import pathlib
from typing import List, Dict, Any, Tuple, Optional
import pymupdf
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageOps, ImageEnhance

BASE_DIR = pathlib.Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(BASE_DIR))

from ppt_to_pdf import PPT2PDFConverter, ConversionConfig

DEFAULT_GT_PDF = BASE_DIR / "ground_truth" / "ground_truth.pdf"
DEFAULT_DIFF_DIR = BASE_DIR / "ground_truth" / "diffs"


def normalize_text(text: str) -> str:
    """Normalize whitespace and invisible glyphs for strict comparison."""
    if not text:
        return ""
    return (
        text.replace("\xa0", " ")
        .replace("\xad", "-")
        .replace("\u200b", "")
        .replace("\u2010", "-")
        .replace("\u2011", "-")
        .replace("\u2012", "-")
        .replace("\u2013", "-")
        .replace("\u2014", "-")
        .replace("\uf0f1", "\u203a")
        .replace("\uf098", "•")
        .replace("\uf0e9", "•")
        .replace("\uf0ea", "•")
        .replace("▲", "•")
        .replace("▼", "•")
        .replace("\u203a ", "\u203a")
        .replace("\u037e", ";")
        .strip()
    )


def extract_page_lines(page: pymupdf.Page) -> List[Dict[str, Any]]:
    """Extracts true visual lines by consolidating same-baseline word spans."""
    p_dict = page.get_text("dict")
    raw_lines = []

    for b_idx, b in enumerate(p_dict.get("blocks", [])):
        if b.get("type") != 0:
            continue
        for line in b.get("lines", []):
            spans = line.get("spans", [])
            span_texts = []
            for s in spans:
                t = s.get("text", "")
                if t == "\x00" and any(k in s.get("font", "") for k in ("Wingdings", "Symbol", "Webdings")):
                    t = "•"
                span_texts.append(t)
            raw_text = "".join(span_texts)
            norm_text = normalize_text(raw_text)
            if not norm_text:
                continue

            primary_font_size = spans[0].get("size", 0.0) if spans else 0.0
            primary_font = spans[0].get("font", "") if spans else ""

            raw_bbox = list(line.get("bbox", [0, 0, 0, 0]))
            raw_lines.append({
                "text": norm_text,
                "raw_text": raw_text,
                "bbox": [round(c, 2) for c in raw_bbox],
                "font_size": round(primary_font_size, 2),
                "font_family": primary_font,
                "spans": spans,
                "block_id": b_idx,
            })

    # Merge same-baseline word runs (e.g. from justified text operators in PDF)
    merged_lines: List[Dict[str, Any]] = []
    for line in raw_lines:
        max_gap = 14.0
        if (
            merged_lines
            and abs(merged_lines[-1]["bbox"][1] - line["bbox"][1]) < 2.0
            and abs(merged_lines[-1]["bbox"][3] - line["bbox"][3]) < 2.0
            and line["bbox"][0] >= merged_lines[-1]["bbox"][0] - 2.0
            and (line["bbox"][0] - merged_lines[-1]["bbox"][2]) < max_gap
            and abs(merged_lines[-1]["font_size"] - line["font_size"]) < 3.5
        ):
            prev = merged_lines[-1]
            sep = "" if (prev["text"].endswith("-") or prev["text"].endswith("/") or line["text"].startswith("-")) else " "
            prev["text"] = prev["text"] + sep + line["text"]
            prev["raw_text"] = prev["raw_text"] + sep + line["raw_text"]
            prev["bbox"][2] = max(prev["bbox"][2], line["bbox"][2])
            prev["spans"].extend(line["spans"])
        else:
            merged_lines.append(line)

    return merged_lines


def generate_3panel_visual_diff(
    gt_page: pymupdf.Page,
    test_page: pymupdf.Page,
    gt_lines: List[Dict[str, Any]],
    test_lines: List[Dict[str, Any]],
    matches: List[Dict[str, Any]],
    missing: List[Dict[str, Any]],
    extra: List[Dict[str, Any]],
    out_path: pathlib.Path,
    dpi: int = 200,
) -> None:
    """
    Renders a comprehensive, high-contrast, razor-sharp 3-panel composite:
    [ Panel 1: Ground Truth ] | [ Panel 2: Generated Output ] | [ Panel 3: High-Contrast Difference Overlay ]
    """
    # 1. Render Pixmaps at high resolution (200 DPI)
    gt_pix = gt_page.get_pixmap(dpi=dpi)
    test_pix = test_page.get_pixmap(dpi=dpi)

    gt_img = Image.frombytes("RGB", [gt_pix.width, gt_pix.height], gt_pix.samples)
    test_img = Image.frombytes("RGB", [test_pix.width, test_pix.height], test_pix.samples)

    # Ensure equal dimensions
    w = max(gt_img.width, test_img.width)
    h = max(gt_img.height, test_img.height)
    if gt_img.size != (w, h):
        gt_img = gt_img.resize((w, h), Image.Resampling.LANCZOS)
    if test_img.size != (w, h):
        test_img = test_img.resize((w, h), Image.Resampling.LANCZOS)

    # 2. Build crisp grayscale base from GT (so text & layout remain 100% readable)
    gray_base = ImageOps.grayscale(gt_img).convert("RGB")
    enhancer = ImageEnhance.Brightness(gray_base)
    crisp_bg = enhancer.enhance(1.10)

    # 3. High-Contrast Pixel Difference Calculation
    diff = ImageChops.difference(gt_img, test_img)
    diff_data = diff.load()
    gt_data = gt_img.load()
    test_data = test_img.load()

    diff_img = crisp_bg.copy()
    diff_data_out = diff_img.load()

    for y in range(h):
        for x in range(w):
            dr, dg, db = diff_data[x, y]
            if max(dr, dg, db) > 20:
                gt_r, gt_g, gt_b = gt_data[x, y]
                ts_r, ts_g, ts_b = test_data[x, y]
                gt_lum = (gt_r + gt_g + gt_b) / 3.0
                ts_lum = (ts_r + ts_g + ts_b) / 3.0

                if gt_lum < ts_lum - 15:
                    diff_data_out[x, y] = (230, 0, 40)   # Crimson Red (Missing in output)
                elif ts_lum < gt_lum - 15:
                    diff_data_out[x, y] = (0, 130, 240)  # Electric Blue (Extra/Shifted in output)
                else:
                    diff_data_out[x, y] = (255, 130, 0)  # Orange (Color/Geometry delta)

    # 4. Scale factor from pt to pixel
    scale_x = w / gt_page.rect.width
    scale_y = h / gt_page.rect.height
    diff_draw = ImageDraw.Draw(diff_img)

    for m in matches:
        g_box = m["gt"]["bbox"]
        t_box = m["test"]["bbox"]
        dx, dy = m["dx"], m["dy"]
        gx0, gy0, gx1, gy1 = [c * scale_x for c in [g_box[0], g_box[1], g_box[2], g_box[3]]]
        tx0, ty0, tx1, ty1 = [c * scale_x for c in [t_box[0], t_box[1], t_box[2], t_box[3]]]

        if abs(dx) > 3.0 or abs(dy) > 3.0:
            diff_draw.rectangle([tx0, ty0, tx1, ty1], outline=(255, 130, 0), width=2)
            diff_draw.line([(gx0 + gx1)/2, (gy0 + gy1)/2, (tx0 + tx1)/2, (ty0 + ty1)/2], fill=(255, 69, 0), width=2)
        else:
            diff_draw.rectangle([tx0, ty0, tx1, ty1], outline=(34, 187, 51), width=1)

    for mis in missing:
        mb = mis["bbox"]
        x0, y0, x1, y1 = [c * scale_x for c in [mb[0], mb[1], mb[2], mb[3]]]
        diff_draw.rectangle([x0, y0, x1, y1], outline=(230, 0, 40), width=2)

    for ext in extra:
        eb = ext["bbox"]
        x0, y0, x1, y1 = [c * scale_x for c in [eb[0], eb[1], eb[2], eb[3]]]
        diff_draw.rectangle([x0, y0, x1, y1], outline=(0, 130, 240), width=2)

    # 5. Assemble 3-Panel Side-by-Side Canvas with Header & Legend Footer
    header_h = 55
    footer_h = 40
    comp_w = w * 3 + 40
    comp_h = h + header_h + footer_h
    composite = Image.new("RGB", (comp_w, comp_h), (240, 243, 246))
    comp_draw = ImageDraw.Draw(composite)

    # Paste panels
    composite.paste(gt_img, (10, header_h))
    composite.paste(test_img, (w + 20, header_h))
    composite.paste(diff_img, (w * 2 + 30, header_h))

    # Panel Borders
    for p_x in (10, w + 20, w * 2 + 30):
        comp_draw.rectangle([p_x, header_h, p_x + w, header_h + h], outline=(170, 185, 200), width=2)

    # Fonts
    try:
        font_title = ImageFont.truetype("arial.ttf", 22)
        font_leg = ImageFont.truetype("arial.ttf", 15)
    except Exception:
        font_title = ImageFont.load_default()
        font_leg = ImageFont.load_default()

    # Header Titles
    comp_draw.text((25, 16), "1. Ground Truth (Native PowerPoint)", fill=(15, 35, 75), font=font_title)
    comp_draw.text((w + 35, 16), "2. Generated Vector PDF (Our Engine)", fill=(15, 35, 75), font=font_title)
    comp_draw.text((w * 2 + 45, 16), "3. High-Contrast Difference Overlay", fill=(180, 15, 15), font=font_title)

    # Footer Legend
    leg_y = h + header_h + 12
    comp_draw.rectangle([w * 2 + 35, leg_y + 2, w * 2 + 50, leg_y + 17], fill=(230, 0, 40))
    comp_draw.text((w * 2 + 55, leg_y), "Missing in Output (Red)", fill=(40, 40, 40), font=font_leg)

    comp_draw.rectangle([w * 2 + 250, leg_y + 2, w * 2 + 265, leg_y + 17], fill=(0, 130, 240))
    comp_draw.text((w * 2 + 270, leg_y), "Extra / Shifted in Output (Blue)", fill=(40, 40, 40), font=font_leg)

    comp_draw.rectangle([w * 2 + 520, leg_y + 2, w * 2 + 535, leg_y + 17], fill=(255, 130, 0))
    comp_draw.text((w * 2 + 540, leg_y), "Color / Style Delta (Orange)", fill=(40, 40, 40), font=font_leg)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    composite.save(str(out_path), quality=95)


def run_diff_on_slide(
    gt_page: pymupdf.Page,
    test_page: pymupdf.Page,
    slide_num: int,
    diff_dir: pathlib.Path,
    pos_tol_pt: float = 2.5,
    font_tol_pt: float = 0.5,
) -> Dict[str, Any]:
    """Compares a single slide and returns structured metrics and visual diff."""
    gt_lines = extract_page_lines(gt_page)
    test_lines = extract_page_lines(test_page)

    matched_gt = set()
    matched_test = set()
    matches = []

    for g_idx, g_line in enumerate(gt_lines):
        g_text = g_line["text"]
        g_bbox = g_line["bbox"]
        g_sz = g_line["font_size"]

        best_t_idx = None
        best_sim = 0.0
        best_dist = float("inf")

        for t_idx, t_line in enumerate(test_lines):
            if t_idx in matched_test:
                continue
            t_text = t_line["text"]
            t_bbox = t_line["bbox"]

            sim = difflib.SequenceMatcher(None, g_text, t_text).ratio()
            dx = abs(t_bbox[0] - g_bbox[0])
            dy = abs(t_bbox[1] - g_bbox[1])
            dist = (dx**2 + dy**2)**0.5

            if sim > 0.65 or g_text in t_text or t_text in g_text:
                if dist > 120.0 and sim < 0.95 and g_text != t_text:
                    continue
                if sim > best_sim or (abs(sim - best_sim) < 0.1 and dist < best_dist):
                    best_sim = sim
                    best_t_idx = t_idx
                    best_dist = dist

        if best_t_idx is not None and best_sim >= 0.50:
            matched_gt.add(g_idx)
            matched_test.add(best_t_idx)
            t_line = test_lines[best_t_idx]
            dx = t_line["bbox"][0] - g_bbox[0]
            dy = t_line["bbox"][1] - g_bbox[1]
            dh = (t_line["bbox"][3] - t_line["bbox"][1]) - (g_bbox[3] - g_bbox[1])
            dsz = t_line["font_size"] - g_sz

            matches.append({
                "gt": g_line,
                "test": t_line,
                "similarity": round(best_sim, 3),
                "dx": round(dx, 2),
                "dy": round(dy, 2),
                "dh": round(dh, 2),
                "dsz": round(dsz, 2),
                "pos_ok": abs(dx) <= pos_tol_pt and abs(dy) <= pos_tol_pt,
                "font_ok": abs(dsz) <= font_tol_pt,
                "exact_wrap": best_sim >= 0.95 and g_line["text"] == t_line["text"]
            })

    missing = [gt_lines[i] for i in range(len(gt_lines)) if i not in matched_gt]
    extra = [test_lines[i] for i in range(len(test_lines)) if i not in matched_test]

    total_gt = len(gt_lines)
    text_match_pct = (len(matches) / total_gt * 100.0) if total_gt else 100.0
    wrap_match_pct = (sum(1 for m in matches if m["exact_wrap"]) / total_gt * 100.0) if total_gt else 100.0
    pos_match_pct = (sum(1 for m in matches if m["pos_ok"]) / total_gt * 100.0) if total_gt else 100.0
    font_match_pct = (sum(1 for m in matches if m["font_ok"]) / total_gt * 100.0) if total_gt else 100.0

    # Composite Strict Fidelity Score
    strict_score = (text_match_pct * 0.35 + wrap_match_pct * 0.25 + pos_match_pct * 0.25 + font_match_pct * 0.15)

    diff_img_path = diff_dir / f"diff_slide_{slide_num}.png"
    generate_3panel_visual_diff(gt_page, test_page, gt_lines, test_lines, matches, missing, extra, diff_img_path)

    return {
        "slide_num": slide_num,
        "strict_fidelity_score": round(strict_score, 1),
        "text_match_score": round(text_match_pct, 1),
        "wrap_match_score": round(wrap_match_pct, 1),
        "position_score": round(pos_match_pct, 1),
        "font_size_score": round(font_match_pct, 1),
        "total_gt_lines": total_gt,
        "total_test_lines": len(test_lines),
        "matched_count": len(matches),
        "missing_count": len(missing),
        "extra_count": len(extra),
        "diff_image": str(diff_img_path),
        "matches": matches,
        "missing": missing,
        "extra": extra,
    }


def main():
    parser = argparse.ArgumentParser(description="Advanced PPT-to-PDF Visual & Structural Diff Engine")
    parser.add_argument("--input", "-i", default="sample_ppt.pptx", help="Source PPTX file")
    parser.add_argument("--gt", default=str(DEFAULT_GT_PDF), help="Ground Truth PDF path")
    parser.add_argument("--slides", "-s", default="11", help="Slides to compare (e.g. '6,11' or 'all')")
    parser.add_argument("--out-pdf", "-o", default="diff_output.pdf", help="Output PDF path for test run")
    parser.add_argument("--diff-dir", default=str(DEFAULT_DIFF_DIR), help="Output directory for visual diff PNGs")
    parser.add_argument("--pos-tol", type=float, default=2.5, help="Position tolerance in points (default: 2.5pt)")
    parser.add_argument("--font-tol", type=float, default=0.5, help="Font size tolerance in points (default: 0.5pt)")
    args = parser.parse_args()

    pptx_path = pathlib.Path(args.input)
    gt_pdf_path = pathlib.Path(args.gt)
    diff_dir = pathlib.Path(args.diff_dir)

    if not pptx_path.exists():
        print(f"Error: PPTX file '{pptx_path}' not found.")
        sys.exit(1)
    if not gt_pdf_path.exists():
        print(f"Error: Ground truth PDF '{gt_pdf_path}' not found.")
        sys.exit(1)

    print(f"[DiffEngine] Converting '{pptx_path}' (slides: {args.slides})...")
    conv = PPT2PDFConverter()
    test_pdf_path = conv.convert(pptx_path, args.out_pdf, slide_selection=args.slides)

    gt_doc = pymupdf.open(str(gt_pdf_path))
    test_doc = pymupdf.open(str(test_pdf_path))

    # Parse slide selection
    total_gt = len(gt_doc)
    if args.slides.lower() in ("all", "*"):
        slide_indices = list(range(total_gt))
    else:
        slide_indices = []
        for token in args.slides.split(","):
            token = token.strip()
            if token.isdigit():
                idx = int(token) - 1
                if 0 <= idx < total_gt:
                    slide_indices.append(idx)

    print("\n" + "=" * 80)
    print(" ADVANCED PPT-TO-PDF FIDELITY & DIFF REPORT")
    print("=" * 80)

    overall_scores = []
    for test_page_idx, s_idx in enumerate(slide_indices):
        slide_num = s_idx + 1
        gt_page = gt_doc[s_idx]
        test_page = test_doc[test_page_idx]

        res = run_diff_on_slide(gt_page, test_page, slide_num, diff_dir, pos_tol_pt=args.pos_tol, font_tol_pt=args.font_tol)
        overall_scores.append(res["strict_fidelity_score"])

        print(f"\n--- Slide {slide_num:02d} Comparison ---")
        print(f"  Strict Fidelity Score : {res['strict_fidelity_score']}%")
        print(f"  * Text Content Match  : {res['text_match_score']}% ({res['matched_count']}/{res['total_gt_lines']} lines)")
        print(f"  * Line Wrap / Breaks  : {res['wrap_match_score']}% exact wrap")
        print(f"  * Position Alignment  : {res['position_score']}% within +/-{args.pos_tol}pt")
        print(f"  * Font Size Match     : {res['font_size_score']}% within +/-{args.font_tol}pt")
        print(f"  * 3-Panel Visual Diff : {res['diff_image']}")

        # Top misaligned or missing items
        wrap_mismatches = [m for m in res["matches"] if not m["exact_wrap"]]
        if wrap_mismatches:
            print(f"  [!] Line Wrap / Text Mismatches ({len(wrap_mismatches)}):")
            for wm in wrap_mismatches[:8]:
                print(f"      - GT : {ascii(wm['gt']['text'][:60])}")
                print(f"        GEN: {ascii(wm['test']['text'][:60])}")
            if len(wrap_mismatches) > 8:
                print(f"        ... and {len(wrap_mismatches) - 8} more")

        if res["missing"]:
            print(f"  [!] Missing Lines ({len(res['missing'])}):")
            for m in res["missing"][:5]:
                print(f"      - {ascii(m['text'][:50])} at {m['bbox']}")
            if len(res["missing"]) > 5:
                print(f"      ... and {len(res['missing']) - 5} more")

        sig_shifts = [m for m in res["matches"] if abs(m["dx"]) > 3.0 or abs(m["dy"]) > 3.0]
        if sig_shifts:
            print(f"  [!] Significant Shifts ({len(sig_shifts)}):")
            for s in sig_shifts[:5]:
                print(f"      - {ascii(s['gt']['text'][:40])} dx={s['dx']}pt, dy={s['dy']}pt, dh={s['dh']}pt")

    avg_score = sum(overall_scores) / len(overall_scores) if overall_scores else 0.0
    print("\n" + "=" * 80)
    print(f" OVERALL FIDELITY: {avg_score:.1f}% across {len(slide_indices)} slide(s)")
    print(f" Visual Diffs saved to: {diff_dir.resolve()}")
    print("=" * 80 + "\n")

    summary_path = diff_dir / "summary.json"
    diff_dir.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump({
            "overall_fidelity": round(avg_score, 1),
            "slide_count": len(slide_indices),
            "slides": [
                {
                    "slide": s_idx + 1,
                    "strict_fidelity_score": overall_scores[i]
                }
                for i, s_idx in enumerate(slide_indices)
            ]
        }, f, indent=2)


if __name__ == "__main__":
    main()
