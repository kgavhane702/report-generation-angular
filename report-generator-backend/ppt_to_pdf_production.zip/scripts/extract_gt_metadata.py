"""
Extracts slide PNGs and structured text metadata from ground_truth/ground_truth.pdf.
"""

import os
import json
import pymupdf

GT_DIR = r"d:\app\ppt-pdf-conversion\ground_truth"
GT_PDF = os.path.join(GT_DIR, "ground_truth.pdf")
GT_SLIDES_DIR = os.path.join(GT_DIR, "slides")
GT_META_PATH = os.path.join(GT_DIR, "ground_truth_metadata.json")

os.makedirs(GT_SLIDES_DIR, exist_ok=True)

print(f"Loading {GT_PDF}...")
doc = pymupdf.open(GT_PDF)
print(f"Total slides: {len(doc)}")

slides_meta = []

for idx, page in enumerate(doc):
    slide_num = idx + 1
    # Save slide PNG at 150 DPI
    img_path = os.path.join(GT_SLIDES_DIR, f"slide_{slide_num}.png")
    pix = page.get_pixmap(dpi=150)
    pix.save(img_path)

    # Extract text dictionary
    p_dict = page.get_text("dict")
    blocks_data = []

    for b in p_dict.get("blocks", []):
        if b.get("type") != 0:  # Text only
            continue
        
        lines_data = []
        for line in b.get("lines", []):
            spans_data = []
            line_text = ""
            for span in line.get("spans", []):
                st = span.get("text", "")
                line_text += st
                spans_data.append({
                    "text": st,
                    "font": span.get("font", ""),
                    "size": round(span.get("size", 0.0), 2),
                    "color": span.get("color", 0),
                    "bbox": [round(c, 2) for c in span.get("bbox", [])]
                })
            
            clean_line_text = line_text.replace("\xa0", " ").replace("\xad", "-").strip()
            if clean_line_text:
                lines_data.append({
                    "text": clean_line_text,
                    "raw_text": line_text,
                    "bbox": [round(c, 2) for c in line.get("bbox", [])],
                    "spans": spans_data
                })

        if lines_data:
            blocks_data.append({
                "bbox": [round(c, 2) for c in b.get("bbox", [])],
                "lines": lines_data
            })

    slides_meta.append({
        "slide_num": slide_num,
        "width": round(page.rect.width, 2),
        "height": round(page.rect.height, 2),
        "blocks": blocks_data
    })

with open(GT_META_PATH, "w", encoding="utf-8") as f:
    json.dump(slides_meta, f, indent=2, ensure_ascii=False)

print(f"Extracted {len(doc)} slide images and saved metadata to {GT_META_PATH}")
