"""
Strictness Evaluation and Ground Truth Diff Tool.

Compares our PPT2PDF conversion output against native Microsoft PowerPoint ground truth.
Focuses strictly on:
- Text content accuracy
- Word wrapping and line breaks
- Font size match
- Text coordinates and bounding box positioning (tables, headers, metrics, labels)
- Generates side-by-side visual diff images with highlighted alignment errors
"""

import os
import sys
import json
import argparse
import difflib
import pathlib
from typing import List, Dict, Any, Tuple
import pymupdf
from PIL import Image, ImageDraw, ImageFont

# Add project root to sys.path
BASE_DIR = pathlib.Path(__file__).parent.parent.resolve()
sys.path.insert(0, str(BASE_DIR))

from ppt_to_pdf import PPT2PDFConverter, ConversionConfig

GT_DIR = BASE_DIR / "ground_truth"
GT_PDF = GT_DIR / "ground_truth.pdf"
GT_META = GT_DIR / "ground_truth_metadata.json"
DIFF_DIR = GT_DIR / "diffs"


def normalize_text(text: str) -> str:
    """Normalize whitespace and special characters for strict comparison."""
    if not text:
        return ""
    return (
        text.replace("\xa0", " ")
        .replace("\xad", "-")
        .replace("\u200b", "")
        .replace("\u2010", "-")
        .replace("\u2011", "-")
        .replace("\u2012", "-")
        .replace("\u2013", "-")
        .replace("\u2014", "-")
        .strip()
    )


def extract_slide_text_lines(page: pymupdf.Page) -> List[Dict[str, Any]]:
    """Extracts lines and spans with geometry from a PDF page."""
    p_dict = page.get_text("dict")
    extracted_lines = []

    for b in p_dict.get("blocks", []):
        if b.get("type") != 0:
            continue
        for line in b.get("lines", []):
            spans = line.get("spans", [])
            span_texts = []
            for s in spans:
                t = s.get("text", "")
                if t == "\x00" and any(k in s.get("font", "") for k in ("Wingdings", "Symbol", "Webdings")):
                    t = "\uf098"
                span_texts.append(t)
            raw_text = "".join(span_texts)
            norm_text = normalize_text(raw_text)
            if not norm_text:
                continue

            # Average or primary font size
            primary_font_size = spans[0].get("size", 0.0) if spans else 0.0
            primary_font = spans[0].get("font", "") if spans else ""

            # Normalize true visual bounding box for vertical rotated text
            line_dir = line.get("dir", (1.0, 0.0))
            raw_bbox = list(line.get("bbox", [0, 0, 0, 0]))
            if spans and abs(line_dir[0]) < 0.1 and line_dir[1] < -0.5:
                # Text is rotated 270 degrees (drawn upwards along -Y)
                # If bbox[1] is origin.y and bbox[3] > bbox[1], the true rendered Y is [origin.y - text_h, origin.y]
                origin_y = spans[0].get("origin", (0, 0))[1]
                if abs(raw_bbox[1] - origin_y) < 1.0 and raw_bbox[3] > raw_bbox[1]:
                    span_h = raw_bbox[3] - raw_bbox[1]
                    raw_bbox[1] = origin_y - span_h
                    raw_bbox[3] = origin_y

            extracted_lines.append({
                "text": norm_text,
                "raw_text": raw_text,
                "bbox": [round(c, 2) for c in raw_bbox],
                "font_size": round(primary_font_size, 2),
                "font_family": primary_font,
                "spans": spans
            })

    return extracted_lines




def compare_slide(
    slide_num: int,
    gt_lines: List[Dict[str, Any]],
    test_lines: List[Dict[str, Any]],
    pos_tol_pt: float = 2.0,
    font_tol_pt: float = 0.5
) -> Dict[str, Any]:
    """
    Performs strict comparison between ground truth lines and test lines for a single slide.
    """
    total_gt = len(gt_lines)
    if total_gt == 0:
        return {
            "slide_num": slide_num,
            "total_gt_lines": 0,
            "total_test_lines": len(test_lines),
            "text_match_score": 100.0,
            "wrap_match_score": 100.0,
            "position_score": 100.0,
            "font_size_score": 100.0,
            "strict_fidelity_score": 100.0,
            "matches": [],
            "missing_lines": [],
            "extra_lines": []
        }

    matched_gt = set()
    matched_test = set()
    matches = []

    # 1. Exact or near-exact line matching
    for g_idx, g_line in enumerate(gt_lines):
        g_text = g_line["text"]
        g_bbox = g_line["bbox"]
        g_sz = g_line["font_size"]
        
        best_t_idx = None
        best_sim = 0.0
        best_dist = float("inf")

        for t_idx, t_line in enumerate(test_lines):
            if t_idx in matched_test:
                continue
            t_text = t_line["text"]
            t_bbox = t_line["bbox"]

            # Text similarity
            sim = difflib.SequenceMatcher(None, g_text, t_text).ratio()
            # Center distance
            g_cx = (g_bbox[0] + g_bbox[2]) / 2.0
            g_cy = (g_bbox[1] + g_bbox[3]) / 2.0
            t_cx = (t_bbox[0] + t_bbox[2]) / 2.0
            t_cy = (t_bbox[1] + t_bbox[3]) / 2.0
            dist = ((g_cx - t_cx)**2 + (g_cy - t_cy)**2)**0.5

            if sim > 0.8:
                if sim > best_sim or (abs(sim - best_sim) < 0.05 and dist < best_dist):
                    best_sim = sim
                    best_dist = dist
                    best_t_idx = t_idx

        if best_t_idx is not None and best_sim > 0.7:
            t_line = test_lines[best_t_idx]
            matched_gt.add(g_idx)
            matched_test.add(best_t_idx)

            dx = abs(g_bbox[0] - t_line["bbox"][0])
            dy_top = abs(g_bbox[1] - t_line["bbox"][1])
            dy_bot = abs(g_bbox[3] - t_line["bbox"][3])
            dy_mid = abs((g_bbox[1] + g_bbox[3]) / 2.0 - (t_line["bbox"][1] + t_line["bbox"][3]) / 2.0)
            dy = min(dy_top, dy_bot, dy_mid)
            dw = abs((g_bbox[2] - g_bbox[0]) - (t_line["bbox"][2] - t_line["bbox"][0]))
            dh = abs((g_bbox[3] - g_bbox[1]) - (t_line["bbox"][3] - t_line["bbox"][1]))
            dfont = abs(g_sz - t_line["font_size"])

            is_exact_text = (g_text == t_line["text"])
            is_pos_match = (dx <= pos_tol_pt and dy <= pos_tol_pt)
            is_font_match = (dfont <= font_tol_pt)

            matches.append({
                "gt_text": g_text,
                "test_text": t_line["text"],
                "gt_bbox": g_bbox,
                "test_bbox": t_line["bbox"],
                "gt_font_size": g_sz,
                "test_font_size": t_line["font_size"],
                "similarity": round(best_sim, 3),
                "exact_text": is_exact_text,
                "dx": round(dx, 2),
                "dy": round(dy, 2),
                "dfont": round(dfont, 2),
                "pos_match": is_pos_match,
                "font_match": is_font_match
            })

    # Scores
    num_matched = len(matches)
    text_exact_count = sum(1 for m in matches if m["exact_text"])
    pos_match_count = sum(1 for m in matches if m["pos_match"])
    font_match_count = sum(1 for m in matches if m["font_match"])

    text_match_score = (num_matched / total_gt) * 100.0
    wrap_match_score = (text_exact_count / total_gt) * 100.0
    position_score = (pos_match_count / total_gt) * 100.0
    font_size_score = (font_match_count / total_gt) * 100.0

    # Composite Strict Fidelity Score
    strict_fidelity_score = (
        0.30 * text_match_score +
        0.25 * wrap_match_score +
        0.25 * position_score +
        0.20 * font_size_score
    )

    missing_lines = [gt_lines[i] for i in range(total_gt) if i not in matched_gt]
    extra_lines = [test_lines[i] for i in range(len(test_lines)) if i not in matched_test]

    return {
        "slide_num": slide_num,
        "total_gt_lines": total_gt,
        "total_test_lines": len(test_lines),
        "matched_lines": num_matched,
        "text_match_score": round(text_match_score, 1),
        "wrap_match_score": round(wrap_match_score, 1),
        "position_score": round(position_score, 1),
        "font_size_score": round(font_size_score, 1),
        "strict_fidelity_score": round(strict_fidelity_score, 1),
        "matches": matches,
        "missing_lines": missing_lines,
        "extra_lines": extra_lines
    }


def create_visual_diff_image(
    slide_num: int,
    gt_page: pymupdf.Page,
    test_page: pymupdf.Page,
    result: Dict[str, Any],
    out_path: pathlib.Path
):
    """Generates a 3-panel comparison image: [Ground Truth] | [Our Conversion] | [Diff Overlay]."""
    scale = 2.0  # High res
    mat = pymupdf.Matrix(scale, scale)

    # 1. Render base images
    gt_pix = gt_page.get_pixmap(matrix=mat)
    test_pix = test_page.get_pixmap(matrix=mat)

    gt_img = Image.frombytes("RGB", [gt_pix.width, gt_pix.height], gt_pix.samples)
    test_img = Image.frombytes("RGB", [test_pix.width, test_pix.height], test_pix.samples)

    # 2. Create Diff Overlay image on top of test_img
    overlay_img = test_img.copy()
    draw = ImageDraw.Draw(overlay_img, "RGBA")

    for match in result["matches"]:
        bx0, by0, bx1, by1 = match["test_bbox"]
        rect = [bx0 * scale, by0 * scale, bx1 * scale, by1 * scale]
        
        if match["exact_text"] and match["pos_match"] and match["font_match"]:
            # Green: Perfect match
            draw.rectangle(rect, outline=(0, 200, 0, 180), width=2)
        elif match["exact_text"]:
            # Yellow: Content matches, slight position delta
            draw.rectangle(rect, outline=(230, 180, 0, 220), width=2)
        else:
            # Orange: Text wrapped differently
            draw.rectangle(rect, outline=(255, 120, 0, 230), width=3)

    for missing in result["missing_lines"]:
        bx0, by0, bx1, by1 = missing["bbox"]
        rect = [bx0 * scale, by0 * scale, bx1 * scale, by1 * scale]
        # Red: Missing line from ground truth
        draw.rectangle(rect, outline=(255, 0, 0, 255), fill=(255, 0, 0, 40), width=3)

    # 3. Assemble composite image
    w, h = gt_img.size
    banner_h = 50
    comp = Image.new("RGB", (w * 3 + 40, h + banner_h), (245, 245, 248))
    
    comp.paste(gt_img, (10, banner_h))
    comp.paste(test_img, (w + 20, banner_h))
    comp.paste(overlay_img, (w * 2 + 30, banner_h))

    # Add Titles
    draw_comp = ImageDraw.Draw(comp)
    score_txt = f"Slide {slide_num} — Strict Fidelity Score: {result['strict_fidelity_score']}%  (Text: {result['text_match_score']}%, Wrap: {result['wrap_match_score']}%, Pos: {result['position_score']}%, Font: {result['font_size_score']}%)"
    draw_comp.text((15, 15), score_txt, fill=(20, 20, 20))
    draw_comp.text((15, 32), "Left: Native PowerPoint (Ground Truth)   |   Middle: Our Conversion Output   |   Right: Strict Alignment Diff Overlay", fill=(80, 80, 80))

    out_path.parent.mkdir(exist_ok=True, parents=True)
    comp.save(str(out_path), quality=92)


def main():
    parser = argparse.ArgumentParser(description="Evaluate conversion fidelity against native PowerPoint ground truth.")
    parser.add_argument("--slides", type=str, default="5,8", help="Slide selection (e.g. '5,8' or 'all')")
    parser.add_argument("--pos-tol", type=float, default=2.0, help="Position tolerance in points (default: 2.0pt)")
    parser.add_argument("--font-tol", type=float, default=0.5, help="Font size tolerance in points (default: 0.5pt)")
    args = parser.parse_args()

    if not GT_PDF.exists():
        print(f"Error: Ground truth PDF not found at {GT_PDF}. Run scripts/generate_ground_truth.py first.")
        sys.exit(1)

    with open(GT_META, "r", encoding="utf-8") as f:
        gt_meta_all = json.load(f)

    gt_doc = pymupdf.open(str(GT_PDF))
    total_slides = len(gt_doc)

    if args.slides.lower() == "all":
        slide_indices = list(range(1, total_slides + 1))
    else:
        slide_indices = [int(s.strip()) for s in args.slides.split(",") if s.strip()]

    print(f"\n================================================================================")
    print(f" STRICT FIDELITY EVALUATION AGAINST GROUND TRUTH (PowerPoint 16.0 Native PDF)")
    print(f" Slides: {args.slides}  |  Pos Tol: +/-{args.pos_tol}pt  |  Font Tol: +/-{args.font_tol}pt")
    print(f"================================================================================\n")

    # Convert specified slides
    test_pdf_path = BASE_DIR / "eval_output.pdf"
    conv = PPT2PDFConverter(config=ConversionConfig(slide_selection=args.slides, dpi=150))
    conv.convert(str(BASE_DIR / "sample_ppt.pptx"), str(test_pdf_path))

    test_doc = pymupdf.open(str(test_pdf_path))

    total_fidelity = 0.0
    slide_results = []

    for t_page_idx, slide_num in enumerate(slide_indices):
        gt_page = gt_doc[slide_num - 1]
        test_page = test_doc[t_page_idx]

        # Extract lines
        gt_lines = extract_slide_text_lines(gt_page)
        test_lines = extract_slide_text_lines(test_page)

        # Compare
        result = compare_slide(slide_num, gt_lines, test_lines, args.pos_tol, args.font_tol)
        slide_results.append(result)
        total_fidelity += result["strict_fidelity_score"]

        # Generate visual diff
        diff_img_path = DIFF_DIR / f"diff_slide_{slide_num}.png"
        create_visual_diff_image(slide_num, gt_page, test_page, result, diff_img_path)

        print(f"--- Slide {slide_num} Results ---")
        print(f"  Strict Fidelity Score: {result['strict_fidelity_score']}%")
        print(f"  * Text Content Match : {result['text_match_score']}% ({result['matched_lines']}/{result['total_gt_lines']} lines)")
        print(f"  * Line Wrap / Breaks : {result['wrap_match_score']}% exact wrap")
        print(f"  * Position Alignment : {result['position_score']}% within +/-{args.pos_tol}pt")
        print(f"  * Font Size Match    : {result['font_size_score']}% within +/-{args.font_tol}pt")
        print(f"  * Visual Diff Saved  : {diff_img_path.relative_to(BASE_DIR)}")


        if result["missing_lines"]:
            print(f"  [!] Missing Lines ({len(result['missing_lines'])}):")
            for m in result["missing_lines"][:5]:
                safe_t = m['text'][:60].encode('ascii', 'replace').decode('ascii')
                print(f"      - '{safe_t}' at {m['bbox']}")

        misaligned = [m for m in result["matches"] if not m["pos_match"]]
        if misaligned:
            print(f"  [!] Misaligned Lines ({len(misaligned)}):")
            for m in misaligned[:5]:
                safe_gt = m['gt_text'][:40].encode('ascii', 'replace').decode('ascii')
                print(f"      - '{safe_gt}' dx={m['dx']}pt, dy={m['dy']}pt")
        print()


    avg_fidelity = total_fidelity / len(slide_indices)
    print(f"================================================================================")
    print(f" OVERALL FIDELITY SCORE: {avg_fidelity:.1f}% across {len(slide_indices)} evaluated slide(s)")
    print(f" Visual Diffs available in: {DIFF_DIR.relative_to(BASE_DIR)}/")
    print(f"================================================================================\n")


if __name__ == "__main__":
    main()
