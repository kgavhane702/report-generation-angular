$pptx = "d:\app\ppt-pdf-conversion\sample_ppt.pptx"
$pdf = "d:\app\ppt-pdf-conversion\ground_truth\ground_truth.pdf"

$gtDir = [System.IO.Path]::GetDirectoryName($pdf)
if (-not (Test-Path $gtDir)) {
    New-Item -ItemType Directory -Path $gtDir -Force | Out-Null
}

Write-Host "Creating PowerPoint COM object..."
$ppt = New-Object -ComObject PowerPoint.Application
try {
    Write-Host "Opening presentation with window..."
    $pres = $ppt.Presentations.Open($pptx, -1, 0, -1)
    Write-Host "Slides count: $($pres.Slides.Count)"
    Write-Host "Saving as PDF..."
    $pres.SaveCopyAs($pdf, 32)
    Write-Host "Closing presentation..."
    $pres.Close()
    Write-Host "PDF successfully saved to $pdf"
} catch {
    Write-Error $_
} finally {
    Write-Host "Quitting PowerPoint..."
    $ppt.Quit()
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($ppt) | Out-Null
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()
}
