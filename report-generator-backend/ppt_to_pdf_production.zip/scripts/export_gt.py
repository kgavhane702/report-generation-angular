import os
import sys
import pythoncom
import win32com.client

print("Starting export script...", flush=True)
pythoncom.CoInitialize()

pptx_path = r"d:\app\ppt-pdf-conversion\sample_ppt.pptx"
pdf_path = r"d:\app\ppt-pdf-conversion\ground_truth\ground_truth.pdf"
os.makedirs(r"d:\app\ppt-pdf-conversion\ground_truth\slides", exist_ok=True)

try:
    print("Connecting to PowerPoint...", flush=True)
    ppt_app = win32com.client.DispatchEx("PowerPoint.Application")
    ppt_app.DisplayAlerts = 0  # ppAlertsNone
    print("Opening presentation...", flush=True)
    # Open(FileName, ReadOnly=-1, Untitled=0, WithWindow=0)
    pres = ppt_app.Presentations.Open(pptx_path, -1, 0, 0)
    print("Presentation opened. Slide count:", pres.Slides.Count, flush=True)
    print("Saving as PDF...", flush=True)
    pres.SaveAs(pdf_path, 32)
    print("Closing presentation...", flush=True)
    pres.Close()
    print("Quitting PowerPoint...", flush=True)
    ppt_app.Quit()
    print("Done!", flush=True)
except Exception as e:
    print("Exception occurred:", e, flush=True)
finally:
    pythoncom.CoUninitialize()

if os.path.exists(pdf_path):
    print("SUCCESS: PDF created at", pdf_path, flush=True)
    import pymupdf
    doc = pymupdf.open(pdf_path)
    print("PDF page count:", len(doc), flush=True)
    for i, page in enumerate(doc):
        img_p = rf"d:\app\ppt-pdf-conversion\ground_truth\slides\slide_{i+1}.png"
        page.get_pixmap(dpi=150).save(img_p)
    print("Extracted all slide PNGs!", flush=True)
