import os
from setuptools import setup, find_packages

setup(
    name="ppt-to-pdf",
    version="1.0.0",
    description="Autonomous Enterprise Pure-Python PowerPoint (.pptx) to PDF Converter",
    long_description=open("README.md", "r", encoding="utf-8").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Autonomous Vector Engine Team",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "pymupdf>=1.23.0",
        "Pillow>=9.0.0",
        "matplotlib>=3.5.0",
        "numpy>=1.20.0",
    ],
    entry_points={
        "console_scripts": [
            "ppt2pdf = ppt_to_pdf.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Multimedia :: Graphics :: Presentation",
        "Topic :: Printing",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
    ],
)
