# Enterprise Pure-Python PowerPoint (`.pptx`) to PDF Converter

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Pure Python](https://img.shields.io/badge/Pure_Python-100%25-green.svg)]()
[![Platform Independent](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-brightgreen)]()

An enterprise-grade, high-fidelity PowerPoint-to-PDF conversion engine built with **100% pure Python and open-source libraries**.

- **Zero Paid Dependencies**: No Aspose, no commercial licenses.
- **Zero Office Binaries**: No Microsoft PowerPoint COM automation, no LibreOffice / unoconv subprocesses.
- **Cross-Platform**: Runs in Docker containers, AWS Lambda / GCP Cloud Run / Azure Functions, Linux, Windows, and macOS.
- **Vector-Level Fidelity**: Generates crisp, scalable vector PDF pages with slide outlines, typography, theme color schemes, shapes, tables, charts, and images.

---

## Architecture Overview

```
ppt_to_pdf/
│
├── __init__.py                  # Public exports: PPT2PDFConverter, ConversionConfig, convert
├── __main__.py                  # CLI runner: python -m ppt_to_pdf
├── api.py                       # High-level clean Python API
├── cli.py                       # Rich CLI interface with progress indicators and batch conversion
├── config.py                    # ConversionConfig dataclass (DPI, font paths, fallback font, flags)
│
├── core/                        # Core engine orchestration & data structures
│   ├── engine.py                # PPT2PDFEngine orchestrator (manages parse -> layout -> render lifecycle)
│   ├── context.py               # RenderContext (slide dimensions, theme palette, transform matrix)
│   ├── models.py                # Intermediate Object Models (Slide, Shape, TextFrame, Table, Chart, Picture)
│   ├── exceptions.py            # Domain-specific exception hierarchy
│   └── transform.py             # 2D Affine transform matrix & coordinate space handlers
│
├── openxml/                     # OpenXML PresentationML & DrawingML parsing
│   ├── constants.py             # XML namespaces, MIME types, DrawingML preset geometry names
│   ├── package.py               # PPTX Zip package manager & relationship resolver (.rels)
│   ├── color_resolver.py        # ColorEngine (resolves srgbClr, schemeClr, sysClr, lumMod, tint, alpha)
│   ├── theme.py                 # ThemeParser (color scheme, font scheme, format scheme)
│   ├── master_resolver.py       # SlideMaster & SlideLayout inheritance & placeholder linker
│   ├── slide_parser.py          # Slide XML parser -> Intermediate AST
│   ├── shape_parser.py          # AutoShape, Connector, GraphicFrame, Picture, Group shape parsers
│   ├── text_parser.py           # TextFrame, Paragraph, Run, Bullet parsers
│   ├── table_parser.py          # Table grid, row, cell, border, and cell span parsers
│   └── chart_parser.py          # Chart XML parser (series, categories, values, chart types, legend)
│
├── typography/                  # Typography, font matching & layout engine
│   ├── font_manager.py          # Cross-platform font discovery & resolver (Windows/Mac/Linux/custom)
│   ├── font_metrics.py          # Text measurement, baseline, ascender, descender calculations
│   └── text_layouter.py         # Multi-line word wrapper, bullet point & tab alignment calculator
│
├── renderers/                   # Visual element renderers
│   ├── base.py                  # BaseElementRenderer abstract interface
│   ├── slide_renderer.py        # Slide background & master/layout layer compositor
│   ├── shape_renderer.py        # AutoShape, fills, strokes, shadows, preset/custom geometries
│   ├── geometry_builder.py      # Preset geometry generators (rect, roundRect, ellipse, chevron, arrows...)
│   ├── text_renderer.py         # Rich multi-run text renderer with styles & bullet formatting
│   ├── image_renderer.py        # Image renderer with EMF/WMF converter, cropping, aspect ratio
│   ├── table_renderer.py        # Table renderer (dynamic row heights, grid, borders, cell backgrounds)
│   ├── chart_renderer.py        # Chart renderer (Bar, Column, Stacked, Line, Pie, etc. with theme colors)
│   ├── connector_renderer.py    # Straight/curved/bent lines & arrow heads
│   └── group_renderer.py        # Nested coordinate transformation & group recursion
│
├── canvas/                      # PDF Vector Canvas abstraction
│   ├── base_canvas.py           # Abstract Canvas interface (draw_rect, draw_path, draw_text, draw_image)
│   └── mupdf_canvas.py          # High-performance PyMuPDF vector PDF canvas
│
└── utils/                       # Shared utility functions
    ├── units.py                 # EMU, pt, inch, pixel, radian conversion functions
    ├── image_utils.py           # Image format detection, RGBA conversion, EMF/WMF metafile handler
    └── logger.py                # Structured logging configuration
```

---

## Features & Capabilities

1. **4-Tier OpenXML Inheritance**:
   - Seamlessly traverses `Theme` -> `SlideMaster` -> `SlideLayout` -> `Slide` to resolve inherited colors, backgrounds, and placeholder positions.

2. **DrawingML Color Pipeline**:
   - Resolves all color types (`schemeClr`, `srgbClr`, `sysClr`, `prstClr`).
   - Supports luminance modifiers (`lumMod`, `lumOff`), tint, shade, saturation modifier (`satMod`), alpha transparency, and color inversion.

3. **Advanced Typography & Font Discovery**:
   - Scans system fonts across Windows, macOS, and Linux.
   - Automatically maps PowerPoint font names (e.g. *Calibri, Arial, Segoe UI, Georgia*) to matching TTF/OTF files with regular, bold, italic, and bold-italic variants.
   - Computes multi-run word wrapping, line heights, hanging indents, and bullet formatting.

4. **Dynamic Table Engine**:
   - Calculates column widths and dynamic row height expansion based on multi-line text contents.
   - Renders cell background colors, custom borders (left, top, right, bottom), and column/row spans.

5. **Theme-Aware Chart Engine**:
   - Parses OpenXML chart definitions (`c:chart`).
   - Supports **Bar, Column (Clustered, Stacked, 100% Stacked), Line, Pie, Doughnut, Area, and Scatter** charts.
   - Renders charts using the presentation's exact theme palette, legend placements, and data series into crisp high-DPI PDF graphics.

6. **Image & Metafile Processing**:
   - Supports PNG, JPEG, GIF, BMP, TIFF, WebP, SVG.
   - Automatically rasterizes Windows Enhanced Metafiles (**EMF / WMF**) ubiquitous in corporate PowerPoint files.
   - Applies crop percentages (`srcRect`), aspect ratio retention, and rotations.

7. **Vector PDF Canvas with Outlines**:
   - Generates vector-native PDF primitives (`pymupdf`).
   - Generates interactive PDF Bookmarks / Table of Contents from slide titles.

---

## Installation

```bash
pip install .
```

Dependencies:
- `pymupdf>=1.23.0`
- `Pillow>=9.0.0`
- `matplotlib>=3.5.0`
- `numpy>=1.20.0`

---

## Python API Usage

### 1. Basic File Conversion
```python
from ppt_to_pdf import PPT2PDFConverter, ConversionConfig

converter = PPT2PDFConverter()
converter.convert("input_deck.pptx", "output_presentation.pdf")
```

### 2. Selective Slide Range Slicing & Custom DPI
```python
from ppt_to_pdf import PPT2PDFConverter, ConversionConfig

config = ConversionConfig(
    dpi=300,                     # High-DPI chart/image resolution
    skip_hidden_slides=True,     # Skip draft slides
    generate_bookmarks=True,     # Add PDF Table of Contents
)

converter = PPT2PDFConverter(config=config)

# Convert only slides 1 to 5, slide 8, and slides 12 to 20
converter.convert(
    input_path="quarterly_review.pptx",
    output_path="quarterly_review_summary.pdf",
    slide_selection="1-5, 8, 12-20"
)
```

### 3. In-Memory Bytes Conversion (Serverless / Cloud APIs)
```python
from ppt_to_pdf import PPT2PDFConverter

converter = PPT2PDFConverter()
raw_pptx_data = open("input.pptx", "rb").read()

# Convert bytes directly without disk I/O
pdf_bytes = converter.convert_bytes(raw_pptx_data)

with open("output.pdf", "wb") as f:
    f.write(pdf_bytes)
```

---

## Command-Line Interface (CLI)

```bash
# Convert entire presentation
ppt2pdf presentation.pptx

# Specify custom output path
ppt2pdf presentation.pptx -o custom_output.pdf

# Convert selective slide range
ppt2pdf presentation.pptx -s "1-10, 15, 20-"

# Batch convert all presentations in a folder
ppt2pdf ./presentations_folder/ -o ./converted_pdfs/

# Advanced options
ppt2pdf presentation.pptx --dpi 300 --skip-hidden --verbose
```

---

## Running Tests

```bash
python -m unittest discover -s ppt_to_pdf/tests
```
