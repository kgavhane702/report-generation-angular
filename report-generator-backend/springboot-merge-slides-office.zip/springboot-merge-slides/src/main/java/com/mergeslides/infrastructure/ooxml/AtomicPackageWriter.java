package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import java.nio.file.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.*;

public final class AtomicPackageWriter {
    private final PackageReader reader;
    public AtomicPackageWriter(PackageReader reader) { this.reader = reader; }
    public void write(Map<String, byte[]> parts, Path output) {
        Path staging = null;
        try {
            Files.createDirectories(output.toAbsolutePath().getParent());
            staging = Files.createTempFile(output.toAbsolutePath().getParent(), Ooxml.TEMP_PREFIX, ".tmp");
            try (var zip = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(staging)))) {
                for (var entry : new TreeMap<>(parts).entrySet()) {
                    var member = new ZipEntry(entry.getKey()); member.setTimeLocal(LocalDateTime.of(1980, 1, 1, 0, 0));
                    zip.putNextEntry(member); zip.write(entry.getValue()); zip.closeEntry();
                }
            }
            reader.read(staging);
            Files.move(staging, output, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) { throw new MergeException(ErrorCode.IO_FAILURE, "Cannot atomically write output " + output + ": " + e.getMessage(), e); }
        finally { if (staging != null) try { Files.deleteIfExists(staging); } catch (IOException ignored) { /* Preserve original failure. */ } }
    }
}
