package com.mergeslides.api;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public record MergeRequest(List<Object> inputs, String recipePath, @NotBlank String output) {}
