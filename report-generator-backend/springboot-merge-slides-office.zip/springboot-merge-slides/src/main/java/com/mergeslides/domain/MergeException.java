package com.mergeslides.domain;

public class MergeException extends RuntimeException {
    private final ErrorCode code;
    public MergeException(ErrorCode code, String message) { super(message); this.code = code; }
    public MergeException(ErrorCode code, String message, Throwable cause) { super(message, cause); this.code = code; }
    public ErrorCode code() { return code; }
    public static MergeException invalid(String message) { return new MergeException(ErrorCode.INVALID_REQUEST, message); }
}
