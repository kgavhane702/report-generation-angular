package com.mergeslides.api;

import com.mergeslides.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.multipart.*;
import java.nio.file.InvalidPathException;
import java.io.IOException;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(MergeException.class)
    public ResponseEntity<Map<String, String>> merge(MergeException e) {
        HttpStatus status = switch (e.code()) {
            case INPUT_NOT_FOUND -> HttpStatus.NOT_FOUND;
            case INVALID_PRESENTATION -> HttpStatus.UNPROCESSABLE_ENTITY;
            case IO_FAILURE -> HttpStatus.INTERNAL_SERVER_ERROR;
            default -> HttpStatus.BAD_REQUEST;
        };
        return ResponseEntity.status(status).body(Map.of("code", e.code().name(), "message", e.getMessage()));
    }
    @ExceptionHandler({MethodArgumentNotValidException.class, HttpMessageNotReadableException.class, InvalidPathException.class})
    public ResponseEntity<Map<String, String>> request(Exception e) { return ResponseEntity.badRequest().body(Map.of("code", "INVALID_REQUEST", "message", e.getMessage())); }
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, String>> size(Exception e) { return ResponseEntity.status(413).body(Map.of("code", "INVALID_REQUEST", "message", "Upload exceeds configured size limits.")); }
    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, String>> io(IOException e) { return ResponseEntity.internalServerError().body(Map.of("code", "IO_FAILURE", "message", e.getMessage())); }
}
