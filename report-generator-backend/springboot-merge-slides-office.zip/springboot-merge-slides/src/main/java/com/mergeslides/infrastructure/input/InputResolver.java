package com.mergeslides.infrastructure.input;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.domain.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

public final class InputResolver {
    private static final Pattern SUFFIX = Pattern.compile("(.+\\.pptx):(.*)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private final ObjectMapper mapper;
    public InputResolver(ObjectMapper mapper) { this.mapper = mapper; }
    public List<InputSpec> resolve(Object inputs, Path base, Path output) {
        List<?> items = inputs instanceof List<?> l ? l : inputs == null ? List.of() : List.of(inputs);
        var result = new ArrayList<InputSpec>();
        for (Object item : items) {
            List<InputSpec> specs = item instanceof String text && text.toLowerCase(Locale.ROOT).endsWith(".json")
                    ? recipe(base.resolve(portable(text))) : List.of(normalize(item, base));
            for (var spec : specs) {
                if (Files.isDirectory(spec.file())) for (Path path : folder(spec.file(), output)) result.add(new InputSpec(path, spec.slides(), spec.skipHidden()));
                else result.add(spec);
            }
        }
        if (result.isEmpty()) throw MergeException.invalid("No input PPTX files provided (the recipe or folder may be empty).");
        return result;
    }
    public List<InputSpec> recipe(Path file) {
        file = file.toAbsolutePath().normalize();
        try {
            Object data = mapper.readValue(Files.readAllBytes(file), Object.class);
            if (!(data instanceof List<?> entries)) throw MergeException.invalid("JSON recipe must contain a top-level list of slide specifications.");
            var result = new ArrayList<InputSpec>(); int index = 0;
            for (Object item : entries) {
                index++;
                try { result.add(normalize(item, file.getParent())); }
                catch (MergeException e) { throw MergeException.invalid(file.getFileName() + ", entry " + index + ": " + e.getMessage()); }
            }
            return result;
        } catch (NoSuchFileException e) { throw new MergeException(ErrorCode.INPUT_NOT_FOUND, "Recipe not found: " + file, e); }
        catch (IOException e) { throw MergeException.invalid("Cannot read recipe " + file + ": " + e.getMessage()); }
    }
    public InputSpec normalize(Object item, Path base) {
        if (item instanceof InputSpec spec) return new InputSpec(base.resolve(spec.file()).toAbsolutePath().normalize(), spec.slides(), spec.skipHidden());
        if (item instanceof Path path) return new InputSpec(base.resolve(path).toAbsolutePath().normalize());
        if (item instanceof String text) {
            var matcher = SUFFIX.matcher(text); boolean match = matcher.matches();
            return new InputSpec(base.resolve(portable(match ? matcher.group(1) : text)).toAbsolutePath().normalize(), match ? matcher.group(2) : null, false);
        }
        if (item instanceof List<?> values) {
            if (values.isEmpty() || values.size() > 3) throw MergeException.invalid("An input tuple needs a path, optional selection, and optional skip_hidden.");
            Map<String, Object> tuple = new LinkedHashMap<>(); tuple.put("file", values.get(0)); tuple.put("skip_hidden", values.size() > 2 ? values.get(2) : false);
            var spec = normalize(tuple, base);
            return new InputSpec(spec.file(), values.size() > 1 ? values.get(1) : null, spec.skipHidden());
        }
        if (item instanceof Map<?, ?> map) {
            Object path = truthy(map.get("file")) ? map.get("file") : map.get("path");
            if (!(path instanceof String text) || text.isBlank()) throw MergeException.invalid("Each input specification needs a nonempty file or path.");
            Object skip = map.containsKey("skip_hidden") ? map.get("skip_hidden") : false;
            if (!(skip instanceof Boolean flag)) throw MergeException.invalid("skip_hidden must be a JSON boolean.");
            Object selection = truthy(map.get("slides")) ? map.get("slides") : map.get("range");
            return new InputSpec(base.resolve(portable(text)).toAbsolutePath().normalize(), selection, flag);
        }
        throw MergeException.invalid("Invalid input presentation specification: " + item);
    }
    public List<Path> folder(Path path, Path output) {
        if (!Files.isDirectory(path)) throw new MergeException(ErrorCode.INPUT_NOT_FOUND, "Input directory not found: " + path);
        try (var files = Files.list(path)) {
            return files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pptx") && !p.getFileName().toString().startsWith("~$") && !p.toAbsolutePath().normalize().equals(output.toAbsolutePath().normalize()))
                    .sorted((a, b) -> NaturalOrder.INSTANCE.compare(a.getFileName().toString(), b.getFileName().toString())).toList();
        } catch (IOException e) { throw new MergeException(ErrorCode.IO_FAILURE, "Cannot read input folder " + path, e); }
    }
    private boolean truthy(Object o) { return o != null && !Boolean.FALSE.equals(o) && !(o instanceof String s && s.isEmpty()) && !(o instanceof Number n && n.doubleValue() == 0) && !(o instanceof Collection<?> c && c.isEmpty()) && !(o instanceof Map<?, ?> m && m.isEmpty()); }
    private String portable(String path) { return path.replace('\\', '/'); }
}
