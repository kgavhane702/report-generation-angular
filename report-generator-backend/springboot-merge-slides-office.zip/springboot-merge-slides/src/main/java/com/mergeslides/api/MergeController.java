package com.mergeslides.api;

import com.mergeslides.application.MergeService;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.nio.file.Path;

@RestController
@RequestMapping("/api/v1/merges")
public class MergeController {
    private final MergeService service;
    private final InputResolver resolver;
    private final Path workspace;
    public MergeController(MergeService service, InputResolver resolver, @Value("${merge.workspace}") String workspace) {
        this.service = service; this.resolver = resolver; this.workspace = Path.of(workspace).toAbsolutePath().normalize();
    }
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public MergeResponse merge(@Valid @RequestBody MergeRequest request) {
        boolean inputs = request.inputs() != null, recipe = request.recipePath() != null && !request.recipePath().isBlank();
        if (inputs == recipe) throw MergeException.invalid("Provide exactly one of inputs or recipePath.");
        Path output = workspace.resolve(request.output()).normalize();
        return MergeResponse.from(service.merge(resolver.resolve(inputs ? request.inputs() : request.recipePath(), workspace, output), output));
    }
}
