package com.mergeslides;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.*;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class MvcTest {
    private static final Path WORKSPACE;
    static { try { WORKSPACE = Files.createTempDirectory("merge-mvc-test-"); } catch (Exception e) { throw new IllegalStateException(e); } }
    @DynamicPropertySource static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", WORKSPACE::toString); r.add("merge.temp-directory", () -> WORKSPACE.resolve("temp").toString());
    }
    @Autowired MockMvc mvc;
    @BeforeEach void input() throws Exception { TestPackages.create(WORKSPACE, "deck.pptx", "MVC", 3); }
    @AfterAll static void cleanup() throws Exception { try (var paths = Files.walk(WORKSPACE)) { for (Path p : paths.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(p); } }
    @Test void pathsWorkThroughMvc() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"inputs\":[{\"file\":\"deck.pptx\",\"slides\":[3,1]}],\"output\":\"out.pptx\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.slideCount").value(2));
        assertEquals(2, TestPackages.reader().read(WORKSPACE.resolve("out.pptx")).slides().size());
    }
    @Test void recipePathWorksThroughMvc() throws Exception {
        Files.writeString(WORKSPACE.resolve("recipe.json"), "[{\"file\":\"deck.pptx\",\"slides\":2}]");
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"recipePath\":\"recipe.json\",\"output\":\"recipe-out.pptx\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.slideCount").value(1));
    }
    @Test void uploadsDownloadAndTemporaryFilesAreRemoved() throws Exception {
        var file = new MockMultipartFile("files", "uploaded.pptx", "application/octet-stream", Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        var async = mvc.perform(multipart("/api/v1/merges/upload").file(file).param("recipe", "[{\"file\":\"uploaded.pptx\",\"slides\":[3,1,3]}]"))
                .andExpect(request().asyncStarted()).andReturn();
        var response = mvc.perform(asyncDispatch(async)).andExpect(status().isOk()).andExpect(header().string("X-Merge-Slide-Count", "3")).andReturn();
        Path output = WORKSPACE.resolve("download.pptx"); Files.write(output, response.getResponse().getContentAsByteArray()); assertEquals(3, TestPackages.reader().read(output).slides().size());
        try (var dirs = Files.list(WORKSPACE.resolve("temp"))) { assertEquals(0, dirs.count()); }
    }
    @Test void uploadCannotReferenceServerFiles() throws Exception {
        var file = new MockMultipartFile("files", "uploaded.pptx", "application/octet-stream", Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        mvc.perform(multipart("/api/v1/merges/upload").file(file).param("recipe", "[\"../deck.pptx\"]")).andExpect(status().isBadRequest());
    }
    @Test void invalidAndMissingRequestsHaveUsefulStatus() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"inputs\":[\"missing.pptx\"],\"output\":\"error.pptx\"}")).andExpect(status().isNotFound());
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"inputs\":[],\"recipePath\":\"a.json\",\"output\":\"error.pptx\"}")).andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"inputs\":[\"deck.pptx\"]}")).andExpect(status().isBadRequest());
        mvc.perform(get("/actuator/health")).andExpect(status().isOk());
    }
}
