package com.mergeslides;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.*;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class MvcTest {
    private static final Path WORKSPACE;
    static {
        try {
            WORKSPACE = Files.createTempDirectory("merge-mvc-test-");
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @DynamicPropertySource
    static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", WORKSPACE::toString);
        r.add("merge.temp-directory", () -> WORKSPACE.resolve("temp").toString());
    }

    @Autowired
    MockMvc mvc;

    @BeforeEach
    void input() throws Exception {
        TestPackages.create(WORKSPACE, "deck.pptx", "MVC", 3);
    }

    @AfterAll
    static void cleanup() throws Exception {
        try (var paths = Files.walk(WORKSPACE)) {
            for (Path p : paths.sorted(java.util.Comparator.reverseOrder()).toList())
                Files.deleteIfExists(p);
        }
    }

    @Test
    void pathsWorkThroughMvc() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"inputs\":[{\"file\":\"deck.pptx\",\"slides\":[3,1]}],\"output\":\"out.pptx\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.slideCount").value(2));
        assertEquals(2, TestPackages.reader().read(WORKSPACE.resolve("out.pptx")).slides().size());
    }

    @Test
    void recipePathWorksThroughMvc() throws Exception {
        Files.writeString(WORKSPACE.resolve("recipe.json"), "[{\"file\":\"deck.pptx\",\"slides\":2}]");
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"recipePath\":\"recipe.json\",\"output\":\"recipe-out.pptx\"}")).andExpect(status().isOk())
                .andExpect(jsonPath("$.slideCount").value(1));
    }

    @Test
    void uploadsDownloadAndTemporaryFilesAreRemoved() throws Exception {
        var file = new MockMultipartFile("files", "uploaded.pptx", "application/octet-stream",
                Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        var async = mvc
                .perform(multipart("/api/v1/merges/upload").file(file).param("recipe",
                        "[{\"file\":\"uploaded.pptx\",\"slides\":[3,1,3]}]"))
                .andExpect(request().asyncStarted()).andReturn();
        var response = mvc.perform(asyncDispatch(async)).andExpect(status().isOk())
                .andExpect(header().string("X-Merge-Slide-Count", "3")).andReturn();
        Path output = WORKSPACE.resolve("download.pptx");
        Files.write(output, response.getResponse().getContentAsByteArray());
        assertEquals(3, TestPackages.reader().read(output).slides().size());
        try (var dirs = Files.list(WORKSPACE.resolve("temp"))) {
            assertEquals(0, dirs.count());
        }
    }

    @Test
    void uploadCannotReferenceServerFiles() throws Exception {
        var file = new MockMultipartFile("files", "uploaded.pptx", "application/octet-stream",
                Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        mvc.perform(multipart("/api/v1/merges/upload").file(file).param("recipe", "[\"../deck.pptx\"]"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void invalidAndMissingRequestsHaveUsefulStatus() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"inputs\":[\"missing.pptx\"],\"output\":\"error.pptx\"}")).andExpect(status().isNotFound());
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"inputs\":[],\"recipePath\":\"a.json\",\"output\":\"error.pptx\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{\"inputs\":[\"deck.pptx\"]}"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/actuator/health")).andExpect(status().isOk());
    }

    @Test
    void inlineV2SupportsNumericSelectionsAndDestinationConflict() throws Exception {
        String request = "{\"recipe\":{\"version\":2,\"sources\":[\"deck.pptx\"],\"options\":{\"remaining\":\"none\"},\"select\":[{\"file\":\"deck.pptx\",\"slides\":[3,1,3]}]},\"output\":\"v2-output.pptx\"}";
        Files.deleteIfExists(WORKSPACE.resolve("v2-output.pptx"));
        mvc.perform(post("/api/v1/merges").contentType("application/json").content(request)).andExpect(status().isOk())
                .andExpect(jsonPath("$.slideCount").value(3)).andExpect(header().exists("X-Merge-Operation-Id"));
        mvc.perform(post("/api/v1/merges").contentType("application/json").content(request))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.failureCode").value("OUTPUT_EXISTS"))
                .andExpect(jsonPath("$.operationId").isNotEmpty());
    }

    @Test
    void missingTitleWarnsWithoutFailingAndMdcIsRestored() throws Exception {
        org.slf4j.MDC.put("merge.operationId", "host-context");
        try {
            mvc.perform(post("/api/v1/merges").contentType("application/json").content(
                    "{\"recipe\":{\"version\":2,\"sources\":[\"deck.pptx\"],\"select\":[\"Not present\"],\"options\":{\"overwrite\":true}},\"output\":\"warning-output.pptx\"}"))
                    .andExpect(status().isOk()).andExpect(jsonPath("$.slideCount").value(3))
                    .andExpect(jsonPath("$.warnings.length()").value(1));
            assertEquals("host-context", org.slf4j.MDC.get("merge.operationId"));
        } finally {
            org.slf4j.MDC.remove("merge.operationId");
        }
    }

    @Test
    void adviceNormalizesMalformedRequestsAndDoesNotExposePathsForMissingInputs() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("{"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("INVALID_REQUEST"))
                .andExpect(jsonPath("$.operationId").isNotEmpty());
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"inputs\":[\"not-present.pptx\"],\"output\":\"a.pptx\"}")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("A requested input file or directory was not found."));
    }

    @Test
    void v2UploadUsesUploadPoolAndCannotEscapeIt() throws Exception {
        var file = new MockMultipartFile("files", "uploaded.pptx", "application/octet-stream",
                Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        var async = mvc.perform(multipart("/api/v1/merges/upload").file(file).param("recipe",
                "{\"version\":2,\"select\":[{\"file\":\"uploaded.pptx\",\"slides\":[2,1]}],\"options\":{\"remaining\":\"none\"}}"))
                .andExpect(request().asyncStarted()).andReturn();
        mvc.perform(asyncDispatch(async)).andExpect(status().isOk())
                .andExpect(header().string("X-Merge-Slide-Count", "2"));
        mvc.perform(multipart("/api/v1/merges/upload").file(file).param("recipe",
                "{\"version\":2,\"sources\":[\"../deck.pptx\"]}")).andExpect(status().isBadRequest());
    }

    @Test
    void duplicateUploadNamesAndCorruptUnusedUploadsAreRejected() throws Exception {
        var good = new MockMultipartFile("files", "good.pptx", "application/octet-stream",
                Files.readAllBytes(WORKSPACE.resolve("deck.pptx")));
        var bad = new MockMultipartFile("files", "bad.pptx", "application/octet-stream", "invalid".getBytes());
        mvc.perform(multipart("/api/v1/merges/upload").file(good).file(bad).param("recipe",
                "[{\"file\":\"good.pptx\",\"slides\":[1]}]")).andExpect(status().isUnprocessableEntity());
        mvc.perform(multipart("/api/v1/merges/upload").file(good).file(good)).andExpect(status().isBadRequest());
        try (var dirs = Files.list(WORKSPACE.resolve("temp"))) {
            assertEquals(0, dirs.count());
        }
    }

    @Test
    void committedTransfersDoNotProduceAnotherJsonResponseAndCleanupIsIdempotent() throws Exception {
        var response = new org.springframework.mock.web.MockHttpServletResponse();
        response.setCommitted(true);
        var request = new org.springframework.web.context.request.ServletWebRequest(
                new org.springframework.mock.web.MockHttpServletRequest(), response);
        assertNull(new com.mergeslides.api.ApiExceptionHandler().io(new java.io.IOException("client disconnected"),
                request));
        Path directory = Files.createTempDirectory(WORKSPACE, "cleanup-");
        Files.writeString(directory.resolve("temporary"), "data");
        var download = new com.mergeslides.application.UploadMergeService.PreparedDownload(directory, null);
        download.close();
        download.close();
        assertFalse(Files.exists(directory));
    }
}
