package com.mergeslides;

import com.mergeslides.api.*;
import com.mergeslides.application.UploadMergeService;
import com.mergeslides.application.UploadMergeService.*;
import com.mergeslides.domain.MergeResult;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UploadLifecycleRegressionTest {
    @TempDir
    Path dir;

    MultipartFile file(InputStream stream) throws Exception {
        var file = mock(MultipartFile.class);
        when(file.getOriginalFilename()).thenReturn("a.pptx");
        when(file.getInputStream()).thenReturn(stream);
        return file;
    }

    PreparedDownload download(boolean outputExists) throws Exception {
        Path folder = Files.createDirectory(dir.resolve("prepared")), output = folder.resolve("out.pptx");
        if (outputExists)
            Files.writeString(output, "bytes");
        return new PreparedDownload(folder, new MergeResult(output, 1, List.of(), 0));
    }

    @Test
    void preparationErrorRemainsPrimaryAndEveryStreamIsClosed() throws Exception {
        var service = mock(UploadMergeService.class);
        var primary = new IOException("prepare");
        when(service.prepare(anyList(), any())).thenThrow(primary);
        var first = mock(InputStream.class);
        var second = mock(InputStream.class);
        var close = new IOException("close");
        doThrow(close).when(first).close();
        assertSame(primary, assertThrows(IOException.class, () -> new UploadController(service)
                .upload(List.of(file(first), file(second)), null, new MockHttpServletRequest())));
        assertArrayEquals(new Throwable[]{close}, primary.getSuppressed());
        verify(first).close();
        verify(second).close();
    }

    @Test
    void successfulPreparationIsCleanedIfClosingAnyUploadFails() throws Exception {
        var service = mock(UploadMergeService.class);
        var prepared = download(true);
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        var first = mock(InputStream.class);
        var second = mock(InputStream.class);
        var close = new IOException("close");
        var later = new IOException("later");
        doThrow(close).when(first).close();
        doThrow(later).when(second).close();
        assertSame(close, assertThrows(IOException.class, () -> new UploadController(service)
                .upload(List.of(file(first), file(second)), null, new MockHttpServletRequest())));
        assertArrayEquals(new Throwable[]{later}, close.getSuppressed());
        verify(second).close();
        assertFalse(Files.exists(prepared.directory()));
    }

    @Test
    void responsePreparationFailureClosesPreparedDownload() throws Exception {
        var service = mock(UploadMergeService.class);
        var prepared = download(false);
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        assertThrows(IOException.class, () -> new UploadController(service)
                .upload(List.of(file(new ByteArrayInputStream(new byte[0]))), null, new MockHttpServletRequest()));
        assertFalse(Files.exists(prepared.directory()));
    }

    @Test
    void openFailureClosesEarlierStreamsAndTransferFailureClosesPreparedDownload() throws Exception {
        var service = mock(UploadMergeService.class);
        var opened = mock(InputStream.class);
        var failing = mock(MultipartFile.class);
        var primary = new IOException("open");
        when(failing.getInputStream()).thenThrow(primary);
        assertSame(primary, assertThrows(IOException.class, () -> new UploadController(service)
                .upload(List.of(file(opened), failing), null, new MockHttpServletRequest())));
        verify(opened).close();
        verifyNoInteractions(service);
        var prepared = download(true);
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        var request = new MockHttpServletRequest();
        request.setAttribute(MergeOperationFilter.ATTRIBUTE, "request-id");
        var response = new UploadController(service).upload(List.of(file(new ByteArrayInputStream(new byte[0]))), null,
                request);
        var output = mock(OutputStream.class);
        doThrow(primary).when(output).write(any(byte[].class), anyInt(), anyInt());
        org.slf4j.MDC.put("merge.operationId", "prior");
        try {
            assertSame(primary, assertThrows(IOException.class, () -> response.getBody().writeTo(output)));
            assertEquals("prior", org.slf4j.MDC.get("merge.operationId"));
        } finally {
            org.slf4j.MDC.remove("merge.operationId");
        }
        assertFalse(Files.exists(prepared.directory()));
        prepared.close();
    }

    @Test
    void runtimeAndErrorCloseFailuresPreserveSuppressedCleanupFailures() throws Exception {
        for (Throwable failure : List.of(new IllegalStateException("close runtime"),
                new AssertionError("close error"))) {
            var service = mock(UploadMergeService.class);
            var prepared = mock(PreparedDownload.class);
            when(service.prepare(anyList(), any())).thenReturn(prepared);
            var input = mock(InputStream.class);
            doThrow(failure).when(input).close();
            var cleanup = new IOException("cleanup");
            doThrow(cleanup).when(prepared).close();
            assertSame(failure, assertThrows(failure.getClass(), () -> new UploadController(service)
                    .upload(List.of(file(input)), null, new MockHttpServletRequest())));
            assertArrayEquals(new Throwable[]{cleanup}, failure.getSuppressed());
            verify(prepared).close();
        }
        var service = mock(UploadMergeService.class);
        var prepared = mock(PreparedDownload.class);
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        var failure = new IllegalStateException("setup");
        when(prepared.result()).thenThrow(failure);
        doThrow(failure).when(prepared).close();
        assertSame(failure, assertThrows(IllegalStateException.class, () -> new UploadController(service)
                .upload(List.of(file(new ByteArrayInputStream(new byte[0]))), null, new MockHttpServletRequest())));
        assertEquals(0, failure.getSuppressed().length);
    }

    @Test
    void timeoutCancellationAndCompletionCleanPreparedFilesIdempotentlyWithoutSleeps() throws Exception {
        var service = mock(UploadMergeService.class);
        var prepared = download(true);
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        var request = new MockHttpServletRequest();
        new UploadController(service).upload(List.of(file(new ByteArrayInputStream(new byte[0]))), null, request);
        var interceptor = org.springframework.web.context.request.async.WebAsyncUtils.getAsyncManager(request)
                .getCallableInterceptor(prepared);
        var web = new org.springframework.web.context.request.ServletWebRequest(request);
        java.util.concurrent.Callable<Object> task = () -> null;
        assertSame(org.springframework.web.context.request.async.CallableProcessingInterceptor.RESULT_NONE,
                interceptor.handleTimeout(web, task));
        assertFalse(Files.exists(prepared.directory()));
        assertSame(org.springframework.web.context.request.async.CallableProcessingInterceptor.RESULT_NONE,
                interceptor.handleError(web, task, new java.util.concurrent.CancellationException()));
        interceptor.afterCompletion(web, task);
        assertFalse(Files.exists(prepared.directory()));
    }

    @Test
    void transferPreservesPrimaryErrorWhenCleanupFailsAndRetriesOnCompletion() throws Exception {
        var service = mock(UploadMergeService.class);
        var actual = download(true);
        var prepared = mock(PreparedDownload.class);
        when(prepared.result()).thenReturn(actual.result());
        when(service.prepare(anyList(), any())).thenReturn(prepared);
        var cleanup = new IOException("cleanup");
        doAnswer(call -> {
            actual.close();
            throw cleanup;
        }).when(prepared).close();
        var request = new MockHttpServletRequest();
        var response = new UploadController(service).upload(List.of(file(new ByteArrayInputStream(new byte[0]))), null,
                request);
        var output = mock(OutputStream.class);
        var primary = new IOException("delivery");
        doThrow(primary).when(output).write(any(byte[].class), anyInt(), anyInt());
        assertSame(primary, assertThrows(IOException.class, () -> response.getBody().writeTo(output)));
        assertArrayEquals(new Throwable[]{cleanup}, primary.getSuppressed());
        assertFalse(Files.exists(actual.directory()));
        var interceptor = org.springframework.web.context.request.async.WebAsyncUtils.getAsyncManager(request)
                .getCallableInterceptor(prepared);
        interceptor.afterCompletion(new org.springframework.web.context.request.ServletWebRequest(request), () -> null);
        verify(prepared, times(2)).close();
    }

    @Test
    void repeatedIdenticalCloseExceptionIsNotSuppressedOntoItself() throws Exception {
        var primary = new IOException("same");
        var input = mock(InputStream.class);
        doThrow(primary).when(input).close();
        var service = mock(UploadMergeService.class);
        when(service.prepare(anyList(), any())).thenThrow(primary);
        assertSame(primary, assertThrows(IOException.class,
                () -> new UploadController(service).upload(List.of(file(input)), null, new MockHttpServletRequest())));
        assertEquals(0, primary.getSuppressed().length);
    }
}
