package com.mergeslides;

import com.fasterxml.jackson.databind.*;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.w3c.dom.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.net.URLDecoder;
import java.util.*;
import java.util.stream.Stream;
import java.util.zip.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static org.junit.jupiter.api.Assertions.*;

/** Opt-in tests: downloaded inputs are external; no network or Office tool is used here. */
@Tag("internet")
class InternetSamplesTest {
    static final Path ROOT = Path.of(System.getProperty("merge.internet", "../springboot-oupt/internet-complex-review"))
            .toAbsolutePath().normalize();
    static final ObjectMapper JSON = new ObjectMapper();
    static final List<Map<String, Object>> RECEIPTS = new ArrayList<>();
    static final Map<Path, Audit> SOURCES = new HashMap<>();
    final PackageReader reader = TestPackages.reader();
    final PackageMergeService engine = new PackageMergeService(reader, new AtomicPackageWriter(reader));
    final InputResolver resolver = new InputResolver(JSON);

    record Pick(Path file, int slide) {
    }

    @TestFactory
    Stream<DynamicTest> externalSamples() throws Exception {
        Assumptions.assumeTrue(Files.exists(ROOT.resolve("sources-manifest.json")),
                "Download external samples first; see external verification folder.");
        var manifest = JSON.readTree(ROOT.resolve("sources-manifest.json").toFile());
        var tests = new ArrayList<DynamicTest>();
        var originals = new ArrayList<Pick>();
        var folders = new ArrayList<Object>();
        for (var sample : manifest.get("samples")) {
            String id = sample.get("id").asText();
            Path source = ROOT.resolve(sample.get("file").asText());
            int count = sample.get("features").get("slides").asInt();
            List<Pick> all = picks(source, count);
            originals.addAll(all);
            Path splitDir = ROOT.resolve("split/" + id);
            folders.add(splitDir);
            tests.add(DynamicTest.dynamicTest(id + " identity",
                    () -> mergeAndCheck(id + "/identity", List.of(new InputSpec(source)), all)));
            tests.add(DynamicTest.dynamicTest(id + " split and reassemble", () -> {
                Files.createDirectories(splitDir);
                for (int i = 1; i <= count; i++)
                    mergeAndCheck(id + "/split-" + i, List.of(new InputSpec(source, i, false)),
                            List.of(new Pick(source, i)), splitDir.resolve(String.format("slide_%03d.pptx", i)));
                Path out = ROOT.resolve("outputs/" + id + "/roundtrip.pptx");
                mergeAndCheck(id + "/roundtrip", resolver.resolve(splitDir, ROOT, out), all, out);
            }));
            tests.add(DynamicTest.dynamicTest(id + " recipe reverse and repeat", () -> {
                var selection = new ArrayList<Integer>();
                for (int i = count; i >= 1; i--)
                    selection.add(i);
                selection.add(count);
                var expected = selection.stream().map(i -> new Pick(source, i)).toList();
                Path recipe = ROOT.resolve("recipes/" + id + "-reverse-repeat.json");
                Files.createDirectories(recipe.getParent());
                JSON.writerWithDefaultPrettyPrinter().writeValue(recipe.toFile(), List.of(Map.of("file",
                        recipe.getParent().relativize(source).toString().replace('\\', '/'), "slides", selection)));
                Path out = ROOT.resolve("outputs/" + id + "/reverse-repeat.pptx");
                mergeAndCheck(id + "/reverse-repeat", resolver.resolve(recipe.toString(), ROOT, out), expected, out);
            }));
        }
        tests.add(DynamicTest.dynamicTest("All eight originals", () -> mergeAndCheck("all-originals",
                originals.stream().map(Pick::file).distinct().map(InputSpec::new).toList(), originals)));
        tests.add(DynamicTest.dynamicTest("All single-slide splits", () -> {
            Path out = ROOT.resolve("outputs/all-split-files.pptx");
            mergeAndCheck("all-split-files", resolver.resolve(folders, ROOT, out), originals, out);
        }));
        return tests.stream();
    }

    private void mergeAndCheck(String id, List<InputSpec> specs, List<Pick> expected) throws Exception {
        mergeAndCheck(id, specs, expected, ROOT.resolve("outputs/" + id + ".pptx"));
    }

    private void mergeAndCheck(String id, List<InputSpec> specs, List<Pick> expected, Path output) throws Exception {
        var receipt = new LinkedHashMap<String, Object>();
        receipt.put("scenario", id);
        receipt.put("output", ROOT.relativize(output).toString().replace('\\', '/'));
        receipt.put("expected_slides", expected.size());
        receipt.put("expected_order",
                expected.stream().map(
                        p -> Map.of("file", ROOT.relativize(p.file).toString().replace('\\', '/'), "slide", p.slide))
                        .toList());
        long started = System.nanoTime();
        try {
            var result = engine.merge(specs, output);
            receipt.put("warnings", result.warnings());
            var actual = new Audit(output);
            actual.integrity();
            assertEquals(expected.size(), actual.slides.size());
            Set<String> needed = new HashSet<>();
            for (int i = 0; i < expected.size(); i++) {
                var pick = expected.get(i);
                Audit source = SOURCES.get(pick.file);
                if (source == null) {
                    source = new Audit(pick.file);
                    SOURCES.put(pick.file, source);
                }
                String part = source.slides.get(pick.slide - 1);
                assertEquals(canonical(Xml.parse(source.parts.get(part), part)),
                        canonical(Xml.parse(actual.parts.get(actual.slides.get(i)), "output")),
                        "Slide markup/order " + (i + 1));
                needed.addAll(source.binaryDependencies(part));
            }
            Set<String> found = new HashSet<>();
            actual.parts.forEach((name, bytes) -> {
                if (!isXml(name))
                    found.add(hash(bytes));
            });
            assertTrue(found.containsAll(needed), "A native binary dependency was lost or changed");
            receipt.put("binary_dependency_hashes_preserved", needed.size());
            receipt.put("features", actual.features());
            receipt.put("sha256", hash(Files.readAllBytes(output)));
            receipt.put("passed", true);
        } catch (Throwable e) {
            receipt.put("passed", false);
            receipt.put("error", e.toString());
            throw e;
        } finally {
            receipt.put("seconds", (System.nanoTime() - started) / 1e9);
            RECEIPTS.add(receipt);
            Path path = ROOT.resolve("receipts/" + id.replace('/', '_') + ".json");
            Files.createDirectories(path.getParent());
            JSON.writerWithDefaultPrettyPrinter().writeValue(path.toFile(), receipt);
        }
    }

    @AfterAll
    static void report() throws Exception {
        if (RECEIPTS.isEmpty())
            return;
        var manifest = JSON.readTree(ROOT.resolve("sources-manifest.json").toFile());
        boolean unchanged = true;
        for (var sample : manifest.get("samples"))
            unchanged &= hash(Files.readAllBytes(ROOT.resolve(sample.get("file").asText())))
                    .equals(sample.get("sha256").asText());
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("scenarios", RECEIPTS);
        report.put("merges_checked", RECEIPTS.size());
        report.put("passed", RECEIPTS.stream().filter(r -> Boolean.TRUE.equals(r.get("passed"))).count());
        report.put("sources_unchanged", unchanged);
        report.put("all_passed", unchanged && RECEIPTS.stream().allMatch(r -> Boolean.TRUE.equals(r.get("passed"))));
        report.put("boundary",
                "Structural/content checks preserve native packages and binary bytes; optional PowerPoint verification is external. Omitted cross-slide hyperlinks are removed by the existing selection policy and are excluded from slide markup comparison.");
        JSON.writerWithDefaultPrettyPrinter().writeValue(ROOT.resolve("report.json").toFile(), report);
        assertTrue(unchanged);
    }

    private static List<Pick> picks(Path path, int count) {
        var p = new ArrayList<Pick>();
        for (int i = 1; i <= count; i++)
            p.add(new Pick(path, i));
        return p;
    }

    private static boolean isXml(String n) {
        return n.endsWith(".xml") || n.endsWith(".rels");
    }

    private static String hash(byte[] bytes) {
        return PackageDocument.hex(PackageDocument.sha(bytes));
    }

    private static String canonical(Element e) {
        if (A.equals(e.getNamespaceURI()) && Set.of("hlinkClick", "hlinkMouseOver").contains(e.getLocalName()))
            return "";
        var attributes = new TreeMap<String, String>();
        for (var a : Xml.attributes(e))
            if (!javax.xml.XMLConstants.XMLNS_ATTRIBUTE_NS_URI.equals(a.getNamespaceURI()))
                attributes.put(
                        "{" + a.getNamespaceURI() + "}" + (a.getLocalName() == null ? a.getName() : a.getLocalName()),
                        a.getValue());
        var text = new StringBuilder();
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling())
            if (n.getNodeType() == Node.TEXT_NODE || n.getNodeType() == Node.CDATA_SECTION_NODE)
                text.append(n.getNodeValue());
        var result = new StringBuilder(
                "{" + e.getNamespaceURI() + "}" + e.getLocalName() + attributes + text.toString().strip());
        for (var child : Xml.children(e)) {
            String c = canonical(child);
            if (!c.isEmpty())
                result.append('[').append(c).append(']');
        }
        return result.toString();
    }

    private static final class Audit {
        final Map<String, byte[]> parts = new HashMap<>();
        final List<String> slides = new ArrayList<>();

        Audit(Path file) throws Exception {
            try (var zip = new ZipFile(file.toFile())) {
                var entries = zip.entries();
                while (entries.hasMoreElements()) {
                    var e = entries.nextElement();
                    if (e.isDirectory())
                        continue;
                    try (var in = zip.getInputStream(e)) {
                        byte[] bytes = in.readAllBytes();
                        var crc = new CRC32();
                        crc.update(bytes);
                        assertEquals(e.getCrc(), crc.getValue(), "ZIP CRC");
                        assertNull(parts.put(e.getName(), bytes), "Duplicate ZIP entry");
                    }
                }
            }
            Map<String, String> rels = new HashMap<>();
            for (var e : Xml.children(xml("ppt/_rels/presentation.xml.rels")))
                rels.put(e.getAttribute("Id"), target(PRESENTATION, e.getAttribute("Target")));
            for (var e : Xml.children(Xml.child(xml(PRESENTATION), P, "sldIdLst")))
                slides.add(rels.get(Xml.rid(e)));
        }

        Element xml(String part) {
            return Xml.parse(parts.get(part), part);
        }

        Set<String> binaryDependencies(String slide) {
            var visited = new HashSet<String>();
            var needed = new HashSet<String>();
            var pending = new ArrayDeque<String>();
            pending.add(slide);
            while (!pending.isEmpty()) {
                String owner = pending.remove();
                if (!visited.add(owner))
                    continue;
                if (!isXml(owner))
                    needed.add(hash(parts.get(owner)));
                String rels = relationshipPart(owner);
                if (parts.containsKey(rels))
                    for (var e : Xml.children(xml(rels)))
                        if (!e.getAttribute("TargetMode").equals("External")
                                && !e.getAttribute("Type").endsWith("/slide"))
                            pending.add(target(owner, e.getAttribute("Target")));
            }
            return needed;
        }

        Map<String, Long> features() {
            return Map.of("smartart_data", count("^ppt/diagrams/.*data.*\\.xml$"), "smartart_drawings",
                    count("^ppt/diagrams/.*drawing.*\\.xml$"), "charts", count("^ppt/charts/[^/]+\\.xml$"),
                    "embeddings", count("^ppt/embeddings/.*"), "media", count("^ppt/media/.*"));
        }

        long count(String pattern) {
            return parts.keySet().stream().filter(n -> n.matches(pattern)).count();
        }

        void integrity() {
            var declarations = xml(TYPES);
            Map<String, String> defaults = new HashMap<>(), overrides = new HashMap<>();
            for (var e : Xml.children(declarations)) {
                if ("Default".equals(e.getLocalName()))
                    defaults.put(e.getAttribute("Extension").toLowerCase(Locale.ROOT), e.getAttribute("ContentType"));
                else
                    overrides.put(decode(e.getAttribute("PartName").replaceFirst("^/", "")),
                            e.getAttribute("ContentType"));
            }
            for (String part : parts.keySet()) {
                if (!part.equals(TYPES))
                    assertTrue(
                            overrides.containsKey(part) || defaults
                                    .containsKey(part.substring(part.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT)),
                            "Missing content type " + part);
                if (part.endsWith(".rels")) {
                    String owner = part.equals(ROOT_RELS)
                            ? ""
                            : part.replace("/_rels/", "/").replaceFirst("\\.rels$", "");
                    var ids = new HashSet<String>();
                    for (var e : Xml.children(xml(part))) {
                        assertTrue(ids.add(e.getAttribute("Id")));
                        if (!e.getAttribute("TargetMode").equals("External"))
                            assertTrue(parts.containsKey(target(owner, e.getAttribute("Target"))),
                                    "Missing target from " + part);
                    }
                }
            }
        }

        static String target(String owner, String uri) {
            String decoded = decode(uri.split("#", 2)[0]);
            Path base = Path.of("/" + owner).getParent();
            if (base == null)
                base = Path.of("/");
            return (decoded.startsWith("/") ? Path.of(decoded) : base.resolve(decoded)).normalize().toString()
                    .replace('\\', '/').replaceFirst("^[A-Za-z]:", "").replaceFirst("^/+", "");
        }

        static String decode(String text) {
            return URLDecoder.decode(text.replace("+", "%2B"), StandardCharsets.UTF_8);
        }

        static String relationshipPart(String owner) {
            int i = owner.lastIndexOf('/');
            return (i < 0 ? "" : owner.substring(0, i + 1)) + "_rels/" + owner.substring(i + 1) + ".rels";
        }
    }
}
