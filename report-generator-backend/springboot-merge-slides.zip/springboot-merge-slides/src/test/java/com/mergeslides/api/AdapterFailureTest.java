package com.mergeslides.api;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.*;
import org.junit.jupiter.api.*;
import org.slf4j.*;
import org.springframework.http.*;
import org.springframework.mock.web.*;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import java.io.*;
import java.nio.file.InvalidPathException;
import java.time.Instant;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdapterFailureTest {
    @Test
    void errorMapperPreservesEveryStatusAndUsesSafeMessages() {
        var mapper = new MergeHttpErrorMapper();
        for (var code : DiagnosticCode.values()) {
            var error = new MergeException(ErrorCode.INVALID_REQUEST, code, MergeStage.SELECTION, "private", null, "op",
                    List.of());
            assertEquals(code == DiagnosticCode.OUTPUT_EXISTS ? HttpStatus.CONFLICT : HttpStatus.BAD_REQUEST,
                    mapper.status(error));
            var body = mapper.body(error, "op");
            assertEquals(code.name(), body.get("failureCode"));
            assertEquals("op", body.get("operationId"));
            assertFalse(body.get("message").toString().contains("private"));
        }
        for (var code : ErrorCode.values())
            assertNotNull(mapper.status(new MergeException(code, "private")));
        var advice = new ApiExceptionHandler();
        var request = new ServletWebRequest(new MockHttpServletRequest(), new MockHttpServletResponse());
        assertEquals(400, advice.path(new InvalidPathException("private", "bad"), request).getStatusCode().value());
        assertEquals(500, advice.io(new IOException("private"), request).getStatusCode().value());
        assertEquals(500, advice.unexpected(new IllegalStateException("private"), request).getStatusCode().value());
        assertEquals(400, advice.merge(MergeException.invalid("private"), request).getStatusCode().value());
        assertEquals(500,
                advice.merge(new MergeException(ErrorCode.IO_FAILURE, "private"), request).getStatusCode().value());
        assertEquals(advice.path(new Exception(), request).getHeaders().getFirst(MergeOperationFilter.HEADER),
                request.getAttribute(MergeOperationFilter.ATTRIBUTE, 0));
        var response = new MockHttpServletResponse();
        response.setCommitted(true);
        var committed = new ServletWebRequest(new MockHttpServletRequest(), response);
        assertNull(advice.merge(MergeException.invalid("bad"), committed));
        assertNull(advice.io(new IOException(), committed));
        assertNull(advice.unexpected(new RuntimeException(), committed));
        assertNull(advice.handleExceptionInternal(new Exception(), null, HttpHeaders.EMPTY, HttpStatus.BAD_REQUEST,
                committed));
        assertEquals(400, advice.path(new Exception(), new org.springframework.web.context.request.WebRequest() {
            final Map<String, Object> attrs = new HashMap<>();

            public Object getAttribute(String n, int s) {
                return attrs.get(n);
            }

            public void setAttribute(String n, Object v, int s) {
                attrs.put(n, v);
            }

            public void removeAttribute(String n, int s) {
                attrs.remove(n);
            }

            public String[] getAttributeNames(int s) {
                return attrs.keySet().toArray(String[]::new);
            }

            public void registerDestructionCallback(String n, Runnable c, int s) {
            }

            public Object resolveReference(String k) {
                return null;
            }

            public String getSessionId() {
                return "";
            }

            public Object getSessionMutex() {
                return this;
            }

            public String getHeader(String n) {
                return null;
            }

            public String[] getHeaderValues(String n) {
                return null;
            }

            public Iterator<String> getHeaderNames() {
                return Collections.emptyIterator();
            }

            public String getParameter(String n) {
                return null;
            }

            public String[] getParameterValues(String n) {
                return null;
            }

            public Iterator<String> getParameterNames() {
                return Collections.emptyIterator();
            }

            public Map<String, String[]> getParameterMap() {
                return Map.of();
            }

            public Locale getLocale() {
                return Locale.ROOT;
            }

            public String getContextPath() {
                return "";
            }

            public String getRemoteUser() {
                return null;
            }

            public java.security.Principal getUserPrincipal() {
                return null;
            }

            public boolean isUserInRole(String r) {
                return false;
            }

            public boolean isSecure() {
                return false;
            }

            public boolean checkNotModified(long l) {
                return false;
            }

            public boolean checkNotModified(String e) {
                return false;
            }

            public boolean checkNotModified(String e, long l) {
                return false;
            }

            public String getDescription(boolean s) {
                return "";
            }
        }).getStatusCode().value());
    }

    @Test
    void reporterAdaptersEmitAllLevelsAndCauses() {
        var logger = mock(Logger.class);
        var adapter = Slf4jMergeReporter.of(logger);
        var system = MergeReporter.systemLogger();
        for (var severity : Severity.values())
            for (Throwable cause : Arrays.asList(null, new IOException("test"))) {
                var diagnostic = new MergeDiagnostic(DiagnosticCode.INVALID_SELECTION, severity, MergeStage.SELECTION,
                        "op", "message", null, null, null, null);
                var event = new MergeEvent("op", MergeEvent.Type.DIAGNOSTIC, severity, MergeStage.SELECTION, "message",
                        diagnostic, cause, Instant.now());
                adapter.report(event);
                system.report(event);
                assertEquals("INVALID_SELECTION", event.code());
                assertEquals(Map.of(), diagnostic.details());
            }
        verify(logger, times(2)).debug(anyString());
        verify(logger, times(2)).info(anyString());
        verify(logger, times(2)).warn(anyString());
        verify(logger).error(anyString());
        verify(logger).error(anyString(), any(Throwable.class));
        assertEquals(null, new MergeRequest(List.of(), "recipe", "out").recipe());
    }

    @Test
    void filterRestoresMdcOnFailureHonorsContextPathAndDoesNotTouchOtherRoutes() throws Exception {
        var filter = new MergeOperationFilter();
        var request = new MockHttpServletRequest("POST", "/context/api/v1/merges/upload");
        request.setContextPath("/context");
        var response = new MockHttpServletResponse();
        MDC.put("merge.operationId", "host");
        try {
            assertThrows(IOException.class, () -> filter.doFilter(request, response, (req, res) -> {
                assertNotEquals("host", MDC.get("merge.operationId"));
                throw new IOException("failure");
            }));
            assertEquals("host", MDC.get("merge.operationId"));
            assertEquals(request.getAttribute(MergeOperationFilter.ATTRIBUTE),
                    response.getHeader(MergeOperationFilter.HEADER));
        } finally {
            MDC.remove("merge.operationId");
        }
        for (String route : List.of("/other", "/api/v1/merges-other")) {
            var other = new MockHttpServletRequest("GET", route);
            var res = new MockHttpServletResponse();
            filter.doFilter(other, res, (req, out) -> {
            });
            assertNull(res.getHeader(MergeOperationFilter.HEADER));
        }
    }

    @Test
    void routeResolverLeavesHostHandlersAloneAndHandlesCommittedOrBrokenResponses() throws Exception {
        var resolver = new MergeRouteExceptionResolver();
        var request = new MockHttpServletRequest("GET", "/api/v1/merges");
        var response = new MockHttpServletResponse();
        var error = new HttpRequestMethodNotSupportedException("GET", List.of("POST"));
        assertNull(resolver.resolveException(request, response, new Object(), error));
        assertNull(resolver.resolveException(request, response, null, new Exception()));
        assertNull(resolver.resolveException(new MockHttpServletRequest("GET", "/host"), response, null, error));
        response.setCommitted(true);
        assertNotNull(resolver.resolveException(request, response, null, error));
        assertEquals(0, response.getContentAsByteArray().length);
        var broken = mock(jakarta.servlet.http.HttpServletResponse.class);
        when(broken.getOutputStream()).thenThrow(new IOException("disconnected"));
        assertNotNull(resolver.resolveException(request, broken, null, error));
        assertEquals(1, error.getSuppressed().length);
    }
}
