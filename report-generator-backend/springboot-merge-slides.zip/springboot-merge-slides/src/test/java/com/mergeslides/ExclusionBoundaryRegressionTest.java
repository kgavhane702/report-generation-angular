package com.mergeslides;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.RecipeCodec;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ExclusionBoundaryRegressionTest {
    @TempDir
    Path dir;

    @Test
    void genericExclusionBoundariesRejectNestedNullsWithoutReplacingOutput() throws Exception {
        Path file = ExclusionFixtures.deck(dir, "a.pptx");
        Path output = dir.resolve("existing.pptx");
        Files.writeString(output, "sentinel");
        for (Object value : List.of(Arrays.asList(3, null), List.of(Arrays.asList(6, null)))) {
            for (int scope = 0; scope < 4; scope++) {
                int selected = scope;
                var error = assertThrows(MergeException.class, () -> {
                    var builder = MergeSlides.builder().addFile(file).output(output).overwrite(true);
                    var selection = InputSelection.numeric(value);
                    switch (selected) {
                        case 0 -> builder.exclude(file, selection);
                        case 1 -> builder.exclude(List.of(file), selection);
                        case 2 -> builder.excludeDirectory(dir, selection);
                        default -> builder.excludeDirectories(List.of(dir), selection);
                    }
                    builder.merge();
                });
                assertTrue(error.getMessage().toLowerCase(Locale.ROOT).contains("null"));
                assertEquals("sentinel", Files.readString(output));
            }
            assertThrows(MergeException.class, () -> MergeSlides.builder().addFile(file)
                    .exclude(file, InputSelection.title("Confidential").withinSelection(value)).plan());
        }
    }

    @Test
    void recipesRejectNullsInNumericAndWithinListsButKeepTopLevelAllAndNullableSlices() throws Exception {
        Path file = ExclusionFixtures.deck(dir, "a.pptx");
        var codec = new RecipeCodec();
        for (String selector : List.of("\"slides\":[3,null]", "\"slides\":[[3,null]]",
                "\"title\":\"Confidential\",\"within\":[[null]]")) {
            String json = "{\"version\":2,\"sources\":[\"a.pptx\"],\"exclude\":[{\"file\":\"a.pptx\"," + selector
                    + "}]}";
            assertThrows(MergeException.class, () -> codec.decode(codec.parse(json), dir));
        }
        assertThrows(MergeException.class,
                () -> codec.decode(codec.parse("{\"version\":2,\"exclude\":[{\"files\":[],\"slides\":[null]}]}"), dir));
        assertThrows(MergeException.class, () -> codec
                .decode(codec.parse("{\"version\":2,\"exclude\":[{\"titles\":[],\"within\":[null]}]}"), dir));
        var all = codec.decode(
                codec.parse(
                        "{\"version\":2,\"sources\":[\"a.pptx\"],\"exclude\":[{\"file\":\"a.pptx\",\"slides\":null}]}"),
                dir);
        assertEquals(DiagnosticCode.NO_ELIGIBLE_SLIDES,
                assertThrows(MergeException.class, () -> MergeJob.fromDefinition(all, MergeReporter.silent()).plan())
                        .failureCode());
        assertEquals(10, MergeSlides.builder().addFile(file)
                .exclude(file, InputSelection.numeric(Map.of("slice", new HashMap<String, Object>() {
                    {
                        put("start", null);
                        put("stop", 2);
                    }
                }))).plan().slides().size());
        // Legacy inclusion retains recursive null-as-all semantics.
        assertEquals(13, MergeSlides.builder().addFile(file, InputSelection.numeric(Arrays.asList(1, null)))
                .remainingSlides(RemainingSlides.NONE).plan().slides().size());
    }

    @Test
    void excludedRichSourceCannotSupplyCanvasOrCoreMetadataButLegacyPolicyIsPreserved() throws Exception {
        Path rich = sized("rich.pptx", 4, 12192000, "excluded metadata");
        Path kept = sized("kept.pptx", 2, 9144000, "retained metadata");
        byte[] richHash = PackageDocument.sha(Files.readAllBytes(rich)),
                keptHash = PackageDocument.sha(Files.readAllBytes(kept));
        for (boolean legacy : List.of(false, true)) {
            Path output = dir.resolve(legacy ? "legacy.pptx" : "new.pptx");
            var builder = MergeSlides.builder().addFiles(List.of(rich, kept)).output(output);
            if (legacy)
                builder.exclude(rich, InputSelection.all());
            else
                builder.excludeFile(rich);
            assertEquals(2, builder.merge().slideCount());
            var document = TestPackages.reader().read(output);
            var presentation = Xml.parse(document.parts().get(Ooxml.PRESENTATION), "test");
            assertEquals(legacy ? "12192000" : "9144000", Xml.child(presentation, Ooxml.P, "sldSz").getAttribute("cx"));
            assertTrue(new String(document.parts().get("docProps/core.xml"), StandardCharsets.UTF_8)
                    .contains(legacy ? "excluded metadata" : "retained metadata"));
        }
        assertArrayEquals(richHash, PackageDocument.sha(Files.readAllBytes(rich)));
        assertArrayEquals(keptHash, PackageDocument.sha(Files.readAllBytes(kept)));
    }

    private Path sized(String name, int count, long width, String title) throws Exception {
        var parts = TestPackages.parts(name, count);
        parts.put(Ooxml.PRESENTATION, new String(parts.get(Ooxml.PRESENTATION), StandardCharsets.UTF_8)
                .replace("9144000", Long.toString(width)).getBytes(StandardCharsets.UTF_8));
        parts.put("docProps/core.xml",
                ("<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>"
                        + title + "</dc:title></cp:coreProperties>").getBytes(StandardCharsets.UTF_8));
        parts.put(Ooxml.ROOT_RELS, TestPackages.relationships(TestPackages.rel("r",
                Ooxml.RelationshipType.OFFICE_DOCUMENT, Ooxml.PRESENTATION)
                + "<Relationship Id=\"core\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>")
                .getBytes(StandardCharsets.UTF_8));
        String ct = new String(parts.get(Ooxml.TYPES), StandardCharsets.UTF_8).replace("</Types>",
                "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/></Types>");
        parts.put(Ooxml.TYPES, ct.getBytes(StandardCharsets.UTF_8));
        return TestPackages.write(dir.resolve(name), parts);
    }
}
