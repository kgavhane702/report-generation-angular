package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.TestPackages;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static org.junit.jupiter.api.Assertions.*;

class MetadataPreservationTest {
    @TempDir
    Path dir;

    @Test
    void commentsConflictingStylesNotesSectionsAndShowsSurviveReorderingAndRepetition() throws Exception {
        var a = features("a.pptx", false);
        var b = features("b.pptx", true);
        var same = features("same.pptx", false);
        var sequence = List.of(new MergeContext.Occurrence(a, a.slides.get(1)),
                new MergeContext.Occurrence(a, a.slides.get(0)), new MergeContext.Occurrence(b, b.slides.get(0)),
                new MergeContext.Occurrence(a, a.slides.get(0)));
        var context = new MergeContext(List.of(a, b, same), sequence);
        var parts = new PresentationAssembler(context).build();
        Path output = dir.resolve("output.pptx");
        new AtomicPackageWriter(TestPackages.reader()).write(parts, output);
        var result = TestPackages.reader().read(output);
        assertEquals(4, result.slides.size());
        var authors = Xml.parse(result.parts.get(AUTHORS), AUTHORS);
        assertEquals(1, Xml.children(authors).size());
        assertEquals("3", Xml.children(authors).get(0).getAttribute("lastIdx"));
        assertEquals(2, Xml.children(Xml.parse(result.parts.get(TABLE_STYLES), TABLE_STYLES)).size());
        assertTrue(context.tableIds.get(b.path).get("original").matches("\\{[A-F0-9-]{36}\\}"));
        var bSlide = result.slideXml(2);
        assertEquals(context.tableIds.get(b.path).get("original"),
                Xml.findAll(bSlide, A, "tableStyleId").get(0).getTextContent());
        var presentation = result.xml.get(PRESENTATION);
        assertEquals(3, Xml.findAll(presentation, P14, "section").size());
        assertEquals(1, Xml.children(Xml.child(presentation, P, "custShowLst")).size());
        var app = Xml.parse(result.parts.get("docProps/app.xml"), "app");
        assertEquals("4", Xml.child(app, EP, "Slides").getTextContent());
        assertEquals("0", Xml.child(app, EP, "HiddenSlides").getTextContent());
        assertNull(Xml.child(app, EP, "HeadingPairs"));
        assertNull(Xml.child(app, EP, "TitlesOfParts"));
        assertTrue(result.types.containsValue(ContentType.NOTES_MASTER.mime()));
        assertTrue(result.types.containsValue(ContentType.NOTES_SLIDE.mime()));
        assertTrue(result.types.containsValue(ContentType.HANDOUT_MASTER.mime()));
        assertTrue(new String(result.parts.get(PackagePaths.rels(PRESENTATION)), StandardCharsets.UTF_8)
                .contains("https://example.com"));
        assertEquals(3, context.warnings.size()); // Each imported occurrence prunes its omitted slide link.
    }

    @Test
    void unusedAuthorsAreRemovedAndSectionExtensionCanBeCreatedFromAnotherSource() throws Exception {
        var source = features("source.pptx", false);
        var plain = TestPackages.reader().read(TestPackages.create(dir, "plain.pptx", "plain", 3));
        var context = new MergeContext(List.of(plain, source),
                List.of(new MergeContext.Occurrence(plain, plain.slides.get(0))));
        var metadata = new MetadataMerger(context);
        metadata.authorsAndStyles();
        metadata.pruneAuthors();
        assertFalse(context.parts.containsKey(AUTHORS));
        assertFalse(context.types.containsKey(AUTHORS));
        var presentation = Xml.copy(plain.xml.get(PRESENTATION));
        metadata.sections(presentation);
        assertEquals("plain", Xml.findAll(presentation, P14, "section").get(0).getAttribute("name"));
        assertEquals(1, Xml.findAll(presentation, P, "ext").size());
        var ext = Xml.child(presentation, P, "extLst");
        ext.removeChild(ext.getFirstChild());
        metadata.sections(presentation);
        assertEquals(1, Xml.findAll(presentation, P14, "sectionLst").size());
    }

    PackageDocument features(String name, boolean changed) throws Exception {
        var parts = TestPackages.parts("features", 3);
        add(parts, AUTHORS, "<p:cmAuthorLst xmlns:p=\"" + P
                + "\"><p:cmAuthor id=\"0\" name=\"Sam\" initials=\"S\"/><p:cmAuthor id=\"1\" name=\"Unused\" initials=\"U\"/><p:cmAuthor id=\"2\"><p:presence userId=\"user\" providerId=\"provider\"/></p:cmAuthor></p:cmAuthorLst>",
                ContentType.AUTHORS.mime());
        add(parts, TABLE_STYLES,
                "<a:tblStyleLst xmlns:a=\"" + A + "\" def=\"original\"><a:tblStyle styleId=\"original\" styleName=\""
                        + (changed ? "changed" : "same") + "\"/></a:tblStyleLst>",
                ContentType.TABLE_STYLES.mime());
        add(parts, "ppt/comments/comment1.xml",
                "<p:cmLst xmlns:p=\"" + P
                        + "\"><p:cm authorId=\"0\" idx=\"9\"><p:text>Comment</p:text></p:cm><p:extLst/></p:cmLst>",
                ContentType.COMMENTS.mime());
        add(parts, "ppt/notesSlides/notesSlide1.xml", "<p:notes xmlns:p=\"" + P + "\"><p:cSld/></p:notes>",
                ContentType.NOTES_SLIDE.mime());
        add(parts, "ppt/notesMasters/notesMaster1.xml",
                "<p:notesMaster xmlns:p=\"" + P + "\"><p:cSld/></p:notesMaster>", ContentType.NOTES_MASTER.mime());
        add(parts, "ppt/handoutMasters/handoutMaster1.xml",
                "<p:handoutMaster xmlns:p=\"" + P + "\"><p:cSld/></p:handoutMaster>",
                ContentType.HANDOUT_MASTER.mime());
        add(parts, "ppt/notesSlides/_rels/notesSlide1.xml.rels",
                TestPackages.relationships(
                        TestPackages.rel("n", RelationshipType.NOTES_MASTER, "../notesMasters/notesMaster1.xml")
                                + TestPackages.rel("s", RelationshipType.SLIDE, "../slides/slide1.xml")),
                RELS_MIME);
        add(parts, "ppt/notesMasters/_rels/notesMaster1.xml.rels",
                TestPackages.relationships(TestPackages.rel("t", RelationshipType.THEME, "../theme/theme1.xml")),
                RELS_MIME);
        add(parts, "docProps/app.xml", "<Properties xmlns=\"" + EP
                + "\"><Slides>99</Slides><Notes>99</Notes><HiddenSlides>99</HiddenSlides><HeadingPairs/><TitlesOfParts/></Properties>",
                ContentType.EXTENDED_PROPERTIES.mime());
        append(parts, ROOT_RELS, "</Relationships>",
                "<Relationship Id=\"app\" Type=\"" + R + "/extended-properties\" Target=\"docProps/app.xml\"/>");
        append(parts, PackagePaths.rels(PRESENTATION), "</Relationships>", TestPackages.rel("authors",
                RelationshipType.COMMENT_AUTHORS, "commentAuthors.xml")
                + TestPackages.rel("styles", RelationshipType.TABLE_STYLES, "tableStyles.xml")
                + TestPackages.rel("notes", RelationshipType.NOTES_MASTER, "notesMasters/notesMaster1.xml")
                + "<Relationship Id=\"handout\" Type=\"urn:handout-extension\" Target=\"handoutMasters/handoutMaster1.xml\"/>"
                + "<Relationship Id=\"external\" Type=\"urn:external\" Target=\"https://example.com\" TargetMode=\"External\"/>");
        append(parts, "ppt/slides/_rels/slide1.xml.rels", "</Relationships>",
                "<Relationship Id=\"comments\" Type=\"" + R + "/comments\" Target=\"../comments/comment1.xml\"/>"
                        + TestPackages.rel("notes", RelationshipType.NOTES_SLIDE, "../notesSlides/notesSlide1.xml")
                        + TestPackages.rel("omitted", RelationshipType.SLIDE, "slide3.xml"));
        append(parts, "ppt/slides/slide1.xml", "</p:sld>",
                "<a:tableStyleId xmlns:a=\"" + A + "\">original</a:tableStyleId>");
        append(parts, PRESENTATION, "</p:presentation>",
                "<p:custShowLst><p:custShow name=\"keep\" id=\"0\"><p:sldLst><p:sld r:id=\"s1\"/><p:sld r:id=\"s3\"/></p:sldLst></p:custShow><p:custShow name=\"drop\" id=\"1\"><p:sldLst><p:sld r:id=\"s3\"/></p:sldLst></p:custShow></p:custShowLst>"
                        + "<p:extLst><p:ext uri=\"" + SECTION_EXTENSION + "\"><p14:sectionLst xmlns:p14=\"" + P14
                        + "\"><p14:section name=\"Section\" id=\"{00000000-0000-0000-0000-000000000001}\"><p14:sldIdLst><p14:sldId id=\"256\"/><p14:sldId id=\"257\"/></p14:sldIdLst></p14:section><p14:section><p14:sldIdLst><p14:sldId id=\"258\"/></p14:sldIdLst></p14:section></p14:sectionLst></p:ext></p:extLst>");
        return TestPackages.reader().read(TestPackages.write(dir.resolve(name), parts));
    }

    static void add(Map<String, byte[]> parts, String name, String text, String type) {
        parts.put(name, text.getBytes(StandardCharsets.UTF_8));
        append(parts, TYPES, "</Types>", "<Override PartName=\"/" + name + "\" ContentType=\"" + type + "\"/>");
    }

    static void append(Map<String, byte[]> parts, String name, String end, String text) {
        parts.put(name, new String(parts.get(name), StandardCharsets.UTF_8).replace(end, text + end)
                .getBytes(StandardCharsets.UTF_8));
    }
}
