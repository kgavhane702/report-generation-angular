package com.mergeslides;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.*;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class RestContractRegressionTest {
    static final Path DIR;
    static {
        try {
            DIR = Files.createTempDirectory("rest-contract-");
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @DynamicPropertySource
    static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", DIR::toString);
        r.add("merge.temp-directory", () -> DIR.resolve("temp").toString());
    }

    @Autowired
    MockMvc mvc;

    @BeforeEach
    void deck() throws Exception {
        ExclusionFixtures.deck(DIR, "a.pptx");
    }

    @AfterAll
    static void cleanup() throws Exception {
        try (var paths = Files.walk(DIR)) {
            for (Path p : paths.sorted(Comparator.reverseOrder()).toList())
                Files.deleteIfExists(p);
        }
    }

    @Test
    void misplacedControlsAreRejectedButUnrelatedUnknownFieldsRemainIgnored() throws Exception {
        for (String key : List.of("exclude", "select", "sources", "options", "version")) {
            mvc.perform(post("/api/v1/merges").contentType("application/json")
                    .content("{\"inputs\":[\"a.pptx\"],\"output\":\"" + key + ".pptx\",\"" + key + "\":null}"))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("recipe")));
            assertFalse(Files.exists(DIR.resolve(key + ".pptx")));
        }
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"inputs\":[\"a.pptx\"],\"output\":\"unknown.pptx\",\"hostMetadata\":true}"))
                .andExpect(status().isOk());
    }

    @Test
    void duplicateKeysAreRejectedInInlineRecipesAndEnvelope() throws Exception {
        for (String body : List.of(
                "{\"recipe\":{\"version\":2,\"sources\":[\"a.pptx\"],\"exclude\":[\"Confidential\"],\"exclude\":[]},\"output\":\"dup.pptx\"}",
                "{\"inputs\":[\"a.pptx\"],\"output\":\"first.pptx\",\"output\":\"last.pptx\"}"))
            mvc.perform(post("/api/v1/merges").contentType("application/json").content(body))
                    .andExpect(status().isBadRequest());
        assertFalse(Files.exists(DIR.resolve("dup.pptx")));
    }

    @Test
    void invalidExclusionListsFailAcrossInlinePathAndUploadWithoutOutput() throws Exception {
        String recipe = "{\"version\":2,\"sources\":[\"a.pptx\"],\"exclude\":[{\"files\":[\"a.pptx\"],\"slides\":[[3,null]]}]}";
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"recipe\":" + recipe + ",\"output\":\"invalid.pptx\"}")).andExpect(status().isBadRequest());
        Files.writeString(DIR.resolve("recipe.json"), recipe);
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"recipePath\":\"recipe.json\",\"output\":\"invalid.pptx\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(multipart("/api/v1/merges/upload").file(new MockMultipartFile("files", "a.pptx",
                "application/octet-stream", Files.readAllBytes(DIR.resolve("a.pptx")))).param("recipe", recipe))
                .andExpect(status().isBadRequest());
        assertFalse(Files.exists(DIR.resolve("invalid.pptx")));
    }

    @Test
    void duplicateRecipeKeysAreRejectedThroughEveryRecipeEntryPoint() throws Exception {
        String recipe = "[{\"file\":\"missing.pptx\",\"file\":\"a.pptx\"}]";
        Files.writeString(DIR.resolve("duplicate.json"), recipe);
        for (String mode : List.of("\"inputs\":[\"duplicate.json\"]", "\"recipePath\":\"duplicate.json\""))
            mvc.perform(post("/api/v1/merges").contentType("application/json")
                    .content("{" + mode + ",\"output\":\"legacy-duplicate.pptx\"}")).andExpect(status().isBadRequest());
        mvc.perform(multipart("/api/v1/merges/upload").file(new MockMultipartFile("files", "a.pptx",
                "application/octet-stream", Files.readAllBytes(DIR.resolve("a.pptx")))).param("recipe", recipe))
                .andExpect(status().isBadRequest());
        var resolver = new com.mergeslides.infrastructure.input.InputResolver(
                new com.fasterxml.jackson.databind.ObjectMapper());
        var reader = TestPackages.reader();
        var cli = new com.mergeslides.cli.MergeCli(new com.mergeslides.infrastructure.ooxml.PackageMergeService(reader,
                new com.mergeslides.infrastructure.ooxml.AtomicPackageWriter(reader)), resolver);
        assertEquals(2, cli.run(new String[]{"-r", "duplicate.json", "-o", "duplicate-cli.pptx"}, DIR, DIR,
                new java.io.PrintStream(java.io.OutputStream.nullOutputStream()), System.err));
        assertFalse(Files.exists(DIR.resolve("legacy-duplicate.pptx")));
    }
}
