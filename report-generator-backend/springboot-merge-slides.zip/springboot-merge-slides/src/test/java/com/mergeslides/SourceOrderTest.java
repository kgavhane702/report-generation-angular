package com.mergeslides;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

class SourceOrderTest {
    @TempDir
    Path dir;
    Path a, b;

    @BeforeEach
    void decks() throws Exception {
        a = ExclusionFixtures.deck(dir, "a.pptx");
        b = ExclusionFixtures.deck(dir, "b.pptx");
    }

    MergeSlides.Builder job() {
        return MergeSlides.builder().baseDirectory(dir).remaining(RemainingSlides.NONE)
                .reporter(MergeReporter.silent());
    }

    List<String> rows(MergePlan plan) {
        return plan.slides().stream().map(s -> s.file().getFileName() + ":" + s.slideNumber()).toList();
    }

    List<String> occurrences(MergePlan plan) {
        return plan.slides().stream().map(s -> s.sourceOccurrence() + ":" + s.slideNumber()).toList();
    }

    @Test
    void repeatedSourcesCompleteTitleListsIncludingSeparateAndFileScopedCalls() {
        var expected = List.of("1:4", "1:9", "2:4", "2:9");
        assertEquals(expected, occurrences(job().searchFiles(a, a).addTitles("Roadmap", "Appendix").plan()));
        assertEquals(expected, occurrences(job().searchFiles(a, a).addTitle("Roadmap").addTitle("Appendix").plan()));
        assertEquals(expected, occurrences(job().searchFiles(a, a).addTitles(a, "Roadmap", "Appendix").plan()));
        assertEquals(expected,
                occurrences(job().addFiles(List.of(a, a), InputSelection.titles("Roadmap", "Appendix")).plan()));
        assertEquals(List.of("1:4", "1:4", "1:9", "2:4", "2:4", "2:9"),
                occurrences(job().searchFiles(a, a).addTitles("Roadmap", "Roadmap", "Appendix").plan()));
    }

    @Test
    void distinctSourcesAndSeparateNumericCallsFollowSourceDeclarationOrder() {
        assertEquals(List.of("a.pptx:9", "a.pptx:4", "b.pptx:9", "b.pptx:4"),
                rows(job().searchFiles(a, b).addTitles("Appendix", "Roadmap").plan()));
        assertEquals(List.of("1:9", "1:4", "2:9", "2:4"),
                occurrences(job().searchFiles(a, a).addSlide(a, 9).addSlide(a, 4).plan()));
        assertEquals(List.of("a.pptx:4", "b.pptx:9"),
                rows(job().searchFiles(a, b).addSlide(b, 9).addSlide(a, 4).plan()));
    }

    @ParameterizedTest
    @EnumSource(RemainingSlides.class)
    void eachSourceCompletesItsRemainingSlidesAndActualOutput(RemainingSlides mode) throws Exception {
        List<Integer> other = List.of(1, 2, 3, 5, 6, 7, 8, 10, 11, 12), selected = List.of(4, 9);
        List<Integer> block = mode == RemainingSlides.NONE
                ? selected
                : mode == RemainingSlides.START
                        ? Stream.concat(other.stream(), selected.stream()).toList()
                        : Stream.concat(selected.stream(), other.stream()).toList();
        List<String> expected = Stream
                .concat(block.stream().map(i -> "a.pptx:" + i), block.stream().map(i -> "b.pptx:" + i)).toList();
        byte[] beforeA = Files.readAllBytes(a), beforeB = Files.readAllBytes(b);
        var builder = job().searchFiles(a, b).addTitle("Roadmap").addTitle("Appendix").remaining(mode);
        var preview = builder.plan();
        assertEquals(expected, rows(preview));
        assertEquals(4, preview.summary().selectedCount());
        assertEquals(mode == RemainingSlides.NONE ? 0 : 20, preview.summary().remainingCount());
        var report = builder.output(dir.resolve("result.pptx")).mergeDetailed();
        assertEquals(expected,
                report.slides().stream().map(s -> s.file().getFileName() + ":" + s.slideNumber()).toList());
        var output = TestPackages.reader().read(report.result().outputPath());
        assertEquals(expected.size(), output.slides().size());
        var actual = new ArrayList<String>();
        for (int i = 0; i < output.slides().size(); i++)
            actual.add(com.mergeslides.infrastructure.ooxml.Xml
                    .child(output.slideXml(i), com.mergeslides.infrastructure.ooxml.Ooxml.P, "cSld")
                    .getAttribute("name"));
        assertEquals(expected, actual);
        assertArrayEquals(beforeA, Files.readAllBytes(a));
        assertArrayEquals(beforeB, Files.readAllBytes(b));
    }

    @Test
    void numericListsRangesSlicesAndWholeInputsKeepTheirOrderInsideEachSource() {
        for (InputSelection selection : List.of(InputSelection.slides(3, 1), InputSelection.range("2-4,1"),
                InputSelection.slice(new SlideSlice(3, 0, -1)), InputSelection.all())) {
            List<Integer> indices = SlideSelector.select(selection.numbers(), 12).stream().map(i -> i + 1).toList();
            for (RemainingSlides mode : RemainingSlides.values()) {
                var rest = java.util.stream.IntStream.rangeClosed(1, 12).boxed().filter(i -> !indices.contains(i))
                        .toList();
                List<Integer> block = mode == RemainingSlides.NONE
                        ? indices
                        : mode == RemainingSlides.START
                                ? Stream.concat(rest.stream(), indices.stream()).toList()
                                : Stream.concat(indices.stream(), rest.stream()).toList();
                assertEquals(
                        Stream.concat(block.stream().map(i -> "a.pptx:" + i), block.stream().map(i -> "b.pptx:" + i))
                                .toList(),
                        rows(job().addFiles(List.of(a, b), selection).remaining(mode).plan()));
            }
        }
    }

    @Test
    void titlePoliciesAreIndependentWithinEachSourceOccurrence() {
        for (DuplicateTitlePolicy policy : List.of(DuplicateTitlePolicy.FIRST, DuplicateTitlePolicy.LAST)) {
            int index = policy == DuplicateTitlePolicy.FIRST ? 3 : 6;
            assertEquals(List.of("a.pptx:" + index, "b.pptx:" + index),
                    rows(job().searchFiles(a, b).addTitle("Confidential").duplicateTitles(policy).plan()));
            assertEquals(List.of("1:" + index, "2:" + index),
                    occurrences(job().searchFiles(a, a).addTitle("Confidential").duplicateTitles(policy).plan()));
        }
        assertEquals(List.of("a.pptx:4", "b.pptx:4"),
                rows(job().searchFiles(a, b).addTitle("Roadmap").duplicateTitles(DuplicateTitlePolicy.ERROR).plan()));
        assertEquals(DiagnosticCode.DUPLICATE_TITLE, assertThrows(MergeException.class, () -> job().searchFiles(a, b)
                .addTitle("Confidential").duplicateTitles(DuplicateTitlePolicy.ERROR).plan()).failureCode());
    }

    @Test
    void missingTitlesAreReportedPerSourceAndStrictModePreservesDestination() throws Exception {
        Path shortDeck = ExclusionFixtures.deck(dir, "short.pptx", 4);
        var builder = job().searchFiles(a, shortDeck).addTitle("Appendix");
        var plan = builder.plan();
        assertEquals(List.of("a.pptx:9"), rows(plan));
        assertEquals(1, plan.summary().missingTitleCount());
        assertEquals(shortDeck.toString(), plan.diagnostics().get(0).source());
        assertEquals(1, plan.diagnostics().get(0).selectionIndex());
        Path output = Files.writeString(dir.resolve("sentinel.pptx"), "sentinel");
        var error = assertThrows(MergeException.class,
                () -> builder.onMissing(MissingTitlePolicy.ERROR).overwrite(true).output(output).merge());
        assertEquals(DiagnosticCode.TITLE_NOT_FOUND, error.failureCode());
        assertEquals("sentinel", Files.readString(output));
    }

    @Test
    void exclusionsHiddenOverridesAndDeduplicationStillApplyToEveryOccurrence() {
        var builder = job().searchFiles(a, a).addTitles("Roadmap", "Confidential", "Appendix").skipHidden()
                .excludeTitle("Roadmap");
        assertEquals(List.of("1:3", "1:9", "2:3", "2:9"), occurrences(builder.plan()));
        assertEquals(List.of("1:3", "1:9", "1:6", "2:3", "2:9", "2:6"),
                occurrences(builder.selectFile(a, InputSelection.slides(6).skipHidden(false)).plan()));
        assertEquals(List.of("a.pptx:3", "a.pptx:9", "a.pptx:6"),
                rows(builder.repeatedSlides(RepeatedSlidePolicy.SKIP).plan()));
        assertEquals(DiagnosticCode.REPEATED_SLIDE,
                assertThrows(MergeException.class, () -> builder.repeatedSlides(RepeatedSlidePolicy.ERROR).plan())
                        .failureCode());
        assertEquals(2, job().searchFiles(a, a).addTitles("Roadmap", "Appendix")
                .duplicateSources(DuplicateSourcePolicy.SKIP).plan().slides().size());
        assertEquals(DiagnosticCode.DUPLICATE_SOURCE, assertThrows(MergeException.class,
                () -> job().searchFiles(a, a).addTitle("Roadmap").duplicateSources(DuplicateSourcePolicy.ERROR).plan())
                .failureCode());
    }

    @Test
    void directoriesAndRepeatedDirectoriesCompleteEachExpandedFile() throws Exception {
        Path folder = dir.resolve("decks");
        ExclusionFixtures.deck(folder, "deck10.pptx");
        ExclusionFixtures.deck(folder, "deck2.pptx");
        var expected = List.of("deck2.pptx:9", "deck2.pptx:4", "deck10.pptx:9", "deck10.pptx:4");
        assertEquals(expected, rows(job().addDirectory(folder, InputSelection.titles("Appendix", "Roadmap")).plan()));
        assertEquals(Stream.concat(expected.stream(), expected.stream()).toList(),
                rows(job().searchFiles(folder, folder).addTitle("Appendix").addTitle("Roadmap").plan()));
    }

    @Test
    void recipeChunksStayBetweenCompleteSourceBlocksAndSourcesAreEmittedOnce() throws Exception {
        Path c = ExclusionFixtures.deck(dir, "c.pptx");
        Path child = Files.writeString(dir.resolve("child.json"), "[{\"file\":\"b.pptx\",\"slides\":[9]}]");
        var plan = job().addFile(a, InputSelection.slides(4)).addRecipe(child).addSlide(a, 9)
                .addFile(c, InputSelection.slides(1)).remaining(RemainingSlides.END).plan();
        List<Integer> first = List.of(4, 9, 1, 2, 3, 5, 6, 7, 8, 10, 11, 12);
        var expected = new ArrayList<>(first.stream().map(i -> "a.pptx:" + i).toList());
        expected.add("b.pptx:9");
        java.util.stream.IntStream.rangeClosed(1, 12).forEach(i -> expected.add("c.pptx:" + i));
        assertEquals(expected, rows(plan));
        var before = job().searchFiles(a).addRecipe(child).remaining(RemainingSlides.END).plan();
        assertEquals("a.pptx:1", rows(before).get(0));
        assertEquals("b.pptx:9", rows(before).get(12));
        var after = job().addRecipe(child).searchFiles(a).remaining(RemainingSlides.END).plan();
        assertEquals("b.pptx:9", rows(after).get(0));
        assertEquals("a.pptx:1", rows(after).get(1));
    }

    @Test
    void recipeTitleStringsUseTheSameSourceFirstRules() throws Exception {
        Path recipe = Files.writeString(dir.resolve("titles.json"),
                """
                        {"version":2,"sources":["a.pptx","a.pptx"],"select":["Roadmap","Appendix"],"options":{"remaining":"none"}}
                        """);
        assertEquals(List.of("1:4", "1:9", "2:4", "2:9"), occurrences(job().addRecipe(recipe).plan()));
    }

    @Test
    void internalOrderCompatibilityValidationAndFallbacksAreExplicit() throws Exception {
        var source = new MergeDefinition.Source(0, a);
        var query = new MergeDefinition.Query(0, null, InputSelection.slides(4), null);
        var options = MergeDefinition.Options.defaults();
        var original = new MergeDefinition(dir, null, List.of(source), List.of(query), List.of(), options);
        assertEquals(original.inputOrder(), original.withOutput(dir.resolve("out.pptx")).inputOrder());
        var order = new ArrayList<>(List.of(MergeDefinition.InputStep.query(0)));
        var explicit = new MergeDefinition(dir, null, List.of(source), List.of(query), List.of(), options, order);
        order.clear();
        assertEquals(1, explicit.inputOrder().size());
        assertEquals(List.of(4, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12),
                MergeJob.fromDefinition(explicit, MergeReporter.silent()).plan().slides().stream()
                        .map(PlannedSlide::slideNumber).toList());
        var partial = new MergeDefinition(dir, null, List.of(source), List.of(query), List.of(), options, List.of());
        assertEquals(12, MergeJob.fromDefinition(partial, MergeReporter.silent()).plan().slides().size());
        for (MergeDefinition.InputStep invalid : List.of(MergeDefinition.InputStep.source(9),
                MergeDefinition.InputStep.query(9)))
            assertThrows(MergeException.class, () -> new MergeDefinition(dir, null, List.of(source), List.of(query),
                    List.of(), options, List.of(invalid)));
        assertThrows(MergeException.class, () -> new MergeDefinition.InputStep(null, null));
        assertThrows(MergeException.class, () -> new MergeDefinition.InputStep(0, 0));
        assertThrows(MergeException.class, () -> MergeDefinition.InputStep.source(-1));
        assertThrows(MergeException.class, () -> MergeDefinition.InputStep.query(-1));
        Path child = Files.writeString(dir.resolve("same-query.json"), "[{\"file\":\"a.pptx\",\"slides\":4}]");
        var sameQuery = new MergeDefinition.Query(null, null, null, child);
        var repeats = new MergeDefinition(dir, null, List.of(), List.of(sameQuery, sameQuery), List.of(), options,
                List.of());
        var repeatPlan = MergeJob.fromDefinition(repeats, MergeReporter.silent()).plan();
        assertEquals(List.of(4, 4), repeatPlan.slides().stream().map(PlannedSlide::slideNumber).toList());
        assertNotEquals(repeatPlan.slides().get(0).sourceOccurrence(), repeatPlan.slides().get(1).sourceOccurrence());
    }

    @Test
    void earlierFileReferencesDoNotMoveLaterRepeatedInputsAheadOfRecipeChunks() throws Exception {
        Path child = Files.writeString(dir.resolve("middle.json"), "[{\"file\":\"b.pptx\",\"slides\":9}]");
        assertEquals(List.of("a.pptx:4", "a.pptx:9", "b.pptx:9", "a.pptx:4", "a.pptx:1"),
                rows(job().addTitle(a, "Roadmap").addRecipe(child).addFile(a, InputSelection.slides(9))
                        .addFile(a, InputSelection.slides(1)).plan()));
    }

    @Test
    void childRecipeSourcesDoNotSilentlySatisfyAnEmptyParentTitleScope() throws Exception {
        Path child = Files.writeString(dir.resolve("independent.json"), "[{\"file\":\"b.pptx\",\"slides\":9}]");
        var builder = job().addRecipe(child).addTitle("Appendix");
        var preview = builder.plan();
        assertEquals(List.of("b.pptx:9"), rows(preview));
        assertEquals(1, preview.diagnostics().size());
        assertEquals(DiagnosticCode.TITLE_NOT_FOUND, preview.diagnostics().get(0).code());
        assertNull(preview.diagnostics().get(0).source());
        assertEquals(DiagnosticCode.TITLE_NOT_FOUND,
                assertThrows(MergeException.class, () -> builder.onMissing(MissingTitlePolicy.ERROR).plan())
                        .failureCode());
    }

    @Test
    void hiddenRemainingSlidesAndWholeFileSelectionsStayExplicit() {
        var hidden = job().searchFiles(a, b).addTitle("Roadmap").skipHidden().remaining(RemainingSlides.END).plan();
        assertEquals(22, hidden.slides().size());
        assertEquals(2, hidden.summary().hiddenFilteredCount());
        assertTrue(hidden.slides().stream().noneMatch(PlannedSlide::hidden));
        var whole = job().addFiles(a, a).addTitle("Roadmap").plan();
        assertEquals(26, whole.slides().size());
        assertEquals(13, whole.slides().subList(0, 13).stream().filter(s -> s.sourceOccurrence() == 1).count());
        assertEquals(13, whole.slides().subList(13, 26).stream().filter(s -> s.sourceOccurrence() == 2).count());
    }
}
