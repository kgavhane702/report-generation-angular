package com.mergeslides;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.api.lib.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.cli.MergeCli;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.*;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class SelectionValidationCoverageTest {
    @TempDir
    Path dir;

    @Test
    void selectorValidatesNumericTypesSliceBoundsAndMalformedRanges() {
        for (Object number : List.of((byte) 2, (short) 2, 2, 2L, BigInteger.valueOf(2)))
            assertEquals(List.of(1), SlideSelector.select(number, 5));
        for (Object invalid : List.of(0, 6, -6, BigInteger.TEN.pow(40), 3.5, true, new Object(), Map.of("slice", 3),
                Map.of("slice", Map.of("start", "bad")), Map.of("slice", Map.of("stop", Long.MAX_VALUE)),
                Map.of("slice", Map.of("step", 0)), "-", "1--3", "999999999999999999999-", "bad"))
            assertThrows(MergeException.class, () -> SlideSelector.select(invalid, 5), invalid.toString());
        assertEquals(List.of(0, 1, 4), SlideSelector.select(" , -2,5-, ", 5));
        assertEquals(List.of(4, 3, 2, 1, 0), SlideSelector.select(new SlideSlice(null, null, -1), 5));
        assertEquals(List.of(3, 1), SlideSelector.select(new SlideSlice(-2, -6, -2), 5));
        assertEquals(List.of(0, 2, 4),
                SlideSelector.select(Map.of("slice", Map.of("start", -50L, "stop", 50L, "step", 2L)), 5));
        assertEquals(List.of(), SlideSelector.select("4-2", 5));
    }

    @Test
    void recipeValidationRejectsAmbiguousFieldsTypesAndInvalidPolicies() throws Exception {
        var codec = new RecipeCodec();
        for (String json : List.of("null", "1", "{}", "{\"version\":2.0}", "{\"version\":2,\"sources\":null}",
                "{\"version\":2,\"options\":[]}", "{\"version\":2,\"select\":[false]}",
                "{\"version\":2,\"select\":[{\"slides\":2}]}",
                "{\"version\":2,\"select\":[{\"file\":\"a\",\"path\":\"a\",\"slides\":2}]}",
                "{\"version\":2,\"select\":[{\"title\":\"\"}]}", "{\"version\":2,\"select\":[{\"titles\":3}]}",
                "{\"version\":2,\"select\":[{\"titles\":[null]}]}",
                "{\"version\":2,\"select\":[{\"title\":\"A\",\"skip_hidden\":null}]}",
                "{\"version\":2,\"select\":[{\"title\":\"A\",\"duplicate_titles\":\"bad\"}]}",
                "{\"version\":2,\"sources\":[\"bad\\u0000path\"]}", "{\"version\":2,\"options\":{\"overwrite\":1}}",
                "{\"version\":2,\"options\":{\"remaining\":null}}", "{\"version\":2,\"exclude\":[null]}"))
            assertThrows(MergeException.class, () -> codec.decode(codec.parse(json), dir), json);
        assertThrows(MergeException.class, () -> codec.parse("{} {}"));
        assertThrows(MergeException.class, () -> codec.parse("{\"version\":2,\"version\":2}"));
        assertEquals(0, codec.decode(codec.parse("\uFEFF{\"version\":2}"), dir).sources().size());
        assertEquals(ErrorCode.INPUT_NOT_FOUND,
                assertThrows(MergeException.class, () -> codec.read(dir.resolve("absent.json"))).code());
        // Directory-as-file is a deterministic read failure on all supported platforms.
        assertEquals(ErrorCode.IO_FAILURE, assertThrows(MergeException.class, () -> codec.read(dir)).code());
        var definition = codec.decode(codec.parse(
                "{\"version\":2,\"select\":[{\"path\":\"a.pptx\",\"titles\":[\"A\"],\"within\":[1],\"skip_hidden\":true,\"duplicate_titles\":\"last\"}]}"),
                dir);
        assertEquals(DuplicateTitlePolicy.LAST, definition.queries().get(0).selection().duplicateOverride());
    }

    @Test
    void exclusionDefinitionsValidateScopeAndListOwnership() {
        var all = InputSelection.all();
        assertThrows(MergeException.class, () -> new MergeDefinition.Exclusion(null, all));
        assertThrows(MergeException.class, () -> MergeDefinition.Exclusion.files(List.of(), null));
        assertThrows(MergeException.class, () -> new MergeDefinition.Exclusion(null, all, null, List.of(), false));
        assertThrows(MergeException.class,
                () -> new MergeDefinition.Exclusion(null, all, MergeDefinition.ExclusionScope.FILES, null, false));
        assertThrows(MergeException.class, () -> MergeDefinition.Exclusion.files(Arrays.asList((Path) null), all));
        assertThrows(MergeException.class, () -> MergeDefinition.Exclusion.global(all));
        assertThrows(MergeException.class, () -> new MergeDefinition.Exclusion(null, InputSelection.title("A"),
                MergeDefinition.ExclusionScope.GLOBAL, List.of(dir), false));
        assertThrows(MergeException.class, () -> InputSelection.numeric(new Object()));
        assertThrows(MergeException.class, () -> InputSelection.all().duplicates(DuplicateTitlePolicy.ALL));
        assertThrows(MergeException.class, () -> InputSelection.all().within(1));
        for (List<String> titles : Arrays.asList(null, List.<String>of(), List.of(" "), Arrays.asList((String) null)))
            assertThrows(MergeException.class, () -> InputSelection.titles(titles));
    }

    @Test
    void addingAliasesAndReusableClientKeepOriginalSelections() throws Exception {
        Path file = ExclusionFixtures.deck(dir, "a.pptx");
        var client = MergeSlides.client().baseDirectory(dir).reporter(MergeReporter.silent()).build();
        var builder = client.newJob().sources(List.of(Path.of("a.pptx"))).addTitle("Roadmap").addTitles("Slide 2")
                .addTitles(List.of("Slide 1")).addTitle(file, "Appendix").addTitles(file, "Slide 5")
                .addTitles(file, List.of("Slide 7")).addSlide(file, 8).addSlides(file, List.of(10))
                .addRange(file, 11, 11).addSlice(file, new SlideSlice(11, 12, null)).remaining(RemainingSlides.NONE);
        assertEquals(List.of(4, 2, 1, 9, 5, 7, 8, 10, 11, 12),
                builder.preview().slides().stream().map(PlannedSlide::slideNumber).toList());
        assertEquals(12, client.newJob().directory(dir).build().preview().slides().size());
        assertEquals(24,
                client.newJob().addAll(List.of(new MergeInput(file, InputSelection.all()), MergeInput.of(file))).plan()
                        .slides().size());
        assertEquals(12, client.newJob().searchDirectory(dir).addAll(file).plan().slides().size());
        assertEquals(12, client.newJob().addFiles(file).plan().slides().size());
        assertEquals(12, client.newJob().orderByTitles(List.of()).addDirectory(dir).plan().slides().size());
        assertEquals(2, client.newJob().orderByTitles("Roadmap", "Appendix").searchFiles(file)
                .remaining(RemainingSlides.NONE).plan().slides().size());
        Path output = dir.resolve("static.pptx");
        assertEquals(12, MergeSlides.merge(List.of(file), output).slideCount());
    }

    @Test
    void resolverValidatesTuplesLegacyControlsAndFalsyFallbacks() throws Exception {
        var resolver = new InputResolver(new ObjectMapper());
        Path out = dir.resolve("out.pptx");
        for (Object invalid : List.of(List.of(), List.of(1, 2, 3, 4), true, Map.of("title", "A"),
                Map.of("titles", List.of("A")), Map.of("exclude", List.of()), Map.of("file", " "),
                Map.of("file", "a", "skip_hidden", "yes")))
            assertThrows(MergeException.class, () -> resolver.normalize(invalid, dir));
        for (Object falsy : Arrays.asList(null, false, "", 0, List.of(), Map.of())) {
            var map = new HashMap<String, Object>();
            map.put("file", falsy);
            map.put("path", "a.pptx");
            map.put("slides", falsy);
            map.put("range", "2-3");
            assertEquals("2-3", resolver.normalize(map, dir).slides());
        }
        assertEquals(dir.resolve("a.pptx"), resolver.normalize(Path.of("a.pptx"), dir).file());
        assertTrue(resolver.normalize(List.of("a.pptx", 2, true), dir).skipHidden());
        assertNull(resolver.normalize(List.of("a.pptx"), dir).slides());
        assertThrows(MergeException.class, () -> resolver.resolve(null, dir, out));
        Path nested = Files.createDirectory(dir.resolve("nested"));
        TestPackages.create(nested, "x.pptx", "X", 1);
        assertEquals(1, resolver.resolve(List.of("nested"), dir, out).size());
        Files.writeString(dir.resolve("bad.json"), "[{}]");
        assertTrue(assertThrows(MergeException.class, () -> resolver.recipe(dir.resolve("bad.json"))).getMessage()
                .contains("entry 1"));
        Files.writeString(dir.resolve("bad.json"), "{}");
        assertThrows(MergeException.class, () -> resolver.recipe(dir.resolve("bad.json")));
        assertThrows(MergeException.class, () -> resolver.recipe(dir.resolve("missing.json")));
        Files.writeString(dir.resolve("bad.json"), "{");
        assertThrows(MergeException.class, () -> resolver.recipe(dir.resolve("bad.json")));
        for (String[] pair : List.of(new String[]{"deck2", "deck10"}, new String[]{"02", "2"}, new String[]{"2", "02"},
                new String[]{"a", "A"}, new String[]{"a1", "a"}, new String[]{"a", "b"}, new String[]{"z", "a"}))
            assertEquals(-Integer.signum(NaturalOrder.INSTANCE.compare(pair[1], pair[0])),
                    Integer.signum(NaturalOrder.INSTANCE.compare(pair[0], pair[1])));
    }

    @Test
    void cliModesAliasesErrorsAndOverwriteRemainCompatible() throws Exception {
        Path inputs = Files.createDirectory(dir.resolve("inputs"));
        TestPackages.create(inputs, "a.pptx", "A", 2);
        var resolver = new InputResolver(new ObjectMapper());
        var reader = TestPackages.reader();
        var cli = new MergeCli(new PackageMergeService(reader, new AtomicPackageWriter(reader)), resolver);
        var bytes = new ByteArrayOutputStream();
        var log = new PrintStream(bytes);
        for (String[] args : List.of(new String[]{"--inputs"}, new String[]{"--bad"}, new String[]{"-o"},
                new String[]{"-d", "inputs", "a.pptx"}, new String[]{"-d", "inputs", "-i", "a.pptx"}))
            assertEquals(2, cli.run(args, dir, dir, log, log), Arrays.toString(args));
        for (String help : List.of("--help", "-h"))
            assertEquals(0, cli.run(new String[]{help}, dir, dir, log, log));
        int i = 0;
        for (String mode : List.of("-d", "--dir", "-i", "--inputs", "positional", "default")) {
            var args = new ArrayList<String>();
            if (mode.equals("positional"))
                args.add("inputs/a.pptx");
            else if (!mode.equals("default")) {
                args.add(mode);
                args.add(mode.endsWith("d") || mode.endsWith("dir") ? "inputs" : "inputs/a.pptx");
            }
            args.add("--output");
            args.add("mode" + (i++) + ".pptx");
            assertEquals(0, cli.run(args.toArray(String[]::new), dir, inputs, log, log));
        }
        Files.writeString(dir.resolve("recipe.json"),
                "{\"version\":2,\"sources\":[\"inputs/a.pptx\"],\"exclude\":[\"absent\"]}");
        for (String flag : List.of("-r", "-c", "--recipe", "--config"))
            assertEquals(0,
                    cli.run(new String[]{flag, "recipe.json", "-o", "recipe" + (i++) + ".pptx"}, dir, dir, log, log));
        assertTrue(bytes.toString().contains("[WARNING]"));
        assertEquals(2,
                cli.run(new String[]{"-r", "recipe.json", "--no-overwrite", "-o", "recipe6.pptx"}, dir, dir, log, log));
        assertEquals(0, cli.run(new String[]{"inputs/a.pptx", "--overwrite", "-o", "mode0.pptx"}, dir, dir, log, log));
        assertEquals(0, cli.run(new String[]{"recipe.json", "inputs/a.pptx", "--overwrite", "-o", "chunks.pptx"}, dir,
                dir, log, log));
    }
}
