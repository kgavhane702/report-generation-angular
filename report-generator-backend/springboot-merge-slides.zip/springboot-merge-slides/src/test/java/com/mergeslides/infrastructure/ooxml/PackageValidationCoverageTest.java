package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.TestPackages;
import com.mergeslides.api.lib.DiagnosticCode;
import com.mergeslides.domain.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.zip.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PackageValidationCoverageTest {
    @TempDir
    Path dir;

    static void replace(Map<String, byte[]> parts, String name, String old, String value) {
        parts.put(name, new String(parts.get(name), StandardCharsets.UTF_8).replace(old, value)
                .getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void validatorRejectsMalformedTypesRelationshipsIdsThemesAndAuthors() throws Exception {
        String pr = PackagePaths.rels(PRESENTATION), mr = "ppt/slideMasters/slideMaster1.xml",
                mrel = PackagePaths.rels(mr);
        List<Consumer<Map<String, byte[]>>> invalid = List.of(p -> p.remove(ROOT_RELS),
                p -> replace(p, TYPES, CT, "urn:wrong"), p -> replace(p, TYPES, "</Types>", "<Other/></Types>"),
                p -> replace(p, TYPES, "</Types>",
                        "<Default Extension=\"xml\" ContentType=\"x\"/><Default Extension=\"xml\" ContentType=\"x\"/></Types>"),
                p -> replace(p, TYPES, "ContentType=\"" + ContentType.SLIDE.mime() + "\"", "ContentType=\"\""),
                p -> MetadataPreservationTest.add(p, "missing/_rels/owner.xml.rels", TestPackages.relationships(""),
                        RELS_MIME),
                p -> replace(p, ROOT_RELS, RELS, "urn:wrong"), p -> replace(p, ROOT_RELS, "Id=\"r\"", "Id=\"\""),
                p -> replace(p, ROOT_RELS, "Type=\"" + RelationshipType.OFFICE_DOCUMENT.uri() + "\"", "Type=\"\""),
                p -> replace(p, ROOT_RELS, "Target=\"" + PRESENTATION + "\"", ""),
                p -> replace(p, ROOT_RELS, "Relationship Id", "Other Id"),
                p -> replace(p, TYPES, ContentType.PRESENTATION.mime(), "application/macro"),
                p -> p.put(ROOT_RELS, TestPackages.relationships("").getBytes(StandardCharsets.UTF_8)),
                p -> MetadataPreservationTest.append(p, ROOT_RELS, "</Relationships>",
                        TestPackages.rel("other", RelationshipType.OFFICE_DOCUMENT, PRESENTATION)),
                p -> replace(p, ROOT_RELS, PRESENTATION, "ppt/theme/theme1.xml"),
                p -> MetadataPreservationTest.add(p, "_xmlsignatures/signature.xml", "<signature/>", "application/xml"),
                p -> replace(p, PRESENTATION, "id=\"256\"", "id=\"255\""),
                p -> replace(p, PRESENTATION, "id=\"256\"", "id=\"2147483648\""),
                p -> replace(p, PRESENTATION, "id=\"256\"", "id=\"bad\""),
                p -> replace(p, PRESENTATION, "r:id=\"s1\"", "r:id=\"missing\""),
                p -> replace(p, pr, RelationshipType.SLIDE.uri(), RelationshipType.THEME.uri()),
                p -> replace(p, pr, "slides/slide2.xml", "slides/slide1.xml"),
                p -> replace(p, TYPES, ContentType.SLIDE.mime(), ContentType.THEME.mime()),
                p -> replace(p, mr, "r:id=\"l\"", "r:id=\"missing\""),
                p -> replace(p, mrel, RelationshipType.SLIDE_LAYOUT.uri(), RelationshipType.THEME.uri()),
                p -> replace(p, mr, "</p:sldLayoutIdLst>",
                        "<p:sldLayoutId id=\"2147483650\" r:id=\"l\"/></p:sldLayoutIdLst>"),
                p -> MetadataPreservationTest.add(p, "ppt/slideMasters/slideMaster2.xml",
                        "<p:sldMaster xmlns:p=\"" + P + "\"/>", ContentType.MASTER.mime()),
                p -> replace(p, mr, "id=\"2147483649\"", "id=\"1\""),
                p -> replace(p, mr, "id=\"2147483649\"", "id=\"4294967296\""),
                p -> replace(p, mr, "id=\"2147483649\"", "id=\"2147483648\""),
                p -> replace(p, PRESENTATION, "<p:sldSz", "<p:ext r:id=\"unregistered\"/><p:sldSz"),
                p -> MetadataPreservationTest.add(p, "ppt/comments/bad.xml",
                        "<p:cmLst xmlns:p=\"" + P + "\"><p:cm authorId=\"unknown\"/></p:cmLst>",
                        ContentType.COMMENTS.mime()));
        int i = 0;
        for (var mutation : invalid) {
            var parts = TestPackages.parts("validation", 2);
            mutation.accept(parts);
            if (i == 26)
                MetadataPreservationTest
                        .add(parts, "ppt/slideMasters/_rels/slideMaster2.xml.rels",
                                TestPackages.relationships(
                                        TestPackages.rel("t", RelationshipType.THEME, "../theme/theme1.xml")),
                                RELS_MIME);
            Path file = TestPackages.write(dir.resolve("bad" + i + ".pptx"), parts);
            var error = assertThrows(MergeException.class, () -> TestPackages.reader().read(file), "case " + i);
            assertEquals(ErrorCode.INVALID_PRESENTATION, error.code());
            i++;
        }
    }

    @Test
    void zipReaderRejectsUnsafeDuplicateAndCorruptEntriesButDiscardsRecoveryTrash() throws Exception {
        int index = 0;
        for (String member : List.of("../escape.bin", "/absolute.bin", "back\\slash.bin", "ppt/./wrong.bin")) {
            Path file = dir.resolve("unsafe" + (index++) + ".pptx");
            try (var zip = new ZipOutputStream(Files.newOutputStream(file))) {
                zip.putNextEntry(new ZipEntry(member));
                zip.write(1);
                zip.closeEntry();
            }
            assertTrue(assertThrows(MergeException.class, () -> TestPackages.reader().read(file)).getMessage()
                    .contains("Unsafe ZIP"));
        }
        var parts = TestPackages.parts("zip", 1);
        parts.put("[Trash]/ignored.bin", new byte[]{1});
        parts.put("trash/ignored.bin", new byte[]{2});
        var file = TestPackages.write(dir.resolve("trash.pptx"), parts);
        var doc = TestPackages.reader().read(file);
        assertFalse(doc.parts.containsKey("trash/ignored.bin"));
        Path duplicate = dir.resolve("duplicate.pptx");
        try (var zip = new ZipOutputStream(Files.newOutputStream(duplicate))) {
            for (String name : List.of("dupa.xml", "dupb.xml")) {
                zip.putNextEntry(new ZipEntry(name));
                zip.write("<part/>".getBytes());
                zip.closeEntry();
            }
        }
        byte[] bytes = Files.readAllBytes(duplicate);
        byte[] from = "dupb.xml".getBytes(), to = "dupa.xml".getBytes();
        for (int at = 0; at <= bytes.length - from.length; at++)
            if (Arrays.equals(Arrays.copyOfRange(bytes, at, at + from.length), from))
                System.arraycopy(to, 0, bytes, at, to.length);
        Files.write(duplicate, bytes);
        assertTrue(assertThrows(MergeException.class, () -> TestPackages.reader().read(duplicate)).getMessage()
                .contains("Duplicate ZIP"));
        bytes = Files.readAllBytes(file);
        for (int at = 0; at < bytes.length - 20; at++)
            if (bytes[at] == 0x50 && bytes[at + 1] == 0x4b && bytes[at + 2] == 1 && bytes[at + 3] == 2) {
                bytes[at + 16] ^= 1;
                break;
            }
        Files.write(file, bytes);
        assertTrue(assertThrows(MergeException.class, () -> TestPackages.reader().read(file)).getMessage()
                .contains("CRC mismatch"));
    }

    @Test
    void packageUrisAndAllocatorHandleEscapingFragmentsAndNonXmlParts() throws Exception {
        assertEquals("../../a", PackagePaths.normalize("../../a"));
        assertEquals("a", PackagePaths.normalize("./a//"));
        assertEquals("_rels/a.xml.rels", PackagePaths.rels("a.xml"));
        assertEquals("a.xml", PackagePaths.owner("_rels/a.xml.rels"));
        for (String value : List.of("a.xml", "ppt/a.xml.rels"))
            assertThrows(MergeException.class, () -> PackagePaths.owner(value));
        for (String target : List.of("%QQ", "//host/a", "http://host/a", "a?query", "../../escape"))
            assertThrows(MergeException.class, () -> PackagePaths.resolve("ppt/a.xml", target));
        assertEquals("ppt/a.xml", PackagePaths.resolve("ppt/a.xml", "#fragment"));
        assertEquals("ppt/a.xml", PackagePaths.resolve("", "/ppt/a.xml"));
        assertEquals("a%20B%2B1._-~/%C3%A9", PackagePaths.quote("a B+1._-~/é"));
        assertEquals("a.xml#fragment", PackagePaths.relative("ppt/b.xml", "ppt/a.xml", "old#fragment"));
        var doc = TestPackages.reader().read(TestPackages.create(dir, "same.pptx", "A", 1));
        var context = new MergeContext(List.of(doc), List.of(new MergeContext.Occurrence(doc, doc.slides.get(0))));
        assertEquals("media/noext", context.allocate("media/noext"));
        assertEquals("media/noext_merge2", context.allocate("media/noext"));
    }

    @Test
    void writerPreservesDestinationAndCleansStagingOnValidationAndCommitFailures() throws Exception {
        var parts = TestPackages.parts("writer", 1);
        Path output = dir.resolve("output.pptx");
        Files.writeString(output, "sentinel");
        var invalid = new LinkedHashMap<>(parts);
        invalid.remove(TYPES);
        assertEquals(DiagnosticCode.OUTPUT_VALIDATION_FAILED, assertThrows(MergeException.class,
                () -> new AtomicPackageWriter(TestPackages.reader()).write(invalid, output)).failureCode());
        assertEquals("sentinel", Files.readString(output));
        try (var files = mockStatic(Files.class, CALLS_REAL_METHODS)) {
            files.when(() -> Files.createLink(eq(output), any(Path.class)))
                    .thenThrow(new UnsupportedOperationException("controlled"));
            assertEquals(DiagnosticCode.OUTPUT_COMMIT_UNSUPPORTED, assertThrows(MergeException.class,
                    () -> new AtomicPackageWriter(TestPackages.reader()).write(parts, output, false, s -> {
                    })).failureCode());
        }
        try (var files = mockStatic(Files.class, CALLS_REAL_METHODS)) {
            files.when(() -> Files.createDirectories(dir)).thenThrow(new IOException("controlled directory failure"));
            assertEquals(DiagnosticCode.OUTPUT_WRITE_FAILED, assertThrows(MergeException.class,
                    () -> new AtomicPackageWriter(TestPackages.reader()).write(parts, output)).failureCode());
        }
        try (var entries = Files.list(dir)) {
            assertFalse(entries.anyMatch(p -> p.getFileName().toString().startsWith(TEMP_PREFIX)));
        }
        assertEquals("sentinel", Files.readString(output));
    }
}
