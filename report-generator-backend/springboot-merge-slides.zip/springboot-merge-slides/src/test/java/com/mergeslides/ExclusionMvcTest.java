package com.mergeslides;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.*;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.*;
import java.util.Comparator;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class ExclusionMvcTest {
    static final Path WORKSPACE;
    static {
        try {
            WORKSPACE = Files.createTempDirectory("merge-exclusion-mvc-");
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @DynamicPropertySource
    static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", WORKSPACE::toString);
        r.add("merge.temp-directory", () -> WORKSPACE.resolve("temp").toString());
    }

    @Autowired
    MockMvc mvc;

    @BeforeEach
    void decks() throws Exception {
        ExclusionFixtures.deck(WORKSPACE, "a.pptx");
        ExclusionFixtures.deck(WORKSPACE, "b.pptx");
    }

    @AfterAll
    static void cleanup() throws Exception {
        try (var files = Files.walk(WORKSPACE)) {
            for (Path file : files.sorted(Comparator.reverseOrder()).toList())
                Files.deleteIfExists(file);
        }
    }

    MockMultipartFile file(String name) throws Exception {
        return new MockMultipartFile("files", name, "application/octet-stream",
                Files.readAllBytes(WORKSPACE.resolve(name)));
    }

    @Test
    void inlineAndPathRecipesSupportRangeAndTitleExclusions() throws Exception {
        String recipe = """
                {"version":2,"sources":["a.pptx"],"select":[{"file":"a.pptx","range":"1-10"}],
                 "exclude":["Confidential"],"options":{"remaining":"none"}}
                """;
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"recipe\":" + recipe + ",\"output\":\"inline.pptx\"}")).andExpect(status().isOk())
                .andExpect(jsonPath("$.slideCount").value(8));
        Files.writeString(WORKSPACE.resolve("recipe.json"), recipe);
        mvc.perform(post("/api/v1/merges").contentType("application/json")
                .content("{\"recipePath\":\"recipe.json\",\"output\":\"path.pptx\"}")).andExpect(status().isOk())
                .andExpect(jsonPath("$.slideCount").value(8));
        assertEquals(8, TestPackages.reader().read(WORKSPACE.resolve("inline.pptx")).slides().size());
    }

    @Test
    void missingExcludedTitlesProduceWarningsOrSafeStructuredFailures() throws Exception {
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("""
                {"recipe":{"version":2,"sources":["a.pptx"],"exclude":["Absent"]},"output":"warning.pptx"}
                """)).andExpect(status().isOk()).andExpect(jsonPath("$.slideCount").value(12))
                .andExpect(jsonPath("$.warnings.length()").value(1));
        mvc.perform(post("/api/v1/merges").contentType("application/json").content("""
                {"recipe":{"version":2,"sources":["a.pptx"],"exclude":["Absent"],
                  "options":{"on_missing_excluded_title":"error"}},"output":"strict.pptx"}
                """)).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.failureCode").value("EXCLUDED_TITLE_NOT_FOUND"))
                .andExpect(jsonPath("$.stage").value("SELECTION")).andExpect(jsonPath("$.operationId").isNotEmpty());
        assertFalse(Files.exists(WORKSPACE.resolve("strict.pptx")));
    }

    @Test
    void uploadGlobalTitleExclusionUsesUploadPoolAndCleansUp() throws Exception {
        var async = mvc
                .perform(multipart("/api/v1/merges/upload").file(file("a.pptx")).file(file("b.pptx")).param("recipe",
                        "{\"version\":2,\"exclude\":[\"Confidential\"]}"))
                .andExpect(request().asyncStarted()).andReturn();
        var response = mvc.perform(asyncDispatch(async)).andExpect(status().isOk())
                .andExpect(header().string("X-Merge-Slide-Count", "20")).andReturn();
        Path downloaded = WORKSPACE.resolve("download.pptx");
        Files.write(downloaded, response.getResponse().getContentAsByteArray());
        assertEquals(20, TestPackages.reader().read(downloaded).slides().size());
        try (var dirs = Files.list(WORKSPACE.resolve("temp"))) {
            assertEquals(0, dirs.count());
        }
    }

    @Test
    void uploadSupportsFileListsAndWholeUploadedFileExclusion() throws Exception {
        var async = mvc
                .perform(multipart("/api/v1/merges/upload").file(file("a.pptx")).file(file("b.pptx")).param("recipe",
                        """
                                {"version":2,"exclude":[{"files":["a.pptx"],"titles":["Confidential"]},{"file":"b.pptx","all":true}]}
                                """))
                .andExpect(request().asyncStarted()).andReturn();
        mvc.perform(asyncDispatch(async)).andExpect(status().isOk())
                .andExpect(header().string("X-Merge-Slide-Count", "10"));
    }

    @Test
    void uploadRejectsDirectoryScopesAndUnuploadedOrEscapingFiles() throws Exception {
        for (String rule : new String[]{"{\"directory\":\".\",\"all\":true}",
                "{\"directories\":[\".\"],\"title\":\"Confidential\"}", "{\"files\":[\"../b.pptx\"],\"all\":true}",
                "{\"files\":[\"b.pptx\"],\"all\":true}",
                "{\"file\":\"C:/private/server.pptx\",\"title\":\"Confidential\"}"})
            mvc.perform(multipart("/api/v1/merges/upload").file(file("a.pptx")).param("recipe",
                    "{\"version\":2,\"exclude\":[" + rule + "]}")).andExpect(status().isBadRequest());
        try (var dirs = Files.list(WORKSPACE.resolve("temp"))) {
            assertEquals(0, dirs.count());
        }
    }

    @Test
    void excludedCorruptUploadsStillFailValidation() throws Exception {
        var bad = new MockMultipartFile("files", "bad.pptx", "application/octet-stream", "invalid".getBytes());
        mvc.perform(multipart("/api/v1/merges/upload").file(file("a.pptx")).file(bad).param("recipe",
                "{\"version\":2,\"exclude\":[{\"file\":\"bad.pptx\",\"all\":true}]}"))
                .andExpect(status().isUnprocessableEntity());
    }
}
