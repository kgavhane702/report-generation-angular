package com.mergeslides;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.api.lib.*;
import com.mergeslides.cli.MergeCli;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.*;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class ExclusionRecipeTest {
    @TempDir
    Path temp;
    Path a, b;
    final RecipeCodec codec = new RecipeCodec();

    @BeforeEach
    void decks() throws Exception {
        a = ExclusionFixtures.deck(temp, "a.pptx");
        b = ExclusionFixtures.deck(temp, "b.pptx");
    }

    MergeSlides.Builder job() {
        return MergeSlides.builder().baseDirectory(temp).reporter(MergeReporter.silent());
    }

    Path recipe(String name, String json) throws Exception {
        return Files.writeString(temp.resolve(name), json);
    }

    List<Integer> numbers(MergePlan plan) {
        return plan.slides().stream().map(PlannedSlide::slideNumber).toList();
    }

    @Test
    void globalStringsAndObjectsAndFileListsHaveEquivalentResults() throws Exception {
        for (String excluded : List.of("\"Confidential\"", "{\"title\":\"Confidential\"}",
                "{\"titles\":[\"Confidential\"]}", "{\"files\":[\"a.pptx\"],\"titles\":[\"Confidential\"]}",
                "{\"path\":\"a.pptx\",\"title\":\"Confidential\"}", "{\"file\":\"a.pptx\",\"slides\":[3,6]}")) {
            Path config = recipe("recipe.json",
                    "{\"version\":2,\"sources\":[\"a.pptx\"],\"select\":[{\"file\":\"a.pptx\",\"range\":\"1-10\"}],"
                            + "\"exclude\":[" + excluded + "],\"options\":{\"remaining\":\"none\"}}");
            assertEquals(List.of(1, 2, 4, 5, 7, 8, 9, 10), numbers(job().addRecipe(config).plan()), excluded);
        }
    }

    @Test
    void directoryAndMultiDirectoryScopesRemainRelativeAndNonrecursive() throws Exception {
        Path one = temp.resolve("one"), two = temp.resolve("two");
        ExclusionFixtures.deck(one, "one.pptx");
        ExclusionFixtures.deck(two, "two.pptx");
        Path config = recipe("directories.json", """
                {"version":2,"sources":["one","two","a.pptx"],"exclude":[
                  {"directory":"one","titles":["Confidential"]},
                  {"directories":["one","two"],"range":"9-12"}]}
                """);
        var plan = job().addRecipe(config).plan();
        assertEquals(26, plan.slides().size());
        assertEquals(10, plan.summary().excludedCount());
        assertEquals(12, plan.slides().stream().filter(s -> s.file().equals(a)).count());
        var all = recipe("all.json", """
                {"version":2,"sources":["one","two","a.pptx"],"exclude":[
                  {"directory":"one","all":true},{"files":["a.pptx"],"all":true}]}
                """);
        assertEquals(12, job().addRecipe(all).plan().slides().size());
        var directories = recipe("all-directories.json", """
                {"version":2,"sources":["one","two","a.pptx"],"exclude":[{"directories":["one","two"],"all":true}]}
                """);
        assertTrue(job().addRecipe(directories).plan().slides().stream().allMatch(s -> s.file().equals(a)));
    }

    @Test
    void missingExclusionPolicyIsIndependentAndBuilderOverridesSoleRecipeOptions() throws Exception {
        Path config = recipe("missing.json", """
                {"version":2,"sources":["a.pptx","b.pptx"],"exclude":["Absent"],
                 "options":{"on_missing":"error","on_missing_excluded_title":"error"}}
                """);
        assertEquals(DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND,
                assertThrows(MergeException.class, () -> job().addRecipe(config).plan()).failureCode());
        var plan = job().addRecipe(config).onMissingExcludedTitle(MissingTitlePolicy.SKIP).plan();
        assertEquals(24, plan.slides().size());
        assertEquals(1, plan.diagnostics().size());
        assertEquals(DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND, plan.diagnostics().get(0).code());
    }

    @Test
    void outerExclusionsFilterRecipeOnlySourcesWithoutChangingChunkOrder() throws Exception {
        Path child = recipe("child.json", "[{\"file\":\"a.pptx\",\"slides\":[3,1,6,2]}]");
        var plan = job().addRecipe(child).addFile(b, InputSelection.slides(7, 3)).excludeTitle("Confidential")
                .remaining(RemainingSlides.NONE).plan();
        assertEquals(List.of("a.pptx:1", "a.pptx:2", "b.pptx:7"),
                plan.slides().stream().map(s -> s.file().getFileName() + ":" + s.slideNumber()).toList());
        assertEquals(4, plan.summary().excludedCount());
        assertEquals(List.of(1, 2), numbers(job().addRecipe(child).excludeTitles(List.of(a), List.of("Confidential"))
                .remaining(RemainingSlides.NONE).plan()));
    }

    @Test
    void recipeWithinFiltersExclusionCandidatesAndEmptyListsDoNothing() throws Exception {
        Path config = recipe("within.json", """
                {"version":2,"sources":["a.pptx"],"exclude":[
                  {"title":"Confidential","within":"1-5"},
                  {"titles":[]},{"files":[],"all":true},{"directories":[],"range":"1-3"},
                  {"file":"missing.pptx","slides":[]}]}
                """);
        assertEquals(List.of(1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12), numbers(job().addRecipe(config).plan()));
    }

    @Test
    void strictCodecRejectsAmbiguousScopesSelectorsAndInvalidValues() {
        for (String excluded : List.of("{\"slides\":[1]}", "{\"all\":true}",
                "{\"file\":\"a.pptx\",\"files\":[\"a.pptx\"],\"slides\":[1]}",
                "{\"directory\":\"one\",\"directories\":[\"one\"],\"all\":true}",
                "{\"file\":\"a.pptx\",\"path\":\"a.pptx\",\"all\":true}", "{\"file\":\"a.pptx\",\"all\":false}",
                "{\"file\":\"a.pptx\",\"all\":\"true\"}",
                "{\"file\":\"a.pptx\",\"title\":\"Roadmap\",\"range\":\"1-3\"}",
                "{\"file\":\"a.pptx\",\"all\":true,\"within\":[1]}", "{\"files\":\"a.pptx\",\"all\":true}",
                "{\"files\":[null],\"all\":true}", "{\"titles\":[null]}", "{\"titles\":[\" \"]}",
                "{\"title\":\"Roadmap\",\"recursive\":true}", "42")) {
            String json = "{\"version\":2,\"sources\":[\"a.pptx\"],\"exclude\":[" + excluded + "]}";
            assertThrows(MergeException.class, () -> codec.decode(codec.parse(json), temp), excluded);
        }
        assertThrows(MergeException.class, () -> codec
                .decode(codec.parse("{\"version\":2,\"options\":{\"on_missing_excluded_title\":\"ignore\"}}"), temp));
    }

    @Test
    void cliUsesNewExclusionsAndStillAcceptsLegacyRecipes() throws Exception {
        Path config = recipe("cli.json", """
                {"version":2,"sources":["a.pptx"],"select":[{"file":"a.pptx","range":"1-10"}],
                 "exclude":["Confidential",{"file":"a.pptx","range":"8-9"}],"options":{"remaining":"none"}}
                """);
        var reader = TestPackages.reader();
        var cli = new MergeCli(new PackageMergeService(reader, new AtomicPackageWriter(reader)),
                new InputResolver(new ObjectMapper()));
        var output = new ByteArrayOutputStream();
        var stream = new PrintStream(output);
        assertEquals(0, cli.run(new String[]{"-r", config.toString(), "-o", "cli.pptx"}, temp, temp, stream, stream),
                output.toString());
        assertEquals(6, reader.read(temp.resolve("cli.pptx")).slides().size());
        Path legacy = recipe("legacy.json", "[{\"file\":\"a.pptx\",\"slides\":[3,1,3]}]");
        assertEquals(0, cli.run(new String[]{legacy.toString(), "-o", "legacy.pptx"}, temp, temp, stream, stream));
        assertEquals(3, reader.read(temp.resolve("legacy.pptx")).slides().size());
    }
}
