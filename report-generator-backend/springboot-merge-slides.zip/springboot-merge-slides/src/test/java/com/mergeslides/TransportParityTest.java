package com.mergeslides;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.api.lib.*;
import com.mergeslides.cli.MergeCli;
import com.mergeslides.domain.SlideSlice;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.*;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockMultipartFile;
import java.nio.file.*;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
class TransportParityTest {
    static final Path DIR;
    static {
        try {
            DIR = Files.createTempDirectory("transport-parity-");
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @DynamicPropertySource
    static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", DIR::toString);
        r.add("merge.temp-directory", () -> DIR.resolve("temp").toString());
    }

    @Autowired
    MockMvc mvc;

    @AfterAll
    static void cleanup() throws Exception {
        try (var files = Files.walk(DIR)) {
            for (Path p : files.sorted(Comparator.reverseOrder()).toList())
                Files.deleteIfExists(p);
        }
    }

    record Scenario(String name, InputSelection selection, Map<String, Object> selector, RemainingSlides remaining,
            List<Integer> expected) {
    }

    @Test
    void commonSelectionMatrixAgreesAcrossBuilderCliInlineSavedAndMultipartRecipes() throws Exception {
        Path source = ExclusionFixtures.deck(DIR, "a.pptx");
        byte[] original = Files.readAllBytes(source), hash = PackageDocument.sha(original);
        var mapper = new ObjectMapper();
        var reader = TestPackages.reader();
        var cli = new MergeCli(new PackageMergeService(reader, new AtomicPackageWriter(reader)),
                new InputResolver(mapper));
        var scenarios = List.of(
                new Scenario("all", null, null, RemainingSlides.NONE, List.of(1, 2, 4, 5, 7, 8, 9, 10, 11, 12)),
                new Scenario("range", InputSelection.range("1-10"), Map.of("range", "1-10"), RemainingSlides.NONE,
                        List.of(1, 2, 4, 5, 7, 8, 9, 10)),
                new Scenario("end", InputSelection.range("1-10"), Map.of("range", "1-10"), RemainingSlides.END,
                        List.of(1, 2, 4, 5, 7, 8, 9, 10, 11, 12)),
                new Scenario("start", InputSelection.range("1-10"), Map.of("range", "1-10"), RemainingSlides.START,
                        List.of(11, 12, 1, 2, 4, 5, 7, 8, 9, 10)),
                new Scenario("individual", InputSelection.slides(3, 4), Map.of("slides", List.of(3, 4)),
                        RemainingSlides.NONE, List.of(4)),
                new Scenario("list", InputSelection.slides(8, 6, 2, 3, 8), Map.of("slides", List.of(8, 6, 2, 3, 8)),
                        RemainingSlides.NONE, List.of(8, 2, 8)),
                new Scenario("ranges", InputSelection.range("2-4,8-10"), Map.of("range", "2-4,8-10"),
                        RemainingSlides.NONE, List.of(2, 4, 8, 9, 10)),
                new Scenario("slice", InputSelection.slice(new SlideSlice(null, null, -1)),
                        Map.of("slides", Map.of("slice", Map.of("step", -1))), RemainingSlides.NONE,
                        List.of(12, 11, 10, 9, 8, 7, 5, 4, 2, 1)),
                new Scenario("titles", InputSelection.titles("Appendix", "Confidential", "Roadmap"),
                        Map.of("titles", List.of("Appendix", "Confidential", "Roadmap")), RemainingSlides.NONE,
                        List.of(9, 4)));
        for (var scenario : scenarios) {
            var builder = MergeSlides.builder().baseDirectory(DIR).excludeTitles("Confidential")
                    .remainingSlides(scenario.remaining()).reporter(MergeReporter.silent());
            if (scenario.selection() == null)
                builder.searchFiles(source);
            else
                builder.addFile(source, scenario.selection());
            assertEquals(scenario.expected(), builder.plan().slides().stream().map(PlannedSlide::slideNumber).toList());
            Path output = DIR.resolve(scenario.name() + "-builder.pptx");
            builder.output(output).merge();
            verify(output, scenario.expected());
            var recipe = new LinkedHashMap<String, Object>();
            recipe.put("version", 2);
            recipe.put("sources", List.of("a.pptx"));
            recipe.put("exclude", List.of("Confidential"));
            recipe.put("options", Map.of("remaining", scenario.remaining().name().toLowerCase(Locale.ROOT)));
            if (scenario.selector() != null) {
                var selected = new LinkedHashMap<String, Object>(scenario.selector());
                selected.put("file", "a.pptx");
                recipe.put("select", List.of(selected));
            }
            String recipeText = mapper.writeValueAsString(recipe);
            Files.writeString(DIR.resolve("scenario.json"), recipeText);
            output = DIR.resolve(scenario.name() + "-cli.pptx");
            assertEquals(0, cli.run(new String[]{"-r", "scenario.json", "-o", output.toString()}, DIR, DIR,
                    new java.io.PrintStream(java.io.OutputStream.nullOutputStream()), System.err));
            verify(output, scenario.expected());
            for (String mode : List.of("inline", "saved")) {
                String name = scenario.name() + "-" + mode + ".pptx";
                String request = mode.equals("inline")
                        ? mapper.writeValueAsString(Map.of("recipe", recipe, "output", name))
                        : mapper.writeValueAsString(Map.of("recipePath", "scenario.json", "output", name));
                mvc.perform(post("/api/v1/merges").contentType("application/json").content(request))
                        .andExpect(status().isOk())
                        .andExpect(jsonPath("$.slideCount").value(scenario.expected().size()));
                verify(DIR.resolve(name), scenario.expected());
            }
            var async = mvc.perform(multipart("/api/v1/merges/upload")
                    .file(new MockMultipartFile("files", "a.pptx", "application/octet-stream", original))
                    .param("recipe", recipeText)).andExpect(request().asyncStarted()).andReturn();
            var response = mvc.perform(asyncDispatch(async)).andExpect(status().isOk())
                    .andExpect(header().string("X-Merge-Slide-Count", Integer.toString(scenario.expected().size())))
                    .andReturn();
            output = DIR.resolve(scenario.name() + "-download.pptx");
            Files.write(output, response.getResponse().getContentAsByteArray());
            verify(output, scenario.expected());
        }
        assertArrayEquals(hash, PackageDocument.sha(Files.readAllBytes(source)));
        try (var files = Files.list(DIR.resolve("temp"))) {
            assertEquals(0, files.count());
        }
    }

    void verify(Path output, List<Integer> expected) {
        var doc = TestPackages.reader().read(output);
        var order = new ArrayList<Integer>();
        for (int i = 0; i < doc.slides().size(); i++)
            order.add(Integer.parseInt(Xml.child(doc.slideXml(i), Ooxml.P, "cSld").getAttribute("name").split(":")[1]));
        assertEquals(expected, order, output.toString());
    }
}
