package com.mergeslides;

import com.fasterxml.jackson.databind.*;
import com.mergeslides.application.MergeService;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.*;
import org.springframework.test.context.*;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@Tag("http")
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {MergeSlidesApplication.class,
        HttpContractTest.HostConfiguration.class}, properties = {"spring.servlet.multipart.max-file-size=48KB",
                "spring.servlet.multipart.max-request-size=96KB"})
class HttpContractTest {
    static final Path DIR;
    static {
        try {
            DIR = Files.createTempDirectory("merge-http-");
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    @DynamicPropertySource
    static void config(DynamicPropertyRegistry r) {
        r.add("merge.workspace", DIR::toString);
        r.add("merge.temp-directory", () -> DIR.resolve("temp").toString());
    }

    @TestConfiguration(proxyBeanMethods = false)
    static class HostConfiguration {
        @Bean
        HostController hostController() {
            return new HostController();
        }
    }

    @RestController
    static class HostController {
        @PostMapping("/host")
        Map<String, Object> echo(@RequestBody Map<String, Object> value) {
            return value;
        }

        @GetMapping("/host/error")
        void error() {
            throw new IllegalStateException("host failure");
        }
    }

    @LocalServerPort
    int port;
    @MockitoSpyBean
    MergeService service;
    final HttpClient client = HttpClient.newHttpClient();
    final ObjectMapper mapper = new ObjectMapper();

    @BeforeAll
    static void fixtures() throws Exception {
        ExclusionFixtures.deck(DIR, "a.pptx");
        Files.writeString(DIR.resolve("corrupt.pptx"), "corrupt");
    }

    @AfterAll
    static void cleanup() throws Exception {
        try (var paths = Files.walk(DIR)) {
            for (Path p : paths.sorted(Comparator.reverseOrder()).toList())
                Files.deleteIfExists(p);
        }
    }

    URI uri(String path) {
        return URI.create("http://localhost:" + port + path);
    }

    HttpRequest request(String path, String type, byte[] bytes) {
        return HttpRequest.newBuilder(uri(path)).header("Content-Type", type)
                .POST(HttpRequest.BodyPublishers.ofByteArray(bytes)).build();
    }

    HttpResponse<byte[]> json(String value) throws Exception {
        return client.send(request("/api/v1/merges", "application/json", value.getBytes(StandardCharsets.UTF_8)),
                HttpResponse.BodyHandlers.ofByteArray());
    }

    JsonNode body(HttpResponse<byte[]> response) throws Exception {
        return mapper.readTree(response.body());
    }

    void error(HttpResponse<byte[]> response, int expected) throws Exception {
        assertEquals(expected, response.statusCode(), new String(response.body(), StandardCharsets.UTF_8));
        assertEquals(response.headers().firstValue("X-Merge-Operation-Id").orElseThrow(),
                body(response).path("operationId").asText());
        assertFalse(body(response).path("code").asText().isBlank());
    }

    @Test
    void jsonRecipesAndDownloadedPackagesRetainOrderHeadersAndInputHashes() throws Exception {
        byte[] before = PackageDocument.sha(Files.readAllBytes(DIR.resolve("a.pptx")));
        var merged = json(
                "{\"recipe\":{\"version\":2,\"sources\":[\"a.pptx\"],\"select\":[{\"file\":\"a.pptx\",\"range\":\"1-10\"}],\"exclude\":[\"Confidential\"],\"options\":{\"remaining\":\"start\"}},\"output\":\"http.pptx\"}");
        assertEquals(200, merged.statusCode());
        assertEquals(10, body(merged).path("slideCount").asInt());
        var doc = TestPackages.reader().read(DIR.resolve("http.pptx"));
        assertEquals(List.of(11, 12, 1, 2, 4, 5, 7, 8, 9, 10), sourceIndices(doc));
        byte[] bytes = multipart(List.of(Files.readAllBytes(DIR.resolve("a.pptx"))),
                "{\"version\":2,\"exclude\":[\"Confidential\"]}");
        var download = client.send(
                request("/api/v1/merges/upload", "multipart/form-data; boundary=merge-boundary", bytes),
                HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(200, download.statusCode());
        assertEquals(Ooxml.PPTX_MIME, download.headers().firstValue("Content-Type").orElseThrow());
        assertEquals("10", download.headers().firstValue("X-Merge-Slide-Count").orElseThrow());
        assertEquals("0", download.headers().firstValue("X-Merge-Warning-Count").orElseThrow());
        assertTrue(download.headers().firstValue("Content-Disposition").orElseThrow().contains("merged.pptx"));
        assertEquals(download.body().length,
                Long.parseLong(download.headers().firstValue("Content-Length").orElseThrow()));
        Files.write(DIR.resolve("download.pptx"), download.body());
        assertEquals(List.of(1, 2, 4, 5, 7, 8, 9, 10, 11, 12),
                sourceIndices(TestPackages.reader().read(DIR.resolve("download.pptx"))));
        assertArrayEquals(before, PackageDocument.sha(Files.readAllBytes(DIR.resolve("a.pptx"))));
    }

    @Test
    void malformedMissingConflictingCorruptAndInvalidSelectionRequestsKeepStatusContracts() throws Exception {
        for (String value : List.of("{", "{}", "{\"inputs\":[]}",
                "{\"inputs\":[],\"recipe\":{},\"output\":\"bad.pptx\"}",
                "{\"inputs\":[{\"file\":\"a.pptx\",\"slides\":[0]}],\"output\":\"bad.pptx\"}",
                "{\"inputs\":[\"a.pptx\"],\"output\":\"bad.pptx\",\"exclude\":[]}",
                "{\"recipe\":{\"version\":2,\"version\":2},\"output\":\"bad.pptx\"}"))
            error(json(value), 400);
        error(json("{\"inputs\":[\"absent.pptx\"],\"output\":\"bad.pptx\"}"), 404);
        error(json("{\"inputs\":[\"corrupt.pptx\"],\"output\":\"bad.pptx\"}"), 422);
        error(client.send(request("/api/v1/merges", "text/plain", "{}".getBytes()),
                HttpResponse.BodyHandlers.ofByteArray()), 415);
        var method = client.send(HttpRequest.newBuilder(uri("/api/v1/merges")).GET().build(),
                HttpResponse.BodyHandlers.ofByteArray());
        error(method, 405);
        assertTrue(method.headers().firstValue("Allow").orElseThrow().contains("POST"));
        error(client.send(request("/api/v1/merges/upload", "multipart/form-data; boundary=merge-boundary",
                multipart(List.of(), null)), HttpResponse.BodyHandlers.ofByteArray()), 400);
    }

    @Test
    void containerEnforcesIndividualAndAggregateUploadLimitsWithScopedJsonErrors() throws Exception {
        for (List<byte[]> files : List.of(List.of(new byte[50 * 1024]),
                List.of(new byte[40 * 1024], new byte[40 * 1024], new byte[40 * 1024]))) {
            error(client.send(request("/api/v1/merges/upload", "multipart/form-data; boundary=merge-boundary",
                    multipart(files, null)), HttpResponse.BodyHandlers.ofByteArray()), 413);
        }
        var host = client.send(
                request("/host", "application/json", "{\"version\":1,\"version\":2,\"exclude\":[]}".getBytes()),
                HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(200, host.statusCode());
        assertEquals(2, body(host).path("version").asInt());
        assertTrue(host.headers().firstValue("X-Merge-Operation-Id").isEmpty());
        var unsupported = client.send(request("/host", "text/plain", "data".getBytes()),
                HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(415, unsupported.statusCode());
        assertFalse(body(unsupported).has("operationId"));
        var hostError = client.send(HttpRequest.newBuilder(uri("/host/error")).GET().build(),
                HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(500, hostError.statusCode());
        assertFalse(body(hostError).has("operationId"));
    }

    @Test
    void concurrentIndependentMergesAndCreateOnlyConflictsAreAtomic() throws Exception {
        List<CompletableFuture<HttpResponse<byte[]>>> independent = new ArrayList<>();
        for (int i = 0; i < 4; i++)
            independent.add(client.sendAsync(
                    request("/api/v1/merges", "application/json", envelope("parallel" + i + ".pptx").getBytes()),
                    HttpResponse.BodyHandlers.ofByteArray()));
        Set<String> ids = new HashSet<>();
        for (var future : independent) {
            var response = future.join();
            assertEquals(200, response.statusCode());
            ids.add(response.headers().firstValue("X-Merge-Operation-Id").orElseThrow());
        }
        assertEquals(4, ids.size());
        var req = request("/api/v1/merges", "application/json", envelope("contended.pptx").getBytes());
        var first = client.sendAsync(req, HttpResponse.BodyHandlers.ofByteArray());
        var second = client.sendAsync(req, HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(Set.of(200, 409), Set.of(first.join().statusCode(), second.join().statusCode()));
        assertEquals(12, TestPackages.reader().read(DIR.resolve("contended.pptx")).slides().size());
    }

    @Test
    void controlledInternalFailuresAreSafeAndCarryTheOperationId() throws Exception {
        try {
            doThrow(new java.io.UncheckedIOException(new java.io.IOException("private path"))).when(service)
                    .merge(anyList(), any());
            var unexpected = json("{\"inputs\":[\"a.pptx\"],\"output\":\"never.pptx\"}");
            error(unexpected, 500);
            assertFalse(new String(unexpected.body()).contains("private path"));
            doThrow(new MergeException(ErrorCode.IO_FAILURE, "private path")).when(service).merge(anyList(), any());
            error(json("{\"inputs\":[\"a.pptx\"],\"output\":\"never.pptx\"}"), 500);
        } finally {
            reset(service);
        }
    }

    @Test
    void repeatedSourceTitleOrderIsPreservedThroughRealJsonAndMultipartHttp() throws Exception {
        String recipe = "{\"version\":2,\"sources\":[\"a.pptx\",\"a.pptx\"],\"select\":[\"Roadmap\",\"Appendix\"],\"options\":{\"remaining\":\"none\"}}";
        var response = json("{\"recipe\":" + recipe + ",\"output\":\"ordered-titles.pptx\"}");
        assertEquals(200, response.statusCode());
        assertEquals(4, body(response).path("slideCount").asInt());
        assertEquals(List.of(4, 9, 4, 9),
                sourceIndices(TestPackages.reader().read(DIR.resolve("ordered-titles.pptx"))));
        var download = client.send(
                request("/api/v1/merges/upload", "multipart/form-data; boundary=merge-boundary",
                        multipart(List.of(Files.readAllBytes(DIR.resolve("a.pptx"))), recipe)),
                HttpResponse.BodyHandlers.ofByteArray());
        assertEquals(200, download.statusCode());
        assertEquals("4", download.headers().firstValue("X-Merge-Slide-Count").orElseThrow());
        Path output = DIR.resolve("ordered-titles-download.pptx");
        Files.write(output, download.body());
        assertEquals(List.of(4, 9, 4, 9), sourceIndices(TestPackages.reader().read(output)));
    }

    String envelope(String output) {
        return "{\"recipe\":{\"version\":2,\"sources\":[\"a.pptx\"]},\"output\":\"" + output + "\"}";
    }

    static List<Integer> sourceIndices(PackageDocument doc) {
        var values = new ArrayList<Integer>();
        for (int i = 0; i < doc.slides().size(); i++)
            values.add(
                    Integer.parseInt(Xml.child(doc.slideXml(i), Ooxml.P, "cSld").getAttribute("name").split(":")[1]));
        return values;
    }

    static byte[] multipart(List<byte[]> files, String recipe) throws Exception {
        var bytes = new java.io.ByteArrayOutputStream();
        for (int i = 0; i < files.size(); i++) {
            bytes.write(("--merge-boundary\r\nContent-Disposition: form-data; name=\"files\"; filename=\""
                    + (i == 0 ? "a" : "file" + i) + ".pptx\"\r\nContent-Type: application/octet-stream\r\n\r\n")
                    .getBytes(StandardCharsets.UTF_8));
            bytes.write(files.get(i));
            bytes.write("\r\n".getBytes());
        }
        if (recipe != null)
            bytes.write(
                    ("--merge-boundary\r\nContent-Disposition: form-data; name=\"recipe\"\r\n\r\n" + recipe + "\r\n")
                            .getBytes(StandardCharsets.UTF_8));
        bytes.write("--merge-boundary--\r\n".getBytes());
        return bytes.toByteArray();
    }
}
