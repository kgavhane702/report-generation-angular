package com.mergeslides;

import com.mergeslides.api.lib.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.ooxml.Xml;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static org.junit.jupiter.api.Assertions.*;

class ExclusionTest {
    @TempDir
    Path temp;
    Path a, b;

    @BeforeEach
    void decks() throws Exception {
        a = ExclusionFixtures.deck(temp, "a.pptx");
        b = ExclusionFixtures.deck(temp, "b.pptx");
    }

    MergeSlides.Builder job() {
        return MergeSlides.builder().baseDirectory(temp).reporter(MergeReporter.silent());
    }

    List<Integer> numbers(MergePlan plan) {
        return plan.slides().stream().map(PlannedSlide::slideNumber).toList();
    }

    List<Integer> kept() {
        return List.of(1, 2, 4, 5, 7, 8, 9, 10, 11, 12);
    }

    static Stream<Arguments> modes() {
        return Stream.of(Arguments.of(RemainingSlides.NONE, List.of(1, 2, 4, 5, 7, 8, 9, 10)),
                Arguments.of(RemainingSlides.END, List.of(1, 2, 4, 5, 7, 8, 9, 10, 11, 12)),
                Arguments.of(RemainingSlides.START, List.of(11, 12, 1, 2, 4, 5, 7, 8, 9, 10)));
    }

    @ParameterizedTest
    @MethodSource("modes")
    void rangeExceptionsRespectRemainingModes(RemainingSlides mode, List<Integer> expected) {
        assertEquals(expected,
                numbers(job().addRange(a, 1, 10).excludeSlides(a, List.of(3, 6)).remainingSlides(mode).plan()));
        assertEquals(expected,
                numbers(job().addRange(a, 1, 10).excludeTitles(List.of("confidential")).remainingSlides(mode).plan()));
        assertEquals(expected,
                numbers(job().addRange(a, 1, 10).excludeSlides(List.of(a), 3, 6).remainingSlides(mode).plan()));
    }

    @Test
    void allSlidesAndExclusionOnlyJobsKeepOriginalIndices() {
        assertEquals(kept(), numbers(job().searchFiles(a).excludeSlides(a, 3, 6).plan()));
        assertEquals(kept(), numbers(
                job().searchFiles(a).excludeTitle("Confidential").remainingSlides(RemainingSlides.NONE).plan()));
        assertEquals(kept(), numbers(
                job().addFile(a, InputSelection.all()).exclude(a, InputSelection.titles("Confidential")).plan()));
    }

    @Test
    void rangesSlicesAndNegativeIndicesReuseExistingNumericRules() {
        assertEquals(List.of(1, 2, 3, 8, 9, 10),
                numbers(job().addRange(a, 1, 10).excludeRange(a, 4, 7).remaining(RemainingSlides.NONE).plan()));
        assertEquals(kept(), numbers(job().addAll(a).exclude(a, InputSelection.slice(new SlideSlice(2, 6, 3))).plan()));
        assertEquals(kept(), numbers(job().addAll(a).exclude(List.of(a), InputSelection.slides(-10, -7)).plan()));
        assertEquals(List.of(1, 2, 3), numbers(job().addAll(a).excludeRange(List.of(a), 4, 999).plan()));
        assertEquals(12, job().addAll(a).excludeRange(a, 8, 2).plan().slides().size());
        assertEquals(DiagnosticCode.INVALID_SELECTION,
                assertThrows(MergeException.class,
                        () -> job().addAll(a).exclude(a, InputSelection.slice(new SlideSlice(null, null, 0))).plan())
                        .failureCode());
    }

    @Test
    void exclusionsPreserveCustomAndReverseSliceOrder() {
        assertEquals(List.of(10, 8, 1), numbers(job().addSlides(a, List.of(10, 6, 3, 8, 1))
                .excludeTitles(a, "Confidential").remaining(RemainingSlides.NONE).plan()));
        assertEquals(List.of(12, 11, 10, 9, 8, 7, 5, 4, 2, 1), numbers(job().addSlice(a, new SlideSlice(null, null, -1))
                .excludeSlides(a, 3, 6).remaining(RemainingSlides.NONE).plan()));
    }

    @Test
    void scopedAndGlobalTitleListsAndOverlapsFormAUnion() {
        var scoped = job().addFiles(List.of(a, b)).excludeTitles(a, List.of("Confidential", "Appendix"))
                .excludeSlides(a, 3).excludeRange(a, 6, 6).plan();
        assertEquals(21, scoped.slides().size());
        assertEquals(3, scoped.summary().excludedCount());
        assertEquals(2,
                scoped.slides().stream().filter(s -> s.file().equals(b) && "Confidential".equals(s.title())).count());
        var global = job().addFiles(a, b).excludeTitles("Confidential", "Appendix").plan();
        assertEquals(18, global.slides().size());
        assertEquals(6, global.summary().excludedCount());
        assertEquals(18,
                job().addFiles(a, b).excludeTitles(List.of(a, b), "Confidential", "Appendix").plan().slides().size());
        assertEquals(18, job().addFiles(a, b).excludeTitles(List.of(a, b), List.of("Confidential", "Appendix")).plan()
                .slides().size());
    }

    @Test
    void sourceOccurrencesAndDuplicatePlacementDoNotRestoreExcludedSlides() {
        var plan = job().addFiles(a, a).excludeTitle(a, "Confidential").plan();
        assertEquals(Stream.concat(kept().stream(), kept().stream()).toList(), numbers(plan));
        assertEquals(4, plan.summary().excludedCount());
        for (DuplicateTitlePolicy policy : DuplicateTitlePolicy.values()) {
            var conflict = job().searchFiles(a).addTitle("Confidential").duplicateTitles(policy)
                    .onMissing(MissingTitlePolicy.ERROR).excludeTitle("Confidential").addSlides(a, 3, 6).plan();
            assertEquals(kept(), numbers(conflict));
            assertTrue(conflict.diagnostics().isEmpty());
        }
        assertEquals(kept(), numbers(job().excludeTitle("Confidential").addAll(a).plan()));
    }

    @Test
    void hiddenOverridesAndWithinDoNotWeakenHardExclusions() {
        assertEquals(kept(), numbers(job().searchFiles(a).skipHidden().addSlide(a, 3)
                .selectFile(a, InputSelection.slides(6).skipHidden(false)).excludeTitle("Confidential").plan()));
        var plan = job().addAll(a).exclude(a, InputSelection.title("Confidential").withinRange("1-5").skipHidden()
                .duplicates(DuplicateTitlePolicy.LAST)).plan();
        assertFalse(numbers(plan).contains(3));
        assertTrue(numbers(plan).contains(6));
        assertEquals(1, plan.summary().excludedCount());
    }

    @Test
    void oldNumericOnlyMissingTitleDiagnosticsRemainStrict() {
        var error = assertThrows(MergeException.class, () -> job().addTitle(a, "Confidential").excludeSlides(a, 3, 6)
                .onMissing(MissingTitlePolicy.ERROR).plan());
        assertEquals(DiagnosticCode.TITLE_NO_ELIGIBLE_MATCH, error.failureCode());
        assertEquals(1, job().addTitle(a, "Confidential").excludeSlides(a, 3, 6).plan().diagnostics().size());
    }

    @Test
    void missingExcludedTitlesWarnOnceForCompleteScopeAndHaveSeparateStrictPolicy() {
        var plan = job().addFiles(a, b).excludeTitles(List.of(a, b), List.of("Absent"))
                .onMissing(MissingTitlePolicy.ERROR).plan();
        assertEquals(24, plan.slides().size());
        assertEquals(1, plan.diagnostics().size());
        var warning = plan.diagnostics().get(0);
        assertEquals(DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND, warning.code());
        assertEquals("Absent", warning.details().get("title"));
        assertEquals(1, plan.summary().missingTitleCount());
        assertEquals(DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND, assertThrows(MergeException.class,
                () -> job().addAll(a).excludeTitle("Absent").onMissingExcludedTitle(MissingTitlePolicy.ERROR).plan())
                .failureCode());
    }

    @Test
    void exactPlaceholderMatchingDoesNotGuessFromBodyOrPartialText() {
        var plan = job().addAll(a).excludeTitles(List.of("Confidential ", "Confident", "Body 3", "a.pptx")).plan();
        assertEquals(12, plan.slides().size());
        assertEquals(4, plan.diagnostics().size());
        assertNull(plan.slides().get(11).title());
    }

    @Test
    void directoryScopeIsNonrecursiveAndDoesNotAffectOutsideFiles() throws Exception {
        Path folder = temp.resolve("folder"), nested = folder.resolve("nested");
        Path ten = ExclusionFixtures.deck(folder, "deck10.pptx"), two = ExclusionFixtures.deck(folder, "deck2.pptx");
        Path inner = ExclusionFixtures.deck(nested, "inner.pptx");
        Files.writeString(folder.resolve("~$lock.pptx"), "ignore");
        Files.writeString(folder.resolve("readme.txt"), "ignore");
        var plan = job().addDirectory(folder).addFile(inner).addFile(a)
                .excludeDirectory(folder, InputSelection.titles(List.of("Confidential"))).plan();
        assertEquals(two, plan.slides().get(0).file());
        assertEquals(44, plan.slides().size());
        assertEquals(4, plan.summary().excludedCount());
        assertEquals(12, plan.slides().stream().filter(s -> s.file().equals(inner)).count());
        assertEquals(12, plan.slides().stream().filter(s -> s.file().equals(a)).count());
        assertEquals(20, job().searchDirectory(folder).excludeTitle("Confidential").plan().slides().size());
        assertEquals(4, job().searchDirectory(folder).addTitles(List.of("Roadmap"))
                .excludeDirectory(folder, InputSelection.range("1-3")).plan().slides().get(0).slideNumber());
        assertTrue(Files.exists(ten));
    }

    @Test
    void directoryAndFileListsSupportRangesAndWholeSourceExclusions() throws Exception {
        Path first = temp.resolve("one"), second = temp.resolve("two");
        Path x = ExclusionFixtures.deck(first, "x.pptx"), y = ExclusionFixtures.deck(second, "y.pptx");
        List<Path> folders = List.of(first, second);
        assertEquals(16,
                job().addFiles(folders, InputSelection.range("1-10"))
                        .excludeDirectories(folders, InputSelection.slides(3, 6)).remaining(RemainingSlides.NONE).plan()
                        .slides().size());
        assertEquals(20,
                job().addFiles(List.of(x, y)).excludeSlides(List.of(x, y), List.of(3, 6)).plan().slides().size());
        assertEquals(18, job().addFiles(List.of(x, y)).excludeRange(List.of(x, y), 4, 6).plan().slides().size());
        assertEquals(12, job().addFiles(folders).excludeDirectory(first).plan().slides().size());
        assertEquals(12, job().addFiles(folders).addFile(a).excludeDirectories(folders).plan().slides().size());
        assertEquals(12, job().addFiles(x, y).excludeFile(x).plan().slides().size());
        assertEquals(12, job().addFiles(x, y, a).excludeFiles(List.of(x, y)).plan().slides().size());
        assertEquals(12, job().addFiles(x, y, a).excludeFiles(x, y).plan().slides().size());
        assertEquals(12, job().addFiles(x, y).exclude(List.of(x), InputSelection.all()).plan().slides().size());
    }

    @Test
    void bulkNumbersRemainStrictForShorterSourcesAndExclusionsDoNotRegisterInputs() throws Exception {
        Path shortDeck = ExclusionFixtures.deck(temp, "short.pptx", 2);
        assertEquals(DiagnosticCode.INVALID_SELECTION,
                assertThrows(MergeException.class,
                        () -> job().addFiles(a, shortDeck).excludeSlides(List.of(a, shortDeck), 3, 6).plan())
                        .failureCode());
        assertEquals(DiagnosticCode.INVALID_SELECTION,
                assertThrows(MergeException.class, () -> job().addAll(a).excludeFile(b).plan()).failureCode());
        assertEquals(DiagnosticCode.INVALID_SELECTION,
                assertThrows(MergeException.class,
                        () -> job().addAll(a).excludeDirectory(Files.createDirectory(temp.resolve("unused"))).plan())
                        .failureCode());
        assertEquals(DiagnosticCode.INVALID_REQUEST,
                assertThrows(MergeException.class, () -> job().excludeTitle("Confidential").plan()).failureCode());
    }

    @Test
    void directoryExclusionsRecognizePhysicalAliasesAndAllTheirOccurrences() throws Exception {
        Path folder = Files.createDirectory(temp.resolve("aliases"));
        Files.createLink(folder.resolve("linked.pptx"), a);
        var plan = job().addFile(a).addDirectory(folder).addFile(b).excludeDirectory(folder).plan();
        assertEquals(12, plan.slides().size());
        assertEquals(24, plan.summary().excludedCount());
        assertTrue(plan.slides().stream().allMatch(s -> s.file().equals(b)));
    }

    @Test
    void exclusionCollectionsAreCopiedAndEmptyListsAreNoOps() {
        var paths = new ArrayList<>(List.of(a));
        var titles = new ArrayList<>(List.of("Confidential"));
        var slides = new ArrayList<>(List.of(9));
        var builder = job().addFiles(a, b).excludeTitles(paths, titles).excludeSlides(paths, slides);
        paths.set(0, b);
        titles.set(0, "Roadmap");
        slides.set(0, 1);
        assertEquals(21, builder.plan().slides().size());
        assertTrue(builder.plan().slides().stream().anyMatch(s -> s.file().equals(b) && s.slideNumber() == 3));
        assertEquals(12, job().addAll(a).excludeTitles(List.of()).excludeTitles(a, List.of())
                .excludeTitles(List.of(b), List.of()).excludeSlides(a, List.of()).excludeSlides(List.of(b), List.of())
                .excludeFiles(List.of()).excludeDirectories(List.of())
                .excludeDirectory(temp.resolve("not-registered"), InputSelection.slides()).plan().slides().size());
        for (Runnable invalid : List.<Runnable>of(() -> job().excludeTitles((List<String>) null),
                () -> job().excludeTitles(List.of(" ")), () -> job().excludeFiles(Arrays.asList(a, null)),
                () -> job().excludeSlides(List.of(a), Arrays.asList(3, null)), () -> job().exclude(a, null),
                () -> job().excludeFiles((Path[]) null)))
            assertEquals(DiagnosticCode.INVALID_REQUEST,
                    assertThrows(MergeException.class, invalid::run).failureCode());
    }

    @Test
    void allFilteredAndStrictFailuresPreserveExistingOutputAndStillValidateSources() throws Exception {
        Path output = Files.writeString(temp.resolve("existing.pptx"), "sentinel");
        assertEquals(DiagnosticCode.NO_ELIGIBLE_SLIDES, assertThrows(MergeException.class,
                () -> job().addAll(a).excludeFile(a).output(output).overwrite(true).merge()).failureCode());
        assertEquals("sentinel", Files.readString(output));
        assertThrows(MergeException.class, () -> job().addAll(a).excludeTitle("Absent")
                .onMissingExcludedTitle(MissingTitlePolicy.ERROR).output(output).overwrite(true).merge());
        assertEquals("sentinel", Files.readString(output));
        Path corrupt = Files.writeString(temp.resolve("corrupt.pptx"), "invalid");
        assertEquals(DiagnosticCode.INVALID_PRESENTATION,
                assertThrows(MergeException.class,
                        () -> job().addFiles(a, corrupt).excludeFile(corrupt).output(output).overwrite(true).merge())
                        .failureCode());
        assertEquals("sentinel", Files.readString(output));
    }

    @Test
    void previewAndActualPackageAgreeAndOmittedLinksRemainWarnings() throws Exception {
        // A retained first slide links to slide 3, which will be excluded.
        var document = TestPackages.reader().read(a);
        var parts = new LinkedHashMap<>(document.parts());
        String slide = new String(parts.get("ppt/slides/slide1.xml"), StandardCharsets.UTF_8).replace("<a:r><a:t>",
                "<a:r><a:rPr><a:hlinkClick r:id=\"jump\"/></a:rPr><a:t>");
        parts.put("ppt/slides/slide1.xml", slide.getBytes(StandardCharsets.UTF_8));
        parts.put("ppt/slides/_rels/slide1.xml.rels", TestPackages
                .relationships(TestPackages.rel("l", RelationshipType.SLIDE_LAYOUT, "../slideLayouts/slideLayout1.xml")
                        + TestPackages.rel("jump", RelationshipType.SLIDE, "slide3.xml"))
                .getBytes(StandardCharsets.UTF_8));
        TestPackages.write(a, parts);
        var built = job().addRange(a, 1, 10).excludeTitle("Confidential").remaining(RemainingSlides.END)
                .output(temp.resolve("actual.pptx")).build();
        var preview = built.plan();
        var report = built.mergeDetailed();
        assertEquals(preview.slides(), report.slides());
        assertEquals(preview.summary(), report.summary());
        var merged = TestPackages.reader().read(report.result().outputPath());
        assertEquals(kept().stream().map(i -> "a.pptx:" + i).toList(), IntStream.range(0, merged.slides().size())
                .mapToObj(i -> Xml.child(merged.slideXml(i), P, "cSld").getAttribute("name")).toList());
        assertTrue(report.diagnostics().stream().anyMatch(d -> d.code() == DiagnosticCode.OMITTED_SLIDE_LINK));
        assertTrue(report.result().warnings().stream().anyMatch(w -> w.contains("omitted slide")));
    }

    @Test
    void oldDefinitionConstructorsAndAccessorsRemainUsable() {
        var rule = new MergeDefinition.Exclusion(a, InputSelection.slides(3));
        assertEquals(a, rule.file());
        assertTrue(rule.legacyNumeric());
        var options = new MergeDefinition.Options(false, DuplicateTitlePolicy.ALL, DuplicateSourcePolicy.ALLOW,
                RepeatedSlidePolicy.ALLOW, MissingTitlePolicy.SKIP, RemainingSlides.END, false);
        assertEquals(MissingTitlePolicy.SKIP,
                options.orElse(MergeDefinition.Options.defaults()).onMissingExcludedTitle());
    }
}
