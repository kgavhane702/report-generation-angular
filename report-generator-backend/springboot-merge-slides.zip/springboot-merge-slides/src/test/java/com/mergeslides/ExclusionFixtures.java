package com.mergeslides;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

/** Real OOXML fixtures with identifiable source slides and two duplicate title placeholders. */
final class ExclusionFixtures {
    private ExclusionFixtures() {
    }

    static Path deck(Path folder, String name) throws Exception {
        return deck(folder, name, 12);
    }

    static Path deck(Path folder, String name, int count) throws Exception {
        Files.createDirectories(folder);
        var parts = TestPackages.parts(name, count);
        for (int i = 1; i <= count; i++) {
            String title = switch (i) {
                case 3, 6 -> "Confidential";
                case 4 -> "Roadmap";
                case 9 -> "Appendix";
                case 12 -> null;
                default -> "Slide " + i;
            };
            String text = title == null
                    ? ""
                    : "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title\"/><p:cNvSpPr/>"
                            + "<p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>"
                            + "<a:p><a:r><a:t>" + title + "</a:t></a:r></a:p></p:txBody></p:sp>";
            String body = "<p:sp><p:txBody><a:p><a:r><a:t>Body " + i + "</a:t></a:r></a:p></p:txBody></p:sp>";
            String xml = "<p:sld xmlns:p=\"" + P + "\" xmlns:a=\"" + A + "\" xmlns:r=\"" + R + "\""
                    + (i == 6 ? " show=\"0\"" : "") + "><p:cSld name=\"" + name + ":" + i + "\"><p:spTree>" + text
                    + body + "</p:spTree></p:cSld></p:sld>";
            parts.put("ppt/slides/slide" + i + ".xml", xml.getBytes(StandardCharsets.UTF_8));
        }
        return TestPackages.write(folder.resolve(name), parts);
    }
}
