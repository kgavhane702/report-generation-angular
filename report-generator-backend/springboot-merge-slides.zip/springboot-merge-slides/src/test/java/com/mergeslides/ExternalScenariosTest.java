package com.mergeslides;

import com.fasterxml.jackson.databind.*;
import com.mergeslides.cli.MergeCli;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import org.junit.jupiter.api.*;
import org.w3c.dom.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
import java.net.URLDecoder;
import java.util.*;
import java.util.stream.Stream;
import java.util.zip.ZipFile;
import static org.junit.jupiter.api.Assertions.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

/** External fixtures stay outside the distributable project. No Python is executed. */
@Tag("external")
class ExternalScenariosTest {
    static final Path ROOT = Path.of(System.getProperty("merge.workspace", "..")).toAbsolutePath().normalize();
    static final Path OUTPUT = Path.of(System.getProperty("merge.results", "../springboot-oupt")).toAbsolutePath()
            .normalize();
    static final ObjectMapper JSON = new ObjectMapper();
    static final List<Map<String, Object>> RECEIPTS = new ArrayList<>();
    static final Map<Path, Audit> SOURCE_CACHE = new HashMap<>();
    static final Map<String, String> BEFORE = new TreeMap<>();
    final PackageReader reader = TestPackages.reader();
    final PackageMergeService engine = new PackageMergeService(reader, new AtomicPackageWriter(reader));
    final InputResolver resolver = new InputResolver(JSON);

    @BeforeAll
    static void before() throws Exception {
        Files.createDirectories(OUTPUT);
        Path hashes = ROOT.resolve("output/2026-10-15_merge_review/source_sha256_before.json");
        Assumptions.assumeTrue(Files.exists(hashes),
                "External Python verification baseline is unavailable; use -PmergeWorkspace.");
        for (var fields = JSON.readTree(hashes.toFile()).fieldNames(); fields.hasNext();) {
            String name = fields.next();
            BEFORE.put(name, PackageDocument.hex(PackageDocument.sha(Files.readAllBytes(ROOT.resolve(name)))));
        }
        JSON.writerWithDefaultPrettyPrinter().writeValue(OUTPUT.resolve("source_sha256_before.json").toFile(), BEFORE);
    }

    @TestFactory
    Stream<DynamicTest> scenarios() throws Exception {
        var baseline = JSON.readTree(ROOT.resolve("output/2026-10-15_merge_review/report.json").toFile());
        var tests = new ArrayList<DynamicTest>();
        for (var row : baseline.get("scenarios"))
            tests.add(DynamicTest.dynamicTest(row.get("scenario").asText(), () -> run(row)));
        return tests.stream();
    }

    private void run(JsonNode row) throws Exception {
        String name = row.get("scenario").asText();
        Path dir = OUTPUT.resolve(name);
        Files.createDirectories(dir);
        Path output = dir.resolve("merged.pptx");
        Files.deleteIfExists(output);
        var receipt = new LinkedHashMap<String, Object>();
        receipt.put("scenario", name);
        receipt.put("output", OUTPUT.relativize(output).toString());
        boolean failure = row.get("expected_failure").asBoolean();
        receipt.put("expected_failure", failure);
        receipt.put("expected_slides", row.get("expected_slides").asInt());
        long started = System.nanoTime();
        var log = new ByteArrayOutputStream();
        try {
            int code;
            if (name.startsWith("14_") || name.startsWith("16_")) {
                List<InputSpec> specs = name.startsWith("14_")
                        ? List.of(
                                new InputSpec(ROOT.resolve("multi_slide_ppt/part_01.pptx"), new SlideSlice(-1, -5, -1),
                                        false),
                                new InputSpec(ROOT.resolve("multi_slide_ppt/part_02.pptx"), new SlideSlice(0, 5, 2),
                                        false))
                        : resolver
                                .resolve(
                                        List.of(new InputSpec(ROOT.resolve("multi_slide_ppt/part_01.pptx"),
                                                List.of(1, 3), false), ROOT.resolve("multi_slide_test_set_2")),
                                        ROOT, output);
                var result = engine.merge(specs, output);
                log.write(result.toString().getBytes(StandardCharsets.UTF_8));
                code = 0;
            } else {
                var args = new ArrayList<String>();
                var command = row.get("command");
                for (int i = 3; i < command.size() - 2; i++)
                    args.add(command.get(i).asText());
                args.add("-o");
                args.add(output.toString());
                receipt.put("arguments", args);
                try (var print = new PrintStream(log, true, StandardCharsets.UTF_8)) {
                    code = new MergeCli(engine, resolver).run(args.toArray(String[]::new), ROOT, ROOT, print, print);
                }
            }
            receipt.put("exit_code", code);
            if (failure) {
                assertEquals(2, code);
                assertFalse(Files.exists(output));
            } else {
                assertEquals(0, code, log.toString(StandardCharsets.UTF_8));
                reader.read(output);
                var actual = new Audit(output);
                assertEquals(row.get("expected_slides").asInt(), actual.slides.size());
                var expected = row.get("expected_order");
                Set<String> binaries = new HashSet<>();
                for (int i = 0; i < expected.size(); i++) {
                    var pick = expected.get(i);
                    Path sourcePath = ROOT.resolve(pick.get("file").asText()).normalize();
                    var source = SOURCE_CACHE.computeIfAbsent(sourcePath, p -> {
                        try {
                            return new Audit(p);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                    String sourceSlide = source.slides.get(pick.get("slide").asInt() - 1);
                    assertEquals(canonical(Xml.parse(source.parts.get(sourceSlide), sourceSlide)),
                            canonical(Xml.parse(actual.parts.get(actual.slides.get(i)), "output")),
                            "Slide markup/order at " + (i + 1));
                    binaries.addAll(source.binaryDependencies(sourceSlide));
                }
                Set<String> outputBinaries = new HashSet<>();
                actual.parts.forEach((n, bytes) -> {
                    if (!n.endsWith(".xml") && !n.endsWith(".rels"))
                        outputBinaries.add(PackageDocument.hex(PackageDocument.sha(bytes)));
                });
                assertTrue(outputBinaries.containsAll(binaries), "Native binary dependencies changed/lost");
                actual.audit();
                receipt.put("actual_slides", actual.slides.size());
                receipt.put("order_and_content_match", true);
                receipt.put("binary_dependencies_match", true);
                receipt.put("expected_order", JSON.convertValue(expected, Object.class));
                receipt.put("sha256", PackageDocument.hex(PackageDocument.sha(Files.readAllBytes(output))));
            }
            receipt.put("passed", true);
        } catch (Throwable e) {
            receipt.put("passed", false);
            receipt.put("error", e.toString());
            throw e;
        } finally {
            receipt.put("seconds", (System.nanoTime() - started) / 1e9);
            RECEIPTS.add(receipt);
            Files.writeString(dir.resolve("command.log"), log.toString(StandardCharsets.UTF_8));
            JSON.writerWithDefaultPrettyPrinter().writeValue(dir.resolve("validation.json").toFile(), receipt);
        }
    }

    @AfterAll
    static void after() throws Exception {
        if (BEFORE.isEmpty())
            return;
        var after = new TreeMap<String, String>();
        for (String name : BEFORE.keySet())
            after.put(name, PackageDocument.hex(PackageDocument.sha(Files.readAllBytes(ROOT.resolve(name)))));
        boolean unchanged = BEFORE.equals(after);
        JSON.writerWithDefaultPrettyPrinter().writeValue(OUTPUT.resolve("source_sha256_after.json").toFile(), after);
        var report = new LinkedHashMap<String, Object>();
        report.put("implementation", "Standalone Java/Spring Boot 3.5.16");
        report.put("scenarios", RECEIPTS);
        report.put("passed", RECEIPTS.stream().filter(r -> Boolean.TRUE.equals(r.get("passed"))).count());
        report.put("total", RECEIPTS.size());
        report.put("sources_unchanged", unchanged);
        report.put("source_files_checked", BEFORE.size());
        report.put("all_passed", unchanged && RECEIPTS.size() == 43
                && RECEIPTS.stream().allMatch(r -> Boolean.TRUE.equals(r.get("passed"))));
        JSON.writerWithDefaultPrettyPrinter().writeValue(OUTPUT.resolve("report.json").toFile(), report);
        assertTrue(unchanged, "Original source files changed");
    }

    private static String canonical(Element e) {
        if (A.equals(e.getNamespaceURI()) && Set.of("hlinkClick", "hlinkMouseOver").contains(e.getLocalName()))
            return "";
        var attrs = new TreeMap<String, String>();
        for (var a : Xml.attributes(e))
            if (!javax.xml.XMLConstants.XMLNS_ATTRIBUTE_NS_URI.equals(a.getNamespaceURI()))
                attrs.put("{" + a.getNamespaceURI() + "}" + (a.getLocalName() == null ? a.getName() : a.getLocalName()),
                        a.getValue());
        var text = new StringBuilder();
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling())
            if (n.getNodeType() == Node.TEXT_NODE || n.getNodeType() == Node.CDATA_SECTION_NODE)
                text.append(n.getNodeValue());
        var out = new StringBuilder(
                "{" + e.getNamespaceURI() + "}" + e.getLocalName() + attrs + text.toString().strip());
        for (var child : Xml.children(e)) {
            String value = canonical(child);
            if (!value.isEmpty())
                out.append('[').append(value).append(']');
        }
        return out.toString();
    }

    private static final class Audit {
        final Map<String, byte[]> parts = new HashMap<>();
        final List<String> slides = new ArrayList<>();

        Audit(Path file) throws Exception {
            try (var zip = new ZipFile(file.toFile())) {
                var entries = zip.entries();
                while (entries.hasMoreElements()) {
                    var e = entries.nextElement();
                    if (!e.isDirectory())
                        try (var in = zip.getInputStream(e)) {
                            parts.put(e.getName(), in.readAllBytes());
                        }
                }
            }
            Map<String, String> rels = new HashMap<>();
            for (var e : Xml.children(Xml.parse(parts.get("ppt/_rels/presentation.xml.rels"), "rels")))
                rels.put(e.getAttribute("Id"), target(PRESENTATION, e.getAttribute("Target")));
            for (var e : Xml.children(Xml.child(Xml.parse(parts.get(PRESENTATION), "presentation"), P, "sldIdLst")))
                slides.add(rels.get(Xml.rid(e)));
        }

        Set<String> binaryDependencies(String slide) {
            var found = new HashSet<String>();
            var visited = new HashSet<String>();
            var pending = new ArrayDeque<String>();
            pending.add(slide);
            while (!pending.isEmpty()) {
                String owner = pending.remove();
                if (!visited.add(owner))
                    continue;
                if (!owner.endsWith(".xml") && !owner.endsWith(".rels"))
                    found.add(PackageDocument.hex(PackageDocument.sha(parts.get(owner))));
                String rels = relsPart(owner);
                if (parts.containsKey(rels))
                    for (var rel : Xml.children(Xml.parse(parts.get(rels), rels)))
                        if (!rel.getAttribute("TargetMode").equals("External")
                                && !rel.getAttribute("Type").endsWith("/slide"))
                            pending.add(target(owner, rel.getAttribute("Target")));
            }
            return found;
        }

        void audit() {
            for (String name : parts.keySet())
                if (name.endsWith(".rels")) {
                    String owner = name.equals("_rels/.rels")
                            ? ""
                            : name.replace("/_rels/", "/").replaceFirst("\\.rels$", "");
                    var ids = new HashSet<String>();
                    for (var e : Xml.children(Xml.parse(parts.get(name), name))) {
                        assertTrue(ids.add(e.getAttribute("Id")), "Duplicate relationship ID");
                        if (!e.getAttribute("TargetMode").equals("External"))
                            assertTrue(parts.containsKey(target(owner, e.getAttribute("Target"))),
                                    "Missing relationship target");
                    }
                }
            var presentation = Xml.parse(parts.get(PRESENTATION), "presentation");
            var sections = new ArrayList<String>();
            for (var section : Xml.findAll(presentation, P14, "section"))
                for (var id : Xml.children(Xml.child(section, P14, "sldIdLst")))
                    sections.add(id.getAttribute("id"));
            var ids = Xml.children(Xml.child(presentation, P, "sldIdLst")).stream().map(e -> e.getAttribute("id"))
                    .toList();
            if (!sections.isEmpty())
                assertEquals(ids, sections, "Sections must follow output order exactly once");
        }

        private static String target(String owner, String uri) {
            String decoded = URLDecoder.decode(uri.split("#", 2)[0].replace("+", "%2B"), StandardCharsets.UTF_8);
            Path base = Path.of("/" + owner).getParent();
            if (base == null)
                base = Path.of("/");
            String result = (decoded.startsWith("/") ? Path.of(decoded) : base.resolve(decoded)).normalize().toString()
                    .replace('\\', '/');
            return result.replaceFirst("^[A-Za-z]:", "").replaceFirst("^/+", "");
        }

        private static String relsPart(String owner) {
            int slash = owner.lastIndexOf('/');
            return (slash < 0 ? "" : owner.substring(0, slash + 1)) + "_rels/" + owner.substring(slash + 1) + ".rels";
        }
    }
}
