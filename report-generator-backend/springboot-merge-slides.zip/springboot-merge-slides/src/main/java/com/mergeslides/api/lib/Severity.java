package com.mergeslides.api.lib;

public enum Severity {
    DEBUG, INFO, WARN, ERROR
}
