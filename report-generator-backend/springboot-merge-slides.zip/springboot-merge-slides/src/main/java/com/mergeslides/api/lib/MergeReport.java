package com.mergeslides.api.lib;

import com.mergeslides.domain.MergeResult;
import java.util.List;

public record MergeReport(MergeResult result, String operationId, List<MergeDiagnostic> diagnostics,
        MergeSummary summary, List<PlannedSlide> slides) {
    public MergeReport {
        diagnostics = List.copyOf(diagnostics);
        slides = List.copyOf(slides);
    }
}
