package com.mergeslides.api.lib;

public enum DuplicateTitlePolicy {
    ALL, FIRST, LAST, ERROR
}
