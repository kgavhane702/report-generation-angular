package com.mergeslides.infrastructure.input;

import java.math.BigInteger;
import java.util.*;
import java.util.regex.Pattern;

public final class NaturalOrder implements Comparator<String> {
    public static final NaturalOrder INSTANCE = new NaturalOrder();
    private static final Pattern TOKENS = Pattern.compile("\\d+|\\D+");

    private NaturalOrder() {
    }

    @Override
    public int compare(String left, String right) {
        var a = TOKENS.matcher(left.toLowerCase(Locale.ROOT));
        var b = TOKENS.matcher(right.toLowerCase(Locale.ROOT));
        while (true) {
            boolean x = a.find(), y = b.find();
            if (!x || !y)
                return x ? 1 : y ? -1 : left.compareTo(right);
            String p = a.group(), q = b.group();
            int c = Character.isDigit(p.charAt(0)) && Character.isDigit(q.charAt(0))
                    ? new BigInteger(p).compareTo(new BigInteger(q))
                    : p.compareTo(q);
            if (c != 0)
                return c;
        }
    }
}
