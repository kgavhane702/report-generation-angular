package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class PackageReader {
    private final PackageValidator validator;

    public PackageReader(PackageValidator validator) {
        this.validator = validator;
    }

    public PackageDocument read(Path path) {
        Map<String, byte[]> parts = new LinkedHashMap<>();
        try (var archive = new ZipFile(path.toFile())) {
            var entries = archive.entries();
            while (entries.hasMoreElements()) {
                var entry = entries.nextElement();
                if (entry.isDirectory())
                    continue;
                String name = entry.getName();
                if (name.contains("\\") || name.startsWith("/") || !PackagePaths.normalize(name).equals(name)
                        || name.startsWith("../"))
                    throw new MergeException(ErrorCode.INVALID_PRESENTATION, "Unsafe ZIP member " + name);
                if (Set.of("trash", "[trash]").contains(name.split("/", 2)[0].toLowerCase(Locale.ROOT)))
                    continue;
                if (parts.containsKey(name))
                    throw new MergeException(ErrorCode.INVALID_PRESENTATION, "Duplicate ZIP member " + name);
                byte[] data;
                try (var stream = archive.getInputStream(entry)) {
                    data = stream.readAllBytes();
                }
                var crc = new CRC32();
                crc.update(data);
                if (crc.getValue() != entry.getCrc())
                    throw new MergeException(ErrorCode.INVALID_PRESENTATION, "ZIP CRC mismatch: " + name);
                parts.put(name, data);
            }
        } catch (IOException e) {
            throw new MergeException(ErrorCode.INVALID_PRESENTATION,
                    path.getFileName() + ": Cannot read PPTX: " + e.getMessage(), e);
        }
        var document = new PackageDocument(path, parts);
        validator.validate(document);
        return document;
    }
}
