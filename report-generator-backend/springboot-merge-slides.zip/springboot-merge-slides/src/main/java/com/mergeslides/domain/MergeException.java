package com.mergeslides.domain;

import com.mergeslides.api.lib.*;
import java.util.List;

public class MergeException extends RuntimeException {
    private final ErrorCode code;
    private final DiagnosticCode failureCode;
    private final MergeStage stage;
    private final String operationId;
    private final List<MergeDiagnostic> diagnostics;

    public MergeException(ErrorCode code, String message) {
        this(code, message, null);
    }

    public MergeException(ErrorCode code, String message, Throwable cause) {
        this(code, DiagnosticCode.valueOf(switch (code) {
            case INPUT_NOT_FOUND -> "SOURCE_NOT_FOUND";
            case INVALID_PRESENTATION -> "INVALID_PRESENTATION";
            case IO_FAILURE -> "OUTPUT_WRITE_FAILED";
            default -> "INVALID_REQUEST";
        }), code == ErrorCode.INVALID_PRESENTATION ? MergeStage.READ : MergeStage.VALIDATION, message, cause, null,
                List.of());
    }

    public MergeException(ErrorCode code, DiagnosticCode failureCode, MergeStage stage, String message, Throwable cause,
            String operationId, List<MergeDiagnostic> diagnostics) {
        super(message, cause);
        this.code = code;
        this.failureCode = failureCode;
        this.stage = stage;
        this.operationId = operationId;
        this.diagnostics = List.copyOf(diagnostics);
    }

    public ErrorCode code() {
        return code;
    }

    public DiagnosticCode failureCode() {
        return failureCode;
    }

    public MergeStage stage() {
        return stage;
    }

    public String operationId() {
        return operationId;
    }

    public List<MergeDiagnostic> diagnostics() {
        return diagnostics;
    }

    public static MergeException invalid(String message) {
        return new MergeException(ErrorCode.INVALID_REQUEST, message);
    }
}
