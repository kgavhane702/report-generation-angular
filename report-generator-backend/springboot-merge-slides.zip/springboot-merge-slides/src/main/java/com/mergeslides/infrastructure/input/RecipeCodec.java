package com.mergeslides.infrastructure.input;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.mergeslides.api.lib.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.domain.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Strict v2 codec and compatibility adapter for legacy array recipes. No file-size policy. */
public final class RecipeCodec {
    private final ObjectMapper mapper = new ObjectMapper().enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);

    public MergeDefinition read(Path recipe) {
        Path path = recipe.toAbsolutePath().normalize();
        try {
            return decode(parse(Files.readString(path)), path.getParent());
        } catch (NoSuchFileException e) {
            throw failure(ErrorCode.INPUT_NOT_FOUND, DiagnosticCode.SOURCE_NOT_FOUND, "Recipe not found: " + path, e);
        } catch (IOException e) {
            throw failure(ErrorCode.IO_FAILURE, DiagnosticCode.SOURCE_UNREADABLE, "Cannot read recipe: " + path, e);
        }
    }

    public Object parse(String json) {
        try {
            return mapper.readValue(json.startsWith("\uFEFF") ? json.substring(1) : json, Object.class);
        } catch (IOException e) {
            throw failure(ErrorCode.INVALID_REQUEST, DiagnosticCode.INVALID_RECIPE,
                    "Invalid recipe JSON: " + e.getMessage(), e);
        }
    }

    public MergeDefinition decode(Object data, Path base) {
        base = base.toAbsolutePath().normalize();
        if (data instanceof List<?> list)
            return legacy(list, base);
        if (!(data instanceof Map<?, ?> root))
            throw invalid("Recipe must be a legacy array or version 2 object.");
        keys(root, Set.of("version", "sources", "options", "select", "exclude"));
        if (!(root.get("version") instanceof Integer version) || version != 2)
            throw invalid("Object recipes require version: 2.");
        var sources = new ArrayList<MergeDefinition.Source>();
        for (Object value : list(root, "sources"))
            sources.add(new MergeDefinition.Source(sources.size(), path(value)));
        var queries = new ArrayList<MergeDefinition.Query>();
        for (Object value : list(root, "select")) {
            if (value instanceof String title)
                queries.add(new MergeDefinition.Query(null, null, InputSelection.title(title), null));
            else if (value instanceof Map<?, ?> item) {
                keys(item, Set.of("file", "path", "title", "titles", "slides", "range", "within", "skip_hidden",
                        "duplicate_titles"));
                Path file = file(item, false);
                InputSelection selection = selection(item);
                if (file == null && selection.kind() != InputSelection.Kind.TITLES)
                    throw invalid("Numeric selections require a file.");
                queries.add(new MergeDefinition.Query(null, file, selection, null));
            } else
                throw invalid("select entries must be titles or selection objects.");
        }
        var exclusions = new ArrayList<MergeDefinition.Exclusion>();
        for (Object value : list(root, "exclude")) {
            if (value instanceof String title)
                exclusions.add(MergeDefinition.Exclusion.global(InputSelection.title(text(title, "title"))));
            else if (value instanceof Map<?, ?> item) {
                var exclusion = exclusion(item);
                if (exclusion != null)
                    exclusions.add(exclusion);
            } else
                throw invalid("exclude entries must be titles or exclusion objects.");
        }
        Map<?, ?> options = root.containsKey("options") ? map(root.get("options"), "options") : Map.of();
        keys(options, Set.of("skip_hidden", "duplicate_titles", "duplicate_sources", "repeated_slides", "on_missing",
                "remaining", "overwrite", "on_missing_excluded_title"));
        return new MergeDefinition(base, null, sources, queries, exclusions,
                new MergeDefinition.Options(bool(options, "skip_hidden"),
                        policy(options, "duplicate_titles", DuplicateTitlePolicy.class),
                        policy(options, "duplicate_sources", DuplicateSourcePolicy.class),
                        policy(options, "repeated_slides", RepeatedSlidePolicy.class),
                        policy(options, "on_missing", MissingTitlePolicy.class),
                        policy(options, "remaining", RemainingSlides.class), bool(options, "overwrite"),
                        policy(options, "on_missing_excluded_title", MissingTitlePolicy.class)));
    }

    private MergeDefinition.Exclusion exclusion(Map<?, ?> item) {
        keys(item, Set.of("file", "path", "files", "directory", "directories", "title", "titles", "slides", "range",
                "all", "within"));
        for (String field : List.of("slides", "range", "within"))
            MergeDefinition.Exclusion.validateCandidates(item.get(field));
        List<String> scopes = List.of("file", "path", "files", "directory", "directories").stream()
                .filter(item::containsKey).toList();
        if (scopes.size() > 1)
            throw invalid("Each exclusion permits only one of file, path, files, directory, directories.");
        List<String> selectors = List.of("title", "titles", "slides", "range", "all").stream().filter(item::containsKey)
                .toList();
        if (selectors.size() != 1)
            throw invalid("Each exclusion requires exactly one of title, titles, slides, range, all.");
        String selector = selectors.get(0), scope = scopes.isEmpty() ? "global" : scopes.get(0);
        if (scope.equals("global") && !Set.of("title", "titles").contains(selector))
            throw invalid("Numeric and all-slide exclusions require an explicit file or directory scope.");
        if (item.containsKey("within") && !Set.of("title", "titles").contains(selector))
            throw invalid("within applies only to title exclusions.");
        List<Path> paths = switch (scope) {
            case "global" -> List.of();
            case "files", "directories" -> list(item, scope).stream().map(this::path).toList();
            default -> List.of(path(item.get(scope)));
        };
        InputSelection selected;
        if (selector.equals("all")) {
            if (!Boolean.TRUE.equals(item.get("all")))
                throw invalid("all must be true.");
            selected = InputSelection.all();
        } else if (selector.equals("titles") && list(item, "titles").isEmpty())
            return null;
        else
            selected = selection(item);
        if ((!scope.equals("global") && paths.isEmpty())
                || (selected.numbers() instanceof List<?> numbers && numbers.isEmpty()))
            return null;
        return switch (scope) {
            case "global" -> MergeDefinition.Exclusion.global(selected);
            case "directory", "directories" -> MergeDefinition.Exclusion.directories(paths, selected);
            case "file",
                    "path" ->
                selector.equals("all")
                        ? MergeDefinition.Exclusion.files(paths, selected)
                        : new MergeDefinition.Exclusion(paths.get(0), selected);
            default -> MergeDefinition.Exclusion.files(paths, selected);
        };
    }

    private MergeDefinition legacy(List<?> entries, Path base) {
        var resolver = new InputResolver(mapper);
        var sources = new ArrayList<MergeDefinition.Source>();
        var queries = new ArrayList<MergeDefinition.Query>();
        for (Object entry : entries) {
            var input = resolver.normalize(entry, base);
            int id = sources.size();
            sources.add(new MergeDefinition.Source(id, input.file()));
            queries.add(new MergeDefinition.Query(id, null,
                    InputSelection.numeric(input.slides()).skipHidden(input.skipHidden()), null));
        }
        var defaults = MergeDefinition.Options.defaults();
        return new MergeDefinition(base, null, sources, queries, List.of(),
                new MergeDefinition.Options(false, defaults.duplicateTitles(), defaults.duplicateSources(),
                        defaults.repeatedSlides(), defaults.onMissing(), RemainingSlides.NONE, true));
    }

    private InputSelection selection(Map<?, ?> item) {
        List<String> selectors = List.of("title", "titles", "slides", "range").stream().filter(item::containsKey)
                .toList();
        if (selectors.size() != 1)
            throw invalid("Each selection requires exactly one of title, titles, slides, range.");
        String key = selectors.get(0);
        Object value = item.get(key);
        InputSelection result;
        if (key.equals("title"))
            result = InputSelection.title(text(value, "title"));
        else if (key.equals("titles")) {
            if (!(value instanceof List<?> values))
                throw invalid("titles must be an array.");
            result = InputSelection.titles(values.stream().map(v -> text(v, "title")).toList());
        } else
            result = InputSelection.numeric(value);
        if (item.containsKey("within"))
            result = result.withinSelection(item.get("within"));
        if (item.containsKey("skip_hidden"))
            result = result.skipHidden(bool(item, "skip_hidden"));
        if (item.containsKey("duplicate_titles"))
            result = result.duplicateTitles(policy(item, "duplicate_titles", DuplicateTitlePolicy.class));
        return result;
    }

    private Path file(Map<?, ?> item, boolean required) {
        if (item.containsKey("file") && item.containsKey("path"))
            throw invalid("Use file or path, not both.");
        Object value = item.containsKey("file") ? item.get("file") : item.get("path");
        if (value == null && !required)
            return null;
        return path(value);
    }

    private Path path(Object value) {
        try {
            return Path.of(text(value, "path").replace('\\', '/'));
        } catch (InvalidPathException e) {
            throw invalid("Invalid file path.");
        }
    }

    private String text(Object value, String label) {
        if (!(value instanceof String text) || text.isBlank())
            throw invalid(label + " must be a nonblank string.");
        return text;
    }

    private List<?> list(Map<?, ?> map, String key) {
        if (!map.containsKey(key))
            return List.of();
        if (!(map.get(key) instanceof List<?> list))
            throw invalid(key + " must be an array.");
        return list;
    }

    private Map<?, ?> map(Object value, String name) {
        if (!(value instanceof Map<?, ?> map))
            throw invalid(name + " must be an object.");
        return map;
    }

    private Boolean bool(Map<?, ?> map, String key) {
        if (!map.containsKey(key))
            return null;
        if (!(map.get(key) instanceof Boolean value))
            throw invalid(key + " must be a boolean.");
        return value;
    }

    private <E extends Enum<E>> E policy(Map<?, ?> map, String key, Class<E> type) {
        if (!map.containsKey(key))
            return null;
        String value = text(map.get(key), key);
        try {
            return Enum.valueOf(type, value.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw invalid("Invalid " + key + ": " + value);
        }
    }

    private void keys(Map<?, ?> map, Set<String> allowed) {
        for (Object key : map.keySet())
            if (!allowed.contains(key))
                throw invalid("Unknown recipe field: " + key);
    }

    private MergeException invalid(String message) {
        return failure(ErrorCode.INVALID_REQUEST, DiagnosticCode.INVALID_RECIPE, message, null);
    }

    private MergeException failure(ErrorCode code, DiagnosticCode detail, String message, Throwable cause) {
        return new MergeException(code, detail, MergeStage.VALIDATION, message, cause, null, List.of());
    }
}
