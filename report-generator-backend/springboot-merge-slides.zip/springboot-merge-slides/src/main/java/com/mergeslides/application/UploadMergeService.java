package com.mergeslides.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import com.mergeslides.api.lib.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.infrastructure.input.RecipeCodec;
import com.mergeslides.infrastructure.ooxml.*;

/** Owns temporary-file lifecycle; the MVC adapter supplies uploaded streams. */
public final class UploadMergeService {
    public record Upload(String filename, InputStream stream) {
    }

    public record PreparedDownload(Path directory, MergeResult result) implements AutoCloseable {
        @Override
        public synchronized void close() throws IOException {
            if (!Files.exists(directory))
                return;
            try (var files = Files.walk(directory)) {
                for (Path p : files.sorted(Comparator.reverseOrder()).toList())
                    Files.deleteIfExists(p);
            } catch (NoSuchFileException ignored) {
                /* Already cleaned by the streaming/completion callback. */
            }
        }
    }

    private final MergeService service;
    private final InputResolver resolver;
    private final ObjectMapper mapper;
    private final Path temp;

    public UploadMergeService(MergeService service, InputResolver resolver, ObjectMapper mapper, Path temp) {
        this.service = service;
        this.resolver = resolver;
        this.mapper = mapper;
        this.temp = temp;
    }

    public PreparedDownload prepare(List<Upload> uploads, String recipe) throws IOException {
        if (uploads.isEmpty())
            throw MergeException.invalid("Upload at least one PPTX file.");
        Files.createDirectories(temp);
        Path dir = Files.createTempDirectory(temp, "pptx-upload-");
        var cleanup = new PreparedDownload(dir, null);
        try {
            var paths = new LinkedHashSet<Path>();
            for (var upload : uploads) {
                String name = upload.filename();
                if (name == null || name.isBlank() || name.contains("/") || name.contains("\\")
                        || !name.toLowerCase(Locale.ROOT).endsWith(".pptx"))
                    throw MergeException.invalid("Each upload needs a plain .pptx filename.");
                Path file = dir.resolve(name).normalize();
                if (!paths.add(file)
                        || paths.stream().filter(p -> p.getFileName().toString().equalsIgnoreCase(name)).count() > 1)
                    throw MergeException.invalid("Uploaded filenames must be unique: " + name);
                Files.copy(upload.stream(), file);
            }
            Path output = dir.resolve("merged.pptx");
            if (paths.contains(output))
                output = dir.resolve(UUID.randomUUID() + ".pptx");
            // Every supplied input must be valid, even when a recipe does not select it.
            var reader = new PackageReader(new PackageValidator());
            for (Path file : paths)
                reader.read(file);
            List<InputSpec> specs;
            if (recipe == null || recipe.isBlank())
                specs = paths.stream().map(InputSpec::new).toList();
            else {
                Object data;
                data = new RecipeCodec().parse(recipe);
                if (data instanceof Map<?, ?>) {
                    var definition = new RecipeCodec().decode(data, dir);
                    for (var source : definition.sources())
                        uploaded(source.path(), paths, dir);
                    for (var query : definition.queries())
                        if (query.file() != null)
                            uploaded(query.file(), paths, dir);
                    for (var exclusion : definition.exclusions()) {
                        if (exclusion.scope() == MergeDefinition.ExclusionScope.DIRECTORIES)
                            throw MergeException.invalid("Upload exclusions cannot reference directories.");
                        for (Path file : exclusion.paths())
                            uploaded(file, paths, dir);
                    }
                    var sources = definition.sources();
                    if (sources.isEmpty()) {
                        var all = new ArrayList<MergeDefinition.Source>();
                        for (Path file : paths)
                            all.add(new MergeDefinition.Source(all.size(), file));
                        sources = all;
                    }
                    var effective = new MergeDefinition(dir, output, sources, definition.queries(),
                            definition.exclusions(), definition.options());
                    return new PreparedDownload(dir,
                            MergeJob.fromDefinition(effective, MergeReporter.silent()).merge());
                }
                if (!(data instanceof List<?> items))
                    throw MergeException.invalid("Upload recipe must be a top-level list.");
                specs = new ArrayList<>();
                for (Object item : items) {
                    var spec = resolver.normalize(item, dir);
                    if (!paths.contains(spec.file()))
                        throw MergeException.invalid(
                                "Upload recipe must reference an uploaded filename: " + spec.file().getFileName());
                    specs.add(spec);
                }
            }
            return new PreparedDownload(dir, service.merge(specs, output));
        } catch (Exception e) {
            try {
                cleanup.close();
            } catch (IOException close) {
                e.addSuppressed(close);
            }
            throw e;
        }
    }

    private void uploaded(Path file, Set<Path> paths, Path directory) {
        if (file.isAbsolute() || file.getNameCount() != 1 || !paths.contains(directory.resolve(file).normalize()))
            throw MergeException.invalid("Upload recipes may reference only plain uploaded filenames.");
    }
}
