package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.domain.*;
import java.nio.file.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.*;
import java.util.function.Consumer;
import com.mergeslides.api.lib.*;

public final class AtomicPackageWriter {
    private final PackageReader reader;

    public AtomicPackageWriter(PackageReader reader) {
        this.reader = reader;
    }

    public void write(Map<String, byte[]> parts, Path output) {
        write(parts, output, true, message -> {
        });
    }

    /** Validated staging is committed using a create-only or replacement strategy. */
    public void write(Map<String, byte[]> parts, Path output, boolean overwrite, Consumer<String> cleanupWarning) {
        Path staging = null;
        boolean committed = false;
        try {
            Files.createDirectories(output.toAbsolutePath().getParent());
            staging = Files.createTempFile(output.toAbsolutePath().getParent(), Ooxml.TEMP_PREFIX, ".tmp");
            try (var zip = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(staging)))) {
                for (var entry : new TreeMap<>(parts).entrySet()) {
                    var member = new ZipEntry(entry.getKey());
                    member.setTimeLocal(LocalDateTime.of(1980, 1, 1, 0, 0));
                    zip.putNextEntry(member);
                    zip.write(entry.getValue());
                    zip.closeEntry();
                }
            }
            try {
                reader.read(staging);
            } catch (MergeException error) {
                throw failure(DiagnosticCode.OUTPUT_VALIDATION_FAILED, "Staged output failed validation.", error);
            }
            (overwrite ? CommitStrategy.REPLACE : CommitStrategy.CREATE_ONLY).commit(staging, output);
            committed = true;
        } catch (FileAlreadyExistsException e) {
            throw new MergeException(ErrorCode.INVALID_REQUEST, DiagnosticCode.OUTPUT_EXISTS, MergeStage.WRITE,
                    "Destination already exists: " + output, e, null, List.of());
        } catch (UnsupportedOperationException | AtomicMoveNotSupportedException e) {
            throw failure(DiagnosticCode.OUTPUT_COMMIT_UNSUPPORTED,
                    "Filesystem does not support the requested safe output commit: " + output, e);
        } catch (IOException e) {
            throw failure(DiagnosticCode.OUTPUT_WRITE_FAILED,
                    "Cannot safely write output " + output + ": " + e.getMessage(), e);
        } finally {
            if (staging != null)
                try {
                    Files.deleteIfExists(staging);
                } catch (IOException ignored) {
                    if (committed)
                        cleanupWarning.accept(
                                "Merged output was committed, but its temporary staging link could not be removed.");
                }
        }
    }

    private MergeException failure(DiagnosticCode code, String message, Throwable cause) {
        return new MergeException(ErrorCode.IO_FAILURE, code, MergeStage.WRITE, message, cause, null, List.of());
    }

    private enum CommitStrategy {
        REPLACE {
            void commit(Path staging, Path output) throws IOException {
                Files.move(staging, output, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            }
        },
        CREATE_ONLY {
            void commit(Path staging, Path output) throws IOException {
                // Unlike ATOMIC_MOVE, createLink cannot replace an existing directory entry.
                Files.createLink(output, staging);
            }
        };

        abstract void commit(Path staging, Path output) throws IOException;
    }
}
