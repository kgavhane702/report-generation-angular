package com.mergeslides.api;

import jakarta.servlet.http.*;
import org.springframework.web.ErrorResponse;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.*;

/** Route scope also covers multipart parsing and mapping errors with no selected handler. */
public final class MergeRouteExceptionResolver implements HandlerExceptionResolver {
    private final ApiExceptionHandler advice = new ApiExceptionHandler();

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception error) {
        String route = request.getRequestURI().substring(request.getContextPath().length());
        if (!(route.equals("/api/v1/merges") || route.equals("/api/v1/merges/upload")) || handler != null
                || !(error instanceof ErrorResponse http))
            return null;
        try {
            var result = advice.handleExceptionInternal(error, null, http.getHeaders(), http.getStatusCode(),
                    new ServletWebRequest(request, response));
            if (result != null) {
                response.setStatus(result.getStatusCode().value());
                result.getHeaders().forEach((key, values) -> values.forEach(value -> response.addHeader(key, value)));
                response.setContentType("application/json");
                new com.fasterxml.jackson.databind.ObjectMapper().writeValue(response.getOutputStream(),
                        result.getBody());
            }
            return new ModelAndView();
        } catch (java.io.IOException delivery) {
            error.addSuppressed(delivery);
            org.slf4j.LoggerFactory.getLogger(MergeRouteExceptionResolver.class).warn("Cannot deliver merge HTTP error",
                    error);
            return new ModelAndView();
        }
    }
}
