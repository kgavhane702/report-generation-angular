package com.mergeslides.api.lib;

import java.time.Instant;

public record MergeEvent(String operationId, Type type, Severity severity, MergeStage stage, String message,
        MergeDiagnostic diagnostic, Throwable cause, Instant timestamp) {
    public enum Type {
        STARTED, PROGRESS, DIAGNOSTIC, COMPLETED, FAILED
    }

    public String code() {
        return diagnostic == null ? type.name() : diagnostic.code().name();
    }
}
