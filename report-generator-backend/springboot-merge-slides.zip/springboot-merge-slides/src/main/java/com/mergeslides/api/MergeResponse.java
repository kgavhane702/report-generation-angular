package com.mergeslides.api;

import com.mergeslides.domain.MergeResult;
import java.util.List;

public record MergeResponse(String outputPath, int slideCount, List<String> warnings, long elapsedMillis) {
    public static MergeResponse from(MergeResult result) {
        return new MergeResponse(result.outputPath().toString(), result.slideCount(), result.warnings(),
                result.elapsedMillis());
    }
}
