package com.mergeslides.api;

import jakarta.validation.constraints.NotBlank;
import java.util.List;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonAnySetter;

public record MergeRequest(List<Object> inputs, String recipePath, @NotBlank String output, Object recipe) {
    public MergeRequest(List<Object> inputs, String recipePath, String output) {
        this(inputs, recipePath, output, null);
    }

    @JsonAnySetter
    public void unknown(String name, Object value) {
        if (Set.of("exclude", "select", "sources", "options", "version").contains(name))
            throw new MisplacedRecipeControl(name);
    }

    public static final class MisplacedRecipeControl extends IllegalArgumentException {
        public MisplacedRecipeControl(String name) {
            super("Place '" + name + "' inside the nested version 2 recipe object.");
        }
    }
}
