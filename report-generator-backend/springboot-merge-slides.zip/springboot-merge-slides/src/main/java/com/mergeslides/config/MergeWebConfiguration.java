package com.mergeslides.config;

import com.fasterxml.jackson.core.JsonParser;
import com.mergeslides.api.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.HandlerExceptionResolver;
import java.util.List;

/** Adapter-local JSON policy and errors raised before a controller is selected. */
@Configuration(proxyBeanMethods = false)
public class MergeWebConfiguration implements WebMvcConfigurer {
    @Override
    public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
        for (var converter : converters)
            if (converter instanceof MappingJackson2HttpMessageConverter jackson)
                jackson.registerObjectMappersForType(MergeRequest.class, mappings -> mappings.put(
                        org.springframework.http.MediaType.APPLICATION_JSON,
                        jackson.getObjectMapper().copy().enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION)));
    }

    @Override
    public void extendHandlerExceptionResolvers(List<HandlerExceptionResolver> resolvers) {
        resolvers.add(0, new MergeRouteExceptionResolver());
    }
}
