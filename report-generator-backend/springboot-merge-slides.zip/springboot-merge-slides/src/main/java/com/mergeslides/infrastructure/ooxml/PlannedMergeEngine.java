package com.mergeslides.infrastructure.ooxml;

import com.mergeslides.api.lib.*;
import com.mergeslides.api.lib.internal.MergeDefinition;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.*;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import static com.mergeslides.api.lib.DiagnosticCode.*;

/** Per-invocation planner. PresentationAssembler and GraphImporter remain unchanged. */
public final class PlannedMergeEngine {
    private final PackageReader reader = new PackageReader(new PackageValidator());
    private final RecipeCodec codec = new RecipeCodec();
    private final SlideTitleReader titles = new SlideTitleReader();

    public MergePlan plan(MergeDefinition definition, String operationId) {
        Context context = new Context(operationId, MergeReporter.silent(), false);
        try {
            MergeDefinition root = root(definition, new HashSet<>());
            context.output = root.output() == null ? null : absolute(root.baseDirectory(), root.output());
            Prepared prepared = prepare(root, context, new HashSet<>());
            requireSequence(prepared.rows);
            return preview(prepared.rows, context);
        } catch (RuntimeException error) {
            throw context.failure(error);
        }
    }

    public MergeReport merge(MergeDefinition definition, MergeReporter reporter, String operationId) {
        Context context = new Context(operationId, reporter, true);
        long started = System.nanoTime();
        context.event(MergeEvent.Type.STARTED, Severity.INFO, MergeStage.VALIDATION, "Merge started", null, null);
        try {
            MergeDefinition root = root(definition, new HashSet<>());
            if (root.output() == null)
                throw fail(INVALID_REQUEST, MergeStage.VALIDATION, "An output path is required for merge.");
            Path output = absolute(root.baseDirectory(), root.output());
            if (!output.toString().toLowerCase(Locale.ROOT).endsWith(".pptx"))
                throw fail(INVALID_REQUEST, MergeStage.VALIDATION, "Output must use the .pptx extension.");
            boolean overwrite = root.options().orElse(MergeDefinition.Options.defaults()).overwrite();
            if (!overwrite && Files.exists(output, LinkOption.NOFOLLOW_LINKS))
                throw fail(OUTPUT_EXISTS, MergeStage.WRITE, "Destination already exists: " + output);
            context.output = output;
            Prepared prepared = prepare(root, context, new HashSet<>());
            requireSequence(prepared.rows);
            context.stage = MergeStage.ASSEMBLY;
            List<MergeContext.Occurrence> sequence = prepared.rows.stream()
                    .map(r -> new MergeContext.Occurrence(r.source.document, r.source.document.slides.get(r.index)))
                    .toList();
            Set<PackageDocument> contributors = new HashSet<>();
            for (Row row : prepared.rows)
                contributors.add(row.source.document);
            List<PackageDocument> templates = context.loaded.values().stream()
                    .filter(document -> !context.nonLegacyExclusionMatched || contributors.contains(document)).toList();
            var merge = new MergeContext(templates, sequence);
            Map<String, byte[]> parts = new PresentationAssembler(merge).build();
            for (String warning : new LinkedHashSet<>(merge.warnings))
                context.warn(warning.contains("source slide size differs") ? MIXED_SLIDE_SIZE : OMITTED_SLIDE_LINK,
                        MergeStage.ASSEMBLY, warning, null, null, null, Map.of());
            context.stage = MergeStage.WRITE;
            new AtomicPackageWriter(reader).write(parts, output, overwrite, message -> context.warn(TEMP_CLEANUP_FAILED,
                    MergeStage.WRITE, message, null, null, null, Map.of()));
            long elapsed = (System.nanoTime() - started) / 1_000_000;
            context.event(MergeEvent.Type.COMPLETED, Severity.INFO, MergeStage.WRITE,
                    "Merged " + sequence.size() + " slides in " + elapsed + " ms", null, null);
            MergePlan plan = preview(prepared.rows, context);
            var result = new MergeResult(output, sequence.size(), context.diagnostics.stream()
                    .filter(d -> d.severity() == Severity.WARN).map(MergeDiagnostic::message).toList(), elapsed);
            return new MergeReport(result, operationId, context.diagnostics, plan.summary(), plan.slides());
        } catch (RuntimeException error) {
            throw context.failure(error);
        }
    }

    private MergeDefinition root(MergeDefinition definition, Set<Path> recipes) {
        if (definition.sources().isEmpty() && definition.exclusions().isEmpty() && definition.queries().size() == 1
                && definition.queries().get(0).recipe() != null) {
            Path path = absolute(definition.baseDirectory(), definition.queries().get(0).recipe());
            if (!recipes.add(path))
                throw fail(INVALID_RECIPE, MergeStage.VALIDATION, "Recursive recipe: " + path);
            MergeDefinition child = root(codec.read(path), recipes);
            return new MergeDefinition(child.baseDirectory(),
                    definition.output() == null ? null : absolute(definition.baseDirectory(), definition.output()),
                    child.sources(), child.queries(), child.exclusions(), definition.options().orElse(child.options()));
        }
        return definition;
    }

    private Prepared prepare(MergeDefinition definition, Context context, Set<Path> recipeStack) {
        context.stage = MergeStage.DISCOVERY;
        int catalogueStart = context.catalogue.size();
        var options = definition.options().orElse(MergeDefinition.Options.defaults());
        var sources = new ArrayList<Source>();
        var registrations = new HashMap<Integer, List<Source>>();
        for (var entry : definition.sources())
            registrations.put(entry.registration(),
                    register(entry.path(), definition.baseDirectory(), sources, options, context));
        for (var query : definition.queries())
            if (query.file() != null) {
                Path file = canonical(absolute(definition.baseDirectory(), query.file()));
                if (sources.stream().noneMatch(s -> same(s.document.path, file)))
                    register(file, definition.baseDirectory(), sources, options, context);
            }
        if (sources.isEmpty() && definition.queries().stream().noneMatch(q -> q.recipe() != null))
            throw fail(INVALID_REQUEST, MergeStage.DISCOVERY, "No input PPTX sources provided.");
        var recipePlans = new IdentityHashMap<MergeDefinition.Query, Prepared>();
        for (var query : definition.queries())
            if (query.recipe() != null) {
                Path recipe = absolute(definition.baseDirectory(), query.recipe());
                if (!recipeStack.add(recipe))
                    throw fail(INVALID_RECIPE, MergeStage.SELECTION, "Recursive recipe: " + recipe);
                recipePlans.put(query, prepare(codec.read(recipe), context, recipeStack));
                recipeStack.remove(recipe);
            }
        List<Source> exclusionScope = new ArrayList<>(
                context.catalogue.subList(catalogueStart, context.catalogue.size()));
        Set<Physical> excluded = new HashSet<>(), intentional = new HashSet<>();
        for (var exclusion : definition.exclusions()) {
            List<Source> matching = exclusionSources(exclusion, definition.baseDirectory(), exclusionScope);
            Set<Physical> resolved = resolveExclusion(exclusion, matching, options, context);
            excluded.addAll(resolved);
            if (!exclusion.legacyNumeric()) {
                intentional.addAll(resolved);
                if (!resolved.isEmpty())
                    context.nonLegacyExclusionMatched = true;
            }
        }
        for (Source source : exclusionScope)
            for (int i = 0; i < source.document.slides.size(); i++)
                if (excluded.contains(new Physical(source.document.path, i)))
                    context.excluded.add(new Key(source.id, i));
        var selected = new ArrayList<Row>();
        Set<Key> handled = new HashSet<>(), suppressed = new HashSet<>();
        context.stage = MergeStage.SELECTION;
        if (definition.queries().isEmpty()) {
            for (Source source : sources)
                numeric(List.of(source), InputSelection.all(), options, excluded, suppressed, handled, selected,
                        context);
        } else
            for (var query : definition.queries()) {
                if (query.recipe() != null) {
                    selected.addAll(recipePlans.get(query).rows);
                    continue;
                }
                List<Source> scope;
                if (query.registration() != null)
                    scope = registrations.getOrDefault(query.registration(), List.of());
                else if (query.file() != null) {
                    Path file = canonical(absolute(definition.baseDirectory(), query.file()));
                    scope = sources.stream().filter(s -> same(s.document.path, file)).toList();
                } else
                    scope = sources;
                if (query.registration() != null && scope.isEmpty())
                    continue; // Explicitly skipped duplicate input, not a missing title.
                if (query.selection().kind() == InputSelection.Kind.TITLES)
                    title(scope, query.selection(), options, excluded, intentional, suppressed, handled, selected,
                            context);
                else
                    numeric(scope, query.selection(), options, excluded, suppressed, handled, selected, context);
            }
        var remaining = new ArrayList<Row>();
        if (!definition.queries().isEmpty() && options.remaining() != RemainingSlides.NONE) {
            for (Source source : sources)
                for (int i = 0; i < source.document.slides.size(); i++) {
                    Key key = new Key(source.id, i);
                    if (handled.contains(key) || suppressed.contains(key)
                            || excluded.contains(new Physical(source.document.path, i)))
                        continue;
                    if (options.skipHidden() && hidden(source, i)) {
                        context.hidden.add(key);
                        continue;
                    }
                    remaining.add(new Row(source, i, PlannedSlide.Origin.REMAINING, null));
                }
        }
        var sequence = new ArrayList<Row>();
        if (options.remaining() == RemainingSlides.START)
            sequence.addAll(remaining);
        sequence.addAll(selected);
        if (options.remaining() != RemainingSlides.START)
            sequence.addAll(remaining);
        var seen = new HashSet<Physical>();
        var filtered = new ArrayList<Row>();
        for (Row row : sequence) {
            if (excluded.contains(new Physical(row.source.document.path, row.index))) {
                context.excluded.add(new Key(row.source.id, row.index));
                continue;
            }
            if (!seen.add(new Physical(row.source.document.path, row.index))
                    && options.repeatedSlides() != RepeatedSlidePolicy.ALLOW) {
                if (options.repeatedSlides() == RepeatedSlidePolicy.ERROR)
                    throw failAt(REPEATED_SLIDE, MergeStage.SELECTION,
                            "Repeated slide: " + row.source.document.path + ":" + (row.index + 1),
                            row.source.document.path.toString(), row.index + 1, row.selector, Map.of());
                context.duplicateFiltered++;
                continue;
            }
            filtered.add(row);
        }
        return new Prepared(filtered);
    }

    private List<Source> exclusionSources(MergeDefinition.Exclusion rule, Path base, List<Source> catalogue) {
        if (rule.scope() == MergeDefinition.ExclusionScope.GLOBAL)
            return catalogue;
        var matching = new LinkedHashSet<Source>();
        for (Path entry : rule.paths()) {
            Path path = absolute(base, entry);
            boolean directory = rule.scope() == MergeDefinition.ExclusionScope.DIRECTORIES;
            if (directory && !Files.isDirectory(path))
                throw failAt(SOURCE_NOT_FOUND, MergeStage.DISCOVERY, "Excluded directory not found: " + path,
                        path.toString(), null, null, Map.of());
            Path target;
            try {
                target = directory ? path.toRealPath() : canonical(path);
            } catch (IOException error) {
                throw failure(ErrorCode.IO_FAILURE, SOURCE_UNREADABLE, MergeStage.DISCOVERY,
                        "Cannot inspect excluded directory: " + path, error);
            }
            List<Path> members = List.of(target);
            if (directory) {
                try (var entries = Files.list(target)) {
                    members = entries.filter(Files::isRegularFile)
                            .filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pptx"))
                            .filter(p -> !p.getFileName().toString().startsWith("~$")).toList();
                } catch (IOException error) {
                    throw failure(ErrorCode.IO_FAILURE, SOURCE_UNREADABLE, MergeStage.DISCOVERY,
                            "Cannot inspect excluded directory: " + path, error);
                }
            }
            List<Path> candidates = members;
            List<Source> scoped = catalogue.stream()
                    .filter(s -> candidates.stream().anyMatch(p -> same(s.document.path, p))).toList();
            if (scoped.isEmpty())
                throw fail(INVALID_SELECTION, MergeStage.SELECTION, "Excluded "
                        + (directory ? "directory has no registered sources: " : "file is not a source: ") + path);
            matching.addAll(scoped);
        }
        return new ArrayList<>(matching);
    }

    private Set<Physical> resolveExclusion(MergeDefinition.Exclusion rule, List<Source> scope,
            MergeDefinition.Options options, Context context) {
        Set<Physical> resolved = new HashSet<>();
        InputSelection selection = rule.selection();
        if (selection.kind() != InputSelection.Kind.TITLES) {
            for (Source source : scope)
                for (int index : indices(selection.numbers(), source))
                    resolved.add(new Physical(source.document.path, index));
            return resolved;
        }
        // Hard exclusions deliberately ignore hidden and duplicate-placement overrides.
        for (String requested : selection.titles()) {
            boolean found = false;
            for (Source source : scope) {
                Set<Integer> within = selection.within() == null
                        ? null
                        : new HashSet<>(indices(selection.within(), source));
                for (int index = 0; index < source.document.slides.size(); index++) {
                    if (within != null && !within.contains(index))
                        continue;
                    String actual = title(source, index, context);
                    if (actual != null && actual.equalsIgnoreCase(requested)) {
                        found = true;
                        resolved.add(new Physical(source.document.path, index));
                    }
                }
            }
            if (!found) {
                String location = scope.size() == 1 ? scope.get(0).document.path.toString() : null;
                Map<String, String> details = Map.of("title", requested, "scope", rule.scope().name(), "paths",
                        rule.paths().toString());
                String message = "Excluded title \"" + requested + "\" was not found in its requested scope.";
                if (options.onMissingExcludedTitle() == MissingTitlePolicy.ERROR)
                    throw failAt(EXCLUDED_TITLE_NOT_FOUND, MergeStage.SELECTION, message, location, null, null,
                            details);
                context.missing++;
                context.warn(EXCLUDED_TITLE_NOT_FOUND, MergeStage.SELECTION, message + " Exclusion skipped.", location,
                        null, null, details);
            }
        }
        return resolved;
    }

    private void numeric(List<Source> scope, InputSelection selection, MergeDefinition.Options options,
            Set<Physical> excluded, Set<Key> suppressed, Set<Key> handled, List<Row> selected, Context context) {
        int selector = ++context.selector;
        for (Source source : scope)
            for (int index : indices(selection.numbers(), source))
                if (eligible(source, index, selection, options, excluded, suppressed, context))
                    emit(selected, handled, source, index, selector);
        context.event(MergeEvent.Type.PROGRESS, Severity.DEBUG, MergeStage.SELECTION, "Resolved selection " + selector,
                null, null);
    }

    private void title(List<Source> scope, InputSelection selection, MergeDefinition.Options options,
            Set<Physical> excluded, Set<Physical> intentional, Set<Key> suppressed, Set<Key> handled,
            List<Row> selected, Context context) {
        for (String requested : selection.titles()) {
            int selector = ++context.selector, raw = 0, hardRemoved = 0, intentionallyRemoved = 0;
            var matches = new ArrayList<Row>();
            for (Source source : scope) {
                Set<Integer> within = selection.within() == null
                        ? null
                        : new HashSet<>(indices(selection.within(), source));
                for (int index = 0; index < source.document.slides.size(); index++) {
                    if (within != null && !within.contains(index))
                        continue;
                    String actual = title(source, index, context);
                    if (actual == null || !actual.equalsIgnoreCase(requested))
                        continue;
                    raw++;
                    Physical physical = new Physical(source.document.path, index);
                    if (excluded.contains(physical))
                        hardRemoved++;
                    if (intentional.contains(physical))
                        intentionallyRemoved++;
                    if (eligible(source, index, selection, options, excluded, suppressed, context))
                        matches.add(new Row(source, index, PlannedSlide.Origin.SELECTED, selector));
                }
            }
            if (matches.isEmpty()) {
                if (raw > 0 && hardRemoved == raw && intentionallyRemoved > 0)
                    continue;
                DiagnosticCode code = raw == 0 ? TITLE_NOT_FOUND : TITLE_NO_ELIGIBLE_MATCH;
                String message = "Selection " + selector + ": title \"" + requested + "\" "
                        + (raw == 0
                                ? "was not found in the requested sources/candidates"
                                : "has only hidden or excluded matches")
                        + "; request skipped.";
                if (options.onMissing() == MissingTitlePolicy.ERROR)
                    throw failAt(code, MergeStage.SELECTION, message,
                            scope.size() == 1 ? scope.get(0).document.path.toString() : null, null, selector,
                            Map.of("title", requested));
                context.missing++;
                context.warn(code, MergeStage.SELECTION, message,
                        scope.size() == 1 ? scope.get(0).document.path.toString() : null, null, selector,
                        Map.of("title", requested));
                continue;
            }
            DuplicateTitlePolicy policy = selection.duplicateOverride() == null
                    ? options.duplicateTitles()
                    : selection.duplicateOverride();
            if (matches.size() > 1 && policy == DuplicateTitlePolicy.ERROR)
                throw failAt(DUPLICATE_TITLE, MergeStage.SELECTION,
                        "Selection " + selector + ": multiple matches for title \"" + requested + "\".", null, null,
                        selector, Map.of("title", requested, "matches", Integer.toString(matches.size())));
            List<Row> chosen = switch (policy) {
                case FIRST -> List.of(matches.get(0));
                case LAST -> List.of(matches.get(matches.size() - 1));
                default -> matches;
            };
            for (Row row : chosen)
                emit(selected, handled, row.source, row.index, selector);
        }
    }

    private boolean eligible(Source source, int index, InputSelection selection, MergeDefinition.Options options,
            Set<Physical> excluded, Set<Key> suppressed, Context context) {
        if (excluded.contains(new Physical(source.document.path, index)))
            return false;
        boolean skip = selection.skipHiddenOverride() == null ? options.skipHidden() : selection.skipHiddenOverride();
        if (skip && hidden(source, index)) {
            Key key = new Key(source.id, index);
            suppressed.add(key);
            context.hidden.add(key);
            return false;
        }
        return true;
    }

    private void emit(List<Row> rows, Set<Key> handled, Source source, int index, int selector) {
        rows.add(new Row(source, index, PlannedSlide.Origin.SELECTED, selector));
        handled.add(new Key(source.id, index));
    }

    private List<Integer> indices(Object selection, Source source) {
        try {
            return SlideSelector.select(selection, source.document.slides.size());
        } catch (MergeException e) {
            throw failAt(INVALID_SELECTION, MergeStage.SELECTION, source.document.path + ": " + e.getMessage(),
                    source.document.path.toString(), null, null, Map.of());
        }
    }

    private List<Source> register(Path input, Path base, List<Source> sources, MergeDefinition.Options options,
            Context context) {
        Path path = absolute(base, input);
        var added = new ArrayList<Source>();
        if (Files.isDirectory(path)) {
            List<Path> files;
            try (var stream = Files.list(path)) {
                files = stream.filter(Files::isRegularFile)
                        .filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pptx"))
                        .filter(p -> !p.getFileName().toString().startsWith("~$"))
                        .filter(p -> context.output == null || !same(p, context.output))
                        .sorted((a, b) -> NaturalOrder.INSTANCE.compare(a.getFileName().toString(),
                                b.getFileName().toString()))
                        .toList();
            } catch (IOException e) {
                throw failure(ErrorCode.IO_FAILURE, SOURCE_UNREADABLE, MergeStage.DISCOVERY,
                        "Cannot read directory: " + path, e);
            }
            if (files.isEmpty())
                throw fail(DIRECTORY_EMPTY, MergeStage.DISCOVERY, "No usable PPTX files in directory: " + path);
            for (Path file : files)
                added.addAll(register(file, base, sources, options, context));
            return added;
        }
        Path real = canonical(path);
        if (!path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pptx"))
            throw fail(INVALID_PRESENTATION, MergeStage.READ, "Only .pptx inputs are supported: " + path);
        if (context.output != null && same(real, context.output))
            throw fail(OUTPUT_IS_SOURCE, MergeStage.VALIDATION, "Output cannot overwrite an input: " + path);
        if (sources.stream().anyMatch(s -> same(s.document.path, real))
                && options.duplicateSources() != DuplicateSourcePolicy.ALLOW) {
            if (options.duplicateSources() == DuplicateSourcePolicy.ERROR)
                throw fail(DUPLICATE_SOURCE, MergeStage.DISCOVERY, "Repeated source: " + path);
            return added;
        }
        PackageDocument document = context.loaded.values().stream().filter(d -> same(d.path, real)).findFirst()
                .orElse(null);
        if (document == null) {
            context.stage = MergeStage.READ;
            try {
                document = reader.read(real);
            } catch (MergeException error) {
                var detail = new MergeDiagnostic(error.failureCode(), Severity.ERROR, MergeStage.READ, null,
                        error.getMessage(), real.toString(), null, null, Map.of());
                throw new MergeException(error.code(), error.failureCode(), MergeStage.READ, error.getMessage(), error,
                        null, List.of(detail));
            }
            context.loaded.put(real, document);
        }
        Source source = new Source(++context.occurrence, document);
        sources.add(source);
        added.add(source);
        context.catalogue.add(source);
        context.event(MergeEvent.Type.PROGRESS, Severity.DEBUG, MergeStage.READ,
                "Validated source occurrence " + source.id + ": " + path, null, null);
        return added;
    }

    private String title(Source source, int index, Context context) {
        Physical key = new Physical(source.document.path, index);
        if (!context.titles.containsKey(key))
            context.titles.put(key, titles.title(source.document, index));
        return context.titles.get(key);
    }

    private boolean hidden(Source source, int index) {
        return Xml.hidden(source.document.slideXml(index));
    }

    private MergePlan preview(List<Row> rows, Context context) {
        var slides = new ArrayList<PlannedSlide>();
        var emitted = new HashSet<Key>();
        int selected = 0;
        for (Row row : rows) {
            emitted.add(new Key(row.source.id, row.index));
            if (row.origin == PlannedSlide.Origin.SELECTED)
                selected++;
            slides.add(new PlannedSlide(slides.size() + 1, row.source.document.path, row.source.id, row.index + 1,
                    title(row.source, row.index, context), hidden(row.source, row.index), row.origin, row.selector));
        }
        var hidden = new HashSet<>(context.hidden);
        hidden.removeAll(emitted);
        return new MergePlan(context.id, slides, context.diagnostics,
                new MergeSummary(context.occurrence, selected, rows.size() - selected, hidden.size(),
                        context.excluded.size(), context.duplicateFiltered, context.missing));
    }

    private Path canonical(Path path) {
        if (!Files.isRegularFile(path))
            throw failAt(SOURCE_NOT_FOUND, MergeStage.DISCOVERY, "Input file not found: " + path, path.toString(), null,
                    null, Map.of());
        try {
            return path.toRealPath();
        } catch (IOException e) {
            throw failure(ErrorCode.IO_FAILURE, SOURCE_UNREADABLE, MergeStage.READ, "Cannot inspect source: " + path,
                    e);
        }
    }

    private static Path absolute(Path base, Path path) {
        return base.resolve(path).toAbsolutePath().normalize();
    }

    private static boolean same(Path a, Path b) {
        if (a.toAbsolutePath().normalize().equals(b.toAbsolutePath().normalize()))
            return true;
        try {
            return Files.exists(a) && Files.exists(b) && Files.isSameFile(a, b);
        } catch (IOException ignored) {
            return false;
        }
    }

    private void requireSequence(List<Row> rows) {
        if (rows.isEmpty())
            throw fail(NO_ELIGIBLE_SLIDES, MergeStage.SELECTION,
                    "No eligible slides remain after selection and filtering.");
    }

    private static MergeException fail(DiagnosticCode code, MergeStage stage, String message) {
        ErrorCode category = switch (code) {
            case SOURCE_NOT_FOUND, DIRECTORY_EMPTY -> ErrorCode.INPUT_NOT_FOUND;
            case INVALID_PRESENTATION -> ErrorCode.INVALID_PRESENTATION;
            default -> ErrorCode.INVALID_REQUEST;
        };
        return failure(category, code, stage, message, null);
    }

    private static MergeException failure(ErrorCode category, DiagnosticCode code, MergeStage stage, String message,
            Throwable cause) {
        return new MergeException(category, code, stage, message, cause, null, List.of());
    }

    private static MergeException failAt(DiagnosticCode code, MergeStage stage, String message, String source,
            Integer slide, Integer selector, Map<String, String> details) {
        MergeException base = fail(code, stage, message);
        var diagnostic = new MergeDiagnostic(code, Severity.ERROR, stage, null, message, source, slide, selector,
                details);
        return new MergeException(base.code(), code, stage, message, null, null, List.of(diagnostic));
    }

    private record Source(int id, PackageDocument document) {
    }

    private record Key(int occurrence, int index) {
    }

    private record Physical(Path path, int index) {
    }

    private record Row(Source source, int index, PlannedSlide.Origin origin, Integer selector) {
    }

    private record Prepared(List<Row> rows) {
    }

    private static final class Context {
        final String id;
        final boolean report;
        MergeReporter reporter;
        MergeStage stage = MergeStage.VALIDATION;
        Path output;
        final Map<Path, PackageDocument> loaded = new LinkedHashMap<>();
        final List<Source> catalogue = new ArrayList<>();
        final Map<Physical, String> titles = new HashMap<>();
        final List<MergeDiagnostic> diagnostics = new ArrayList<>();
        final Set<Key> hidden = new HashSet<>(), excluded = new HashSet<>();
        int occurrence, selector, missing, duplicateFiltered;
        boolean nonLegacyExclusionMatched;

        Context(String id, MergeReporter reporter, boolean report) {
            this.id = id;
            this.reporter = reporter;
            this.report = report;
        }

        void warn(DiagnosticCode code, MergeStage stage, String message, String source, Integer slide, Integer selector,
                Map<String, String> details) {
            var diagnostic = new MergeDiagnostic(code, Severity.WARN, stage, id, message, source, slide, selector,
                    details);
            diagnostics.add(diagnostic);
            event(MergeEvent.Type.DIAGNOSTIC, Severity.WARN, stage, message, diagnostic, null);
        }

        void event(MergeEvent.Type type, Severity severity, MergeStage stage, String message,
                MergeDiagnostic diagnostic, Throwable cause) {
            if (!report || reporter == null)
                return;
            try {
                reporter.report(new MergeEvent(id, type, severity, stage, message, diagnostic, cause, Instant.now()));
            } catch (RuntimeException error) {
                reporter = null; // A consumer's logger cannot change merge outcome or trigger fallback logging.
                diagnostics.add(new MergeDiagnostic(REPORTER_FAILED, Severity.WARN, stage, id,
                        "The configured reporter failed and was disabled for this execution.", null, null, null,
                        Map.of()));
            }
        }

        MergeException failure(RuntimeException error) {
            MergeException original = error instanceof MergeException merge
                    ? merge
                    : PlannedMergeEngine.failure(ErrorCode.IO_FAILURE, INTERNAL_ERROR, stage,
                            "Unexpected merge failure.", error);
            MergeDiagnostic location = original.diagnostics().stream().filter(d -> d.severity() == Severity.ERROR)
                    .reduce((a, b) -> b).orElse(null);
            var diagnostic = new MergeDiagnostic(original.failureCode(), Severity.ERROR, original.stage(), id,
                    original.getMessage(), location == null ? null : location.source(),
                    location == null ? null : location.slideNumber(),
                    location == null ? null : location.selectionIndex(),
                    location == null ? Map.of() : location.details());
            diagnostics.add(diagnostic);
            event(MergeEvent.Type.FAILED, Severity.ERROR, original.stage(), original.getMessage(), diagnostic,
                    original.code() == ErrorCode.IO_FAILURE ? original.getCause() : null);
            return new MergeException(original.code(), original.failureCode(), original.stage(), original.getMessage(),
                    original, id, diagnostics);
        }
    }
}
