package com.mergeslides.api.lib;

import java.util.Map;

/** A warning or failure with context; nullable location fields mean not applicable. */
public record MergeDiagnostic(DiagnosticCode code, Severity severity, MergeStage stage, String operationId,
        String message, String source, Integer slideNumber, Integer selectionIndex, Map<String, String> details) {
    public MergeDiagnostic {
        details = details == null ? Map.of() : Map.copyOf(details);
    }
}
