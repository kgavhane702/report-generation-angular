package com.mergeslides.api;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.UUID;

@Component
public class MergeOperationFilter extends OncePerRequestFilter {
    public static final String ATTRIBUTE = "com.mergeslides.operationId";
    public static final String HEADER = "X-Merge-Operation-Id";

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String prefix = request.getContextPath() + "/api/v1/merges";
        return !request.getRequestURI().equals(prefix) && !request.getRequestURI().startsWith(prefix + "/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String id = UUID.randomUUID().toString(), previous = MDC.get("merge.operationId");
        request.setAttribute(ATTRIBUTE, id);
        response.setHeader(HEADER, id);
        MDC.put("merge.operationId", id);
        try {
            chain.doFilter(request, response);
        } finally {
            if (previous == null)
                MDC.remove("merge.operationId");
            else
                MDC.put("merge.operationId", previous);
        }
    }
}
