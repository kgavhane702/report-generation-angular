package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;

/** Reads title metadata and slide text, never body-text guesses or layout prompt text. */
final class SlideTitleReader {
    String title(PackageDocument source, int index) {
        Element slide = source.slideXml(index), layout = null;
        for (var rel : source.rels(source.slides.get(index)).values())
            if (rel.getAttribute("Type").equals(RelationshipType.SLIDE_LAYOUT.uri()))
                layout = source.xml.get(PackagePaths.resolve(source.slides.get(index), rel.getAttribute("Target")));
        for (Element shape : Xml.descendants(slide)) {
            if (!Xml.is(shape, P, "sp"))
                continue;
            Element ph = placeholder(shape);
            if (ph == null)
                continue;
            String type = ph.getAttribute("type");
            if (type.isEmpty() && layout != null) {
                String id = ph.hasAttribute("idx") ? ph.getAttribute("idx") : "0";
                for (Element candidate : Xml.descendants(layout)) {
                    if (!Xml.is(candidate, P, "sp"))
                        continue;
                    Element inherited = placeholder(candidate);
                    if (inherited != null
                            && id.equals(inherited.hasAttribute("idx") ? inherited.getAttribute("idx") : "0")) {
                        type = inherited.getAttribute("type");
                        break;
                    }
                }
            }
            if (!Set.of("title", "ctrTitle").contains(type))
                continue;
            Element body = Xml.child(shape, P, "txBody");
            if (body == null)
                continue;
            var paragraphs = new ArrayList<String>();
            for (Element paragraph : Xml.children(body))
                if (Xml.is(paragraph, A, "p")) {
                    var text = new StringBuilder();
                    for (Element element : Xml.descendants(paragraph)) {
                        if (Xml.is(element, A, "t"))
                            text.append(element.getTextContent());
                        else if (Xml.is(element, A, "br"))
                            text.append('\n');
                    }
                    paragraphs.add(text.toString());
                }
            String title = String.join("\n", paragraphs);
            if (!title.isBlank())
                return title;
        }
        return null;
    }

    private Element placeholder(Element shape) {
        Element properties = Xml.child(shape, P, "nvSpPr");
        if (properties == null)
            return null;
        Element nv = Xml.child(properties, P, "nvPr");
        return nv == null ? null : Xml.child(nv, P, "ph");
    }
}
