package com.mergeslides.api;

import com.mergeslides.application.MergeService;
import com.mergeslides.domain.*;
import com.mergeslides.infrastructure.input.InputResolver;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.nio.file.Path;
import com.mergeslides.api.lib.*;
import com.mergeslides.infrastructure.input.RecipeCodec;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.*;

@RestController
@RequestMapping("/api/v1/merges")
public class MergeController {
    private static final Logger LOG = LoggerFactory.getLogger(MergeController.class);
    private final MergeService service;
    private final InputResolver resolver;
    private final Path workspace;

    public MergeController(MergeService service, InputResolver resolver,
            @Value("${merge.workspace}") String workspace) {
        this.service = service;
        this.resolver = resolver;
        this.workspace = Path.of(workspace).toAbsolutePath().normalize();
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public MergeResponse merge(@Valid @RequestBody MergeRequest request, HttpServletRequest servlet) {
        boolean inputs = request.inputs() != null,
                recipe = request.recipePath() != null && !request.recipePath().isBlank();
        if ((inputs ? 1 : 0) + (recipe ? 1 : 0) + (request.recipe() != null ? 1 : 0) != 1)
            throw MergeException.invalid("Provide exactly one of inputs, recipePath, or recipe.");
        Path output = workspace.resolve(request.output()).normalize();
        if (recipe || request.recipe() != null) {
            var codec = new RecipeCodec();
            var definition = recipe
                    ? codec.read(workspace.resolve(request.recipePath()))
                    : codec.decode(request.recipe(), workspace);
            MergeReporter reporter = event -> {
                if (event.type() != MergeEvent.Type.FAILED)
                    Slf4jMergeReporter.of(LOG).report(event);
            };
            return MergeResponse.from(MergeJob.fromDefinition(definition.withOutput(output), reporter,
                    (String) servlet.getAttribute(MergeOperationFilter.ATTRIBUTE)).merge());
        }
        var result = service.merge(resolver.resolve(request.inputs(), workspace, output), output);
        for (String warning : result.warnings())
            LOG.warn("Merge: {}", warning);
        return MergeResponse.from(result);
    }
}
