package com.mergeslides.domain;

/** Zero-based slicing with Python-compatible omitted bounds and negative steps. */
public record SlideSlice(Integer start, Integer stop, Integer step) {
}
