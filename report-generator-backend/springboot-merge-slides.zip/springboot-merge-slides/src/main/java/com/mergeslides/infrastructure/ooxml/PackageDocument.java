package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.PackagePaths.*;

/** Per-merge source package, never stored in singleton application state. */
public final class PackageDocument {
    final Path path;
    final Map<String, byte[]> parts;
    final Map<String, Element> xml = new LinkedHashMap<>();
    final Map<String, String> types = new LinkedHashMap<>();
    final Map<String, LinkedHashMap<String, Element>> relationships = new LinkedHashMap<>();
    final List<String> slides = new ArrayList<>();
    final List<Long> slideIds = new ArrayList<>();
    private final Map<String, String> fingerprints = new HashMap<>();

    PackageDocument(Path path, Map<String, byte[]> parts) {
        this.path = path;
        this.parts = parts;
        parts.forEach((name, bytes) -> {
            if (name.endsWith(".xml") || name.endsWith(".rels"))
                xml.put(name, Xml.parse(bytes, path.getFileName() + ":" + name));
        });
    }

    public Path path() {
        return path;
    }

    public List<String> slides() {
        return Collections.unmodifiableList(slides);
    }

    public Element slideXml(int index) {
        return xml.get(slides.get(index));
    }

    public Map<String, byte[]> parts() {
        return Collections.unmodifiableMap(parts);
    }

    public Map<String, String> contentTypes() {
        return Collections.unmodifiableMap(types);
    }

    public int richness() {
        return parts.size() + 10 * (int) parts.keySet().stream().filter(p -> p.contains("slideLayout")).count();
    }

    LinkedHashMap<String, Element> rels(String owner) {
        return relationships.getOrDefault(owner, new LinkedHashMap<>());
    }

    public static byte[] sha(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(data);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static String hex(byte[] data) {
        return HexFormat.of().formatHex(data);
    }

    String fingerprint(String part) {
        return fingerprints.computeIfAbsent(part, root -> {
            Set<String> visited = new TreeSet<>();
            Deque<String> pending = new ArrayDeque<>();
            pending.add(root);
            while (!pending.isEmpty()) {
                String current = pending.removeFirst();
                if (!visited.add(current))
                    continue;
                for (var rel : rels(current).values())
                    if (!rel.getAttribute("TargetMode").equals("External"))
                        pending.add(resolve(current, rel.getAttribute("Target")));
            }
            try {
                var hash = MessageDigest.getInstance("SHA-256");
                hash.update((root + "\0").getBytes(StandardCharsets.UTF_8));
                for (String name : visited) {
                    hash.update((name + "\0" + types.get(name) + "\0").getBytes(StandardCharsets.UTF_8));
                    hash.update(sha(parts.get(name)));
                    hash.update(sha(parts.getOrDefault(PackagePaths.rels(name), new byte[0])));
                }
                return hex(hash.digest());
            } catch (NoSuchAlgorithmException e) {
                throw new IllegalStateException(e);
            }
        });
    }
}
