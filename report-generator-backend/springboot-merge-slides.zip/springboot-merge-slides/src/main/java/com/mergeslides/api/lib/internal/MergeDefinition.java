package com.mergeslides.api.lib.internal;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.MergeException;
import java.nio.file.Path;
import java.util.List;

/** Internal transport model shared by the fluent and JSON adapters. */
public record MergeDefinition(Path baseDirectory, Path output, List<Source> sources, List<Query> queries,
        List<Exclusion> exclusions, Options options) {
    public MergeDefinition {
        sources = List.copyOf(sources);
        queries = List.copyOf(queries);
        exclusions = List.copyOf(exclusions);
    }

    public MergeDefinition withOutput(Path value) {
        return new MergeDefinition(baseDirectory, value, sources, queries, exclusions, options);
    }

    public record Source(int registration, Path path) {
    }

    public record Query(Integer registration, Path file, InputSelection selection, Path recipe) {
    }

    public enum ExclusionScope {
        GLOBAL, FILES, DIRECTORIES
    }

    /** A rule never registers sources. The original constructor retains numeric diagnostic behavior. */
    public record Exclusion(Path file, InputSelection selection, ExclusionScope scope, List<Path> paths,
            boolean legacyNumeric) {
        public Exclusion {
            if (selection == null || scope == null || paths == null || paths.stream().anyMatch(p -> p == null))
                throw MergeException.invalid("Exclusions require a selection, scope, and nonnull paths.");
            validateCandidates(selection.numbers());
            validateCandidates(selection.within());
            paths = List.copyOf(paths);
            if (scope == ExclusionScope.GLOBAL && (!paths.isEmpty() || selection.kind() != InputSelection.Kind.TITLES))
                throw MergeException.invalid("Global exclusions must be title-based and have no paths.");
            file = scope == ExclusionScope.FILES && paths.size() == 1 ? paths.get(0) : null;
        }

        public Exclusion(Path file, InputSelection selection) {
            this(file, selection, ExclusionScope.FILES, single(file),
                    selection != null && selection.kind() != InputSelection.Kind.TITLES);
        }

        public static Exclusion global(InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.GLOBAL, List.of(), false);
        }

        public static Exclusion files(List<Path> paths, InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.FILES, paths, false);
        }

        public static Exclusion directories(List<Path> paths, InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.DIRECTORIES, paths, false);
        }

        private static List<Path> single(Path file) {
            if (file == null)
                throw MergeException.invalid("An excluded file must not be null.");
            return List.of(file);
        }

        public static void validateCandidates(Object value) {
            if (value instanceof List<?> entries)
                for (Object entry : entries) {
                    if (entry == null)
                        throw MergeException.invalid("Exclusion slide and within lists must not contain null entries.");
                    validateCandidates(entry);
                }
            else if (value instanceof java.util.Map<?, ?> map)
                map.values().forEach(Exclusion::validateCandidates);
        }
    }

    public record Options(Boolean skipHidden, DuplicateTitlePolicy duplicateTitles,
            DuplicateSourcePolicy duplicateSources, RepeatedSlidePolicy repeatedSlides, MissingTitlePolicy onMissing,
            RemainingSlides remaining, Boolean overwrite, MissingTitlePolicy onMissingExcludedTitle) {
        public Options(Boolean skipHidden, DuplicateTitlePolicy duplicateTitles, DuplicateSourcePolicy duplicateSources,
                RepeatedSlidePolicy repeatedSlides, MissingTitlePolicy onMissing, RemainingSlides remaining,
                Boolean overwrite) {
            this(skipHidden, duplicateTitles, duplicateSources, repeatedSlides, onMissing, remaining, overwrite, null);
        }

        public static Options defaults() {
            return new Options(false, DuplicateTitlePolicy.ALL, DuplicateSourcePolicy.ALLOW, RepeatedSlidePolicy.ALLOW,
                    MissingTitlePolicy.SKIP, RemainingSlides.END, false, MissingTitlePolicy.SKIP);
        }

        public Options orElse(Options other) {
            return new Options(skipHidden == null ? other.skipHidden : skipHidden,
                    duplicateTitles == null ? other.duplicateTitles : duplicateTitles,
                    duplicateSources == null ? other.duplicateSources : duplicateSources,
                    repeatedSlides == null ? other.repeatedSlides : repeatedSlides,
                    onMissing == null ? other.onMissing : onMissing, remaining == null ? other.remaining : remaining,
                    overwrite == null ? other.overwrite : overwrite,
                    onMissingExcludedTitle == null ? other.onMissingExcludedTitle : onMissingExcludedTitle);
        }
    }
}
