package com.mergeslides.api.lib.internal;

import com.mergeslides.api.lib.*;
import com.mergeslides.domain.MergeException;
import java.nio.file.Path;
import java.util.*;

/** Internal transport model shared by the fluent and JSON adapters. */
public record MergeDefinition(Path baseDirectory, Path output, List<Source> sources, List<Query> queries,
        List<Exclusion> exclusions, Options options, List<InputStep> inputOrder) {
    /** Retains the original constructor for existing recipes and compiled library callers. */
    public MergeDefinition(Path baseDirectory, Path output, List<Source> sources, List<Query> queries,
            List<Exclusion> exclusions, Options options) {
        this(baseDirectory, output, sources, queries, exclusions, options, null);
    }

    public MergeDefinition {
        sources = List.copyOf(sources);
        queries = List.copyOf(queries);
        exclusions = List.copyOf(exclusions);
        inputOrder = inputOrder == null ? defaultInputOrder(sources, queries) : List.copyOf(inputOrder);
        for (InputStep step : inputOrder) {
            if (step.registration() != null && sources.stream().noneMatch(s -> s.registration() == step.registration()))
                throw MergeException.invalid("Input order references an unknown source registration.");
            if (step.queryIndex() != null && step.queryIndex() >= queries.size())
                throw MergeException.invalid("Input order references an unknown query.");
        }
    }

    public MergeDefinition withOutput(Path value) {
        return new MergeDefinition(baseDirectory, value, sources, queries, exclusions, options, inputOrder);
    }

    /** Source declarations and recipe chunks share an ordered input stream. */
    public record InputStep(Integer registration, Integer queryIndex) {
        public InputStep {
            if ((registration == null) == (queryIndex == null) || registration != null && registration < 0
                    || queryIndex != null && queryIndex < 0)
                throw MergeException
                        .invalid("An input step needs exactly one nonnegative source registration or query index.");
        }

        public static InputStep source(int registration) {
            return new InputStep(registration, null);
        }

        public static InputStep query(int index) {
            return new InputStep(null, index);
        }
    }

    private static List<InputStep> defaultInputOrder(List<Source> sources, List<Query> queries) {
        boolean chunks = queries.stream().anyMatch(q -> q.recipe() != null);
        Set<Integer> bound = new HashSet<>();
        for (Query query : queries)
            if (query.registration() != null)
                bound.add(query.registration());
        var order = new ArrayList<InputStep>();
        for (Source source : sources)
            if (!chunks || !bound.contains(source.registration()))
                order.add(InputStep.source(source.registration()));
        for (int i = 0; i < queries.size(); i++) {
            Query query = queries.get(i);
            if (chunks && query.registration() != null)
                order.add(InputStep.source(query.registration()));
            else if (query.file() != null || query.recipe() != null)
                order.add(InputStep.query(i));
        }
        return List.copyOf(order);
    }

    public record Source(int registration, Path path) {
    }

    public record Query(Integer registration, Path file, InputSelection selection, Path recipe) {
    }

    public enum ExclusionScope {
        GLOBAL, FILES, DIRECTORIES
    }

    /** A rule never registers sources. The original constructor retains numeric diagnostic behavior. */
    public record Exclusion(Path file, InputSelection selection, ExclusionScope scope, List<Path> paths,
            boolean legacyNumeric) {
        public Exclusion {
            if (selection == null || scope == null || paths == null || paths.stream().anyMatch(p -> p == null))
                throw MergeException.invalid("Exclusions require a selection, scope, and nonnull paths.");
            validateCandidates(selection.numbers());
            validateCandidates(selection.within());
            paths = List.copyOf(paths);
            if (scope == ExclusionScope.GLOBAL && (!paths.isEmpty() || selection.kind() != InputSelection.Kind.TITLES))
                throw MergeException.invalid("Global exclusions must be title-based and have no paths.");
            file = scope == ExclusionScope.FILES && paths.size() == 1 ? paths.get(0) : null;
        }

        public Exclusion(Path file, InputSelection selection) {
            this(file, selection, ExclusionScope.FILES, single(file),
                    selection != null && selection.kind() != InputSelection.Kind.TITLES);
        }

        public static Exclusion global(InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.GLOBAL, List.of(), false);
        }

        public static Exclusion files(List<Path> paths, InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.FILES, paths, false);
        }

        public static Exclusion directories(List<Path> paths, InputSelection selection) {
            return new Exclusion(null, selection, ExclusionScope.DIRECTORIES, paths, false);
        }

        private static List<Path> single(Path file) {
            if (file == null)
                throw MergeException.invalid("An excluded file must not be null.");
            return List.of(file);
        }

        public static void validateCandidates(Object value) {
            if (value instanceof List<?> entries)
                for (Object entry : entries) {
                    if (entry == null)
                        throw MergeException.invalid("Exclusion slide and within lists must not contain null entries.");
                    validateCandidates(entry);
                }
            else if (value instanceof java.util.Map<?, ?> map)
                map.values().forEach(Exclusion::validateCandidates);
        }
    }

    public record Options(Boolean skipHidden, DuplicateTitlePolicy duplicateTitles,
            DuplicateSourcePolicy duplicateSources, RepeatedSlidePolicy repeatedSlides, MissingTitlePolicy onMissing,
            RemainingSlides remaining, Boolean overwrite, MissingTitlePolicy onMissingExcludedTitle) {
        public Options(Boolean skipHidden, DuplicateTitlePolicy duplicateTitles, DuplicateSourcePolicy duplicateSources,
                RepeatedSlidePolicy repeatedSlides, MissingTitlePolicy onMissing, RemainingSlides remaining,
                Boolean overwrite) {
            this(skipHidden, duplicateTitles, duplicateSources, repeatedSlides, onMissing, remaining, overwrite, null);
        }

        public static Options defaults() {
            return new Options(false, DuplicateTitlePolicy.ALL, DuplicateSourcePolicy.ALLOW, RepeatedSlidePolicy.ALLOW,
                    MissingTitlePolicy.SKIP, RemainingSlides.END, false, MissingTitlePolicy.SKIP);
        }

        public Options orElse(Options other) {
            return new Options(skipHidden == null ? other.skipHidden : skipHidden,
                    duplicateTitles == null ? other.duplicateTitles : duplicateTitles,
                    duplicateSources == null ? other.duplicateSources : duplicateSources,
                    repeatedSlides == null ? other.repeatedSlides : repeatedSlides,
                    onMissing == null ? other.onMissing : onMissing, remaining == null ? other.remaining : remaining,
                    overwrite == null ? other.overwrite : overwrite,
                    onMissingExcludedTitle == null ? other.onMissingExcludedTitle : onMissingExcludedTitle);
        }
    }
}
