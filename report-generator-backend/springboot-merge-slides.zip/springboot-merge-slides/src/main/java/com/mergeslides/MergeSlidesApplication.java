package com.mergeslides;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.cli.MergeCli;
import com.mergeslides.infrastructure.input.InputResolver;
import com.mergeslides.infrastructure.ooxml.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.nio.file.Path;
import java.util.Arrays;

@SpringBootApplication
public class MergeSlidesApplication {
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("merge")) {
            var reader = new PackageReader(new PackageValidator());
            var cli = new MergeCli(new PackageMergeService(reader, new AtomicPackageWriter(reader)),
                    new InputResolver(new ObjectMapper()));
            Path cwd = Path.of("").toAbsolutePath();
            String configured = System.getenv("MERGE_WORKSPACE");
            Path workspace = configured == null
                    ? (java.nio.file.Files.isDirectory(cwd.resolve("ppts")) ? cwd : cwd.getParent())
                    : cwd.resolve(configured);
            System.exit(cli.run(Arrays.copyOfRange(args, 1, args.length), cwd, workspace, System.out, System.err));
        } else
            SpringApplication.run(MergeSlidesApplication.class, args);
    }
}
