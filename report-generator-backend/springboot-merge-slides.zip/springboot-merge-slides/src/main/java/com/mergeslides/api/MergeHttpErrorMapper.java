package com.mergeslides.api;

import com.mergeslides.api.lib.DiagnosticCode;
import com.mergeslides.domain.*;
import org.springframework.http.*;
import java.util.*;

/** Reusable by hosts with their own advice. Preserves the v1 code/message fields. */
public final class MergeHttpErrorMapper {
    public HttpStatus status(MergeException error) {
        if (error.failureCode() == DiagnosticCode.OUTPUT_EXISTS)
            return HttpStatus.CONFLICT;
        return switch (error.code()) {
            case INPUT_NOT_FOUND -> HttpStatus.NOT_FOUND;
            case INVALID_PRESENTATION -> HttpStatus.UNPROCESSABLE_ENTITY;
            case IO_FAILURE -> HttpStatus.INTERNAL_SERVER_ERROR;
            default -> HttpStatus.BAD_REQUEST;
        };
    }

    public Map<String, Object> body(MergeException error, String operationId) {
        var body = new LinkedHashMap<String, Object>();
        body.put("code", error.code().name());
        body.put("message", publicMessage(error));
        body.put("failureCode", error.failureCode().name());
        body.put("stage", error.stage().name());
        body.put("operationId", operationId);
        return body;
    }

    private String publicMessage(MergeException error) {
        if (error.code() == ErrorCode.IO_FAILURE)
            return "The merge could not complete because of an internal I/O failure. Refer to the operation ID.";
        return switch (error.failureCode()) {
            case SOURCE_NOT_FOUND -> "A requested input file or directory was not found.";
            case DIRECTORY_EMPTY -> "An input directory contains no usable PPTX files.";
            case INVALID_PRESENTATION -> "An input is not a supported valid PPTX presentation.";
            case OUTPUT_EXISTS -> "The destination exists; explicitly enable overwrite to replace it.";
            case OUTPUT_IS_SOURCE -> "The output cannot overwrite an input presentation.";
            case TITLE_NOT_FOUND, TITLE_NO_ELIGIBLE_MATCH -> "A required title has no eligible matching slide.";
            case EXCLUDED_TITLE_NOT_FOUND -> "A required excluded title was not found in its requested scope.";
            case INVALID_SELECTION -> "A slide selection is invalid for its input presentation.";
            case NO_ELIGIBLE_SLIDES -> "No eligible slides remain after selection and filtering.";
            default -> "Invalid merge request. Check the files, selectors and options.";
        };
    }
}
