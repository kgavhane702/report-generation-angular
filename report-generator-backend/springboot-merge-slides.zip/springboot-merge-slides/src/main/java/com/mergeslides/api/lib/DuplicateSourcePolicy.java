package com.mergeslides.api.lib;

public enum DuplicateSourcePolicy {
    ALLOW, SKIP, ERROR
}
