package com.mergeslides.infrastructure.ooxml;

import org.w3c.dom.Element;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import static com.mergeslides.infrastructure.ooxml.Ooxml.*;
import static com.mergeslides.infrastructure.ooxml.MergeContext.*;

final class MetadataMerger {
    private static final UUID UUID_NAMESPACE_OID = UUID.fromString("6ba7b812-9dad-11d1-80b4-00c04fd430c8");
    private final MergeContext c;

    MetadataMerger(MergeContext context) {
        c = context;
    }

    void authorsAndStyles() {
        var authors = Xml.root(P, "cmAuthorLst");
        var styles = Xml.root(A, "tblStyleLst");
        Map<String, byte[]> styleData = new HashMap<>();
        Map<List<String>, String> identities = new HashMap<>();
        for (var source : c.sources)
            for (var entry : source.xml.entrySet()) {
                String type = source.types.get(entry.getKey());
                var root = entry.getValue();
                if (ContentType.AUTHORS.mime().equals(type))
                    for (var original : Xml.children(root)) {
                        var presence = Xml.descendants(original).stream()
                                .filter(e -> !e.getAttribute("userId").isEmpty()).findFirst().orElse(null);
                        var identity = presence == null
                                ? List.of("name", original.getAttribute("name"), original.getAttribute("initials"))
                                : List.of("presence", presence.getAttribute("providerId"),
                                        presence.getAttribute("userId"));
                        String id = identities.get(identity);
                        if (id == null) {
                            id = Integer.toString(Xml.children(authors).size());
                            identities.put(identity, id);
                            var author = Xml.appendCopy(authors, original);
                            author.setAttribute("id", id);
                            author.setAttribute("clrIdx", id);
                        }
                        c.authorIds.put(new SourcePart(source.path, original.getAttribute("id")), id);
                    }
                else if (ContentType.TABLE_STYLES.mime().equals(type)) {
                    if (styles.getAttributes().getLength() == 0)
                        for (var attr : Xml.attributes(root))
                            styles.setAttributeNS(attr.getNamespaceURI(), attr.getName(), attr.getValue());
                    for (var original : Xml.children(root)) {
                        String id = original.getAttribute("styleId"), replacement = id;
                        byte[] content = Xml.bytes(original);
                        if (styleData.containsKey(id)) {
                            if (Arrays.equals(styleData.get(id), content))
                                continue;
                            replacement = guid(PackageDocument.hex(PackageDocument.sha(content)));
                            c.tableIds.computeIfAbsent(source.path, k -> new HashMap<>()).put(id, replacement);
                        }
                        if (!styleData.containsKey(replacement)) {
                            var e = Xml.appendCopy(styles, original);
                            e.setAttribute("styleId", replacement);
                            styleData.put(replacement, content);
                        }
                    }
                }
            }
        if (!Xml.children(authors).isEmpty())
            c.store(AUTHORS, Xml.bytes(authors), ContentType.AUTHORS.mime());
        if (styles.hasAttributes() || !Xml.children(styles).isEmpty())
            c.store(TABLE_STYLES, Xml.bytes(styles), ContentType.TABLE_STYLES.mime());
    }

    void sections(Element presentation) {
        Map<SourcePart, String> labels = new HashMap<>();
        boolean any = false;
        for (var source : c.sources)
            for (var section : Xml.findAll(source.xml.get(PRESENTATION), P14, "section")) {
                any = true;
                for (var entry : Xml.children(Xml.child(section, P14, "sldIdLst")))
                    labels.put(new SourcePart(source.path, entry.getAttribute("id")),
                            section.hasAttribute("name") ? section.getAttribute("name") : stem(source));
            }
        for (var element : Xml.findAll(presentation, P14, "sectionLst"))
            element.getParentNode().removeChild(element);
        if (!any)
            return;
        var extensions = Xml.child(presentation, P, "extLst");
        if (extensions == null)
            extensions = Xml.add(presentation, P, "extLst");
        var extension = Xml.children(extensions).stream().filter(e -> e.getAttribute("uri").equals(SECTION_EXTENSION))
                .findFirst().orElse(null);
        if (extension == null) {
            extension = Xml.add(extensions, P, "ext");
            extension.setAttribute("uri", SECTION_EXTENSION);
        }
        var sections = Xml.add(extension, P14, "sectionLst");
        SourcePart previous = null;
        Element members = null;
        for (int i = 0; i < c.sequence.size(); i++) {
            var item = c.sequence.get(i);
            long oldId = item.source().slideIds.get(item.source().slides.indexOf(item.part()));
            String label = labels.getOrDefault(new SourcePart(item.source().path, Long.toString(oldId)),
                    stem(item.source()));
            var key = new SourcePart(item.source().path, label);
            if (!key.equals(previous)) {
                String identity = PackageDocument.hex(PackageDocument.sha(item.source().parts.get(PRESENTATION)));
                String id = guid(Xml.children(sections).size() + ":" + identity + ":" + label);
                var section = Xml.add(sections, P14, "section");
                section.setAttribute("name", label);
                section.setAttribute("id", id);
                members = Xml.add(section, P14, "sldIdLst");
                previous = key;
            }
            Xml.add(members, P14, "sldId").setAttribute("id", Long.toString(FIRST_SLIDE_ID + i));
        }
    }

    void pruneAuthors() {
        if (!c.parts.containsKey(AUTHORS))
            return;
        var root = Xml.parse(c.parts.get(AUTHORS), AUTHORS);
        for (var author : Xml.children(root)) {
            int count = c.commentIndices.getOrDefault(author.getAttribute("id"), 0);
            if (count == 0)
                root.removeChild(author);
            else
                author.setAttribute("lastIdx", Integer.toString(count));
        }
        if (Xml.children(root).isEmpty()) {
            c.parts.remove(AUTHORS);
            c.types.remove(AUTHORS);
        } else
            c.parts.put(AUTHORS, Xml.bytes(root));
    }

    void appProperties() {
        long notes = c.types.values().stream().filter(ContentType.NOTES_SLIDE.mime()::equals).count();
        long hidden = c.sequence.stream().filter(o -> Xml.hidden(o.source().xml.get(o.part()))).count();
        for (String name : new ArrayList<>(c.parts.keySet()))
            if (ContentType.EXTENDED_PROPERTIES.mime().equals(c.types.get(name))) {
                var root = Xml.parse(c.parts.get(name), name);
                var counts = Map.of("Slides", c.sequence.size(), "Notes", notes, "HiddenSlides", hidden);
                counts.forEach((key, value) -> {
                    var e = Xml.child(root, EP, key);
                    if (e != null)
                        e.setTextContent(value.toString());
                });
                for (String key : List.of("HeadingPairs", "TitlesOfParts")) {
                    var e = Xml.child(root, EP, key);
                    if (e != null)
                        root.removeChild(e);
                }
                c.parts.put(name, Xml.bytes(root));
            }
    }

    private static String stem(PackageDocument source) {
        String n = source.path.getFileName().toString();
        return n.substring(0, n.lastIndexOf('.'));
    }

    private static String guid(String text) {
        try {
            var sha = MessageDigest.getInstance("SHA-1");
            sha.update(ByteBuffer.allocate(16).putLong(UUID_NAMESPACE_OID.getMostSignificantBits())
                    .putLong(UUID_NAMESPACE_OID.getLeastSignificantBits()).array());
            byte[] hash = sha.digest(text.getBytes(StandardCharsets.UTF_8));
            hash[6] = (byte) ((hash[6] & 15) | 0x50);
            hash[8] = (byte) ((hash[8] & 63) | 0x80);
            var bytes = ByteBuffer.wrap(hash);
            return "{" + new UUID(bytes.getLong(), bytes.getLong()).toString().toUpperCase(Locale.ROOT) + "}";
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
