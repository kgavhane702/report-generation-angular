package com.mergeslides.api.lib;

import java.nio.file.Path;
import java.util.Objects;

public record MergeInput(Path file, InputSelection selection) {
    public MergeInput {
        Objects.requireNonNull(file, "file");
        selection = selection == null ? InputSelection.all() : selection;
    }

    public static MergeInput of(Path file, InputSelection selection) {
        return new MergeInput(file, selection);
    }

    public static MergeInput of(Path file) {
        return new MergeInput(file, InputSelection.all());
    }
}
