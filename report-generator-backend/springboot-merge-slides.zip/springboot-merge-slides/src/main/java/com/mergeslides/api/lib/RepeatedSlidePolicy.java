package com.mergeslides.api.lib;

public enum RepeatedSlidePolicy {
    ALLOW, SKIP, ERROR
}
