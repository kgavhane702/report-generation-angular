# Merge Slides Java library

Java 17+ library for valid, non-macro transitional OOXML `.pptx` files. Spring and Microsoft PowerPoint are not required. Python files are unchanged. The existing server/CLI remains optional.

## Build and installation

```powershell
.\gradlew.bat test integrationTest internetTest bootJar libraryDist standaloneSmokeTest
```

- `build/libs/merge-slides-library-1.0.0.jar`: normal library JAR.
- `build/distributions/merge-slides-library-1.0.0-distribution.zip`: library, Jackson dependencies, sources/Javadoc, Maven POM, examples and schema.
- `build/libs/merge-slides.jar`: optional runnable server/CLI.

Use every JAR in the distribution's `lib/` directory. Only Jackson Databind and its transitive dependencies are required externally. There is no Spring or logging backend requirement, and the build publishes nothing externally.

After extracting the distribution, compile `examples/LibraryExample.java` with `javac --release 17 -cp "lib/*" -d classes examples/LibraryExample.java`. Run it on Windows with `java -cp "classes;lib/*" LibraryExample INPUT.pptx OUTPUT.pptx`; on Linux/macOS use `"classes:lib/*"` as the classpath.

For the full commented, function-only workspace demo, run `.\gradlew.bat runFunctionScenarios` (or the earlier `runTemporaryScenarios` task name). The single main is `examples/FunctionScenarioMain.java`, class `com.mergeslides.demo.FunctionScenarioMain`. Its successful PPTX files, copied source, scenario report, event log, title inventory and slide-order report are written directly to the workspace's `function_pptx` folder. Use `-PscenarioWorkspace="C:/path/to/workspace"` to select another copy of the required workspace inputs. The examples document expected warnings/errors and assert their exact diagnostic codes. Reruns replace the named demo outputs; source presentations are read only.

Use `-PscenarioOutput="C:/path/to/fresh-results"` to write a separate run. The standalone runner also accepts an optional second `OUTPUT_DIRECTORY` argument after `WORKSPACE`. Examples 77-98 cover title, list, range, slice, directory, whole-source and remaining-slide exclusions.

The distribution also includes this runner. Compile it with `javac --release 17 -cp "lib/*" -d classes examples/FunctionScenarioMain.java`, then run `java -cp "classes;lib/*" com.mergeslides.demo.FunctionScenarioMain "C:/path/to/workspace"` on Windows (use `classes:lib/*` on Linux/macOS). Its workspace inputs are not bundled in the distribution.

## Simple function call

```java
import com.mergeslides.api.lib.*;
import java.nio.file.Path;

var result = MergeSlides.builder()
    .addFiles(Path.of("a.pptx"), Path.of("b.pptx"))
    .output(Path.of("merged.pptx"))
    .merge();
```

Existing destinations fail by default; use `.overwrite(true)` to replace them. An input presentation can never be the output, even with overwrite enabled.

## Sources and selections

`searchFiles`/`searchDirectory` register an ordered search pool. `addFile`, `addFiles`, `addDirectory`, and `addAll(List<MergeInput>)` append explicit input occurrences with bound selections. Repeated inputs do not create a cross-product of their selections.

`selectFile` and file-specific `addTitle/addTitles/addSlides` helpers query matching pool occurrences; an absent file is registered once. File paths must resolve correctly: there is no basename search elsewhere.

```java
var job = MergeSlides.builder()
    .searchFiles(Path.of("a.pptx"), Path.of("b.pptx"))
    .addTitles("Introduction", "Roadmap")
    .selectFile(Path.of("a.pptx"),
        InputSelection.title("Revenue").withinRange("2-8").skipHidden())
    .selectFile(Path.of("b.pptx"), InputSelection.slides(3, 1, 3))
    .excludeRange(Path.of("a.pptx"), 10, 12)
    .output(Path.of("merged.pptx"))
    .build();

var preview = job.plan();        // No output required or written.
var report = job.mergeDetailed();
var result = report.result();    // Existing MergeResult shape.
```

Choose `merge()` or `mergeDetailed()`; each executes a merge. Preview is detached metadata; merging re-reads current sources. Clients and built jobs are immutable/reusable. Builders are mutable; caller collections are copied. Reporter implementations shared between threads must be thread safe.

Directories expand nonrecursively in natural filename order, ignoring non-PPTX files, Office lock files and the destination. Every explicit source must be valid. A missing file/directory or directory with no usable PPTX files fails even when other sources are valid.

## Selection functions

```java
InputSelection.all();
InputSelection.slides(7, 3, 7);
InputSelection.range("2-5,8");
InputSelection.slice(new com.mergeslides.domain.SlideSlice(null, null, -1));
InputSelection.title("Revenue");
InputSelection.titles("Revenue", "Conclusion");
InputSelection.title("Revenue").within(1, 2, 5);
InputSelection.title("Revenue").withinRange("2-8");
InputSelection.title("Revenue").duplicates(DuplicateTitlePolicy.LAST);
InputSelection.range("2-8").skipHidden();
InputSelection.slides(4).skipHidden(false);
```

Picks are one-based; negative integers count from the end. Ranges are inclusive and clamp to bounds; slices retain zero-based Python-style behavior. Invalid individual picks and a zero slice step fail. Valid empty ranges/slices select nothing.

`within` filters title candidates independently per file. It does not reorder matches or exclude other slides from remaining output. Repeated candidate numbers do not duplicate matches. Omitted means unrestricted; an empty list means no candidates.

Titles match exactly, ignoring case only. Spaces, punctuation, accents and line breaks remain significant. No trimming, whitespace collapsing, fuzzy matching or Unicode normalization occurs. Only actual title/centered-title placeholders are read, including layout-inherited identification. The first nonblank title placeholder is used; text runs add no artificial spaces. Body text, notes, filenames, shape names and images are not fallback titles. Untitled slides remain eligible for numeric/remaining selection.

## Exclusions

Exclusions always win over explicit selections, START/END remaining slides, and every occurrence of a repeated source. Source slides keep their original numbers. Overlapping rules remove a slide once per source occurrence; surviving slides keep their requested order.

The following examples use existing, valid presentations. Each output has its own filename and fails if that destination already exists. Supply the common imports and paths once:

```java
import com.mergeslides.api.lib.*;
import java.nio.file.Path;
import java.util.List;

Path a = Path.of("a.pptx");
Path b = Path.of("b.pptx");
Path reports = Path.of("reports");
Path archives = Path.of("archives");
List<Path> files = List.of(a, b);
List<Path> directories = List.of(reports, archives);
List<Integer> omittedSlides = List.of(3, 6);
List<String> omittedTitles = List.of("Confidential", "Appendix");
```

Select slides 1-10 from each file, except 3 and 6. NONE excludes slides outside the selected ranges. END or START includes the other eligible slides after or before the selection; exclusions still apply.

```java
var rangeResult = MergeSlides.builder()
    .addFiles(files, InputSelection.range("1-10"))
    .excludeSlides(files, omittedSlides)
    .remainingSlides(RemainingSlides.NONE)
    .output(Path.of("range-exceptions.pptx"))
    .merge();
```

Merge all slides except matching titles, numbers, ranges, and slices. Title rules match all duplicate and hidden title slides, independently of inclusion FIRST/LAST and hidden settings. `within` can explicitly limit title-exclusion candidates.

```java
var allResult = MergeSlides.builder()
    .addFiles(files)
    .excludeTitles(omittedTitles)
    .excludeRange(files, 10, 12)
    .exclude(a, InputSelection.slice(new com.mergeslides.domain.SlideSlice(2, 6, 3)))
    .output(Path.of("all-with-exclusions.pptx"))
    .merge();
```

Use a list of different per-file selections. Exclusion lists can also target one file or a specified file list; matching titles in other files survive.

```java
var perFileResult = MergeSlides.builder()
    .addAll(List.of(
        MergeInput.of(a, InputSelection.slides(List.of(7, 3, 1))),
        MergeInput.of(b, InputSelection.range("2-8"))))
    .excludeTitles(a, omittedTitles)
    .excludeTitles(List.of(b), List.of("Confidential"))
    .excludeSlides(a, List.of(3))
    .remainingSlides(RemainingSlides.NONE)
    .output(Path.of("per-file-exclusions.pptx"))
    .merge();
```

Search a directory by titles without listing filenames, then append remaining slides. Omitting `addTitles(...)` merges every eligible slide except the exclusions. Directory discovery and directory exclusion scopes are nonrecursive.

```java
var directoryResult = MergeSlides.builder()
    .searchDirectory(reports)
    .addTitles(List.of("Introduction", "Roadmap"))
    .excludeTitles(omittedTitles)
    .remainingSlides(RemainingSlides.END)
    .output(Path.of("directory-titles.pptx"))
    .merge();
```

Apply numeric exceptions to each presentation in a directory. Individual numbers must exist in every scoped presentation; ranges clamp to each presentation's bounds.

```java
var directoryRangeResult = MergeSlides.builder()
    .addDirectory(reports, InputSelection.range("1-10"))
    .excludeDirectory(reports, InputSelection.slides(omittedSlides))
    .excludeDirectory(reports, InputSelection.range("8-9"))
    .remainingSlides(RemainingSlides.NONE)
    .output(Path.of("directory-range.pptx"))
    .merge();
```

Combine directories and individual files. Entire-file and directory exclusions are shorthand for scoped `InputSelection.all()` rules. Every named exclusion scope must match registered sources; it never introduces sources. Supplied presentations are still validated even when excluded completely.

```java
var mixedResult = MergeSlides.builder()
    .addFiles(directories)
    .addFiles(files)
    .excludeDirectories(directories, InputSelection.titles(omittedTitles))
    .excludeFiles(List.of(b))
    .excludeDirectory(archives)
    .output(Path.of("mixed-exclusions.pptx"))
    .merge();
```

`excludeTitle` has global and single-file overloads. `excludeTitles` supports varargs and lists globally, for one file, and for a file list. `excludeSlides` supports varargs and integer lists for one file or a file list; `excludeRange` supports one file or a file list. `exclude(files, selection)` accepts any existing `InputSelection`, including comma-separated ranges, slices, and `all()`. `excludeDirectory(directory, selection)` and `excludeDirectories(directories, selection)` apply a selection per scoped file. `excludeFile`, `excludeFiles` (varargs/list), `excludeDirectory`, and `excludeDirectories` omit entire sources. New exclusion collections are copied; empty lists do nothing; null entries and blank titles fail validation.

A nonexistent excluded title means no actual title placeholder in the requested scope matches that text. The default SKIP policy warns once per requested title across the entire scope and continues. Whitespace, punctuation, body text, notes and filename rules are exactly the same as for title inclusion.

```java
var warningResult = MergeSlides.builder()
    .addFiles(files)
    .excludeTitles(List.of("Title that is absent"))
    .onMissingExcludedTitle(MissingTitlePolicy.SKIP)
    .output(Path.of("missing-exclusion-warning.pptx"))
    .merge();
warningResult.warnings().forEach(System.out::println);
```

Choose `MissingTitlePolicy.ERROR` to fail with `EXCLUDED_TITLE_NOT_FOUND` before writing. This policy is separate from `onMissing(...)` for inclusion requests. A title wholly suppressed by new exclusions is an intentional skip, even when requested explicitly. Existing numeric-only exclusions retain their original missing-inclusion diagnostics. Empty final output fails with `NO_ELIGIBLE_SLIDES`. Summary `missingTitleCount` includes unmatched inclusion and exclusion title requests; `excludedCount` counts source occurrences without double-counting overlapping rules.

## Defaults and precedence

| Setting | Default | Alternatives |
|---|---|---|
| `skipHidden` | false | No-argument method sets true; local overrides global |
| `duplicateTitles` | ALL | FIRST, LAST, ERROR |
| `duplicateSources` | ALLOW | SKIP, ERROR |
| `repeatedSlides` | ALLOW | SKIP, ERROR |
| `onMissing` | SKIP with warning | ERROR |
| `onMissingExcludedTitle` | SKIP with warning | ERROR |
| `remainingSlides` | END | START, NONE |
| `overwrite` | false | true |

Global setters affect the entire job, regardless of call position; the last value wins. Hard exclusions always win across inclusion methods and repeated source occurrences. Exclusions cannot introduce sources. Filtering never renumbers source slides.

Hidden candidates filtered locally cannot return through remaining slides. Other hidden slides follow the global policy. Another explicit selection allowing hidden slides can restore a locally filtered slide; hard exclusions still win.

Selections preserve requested order. Remaining slides preserve source/slide order and include untitled slides and alternatives left by FIRST/LAST. Selected occurrences are not automatically appended again. Intentional repetitions remain allowed. `repeatedSlides(SKIP)` retains the first physical slide in final output order.

No selectors means all eligible source slides, even with remaining NONE. With selectors, NONE means only requested output. Missing titles skip and warn in both global and file scopes. Empty final output is an error.

## Diagnostics and your application's logger

```java
var client = MergeSlides.client()
    .baseDirectory(Path.of("presentations"))
    .reporter(event -> {
        // Route to YOUR logger: severity(), code(), operationId(), stage(), message(), cause().
        System.out.println(event.operationId() + " " + event.code() + " " + event.message());
    }).build();

try {
    var report = client.newJob().addTitle(Path.of("a.pptx"), "Revenue")
        .output(Path.of("merged.pptx")).mergeDetailed();
    report.diagnostics().forEach(d -> System.out.println(d.code()));
} catch (com.mergeslides.domain.MergeException error) {
    // Inspect failureCode(), stage(), operationId(), diagnostics(), getCause(); never parse messages.
    throw error;
}
```

The default reporter uses the JDK logger; a custom reporter replaces it. `MergeReporter.silent()` suppresses reporting without losing diagnostics. Reporter failure records REPORTER_FAILED and disables that reporter for this invocation, with no unexpected fallback logger. Preview does not log warnings. Each execution gets a fresh operation ID unless supplied explicitly.

`MergeResult.warnings()` remains a string list. Detailed reports add typed diagnostics, summary counts and executed slide metadata. Exceptions include prior warnings and the terminal failure. The library does not configure logging backends, global levels, MDC, HTTP or application quotas.

| Situation | Outcome |
|---|---|
| Missing title or title matching only filtered slides | Skip request and warn |
| Configured hidden filtering, exclusions, duplicate SKIP | Silent skip; reflected in counts |
| Allowed duplicates | Normal processing |
| Missing/empty source, corrupt PPTX, invalid selection, strict-policy violation | Typed failure |
| Empty final output | NO_ELIGIBLE_SLIDES |
| Existing destination without overwrite | OUTPUT_EXISTS |
| Mixed canvas sizes or removed links to omitted slides | Preservation warning |

## Recipes and CLI

See `examples/title-recipe.json` and `docs/recipe-v2.schema.json`. V2 has sources, select, exclude and options. Title strings search the known pool. Numeric selectors require a file.

`examples/exclusions-recipe.json` shows extended exclusions. An `exclude` entry is a global title string or an object with one selector (`title`, `titles`, `slides`, `range`, `all: true`) and at most one scope (`file`/`path`, `files`, `directory`, `directories`). Only title exclusions may omit scope. `within` restricts title candidates. Empty exclusion lists do nothing. `options.on_missing_excluded_title` accepts `skip` (default) or `error`. Existing numeric recipe syntax and legacy arrays retain their behavior. Outer exclusions also filter rows contributed by independently validated recipe chunks.

Numeric exclusion lists and title-exclusion `within` lists reject null elements, including nested lists. Top-level `slides: null` still means all, and slice bounds remain nullable. Legacy inclusion lists retain their original behavior. All recipe entry points reject duplicate JSON keys.

```java
MergeSlides.builder().addRecipe(Path.of("recipe.json"))
    .output(Path.of("merged.pptx")).merge();
```

Recipe paths resolve from the recipe's folder. Explicit builder options override a sole loaded recipe. Recipes mixed with other inputs contribute independent ordered selection chunks; ordinary sources stay in their own pool.

Legacy arrays preserve selection-only behavior, aliases, UTF-8 BOM support and replacement policy. They do not gain remaining slides; title fields inside them require migration to v2.

```powershell
java -jar build/libs/merge-slides.jar merge -r recipe.json -o merged.pptx
java -jar build/libs/merge-slides.jar merge -r recipe.json -o merged.pptx --overwrite
```

`--overwrite`/`--no-overwrite` override destination policy. Existing legacy CLI forms remain valid.

## Optional HTTP adapter

`/api/v1/merges` accepts exactly one of inputs, recipePath, or inline recipe, plus output. Existing success fields remain unchanged. Multipart supports legacy/v2 recipes, unique filenames and uploaded-file references only. V2 defaults its pool to upload order when sources are omitted.

Upload exclusions support global titles and single/list uploaded-file scopes, including `all: true`. Directory scopes and non-uploaded paths are rejected; every supplied upload is validated even when excluded.

Keep `exclude`, `select`, `sources`, `options`, and `version` inside the nested `recipe` object in JSON requests. Misplaced controls return a helpful 400. The merger rejects duplicate keys without changing JSON behavior for unrelated host endpoints. [HTTP examples](examples/RestRequests.http) include range exceptions, global titles, uploaded-file scopes and strict missing-title policy.

Scoped controller advice provides safe errors with operation IDs, failure codes and stages. HTTP logging/MDC and the SLF4J bridge are excluded from the library JAR. Transfer failures after headers are committed are logged and cleaned up; they cannot be converted to a JSON response.

Upload limits, media types, request timeouts and logging configuration belong to the application. Direct library calls impose no file-size/upload cap; practical capacity depends on heap and disk. The supplied server retains configurable MERGE_UPLOAD_FILE_LIMIT and MERGE_UPLOAD_REQUEST_LIMIT.

## Output and portability

The Java implementation targets Windows/Linux/macOS; paths must be valid for the current OS. Sources are read only. Corrupt packages fail ZIP/CRC/XML/content-type/relationship/ID validation before output publication.

Create-only output links validated same-directory staging to the destination, preventing replacement by competing writers. Overwrite uses the existing atomic move. Filesystem support is required; unsupported safe commits fail without an unsafe fallback. Existing output survives merge failure. Cleanup failure after commit is a warning.

Existing format/canvas limitations remain: no binary `.ppt`, macro-enabled/encrypted/signed packages, OCR or automatic canvas scaling. Native-object coverage is defined by regression fixtures, not every third-party extension.

When a non-legacy exclusion matches slides, the richest retained contributor supplies the canvas and presentation metadata. Fully excluded inputs remain subject to validation. Jobs using only the older single-file numeric exclusions retain their previous template policy. See [verification and coverage](docs/VERIFICATION.md).
