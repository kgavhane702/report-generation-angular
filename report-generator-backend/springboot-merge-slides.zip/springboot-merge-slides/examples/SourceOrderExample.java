import com.mergeslides.api.lib.*;
import java.nio.file.Path;

/** Run with INPUT.pptx OUTPUT.pptx TITLE_1 TITLE_2, using only the standalone library. */
public final class SourceOrderExample {
    public static void main(String[] args) {
        if (args.length != 4) throw new IllegalArgumentException("Usage: SourceOrderExample INPUT.pptx OUTPUT.pptx TITLE_1 TITLE_2");
        Path input = Path.of(args[0]);
        var job = MergeSlides.builder().searchFiles(input, input)
                .addTitles(args[2], args[3]).duplicateSources(DuplicateSourcePolicy.ALLOW)
                .duplicateTitles(DuplicateTitlePolicy.ALL).onMissing(MissingTitlePolicy.ERROR)
                .remainingSlides(RemainingSlides.NONE).output(Path.of(args[1])).build();
        var preview = job.plan();
        for (var slide : preview.slides()) System.out.println(slide.sourceOccurrence() + ": " + slide.title());
        var result = job.merge();
        System.out.println("Created " + result.outputPath() + " with " + result.slideCount() + " slides");
    }
}
