package com.mergeslides.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mergeslides.api.lib.*;
import com.mergeslides.domain.MergeException;
import com.mergeslides.domain.MergeResult;
import com.mergeslides.domain.SlideSlice;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.IntStream;

/**
 * One executable main demonstrating the public Java function API, without recipes or HTTP.
 *
 * <p>Run from the Spring Boot project: {@code .\gradlew.bat runFunctionScenarios}.
 * To use another copy of these inputs: {@code -PscenarioWorkspace=C:/path/to/workspace}.
 * To keep a run separate, use {@code -PscenarioOutput=C:/path/to/results}.
 * Successful PPTX files and reports go directly into {@code WORKSPACE/function_pptx}.
 * The Gradle task also copies this commented source there for easy review.</p>
 *
 * <p>Defaults: include hidden slides, allow duplicate sources and repeated slides, match ALL
 * duplicate titles, SKIP missing titles with a warning, append remaining slides at END,
 * and protect existing outputs. Title matching is exact except for case. Untitled slides
 * have no special policy: they are eligible for numeric selection and remaining slides.</p>
 *
 * <p>Each numbered example is independent. Normal demo outputs deliberately use overwrite(true)
 * so this runner can be executed again. The convenience example uses a new temporary destination
 * because that overload keeps the library's default create-only behavior. Protection examples
 * use disposable copies, never an original input. This is a scenario demo, not a promise to
 * exercise every possible PPTX feature or every environmental I/O failure.</p>
 */
public final class FunctionScenarioMain {
    private static final String MISSING = "__FUNCTION_DEMO_TITLE_THAT_DOES_NOT_EXIST__";
    private final Path workspace;
    private final Path outputDirectory;
    private final Path scratch;
    private final List<Path> parts;
    private final Path first;
    private final Path overview;
    private final Path hiddenDeck;
    private final Path companion;
    private final Path repeatedTitleDeck;
    private final Map<Path, List<PlannedSlide>> inventories = new LinkedHashMap<>();
    private final List<Map<String, Object>> scenarios = new ArrayList<>();
    private final List<Map<String, Object>> eventLog = new ArrayList<>();
    private final List<String> failures = new ArrayList<>();
    private final List<Path> createdOutputs = new ArrayList<>();
    private final StringBuilder slideOrder = new StringBuilder(
            "scenario\toutput_position\tsource\tsource_occurrence\tsource_slide\torigin\thidden\ttitle\n");
    private Map<String, Object> current;
    private int passed;

    private FunctionScenarioMain(Path root, Path destination) throws IOException {
        workspace = root.toAbsolutePath().normalize();
        outputDirectory = destination == null ? workspace.resolve("function_pptx") : destination.toAbsolutePath().normalize();
        Files.createDirectories(outputDirectory);
        // Disposable inputs stay outside function_pptx; final deliverables have no nested folders.
        scratch = Files.createTempDirectory("merge-functions-");
        parts = IntStream.rangeClosed(1, 4)
                .mapToObj(n -> workspace.resolve("multi_slide_ppt/part_%02d.pptx".formatted(n))).toList();
        first = parts.get(0);
        overview = workspace.resolve("ppts/deck_02_overview.pptx");
        hiddenDeck = workspace.resolve("Merge Slide/test_fixture/decks/merge_test_everything_16x9_final.pptx");
        companion = workspace.resolve("Merge Slide/test_fixture/decks/merge_test_companion_theme_b_4x3_final.pptx");
        repeatedTitleDeck = scratch.resolve("repeated-titles.pptx");
    }

    /** The single entry point: prepare inputs, run every example, then write a complete report. */
    public static void main(String[] args) throws Exception {
        if (args.length > 2) throw new IllegalArgumentException("Usage: FunctionScenarioMain [WORKSPACE] [OUTPUT_DIRECTORY]");
        FunctionScenarioMain demo = new FunctionScenarioMain(args.length >= 1 ? Path.of(args[0]) : defaultWorkspace(),
                args.length == 2 ? Path.of(args[1]) : null);
        try {
            demo.prepare();
            demo.runAll();
        } finally {
            try { demo.writeReports(); }
            finally { demo.removeScratch(); }
        }
        System.out.printf("%nFunction scenarios: %d passed, %d failed; %d verified PPTX outputs.%nFolder: %s%n",
                demo.passed, demo.failures.size(), demo.createdOutputs.size(), demo.outputDirectory);
        if (!demo.failures.isEmpty()) throw new IllegalStateException("Scenario failures: " + demo.failures);
    }

    private static Path defaultWorkspace() {
        Path current = Path.of("").toAbsolutePath().normalize();
        return Files.isDirectory(current.resolve("multi_slide_ppt")) ? current : current.getParent();
    }

    private void prepare() throws IOException {
        for (Path input : concat(parts, List.of(overview, hiddenDeck, companion))) {
            require(Files.isRegularFile(input), "Required workspace input is missing: " + input);
            inventory(input); // plan() is the public, read-only inventory function; no fake missing title.
        }
        require(inventory(first).size() >= 15, "part_01 must contain the expected workspace slides");
        require("Model Risk".equals(inventory(first).get(11).title()), "Expected exact title on part_01 slide 12");
        require("Model Risk".equals(inventory(overview).get(3).title()), "Expected real duplicate title in overview slide 4");
        require(inventory(hiddenDeck).size() == 16 && inventory(hiddenDeck).get(14).hidden(),
                "The 16-slide feature fixture must have hidden slide 15");

        // Build a genuine same-file duplicate-title fixture entirely through public merge functions.
        // Slides 1 and 2 both retain 'Model Risk'; slide 3 is an actual untitled slide.
        MergeSlides.builder().reporter(MergeReporter.silent())
                .addSlides(first, 12, 12, 3).remaining(RemainingSlides.NONE)
                .output(repeatedTitleDeck).merge();
        List<PlannedSlide> repeated = inventory(repeatedTitleDeck);
        require(repeated.get(0).title().equals(repeated.get(1).title()), "Duplicate-title fixture is not duplicated");
        require(repeated.get(2).title() == null, "Third fixture slide must be untitled");
    }

    /** Each run() below shows one ordinary function chain, with an independent expected result. */
    private void runAll() {
        run("01_four_part_whole_deck", "Merge four files in supplied order; include all slides by default.", () ->
                save(job().addFiles(parts), all(parts)));

        run("02_convenience_merge", "Static merge(files, output) overload, without a builder.", () -> {
            Path temporaryOutput = scratch.resolve("convenience-result.pptx");
            MergeResult result = MergeSlides.merge(List.of(first, overview), temporaryOutput);
            require(result.slideCount() == all(first, overview).size(), "Convenience result count");
            Path destination = target();
            Files.copy(temporaryOutput, destination, StandardCopyOption.REPLACE_EXISTING);
            verifyAndRecord(result, destination, all(first, overview), List.of(), null, List.of());
        });

        run("03_explicit_slide_numbers", "One-based picks preserve order and repetitions; NONE selects only these picks.", () ->
                save(job().addSlides(first, 3, 1, 3).remaining(RemainingSlides.NONE), picks(first, 3, 1, 3)));

        run("04_inclusive_range", "addRange(file, first, last) uses inclusive one-based bounds.", () ->
                save(job().addRange(first, 1, 5).remaining(RemainingSlides.NONE), picks(first, 1, 2, 3, 4, 5)));

        run("05_range_collection", "InputSelection.range supports comma-separated ranges and picks.", () ->
                save(job().addFile(first, InputSelection.range("2-4,7")).remaining(RemainingSlides.NONE), picks(first, 2, 3, 4, 7)));

        run("06_negative_picks", "Negative integer picks count backward from the end.", () -> {
            int total = inventory(first).size();
            save(job().addSlides(first, List.of(-1, -2)).remaining(RemainingSlides.NONE), picks(first, total, total - 1));
        });

        run("07_reverse_slice", "SlideSlice is zero-based; omitted bounds and -1 reverse the whole deck.", () -> {
            List<Expected> reversed = new ArrayList<>(all(first));
            Collections.reverse(reversed);
            save(job().addSlice(first, new SlideSlice(null, null, -1)).remaining(RemainingSlides.NONE), reversed);
        });

        run("08_stepped_slice", "A zero-based [0:7:2] slice selects original slides 1, 3, 5, 7.", () ->
                save(job().selectFile(first, InputSelection.slice(new SlideSlice(0, 7, 2)))
                        .remaining(RemainingSlides.NONE), picks(first, 1, 3, 5, 7)));

        run("09_all_slides_helper", "addAll(file) implicitly registers the file and selects every slide.", () ->
                save(job().addAll(first), all(first)));

        run("10_common_selection_for_files", "Apply the same immutable selection independently to each file.", () ->
                save(job().addFiles(List.of(first, overview), InputSelection.slides(List.of(1, 2)))
                        .remaining(RemainingSlides.NONE), concat(picks(first, 1, 2), picks(overview, 1, 2))));

        run("11_typed_input_collection", "MergeInput allows each file to carry its own selection.", () ->
                save(job().addAll(List.of(MergeInput.of(first, InputSelection.slides(3, 1)),
                                MergeInput.of(overview, InputSelection.range("2-3"))))
                        .remaining(RemainingSlides.NONE), concat(picks(first, 3, 1), picks(overview, 2, 3))));

        run("12_whole_directory", "Directories expand nonrecursively in natural filename order.", () ->
                save(job().addDirectory(workspace.resolve("multi_slide_ppt")), all(parts)));

        run("13_title_with_explicit_file", "A file-specific title call implicitly registers that file once.", () ->
                save(job().addTitle(first, "Model Risk").remaining(RemainingSlides.NONE), picks(first, 12)));

        run("14_title_list_with_file", "Pass a List<String> and a specific file; requested title order wins.", () -> {
            String climate = inventory(first).get(12).title(); // Keep exact whitespace and line breaks.
            save(job().addTitles(first, List.of(climate, "Model Risk")).remaining(RemainingSlides.NONE), picks(first, 13, 12));
        });

        run("15_global_title_varargs", "Titles without a file search only the explicitly registered source pool.", () ->
                save(job().searchFiles(parts).addTitles("ORM update", "Model Risk")
                        .remaining(RemainingSlides.NONE), concat(picks(parts.get(2), 9), picks(first, 12))));

        run("16_global_title_list", "addTitles(List<String>) accepts a normal collection of titles.", () ->
                save(job().sources(parts).addTitles(List.of("Model Risk", "ORM update"))
                        .remaining(RemainingSlides.NONE), concat(picks(first, 12), picks(parts.get(2), 9))));

        run("17_directory_title_search", "Search titles across the PPTX files found in one directory.", () -> {
            // The financial title contains a paragraph break: never trim or flatten the extracted text.
            String financialTitle = inventory(parts.get(1)).get(0).title();
            save(job().searchDirectory(workspace.resolve("multi_slide_ppt"))
                    .orderByTitles(List.of(financialTitle, "Model Risk")).remaining(RemainingSlides.NONE),
                    concat(picks(parts.get(1), 1), picks(first, 12)));
        });

        run("18_mixed_title_and_numeric", "Global titles, file-scoped titles and numeric picks share one ordered sequence.", () ->
                save(job().searchFiles(parts).addTitle("ORM update").addTitle(first, "Model Risk")
                        .addSlide(parts.get(1), 3).remaining(RemainingSlides.NONE),
                        concat(picks(parts.get(2), 9), picks(first, 12), picks(parts.get(1), 3))));

        run("19_case_insensitive_exact_title", "Only case is ignored: mOdEl rIsK matches Model Risk.", () ->
                save(job().addTitle(first, "mOdEl rIsK").remaining(RemainingSlides.NONE), picks(first, 12)));

        run("20_no_fuzzy_or_trimmed_matching", "Whitespace, punctuation and partial titles do not match; each miss warns.", () -> {
            MergeReport report = save(job().searchFiles(first).addTitles("Model Risk ", "Model", "Model Risk!"), all(first));
            require(count(report, DiagnosticCode.TITLE_NOT_FOUND) == 3, "Expected three exact-match warnings");
            require(report.summary().missingTitleCount() == 3, "Expected three skipped missing titles");
        });

        run("21_title_within_numbers", "within() filters candidates; repeated/reversed candidate numbers do not reorder matches.", () ->
                save(job().addFile(repeatedTitleDeck, InputSelection.title("Model Risk").within(2, 1, 1))
                        .remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 1, 2)));

        run("22_title_within_range", "withinRange limits title matching to the given original slide numbers.", () ->
                save(job().addFile(repeatedTitleDeck, InputSelection.title("Model Risk").withinRange("2-3"))
                        .remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 2)));

        run("23_title_within_slice", "withinSlice accepts a typed zero-based slice as the candidate filter.", () ->
                save(job().selectFile(repeatedTitleDeck, InputSelection.title("Model Risk")
                        .withinSlice(new SlideSlice(0, 1, 1))).remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 1)));

        run("24_duplicate_titles_all", "ALL is the default: include both matching slides in the same file.", () ->
                save(job().addTitle(repeatedTitleDeck, "Model Risk").remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 1, 2)));

        run("25_duplicate_titles_first", "FIRST picks the earliest eligible title match in source/slide order.", () ->
                save(job().addTitle(repeatedTitleDeck, "Model Risk").duplicateTitles(DuplicateTitlePolicy.FIRST)
                        .remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 1)));

        run("26_duplicate_titles_last", "LAST picks the last eligible title match, not the most recently modified file.", () ->
                save(job().addTitle(repeatedTitleDeck, "Model Risk").duplicateTitles(DuplicateTitlePolicy.LAST)
                        .remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 2)));

        run("27_duplicate_title_across_files", "Distinct input files can contain the same title; ALL includes each match.", () ->
                save(job().searchFiles(first, overview).addTitle("Model Risk").remaining(RemainingSlides.NONE),
                        concat(picks(first, 12), picks(overview, 4))));

        run("28_local_duplicate_override", "A local title policy overrides the job's global duplicate-title policy.", () ->
                save(job().duplicateTitles(DuplicateTitlePolicy.ERROR)
                        .addFile(repeatedTitleDeck, InputSelection.title("Model Risk").duplicates(DuplicateTitlePolicy.FIRST))
                        .remaining(RemainingSlides.NONE), picks(repeatedTitleDeck, 1)));

        run("29_remaining_start", "Unselected alternatives and untitled slides move before the selected block.", () -> {
            MergeReport report = save(job().addTitle(repeatedTitleDeck, "Model Risk")
                    .duplicateTitles(DuplicateTitlePolicy.FIRST).remaining(RemainingSlides.START), picks(repeatedTitleDeck, 2, 3, 1));
            require(report.summary().selectedCount() == 1 && report.summary().remainingCount() == 2, "START summary");
        });

        run("30_remaining_end_default", "END is the default: append the other title match and the untitled slide.", () -> {
            MergeReport report = save(job().addTitle(repeatedTitleDeck, "Model Risk")
                    .duplicateTitles(DuplicateTitlePolicy.FIRST), picks(repeatedTitleDeck, 1, 2, 3));
            require(report.slides().get(2).title() == null, "Untitled slide must remain at the end");
        });

        run("31_remaining_none", "NONE drops all slides that were not explicitly selected.", () ->
                save(job().addTitle(repeatedTitleDeck, "Model Risk").duplicateTitles(DuplicateTitlePolicy.FIRST)
                        .remainingSlides(RemainingSlides.NONE), picks(repeatedTitleDeck, 1)));

        run("32_missing_global_title_skipped", "Missing global titles SKIP with a warning; remaining slides are still appended.", () -> {
            MergeReport report = save(job().searchFiles(first).addTitle(MISSING), all(first));
            require(count(report, DiagnosticCode.TITLE_NOT_FOUND) == 1, "Missing-title warning");
        });

        run("33_missing_file_title_skipped", "The same SKIP default applies when a title is scoped to a file.", () -> {
            MergeReport report = save(job().addTitle(first, MISSING).onMissing(MissingTitlePolicy.SKIP), all(first));
            require(count(report, DiagnosticCode.TITLE_NOT_FOUND) == 1, "File-scoped missing-title warning");
        });

        run("34_global_skip_hidden", "skipHidden() means true and removes the fixture's original slide 15.", () -> {
            MergeReport report = save(job().addFile(hiddenDeck).skipHidden(), without(all(hiddenDeck), e -> e.slide() == 15));
            require(report.summary().hiddenFilteredCount() == 1, "One hidden slide must be filtered");
        });

        run("35_include_hidden_explicit_false", "skipHidden(false), like omission, retains hidden slides and their flags.", () ->
                save(job().addFile(hiddenDeck).skipHidden(false), all(hiddenDeck)));

        run("36_selection_range_skip_hidden", "Per-input hidden filtering also works for a range selection.", () ->
                save(job().addFile(hiddenDeck, InputSelection.range("14-16").skipHidden())
                        .remaining(RemainingSlides.NONE), picks(hiddenDeck, 14, 16)));

        run("37_local_false_overrides_global_true", "An explicit selection can include a hidden slide despite the global filter.", () ->
                save(job().skipHidden().selectFile(hiddenDeck, InputSelection.slides(15).skipHidden(false))
                        .remaining(RemainingSlides.NONE), picks(hiddenDeck, 15)));

        run("38_local_hidden_filter_applies_to_remaining", "A hidden slide suppressed by its selection cannot return through END.", () ->
                save(job().searchFiles(hiddenDeck).selectFile(hiddenDeck, InputSelection.range("14-16").skipHidden()),
                        concat(picks(hiddenDeck, 14, 16), picks(hiddenDeck, IntStream.rangeClosed(1, 13).toArray()))));

        run("39_explicit_hidden_restoration", "A later explicit skipHidden(false) selection can restore a locally suppressed slide.", () ->
                save(job().searchFiles(hiddenDeck).selectFile(hiddenDeck, InputSelection.range("14-16").skipHidden())
                        .selectFile(hiddenDeck, InputSelection.slides(15).skipHidden(false)),
                        concat(picks(hiddenDeck, 14, 16, 15), picks(hiddenDeck, IntStream.rangeClosed(1, 13).toArray()))));

        run("40_title_order_with_skip_hidden", "Title ordering and global hidden filtering compose; untitled visible slides remain.", () ->
                save(job().searchFiles(first, hiddenDeck).addTitle("Model Risk").skipHidden(),
                        concat(picks(first, 12), without(all(first), e -> e.slide() == 12),
                                without(all(hiddenDeck), e -> e.slide() == 15))));

        run("41_hard_slide_and_range_exclusions", "Hard exclusions remove slides from explicit picks and remaining slides.", () ->
                save(job().searchFiles(first).addSlides(first, 3, 2, 4).excludeSlide(first, 2).excludeRange(first, 4, 5),
                        concat(picks(first, 3), without(all(first), e -> Set.of(2, 3, 4, 5).contains(e.slide())))));

        run("42_hard_exclusion_wins_over_hidden_override", "An exclusion wins even when a local selection explicitly includes hidden slides.", () ->
                save(job().selectFile(hiddenDeck, InputSelection.slides(15, 16).skipHidden(false)).excludeSlides(hiddenDeck, List.of(15))
                        .remaining(RemainingSlides.NONE), picks(hiddenDeck, 16)));

        run("43_repeated_source_allowed", "Duplicate source paths are allowed; bound selections do not form a cross-product.", () -> {
            MergeReport report = save(job().addFile(first, InputSelection.slides(1)).addFile(first, InputSelection.slides(3))
                    .remaining(RemainingSlides.NONE), picks(first, 1, 3));
            require(report.summary().sourceCount() == 2, "Two explicitly supplied source occurrences");
            require(report.slides().get(0).sourceOccurrence() != report.slides().get(1).sourceOccurrence(), "Separate source bindings");
        });

        run("44_duplicate_sources_skipped", "duplicateSources(SKIP) registers only the first occurrence of the same physical file.", () ->
                save(job().addFiles(first, first).duplicateSources(DuplicateSourcePolicy.SKIP), all(first)));

        run("45_repeated_title_request_allowed", "Repeated requests may emit the same physical slide again; ALLOW is the default.", () ->
                save(job().searchFiles(first).addTitles("Model Risk", "model risk").remaining(RemainingSlides.NONE), picks(first, 12, 12)));

        run("46_repeated_slides_skipped", "repeatedSlides(SKIP) keeps the first physical occurrence in final output order.", () -> {
            MergeReport report = save(job().searchFiles(first).addTitles("Model Risk", "model risk")
                    .repeatedSlides(RepeatedSlidePolicy.SKIP).remaining(RemainingSlides.NONE), picks(first, 12));
            require(report.summary().duplicateFilteredCount() == 1, "One repeated slide must be removed");
        });

        run("47_read_only_preview", "plan()/preview() reads sources without writing a PPTX or emitting merge events.", () -> {
            List<MergeEvent> events = new ArrayList<>();
            Path previewOutput = scratch.resolve("never-written.pptx");
            // Omit operationId here to demonstrate its generated-per-execution default.
            // job() intentionally supplies a stable application correlation ID in other examples.
            MergeJob selection = MergeSlides.builder().baseDirectory(workspace).reporter(events::add)
                    .addSlide(first, 3).remaining(RemainingSlides.NONE)
                    .output(previewOutput).build();
            MergePlan one = selection.plan();
            MergePlan two = selection.preview();
            assertPlan(one.slides(), picks(first, 3));
            assertPlan(two.slides(), picks(first, 3));
            require(!one.operationId().equals(two.operationId()), "Fresh operation ID per execution");
            require(!Files.exists(previewOutput) && events.isEmpty(), "Preview must have no output/events");
        });

        run("48_reusable_client_relative_paths", "MergeClient supplies the base directory and reporter for ordinary newJob() calls.", () -> {
            MergeClient client = MergeSlides.client().baseDirectory(workspace).reporter(this::logEvent).build();
            save(client.newJob().operationId(id()).addSlide(Path.of("multi_slide_ppt/part_01.pptx"), 1)
                    .remaining(RemainingSlides.NONE), picks(first, 1));
        });

        run("49_application_logging_and_warning", "An application reporter receives structured warning and completion events automatically.", () -> {
            List<MergeEvent> events = new ArrayList<>();
            MergeReport report = save(job().reporter(event -> { events.add(event); logEvent(event); })
                    .addTitle(first, MISSING), all(first));
            require(events.stream().filter(e -> e.code().equals("TITLE_NOT_FOUND") && e.severity() == Severity.WARN).count() == 1,
                    "Exactly one missing-title warning callback");
            require(events.stream().filter(e -> e.type() == MergeEvent.Type.COMPLETED).count() == 1, "One completion callback");
            require(events.stream().allMatch(e -> e.operationId().equals(report.operationId())), "Correlated application operation ID");
            require(report.result().warnings().size() >= 1, "Warnings remain accessible through MergeResult");
        });

        run("50_reporter_failure_is_nonfatal", "A consumer's broken logger is disabled; the merge returns REPORTER_FAILED as a warning.", () -> {
            MergeReport report = save(job().reporter(event -> { throw new IllegalStateException("Example logger unavailable"); })
                    .addSlide(first, 12).remaining(RemainingSlides.NONE), picks(first, 12));
            require(count(report, DiagnosticCode.REPORTER_FAILED) == 1, "Broken reporter diagnostic");
        });

        run("51_mixed_slide_sizes_and_complex_objects", "Merge the real 16:9/4:3 feature decks and inspect the size warning.", () -> {
            MergeReport report = save(job().addFiles(hiddenDeck, companion), all(hiddenDeck, companion));
            require(count(report, DiagnosticCode.MIXED_SLIDE_SIZE) >= 1, "Mixed-size warning is expected");
        });

        run("52_source_pool_without_selectors", "No selectors means merge all eligible sources, even when remaining is NONE.", () ->
                save(job().searchFiles(first).remaining(RemainingSlides.NONE), all(first)));

        run("53_duplicate_title_error", "Opt-in ERROR rejects multiple eligible matches for a requested title.", () ->
                reject(DiagnosticCode.DUPLICATE_TITLE, () -> job().addTitle(repeatedTitleDeck, "Model Risk")
                        .duplicateTitles(DuplicateTitlePolicy.ERROR).output(target()).merge()));

        run("54_duplicate_source_error", "Duplicate source ERROR concerns physical input files, independently of their titles.", () ->
                reject(DiagnosticCode.DUPLICATE_SOURCE, () -> job().addFiles(first, first)
                        .duplicateSources(DuplicateSourcePolicy.ERROR).output(target()).merge()));

        run("55_repeated_slide_error", "Repeated-slide ERROR concerns emitting the same physical slide more than once.", () ->
                reject(DiagnosticCode.REPEATED_SLIDE, () -> job().addSlides(first, 1, 1)
                        .repeatedSlides(RepeatedSlidePolicy.ERROR).output(target()).merge()));

        run("56_missing_title_strict_error", "onMissing(ERROR) is optional; the exception exposes title, source, stage and selection index.", () -> {
            MergeException error = reject(DiagnosticCode.TITLE_NOT_FOUND, () -> job().addTitle(first, MISSING)
                    .onMissing(MissingTitlePolicy.ERROR).output(target()).merge());
            MergeDiagnostic diagnostic = error.diagnostics().get(error.diagnostics().size() - 1);
            require(MISSING.equals(diagnostic.details().get("title")) && diagnostic.selectionIndex() == 1
                    && first.toString().equals(diagnostic.source()), "Structured missing-title location");
        });

        run("57_title_has_only_excluded_matches", "A real title whose matches are all excluded produces a specific SKIP warning.", () -> {
            MergeReport report = save(job().addTitle(first, "Model Risk").excludeSlide(first, 12),
                    without(all(first), e -> e.slide() == 12));
            require(count(report, DiagnosticCode.TITLE_NO_ELIGIBLE_MATCH) == 1, "Excluded title warning");
        });

        run("58_invalid_slide_error", "An out-of-range individual pick is an INVALID_SELECTION error.", () ->
                reject(DiagnosticCode.INVALID_SELECTION, () -> job().addSlide(first, 999).output(target()).merge()));

        run("59_zero_slice_step_error", "A zero slice step is invalid, rather than silently producing an empty selection.", () ->
                reject(DiagnosticCode.INVALID_SELECTION, () -> job().addSlice(first, new SlideSlice(null, null, 0)).output(target()).merge()));

        run("60_missing_file_error", "A missing explicit file fails the operation even alongside a valid source.", () ->
                reject(DiagnosticCode.SOURCE_NOT_FOUND, () -> job().searchFiles(first, scratch.resolve("missing.pptx"))
                        .output(target()).merge()));

        run("61_missing_directory_error", "A missing directory is a source error, not a missing-title warning.", () ->
                reject(DiagnosticCode.SOURCE_NOT_FOUND, () -> job().addDirectory(scratch.resolve("missing-directory"))
                        .output(target()).merge()));

        run("62_no_pptx_in_directory_error", "A directory with only text/nested PPTX files is empty for nonrecursive discovery.", () -> {
            Path folder = Files.createDirectory(scratch.resolve("no-top-level-pptx"));
            Files.writeString(folder.resolve("readme.txt"), "Not a presentation");
            Path nested = Files.createDirectory(folder.resolve("nested"));
            Files.copy(repeatedTitleDeck, nested.resolve("nested.pptx"));
            reject(DiagnosticCode.DIRECTORY_EMPTY, () -> job().searchFiles(first).addDirectory(folder).output(target()).merge());
        });

        run("63_corrupt_input_preserves_destination", "Corrupt PPTX data fails before replacing an existing destination, even with overwrite enabled.", () -> {
            Path bad = Files.writeString(scratch.resolve("corrupt.pptx"), "This is not a ZIP/PPTX package");
            Path protectedOutput = Files.copy(repeatedTitleDeck, scratch.resolve("protected-from-corruption.pptx"));
            byte[] before = Files.readAllBytes(protectedOutput);
            reject(DiagnosticCode.INVALID_PRESENTATION, () -> job().searchFiles(first, bad)
                    .output(protectedOutput).overwrite(true).merge());
            require(Arrays.equals(before, Files.readAllBytes(protectedOutput)), "Existing destination changed after corrupt input");
        });

        run("64_no_eligible_slides_error", "A skipped missing title plus remaining NONE leaves no output and raises NO_ELIGIBLE_SLIDES.", () -> {
            MergeException error = reject(DiagnosticCode.NO_ELIGIBLE_SLIDES, () -> job().addTitle(first, MISSING)
                    .remaining(RemainingSlides.NONE).output(target()).merge());
            require(error.diagnostics().stream().anyMatch(d -> d.code() == DiagnosticCode.TITLE_NOT_FOUND && d.severity() == Severity.WARN),
                    "Earlier warning must remain attached to the failure");
        });

        run("65_existing_destination_protected", "Overwrite defaults to false; an existing valid PPTX is preserved byte for byte.", () -> {
            Path protectedOutput = Files.copy(repeatedTitleDeck, scratch.resolve("protected-existing.pptx"));
            byte[] before = Files.readAllBytes(protectedOutput);
            reject(DiagnosticCode.OUTPUT_EXISTS, () -> job().addFile(first).output(protectedOutput).merge());
            require(Arrays.equals(before, Files.readAllBytes(protectedOutput)), "Existing output was modified");
        });

        run("66_output_cannot_be_input", "Even overwrite(true) cannot overwrite an input presentation.", () -> {
            Path source = Files.copy(repeatedTitleDeck, scratch.resolve("input-is-output.pptx"));
            byte[] before = Files.readAllBytes(source);
            reject(DiagnosticCode.OUTPUT_IS_SOURCE, () -> job().addFile(source).output(source).overwrite(true).merge());
            require(Arrays.equals(before, Files.readAllBytes(source)), "Source was modified");
        });

        run("67_global_title_needs_sources", "A title alone cannot discover arbitrary files; give a source pool or a file-specific title.", () ->
                reject(DiagnosticCode.INVALID_REQUEST, () -> job().addTitle("Model Risk").output(target()).merge()));

        run("68_blank_title_error", "Blank requested titles are invalid; untitled source slides are handled by remaining/numeric selection.", () ->
                reject(DiagnosticCode.INVALID_REQUEST, () -> job().addTitle(first, "   ").output(target()).merge()));

        run("69_invalid_output_extension", "Function merges produce PPTX and reject an output filename with another extension.", () ->
                reject(DiagnosticCode.INVALID_REQUEST, () -> job().addFile(first).output(scratch.resolve("out.pdf")).merge()));

        run("70_invalid_candidate_pick", "Title candidate picks are validated just like explicit numeric picks.", () ->
                reject(DiagnosticCode.INVALID_SELECTION, () -> job().selectFile(first, InputSelection.title("Model Risk").within(999))
                        .output(target()).merge()));

        run("71_merge_needs_output", "Planning requires no output; executing merge() requires an output path.", () ->
                reject(DiagnosticCode.INVALID_REQUEST, () -> job().addFile(first).merge()));

        run("72_directory_natural_order_and_ignored_files", "Natural sorting puts slide2 before slide10; locks, nested inputs and destination are ignored.", () -> {
            Path folder = Files.createDirectory(scratch.resolve("natural-order"));
            Path two = Files.copy(repeatedTitleDeck, folder.resolve("slide2.pptx"));
            Path ten = Files.copy(repeatedTitleDeck, folder.resolve("slide10.pptx"));
            Files.writeString(folder.resolve("~$locked.pptx"), "Office lock file, intentionally not a valid PPTX");
            Files.writeString(folder.resolve("notes.txt"), "ignored");
            Files.copy(repeatedTitleDeck, Files.createDirectory(folder.resolve("nested")).resolve("ignored.pptx"));
            Path destination = Files.copy(repeatedTitleDeck, folder.resolve("destination.pptx"));
            // The destination must be supplied during discovery so the existing file is excluded.
            MergeReport report = job().addDirectory(folder, InputSelection.slides(1)).remaining(RemainingSlides.NONE)
                    .output(destination).overwrite(true).mergeDetailed();
            List<Expected> expected = concat(picks(two, 1), picks(ten, 1));
            assertPlan(report.slides(), expected);
            Files.copy(destination, target(), StandardCopyOption.REPLACE_EXISTING);
            verifyAndRecord(report.result(), target(), expected, report.diagnostics(), report.summary(), report.slides());
        });

        run("73_exclusions_apply_to_repeated_sources", "Hard exclusions use physical slide identity and affect every occurrence of a source.", () ->
                save(job().addFile(first, InputSelection.slides(1, 2)).addFile(first, InputSelection.slides(2, 3))
                        .exclude(first, InputSelection.slides(2)).remaining(RemainingSlides.NONE), picks(first, 1, 3)));

        run("74_within_does_not_restrict_remaining", "Candidate restrictions affect title matching only; other slides still append at END.", () ->
                save(job().addFile(repeatedTitleDeck, InputSelection.title("Model Risk").within(List.of(2))),
                        picks(repeatedTitleDeck, 2, 1, 3)));

        run("75_clamped_range", "Ranges clamp to deck bounds; an out-of-range individual pick would instead fail.", () ->
                save(job().addRange(first, 14, 999).remaining(RemainingSlides.NONE), picks(first, 14, 15)));

        run("76_empty_candidate_list", "An empty within list means no candidates, so a missing-title warning is returned.", () -> {
            MergeReport report = save(job().addFile(first, InputSelection.title("Model Risk").within(List.of())), all(first));
            require(count(report, DiagnosticCode.TITLE_NOT_FOUND) == 1, "Empty candidate list must not mean unrestricted search");
        });

        run("77_exclude_global_title_list", "All slides except listed titles across every registered source.", () ->
                save(job().addFiles(List.of(first, overview)).excludeTitles(List.of("Model Risk")),
                        withoutTitles(all(first, overview), List.of("Model Risk"))));

        run("78_exclude_titles_in_one_file", "A file-specific title list leaves the same title in other files intact.", () ->
                save(job().addFiles(first, overview).excludeTitles(first, List.of("Model Risk")),
                        concat(withoutTitles(all(first), List.of("Model Risk")), all(overview))));

        run("79_exclude_titles_in_file_list", "A title exclusion takes both a file list and a title list.", () ->
                save(job().addFiles(List.of(first, overview)).excludeTitles(List.of(first, overview), List.of("Model Risk")),
                        withoutTitles(all(first, overview), List.of("Model Risk"))));

        run("80_exclude_number_list_in_file_list", "Apply the same original slide-number exceptions independently to each file.", () ->
                save(job().addFiles(List.of(first, overview)).excludeSlides(List.of(first, overview), List.of(3, 6)),
                        without(all(first, overview), e -> Set.of(3, 6).contains(e.slide()))));

        List<Expected> selectedRanges = concat(picks(first, 1,2,4,5,7,8,9,10), picks(overview, 1,2,4,5,7,8,9,10));
        List<Expected> rangeRemainder = without(all(first, overview), e -> e.slide() <= 10);
        run("81_range_exceptions_none", "Select 1-10 in each file, excluding 3 and 6; NONE keeps only those selections.", () ->
                save(job().addFiles(List.of(first, overview), InputSelection.range("1-10"))
                        .excludeSlides(List.of(first, overview), 3, 6).remaining(RemainingSlides.NONE), selectedRanges));
        run("82_range_exceptions_end", "END appends eligible slides outside the selected ranges without restoring exclusions.", () ->
                save(job().addFiles(List.of(first, overview), InputSelection.range("1-10"))
                        .excludeSlides(List.of(first, overview), List.of(3, 6)).remaining(RemainingSlides.END), concat(selectedRanges, rangeRemainder)));
        run("83_range_exceptions_start", "START prepends the eligible remainder without restoring exclusions.", () ->
                save(job().addFiles(List.of(first, overview), InputSelection.range("1-10"))
                        .excludeSlides(List.of(first, overview), 3, 6).remaining(RemainingSlides.START), concat(rangeRemainder, selectedRanges)));

        run("84_directory_title_search_and_exclusion", "Search a directory without filenames; explicit excluded titles skip even in strict inclusion mode.", () -> {
            List<Path> copies = copyDirectory("exclude-title-search", first, overview);
            save(job().searchDirectory(copies.get(0).getParent()).addTitles(List.of("Model Risk"))
                    .excludeTitles(List.of("Model Risk")).onMissing(MissingTitlePolicy.ERROR), withoutTitles(all(copies), List.of("Model Risk")));
        });
        run("85_directory_range_exceptions", "Apply numeric list exceptions to each file in a directory range selection.", () -> {
            List<Path> copies = copyDirectory("exclude-directory-ranges", first, overview);
            save(job().addDirectory(copies.get(0).getParent(), InputSelection.range("1-10"))
                    .excludeDirectory(copies.get(0).getParent(), InputSelection.slides(List.of(3, 6))).remaining(RemainingSlides.NONE),
                    concat(picks(copies.get(0), 1,2,4,5,7,8,9,10), picks(copies.get(1), 1,2,4,5,7,8,9,10)));
        });
        run("86_multiple_directories_exclude_ranges", "Directory-list range rules leave a standalone outside source intact.", () -> {
            List<Path> left = copyDirectory("exclude-left", first), right = copyDirectory("exclude-right", overview);
            List<Path> directories = List.of(left.get(0).getParent(), right.get(0).getParent());
            save(job().addFiles(directories).addFile(first).excludeDirectories(directories, InputSelection.range("3-6")),
                    concat(without(all(concat(left, right)), e -> e.slide() >= 3 && e.slide() <= 6), all(first)));
        });
        run("87_exclude_whole_files", "Omit entire registered presentations using a file list.", () ->
                save(job().addFiles(first, overview).excludeFiles(List.of(overview)), all(first)));
        run("88_exclude_whole_directory", "Omit every registered presentation in a directory while keeping an outside file.", () -> {
            List<Path> copies = copyDirectory("exclude-whole-directory", first, overview);
            save(job().addDirectory(copies.get(0).getParent()).addFile(first).excludeDirectory(copies.get(0).getParent()), all(first));
        });
        run("89_combined_title_number_and_range", "Overlapping title, number and range exclusions form a union.", () ->
                save(job().addAll(first).excludeTitle(first, "Model Risk").excludeSlides(first, List.of(2, 3)).excludeRange(first, 4, 6),
                        withoutTitles(without(all(first), e -> e.slide() >= 2 && e.slide() <= 6), List.of("Model Risk"))));
        run("90_slice_exclusions", "Existing zero-based slices can exclude a nonconsecutive subset.", () ->
                save(job().addAll(first).exclude(first, InputSelection.slice(new SlideSlice(2, 6, 3))),
                        without(all(first), e -> Set.of(3, 6).contains(e.slide()))));
        run("91_missing_excluded_title_warns", "Missing exclusions warn once per requested title across their whole scope.", () -> {
            MergeReport report = save(job().addFiles(first, overview).excludeTitles(List.of(first, overview), List.of(MISSING)), all(first, overview));
            require(count(report, DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND) == 1, "Missing exclusion warning count");
        });
        run("92_missing_excluded_title_strict", "A separate strict exclusion policy fails before output writing.", () ->
                reject(DiagnosticCode.EXCLUDED_TITLE_NOT_FOUND, () -> job().addAll(first).excludeTitle(MISSING)
                        .onMissingExcludedTitle(MissingTitlePolicy.ERROR).output(target()).overwrite(true).merge()));
        run("93_exclude_everything", "Excluding the only source fails with NO_ELIGIBLE_SLIDES.", () ->
                reject(DiagnosticCode.NO_ELIGIBLE_SLIDES, () -> job().addAll(first).excludeFile(first).output(target()).overwrite(true).merge()));
        run("94_repeated_source_title_exclusions", "Title exclusions affect every occurrence of a physical source slide.", () ->
                save(job().addFiles(first, first).excludeTitle("Model Risk"),
                        withoutTitles(all(first, first), List.of("Model Risk"))));
        run("95_heterogeneous_input_list_with_exclusion", "Per-file input selections coexist with a global title exclusion.", () ->
                save(job().addAll(List.of(MergeInput.of(first, InputSelection.range("1-10")),
                                MergeInput.of(overview, InputSelection.titles(List.of("Model Risk")))))
                        .excludeTitle("Model Risk").remaining(RemainingSlides.NONE),
                        withoutTitles(picks(first, 1,2,3,4,5,6,7,8,9,10), List.of("Model Risk"))));
        run("96_all_selection_exclusion", "InputSelection.all() is reusable for whole-file exclusions.", () ->
                save(job().addFiles(first, overview).exclude(List.of(first), InputSelection.all()), all(overview)));
        run("97_title_exclusion_within_candidates", "within limits title-exclusion candidates using original slide numbers.", () ->
                save(job().addAll(first).exclude(first, InputSelection.title("Model Risk").within(List.of(12))),
                        without(all(first), e -> e.slide() == 12)));
        run("98_multiple_excluded_ranges", "Comma-separated exclusion ranges reuse the existing numeric parser.", () ->
                save(job().addAll(first).exclude(List.of(first), InputSelection.range("2-4,7-9")),
                        without(all(first), e -> Set.of(2,3,4,7,8,9).contains(e.slide()))));
    }

    private List<Path> copyDirectory(String name, Path... inputs) throws IOException {
        Path folder = Files.createDirectory(scratch.resolve(name)); var copies = new ArrayList<Path>();
        for (int i = 0; i < inputs.length; i++) copies.add(Files.copy(inputs[i], folder.resolve("deck_%02d.pptx".formatted(i + 1))));
        return copies;
    }
    private List<Expected> withoutTitles(List<Expected> rows, List<String> titles) {
        return without(rows, e -> titles.stream().anyMatch(t -> t.equalsIgnoreCase(inventory(e.file()).get(e.slide() - 1).title())));
    }

    // The helpers below only manage verification/reporting. Every merge above uses the public API.
    private MergeSlides.Builder job() {
        return MergeSlides.builder().baseDirectory(workspace).reporter(this::logEvent).operationId(id());
    }

    private String id() { return "function-" + current.get("name"); }
    private Path target() { return outputDirectory.resolve(current.get("name") + ".pptx"); }

    /** Build once, inspect the plan, execute once, then independently reopen the produced package. */
    private MergeReport save(MergeSlides.Builder builder, List<Expected> expected) throws IOException {
        MergeJob merge = builder.output(target()).overwrite(true).build();
        MergePlan plan = merge.plan();
        assertPlan(plan.slides(), expected);
        MergeReport report = merge.mergeDetailed();
        assertPlan(report.slides(), expected);
        require(plan.summary().equals(report.summary()), "Preview/execution summary differs");
        verifyAndRecord(report.result(), target(), expected, report.diagnostics(), report.summary(), report.slides());
        return report;
    }

    private void verifyAndRecord(MergeResult result, Path output, List<Expected> expected,
                                 List<MergeDiagnostic> diagnostics, MergeSummary summary, List<PlannedSlide> provenance) throws IOException {
        require(Files.isRegularFile(output) && Files.size(output) > 0, "Output PPTX is missing/empty");
        require(result.slideCount() == expected.size(), "MergeResult has the wrong slide count");
        // Reopening through the public planner validates the saved package and its relationships.
        List<PlannedSlide> reopened = MergeSlides.builder().reporter(MergeReporter.silent()).searchFiles(output).plan().slides();
        require(reopened.size() == expected.size(), "Saved PPTX has the wrong slide count");
        for (int i = 0; i < expected.size(); i++) {
            Expected row = expected.get(i);
            PlannedSlide source = inventory(row.file()).get(row.slide() - 1);
            PlannedSlide actual = reopened.get(i);
            require(Objects.equals(source.title(), actual.title()), "Saved title/order mismatch at output slide " + (i + 1));
            require(source.hidden() == actual.hidden(), "Saved hidden flag mismatch at output slide " + (i + 1));
            PlannedSlide detail = provenance.isEmpty() ? null : provenance.get(i);
            slideOrder.append(tsv(current.get("name"))).append('\t').append(i + 1).append('\t')
                    .append(tsv(display(row.file()))).append('\t').append(detail == null ? "" : detail.sourceOccurrence())
                    .append('\t').append(row.slide()).append('\t').append(detail == null ? "EXPECTED_STATIC_MERGE" : detail.origin())
                    .append('\t').append(source.hidden()).append('\t').append(tsv(source.title())).append('\n');
        }
        createdOutputs.add(output);
        current.put("output", output.getFileName().toString());
        current.put("slideCount", expected.size());
        current.put("sha256", sha256(output));
        current.put("verified", "Source order in plan/report; saved package reopened; count, titles and hidden flags checked");
        current.put("summary", summary == null ? Map.of() : summary);
        current.put("diagnostics", diagnostics);
        current.put("warnings", result.warnings());
        current.put("sourceOrder", expected.stream().map(e -> display(e.file()) + ":" + e.slide()).toList());
    }

    private void assertPlan(List<PlannedSlide> actual, List<Expected> expected) {
        require(actual.size() == expected.size(), "Expected " + expected.size() + " planned slides, got " + actual.size());
        for (int i = 0; i < actual.size(); i++) {
            PlannedSlide row = actual.get(i); Expected wanted = expected.get(i);
            require(row.outputPosition() == i + 1 && row.file().toAbsolutePath().normalize().equals(wanted.file())
                    && row.slideNumber() == wanted.slide(), "Wrong planned source/order at position " + (i + 1));
        }
    }

    /** Assert the precise failure code; unrelated failures cannot accidentally pass an error example. */
    private MergeException reject(DiagnosticCode expected, CheckedAction action) throws Exception {
        boolean targetExisted = Files.exists(target());
        try { action.run(); }
        catch (MergeException error) {
            require(error.failureCode() == expected, "Expected " + expected + " but got " + error.failureCode());
            if (!targetExisted) require(!Files.exists(target()), "Failure left an unexpected output PPTX");
            current.put("expectedFailureCode", expected.name());
            current.put("errorStage", error.stage());
            current.put("diagnostics", error.diagnostics());
            current.put("operationId", error.operationId());
            return error;
        }
        throw new IllegalStateException("Expected " + expected + " but the operation succeeded");
    }

    private void run(String name, String purpose, CheckedAction action) {
        current = new LinkedHashMap<>(); current.put("name", name); current.put("purpose", purpose);
        long started = System.nanoTime();
        try { action.run(); current.put("status", "PASS"); passed++; System.out.println("PASS " + name); }
        catch (Exception | AssertionError error) {
            current.put("status", "FAIL"); current.put("failure", error.toString());
            failures.add(name + ": " + error); System.err.println("FAIL " + name + ": " + error);
        } finally {
            current.put("elapsedMillis", (System.nanoTime() - started) / 1_000_000);
            scenarios.add(current);
        }
    }

    /** Replace this callback with log.warn/log.error/etc. in a consuming application. */
    private void logEvent(MergeEvent event) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("scenario", current == null ? "setup" : current.get("name"));
        row.put("time", event.timestamp().toString()); row.put("operationId", event.operationId());
        row.put("type", event.type()); row.put("severity", event.severity()); row.put("stage", event.stage());
        row.put("code", event.code()); row.put("message", event.message()); row.put("diagnostic", event.diagnostic());
        eventLog.add(row);
        if (event.severity() == Severity.WARN || event.severity() == Severity.ERROR)
            System.out.printf("  %s %s [%s] %s%n", event.severity(), event.code(), event.operationId(), event.message());
    }

    private List<PlannedSlide> inventory(Path file) {
        Path key = file.toAbsolutePath().normalize();
        return inventories.computeIfAbsent(key, p -> MergeSlides.builder().reporter(MergeReporter.silent()).searchFiles(p).plan().slides());
    }

    private List<Expected> all(Path... files) { return all(Arrays.asList(files)); }
    private List<Expected> all(List<Path> files) {
        return files.stream().flatMap(file -> IntStream.rangeClosed(1, inventory(file).size())
                .mapToObj(number -> new Expected(file, number))).toList();
    }
    private List<Expected> picks(Path file, int... numbers) {
        return Arrays.stream(numbers).mapToObj(n -> new Expected(file, n)).toList();
    }
    @SafeVarargs private static <T> List<T> concat(List<T>... lists) {
        return Arrays.stream(lists).flatMap(Collection::stream).toList();
    }
    private static List<Expected> without(List<Expected> rows, Predicate<Expected> excluded) {
        return rows.stream().filter(excluded.negate()).toList();
    }
    private static long count(MergeReport report, DiagnosticCode code) {
        return report.diagnostics().stream().filter(d -> d.code() == code && d.severity() == Severity.WARN).count();
    }
    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
    private String display(Path file) {
        Path path = file.toAbsolutePath().normalize();
        if (path.startsWith(workspace)) return workspace.relativize(path).toString().replace('\\', '/');
        if (path.startsWith(scratch)) return "[temporary-demo-input]/" + scratch.relativize(path).toString().replace('\\', '/');
        return path.toString();
    }
    private static String tsv(Object value) {
        return value == null ? "" : value.toString().replace("\t", "\\t").replace("\r", "\\r").replace("\n", "\\n");
    }
    private static String sha256(Path path) throws IOException {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path))); }
        catch (java.security.NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }

    private void writeReports() throws IOException {
        ObjectMapper json = new ObjectMapper();
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("generatedAt", Instant.now().toString()); report.put("workspace", workspace.toString());
        report.put("javaVersion", System.getProperty("java.version")); report.put("os", System.getProperty("os.name"));
        report.put("total", scenarios.size()); report.put("passed", passed); report.put("failed", failures.size());
        report.put("pptxOutputs", createdOutputs.size()); report.put("scenarios", scenarios);
        json.writerWithDefaultPrettyPrinter().writeValue(outputDirectory.resolve("scenario-report.json").toFile(), report);
        StringBuilder events = new StringBuilder();
        for (Map<String, Object> event : eventLog) events.append(json.writeValueAsString(event)).append('\n');
        Files.writeString(outputDirectory.resolve("merge-events.jsonl"), events, StandardCharsets.UTF_8);
        Files.writeString(outputDirectory.resolve("slide-order.tsv"), slideOrder, StandardCharsets.UTF_8);
        StringBuilder inputs = new StringBuilder("source\tsource_slide\thidden\ttitle\n");
        inventories.forEach((file, rows) -> {
            for (PlannedSlide row : rows) inputs.append(tsv(display(file))).append('\t').append(row.slideNumber())
                    .append('\t').append(row.hidden()).append('\t').append(tsv(row.title())).append('\n');
        });
        Files.writeString(outputDirectory.resolve("input-inventory.tsv"), inputs, StandardCharsets.UTF_8);
        StringBuilder readme = new StringBuilder("# Function-call PPTX scenarios\n\n")
                .append(passed).append(" passed, ").append(failures.size()).append(" failed; ")
                .append(createdOutputs.size()).append(" successful PPTX outputs.\n\n")
                .append("Run from `springboot-merge-slides`: `./gradlew.bat runFunctionScenarios`. ")
                .append("Optional: `-PscenarioWorkspace=\"C:/path/to/workspace\"`. ")
                .append("One entry point: `com.mergeslides.demo.FunctionScenarioMain`. ")
                .append("The commented source is `FunctionScenarioMain.java` in this folder and `examples/FunctionScenarioMain.java` in the project.\n\n")
                .append("All merge scenarios use public Java function calls. JSON files here are verification reports, not input recipes. ")
                .append("Numbered successful examples write directly into this folder. Expected errors and read-only previews produce no PPTX. ")
                .append("Re-running replaces this runner's named demo outputs/reports. Original workspace presentations are read only.\n\n")
                .append("Defaults: hidden slides included; duplicate titles ALL; duplicate sources ALLOW; repeated slides ALLOW; ")
                .append("missing titles SKIP with warning; remaining slides END; overwrite false. ")
                .append("Most successful examples set overwrite(true) for repeatability. FIRST/LAST mean source/slide order, not modification time.\n\n")
                .append("Title matching is exact except case. A title without a file searches only registered sources. ")
                .append("File-specific selections register the exact supplied path if needed; filenames are not searched elsewhere. ")
                .append("Directories are nonrecursive and naturally sorted. Untitled slides remain eligible as remaining or numeric slides.\n\n")
                .append("The temporary repeated-title deck is built with `.addSlides(part01, 12, 12, 3).remaining(NONE)`: ")
                .append("two genuine Model Risk titles followed by an untitled slide. Temporary fixtures are removed after execution.\n\n")
                .append("Verification compares each expected physical source/slide sequence with the plan and detailed report, ")
                .append("then reopens each saved package to check slide count, title order and hidden flags. ")
                .append("The convenience and temporary-directory examples verify the relocated saved package too. ")
                .append("This is structural/metadata verification; the runner does not launch PowerPoint or visually inspect playback.\n\n")
                .append("Reports: `scenario-report.json` contains assertions/results and SHA-256 output hashes; ")
                .append("`merge-events.jsonl` contains structured application callback events; ")
                .append("`slide-order.tsv` contains detailed merged provenance; `input-inventory.tsv` contains exact titles (escaped tabs/newlines).\n\n")
                .append("| Scenario | Result | Slides / expected error | Purpose |\n|---|---|---|---|\n");
        for (Map<String, Object> row : scenarios) {
            Object name = row.get("name");
            readme.append('|').append(row.containsKey("output") ? "[" + name + "](" + row.get("output") + ")" : name)
                    .append('|').append(row.get("status")).append('|')
                    .append(row.getOrDefault("slideCount", row.getOrDefault("expectedFailureCode", "preview only")))
                    .append('|').append(row.get("purpose")).append("|\n");
        }
        if (!failures.isEmpty()) readme.append("\nFailures: ").append(failures).append('\n');
        Files.writeString(outputDirectory.resolve("README.md"), readme, StandardCharsets.UTF_8);
    }

    /** Delete only the unique temporary directory owned by this invocation. */
    private void removeScratch() throws IOException {
        try (var paths = Files.walk(scratch)) {
            for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
        }
    }

    private record Expected(Path file, int slide) {
        Expected { file = file.toAbsolutePath().normalize(); }
    }
    @FunctionalInterface private interface CheckedAction { void run() throws Exception; }
}
